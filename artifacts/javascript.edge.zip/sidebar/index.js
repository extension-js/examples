(()=>{"use strict";var e={575:function(e,r,t){e.exports={}}},r={};function t(o){var s=r[o];if(void 0!==s)return s.exports;var n=r[o]={exports:{}};return e[o](n,n.exports,t),n.exports}t.m=e,t.k=e=>""+e+".css",t.o=(e,r)=>Object.prototype.hasOwnProperty.call(e,r),t.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},t.p="/",t.rv=()=>"1.4.10",(()=>{var e=!!(()=>{try{return browser.runtime.getURL("/")}catch(e){}})(),r=!!(()=>{try{return chrome.runtime.getURL("/")}catch(e){}})(),o=e?browser:r?chrome:"object"==typeof self&&self.addEventListener?{get runtime(){throw Error("No chrome or browser runtime found")}}:{runtime:{getURL:e=>e}};t.p="function"!=typeof importScripts&&(e||r)?o.runtime.getURL("/"):"/"})(),t.ruid="bundler=rspack@1.4.10",(()=>{let e=t.p+"assets/logo.15da7f96.png";t(575),!function(){let r=document.getElementById("root");r&&(r.innerHTML=`
    <div class="sidebar_app">
      <img
        class="sidebar_logo"
        src="${e}"
        alt="The JavaScript logo"
      />
      <h1 class="sidebar_title">Sidebar Panel</h1>
      <p class="sidebar_description">
        Learn more about creating cross-browser extensions at
        <a
          href="https://extension.js.org"
          target="_blank"
        >
          https://extension.js.org
        </a>
        .
      </p>
    </div>
  `)}()})()})();