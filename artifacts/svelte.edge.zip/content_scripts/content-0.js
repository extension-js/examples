(() => {
var __webpack_modules__ = ({
5925: 
/*!*********************************************************!*\
  !*** ../../node_modules/@rspack/core/hot/dev-server.js ***!
  \*********************************************************/
(function (module, __unused_webpack_exports, __webpack_require__) {
/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Tobias Koppers @sokra
*/
/* globals __webpack_hash__ */
if (true) {
	/** @type {undefined|string} */
	var lastHash;
	var upToDate = function upToDate() {
		return /** @type {string} */ (lastHash).indexOf(__webpack_require__.h()) >= 0;
	};
	var log = __webpack_require__(/*! ./log */ 3160);
	var check = function check() {
		module.hot
			.check(true)
			.then(function (updatedModules) {
				if (!updatedModules) {
					log(
						"warning",
						"[HMR] Cannot find update. " +
							(typeof window !== "undefined"
								? "Need to do a full reload!"
								: "Please reload manually!")
					);
					log(
						"warning",
						"[HMR] (Probably because of restarting the webpack-dev-server)"
					);
					if (typeof window !== "undefined") {
						window.location.reload();
					}
					return;
				}

				if (!upToDate()) {
					check();
				}

				__webpack_require__(/*! ./log-apply-result */ 3971)(updatedModules, updatedModules);

				if (upToDate()) {
					log("info", "[HMR] App is up to date.");
				}
			})
			.catch(function (err) {
				var status = module.hot.status();
				if (["abort", "fail"].indexOf(status) >= 0) {
					log(
						"warning",
						"[HMR] Cannot apply update. " +
							(typeof window !== "undefined"
								? "Need to do a full reload!"
								: "Please reload manually!")
					);
					log("warning", "[HMR] " + log.formatError(err));
					if (typeof window !== "undefined") {
						window.location.reload();
					}
				} else {
					log("warning", "[HMR] Update failed: " + log.formatError(err));
				}
			});
	};
	var hotEmitter = __webpack_require__(/*! ./emitter */ 360);
	hotEmitter.on("webpackHotUpdate", function (currentHash) {
		lastHash = currentHash;
		if (!upToDate() && module.hot.status() === "idle") {
			log("info", "[HMR] Checking for updates on the server...");
			check();
		}
	});
	log("info", "[HMR] Waiting for update signal from WDS...");
} else {}


}),
360: 
/*!******************************************************!*\
  !*** ../../node_modules/@rspack/core/hot/emitter.js ***!
  \******************************************************/
(function (module) {
function EventEmitter() {
	this.events = {};
}

EventEmitter.prototype.on = function (eventName, callback) {
	if (!this.events[eventName]) {
		this.events[eventName] = [];
	}
	this.events[eventName].push(callback);
};

EventEmitter.prototype.emit = function (eventName) {
	var args = Array.prototype.slice.call(arguments, 1);
	if (this.events[eventName]) {
		this.events[eventName].forEach(function (callback) {
			callback.apply(null, args);
		});
	}
};

module.exports = new EventEmitter();


}),
3971: 
/*!***************************************************************!*\
  !*** ../../node_modules/@rspack/core/hot/log-apply-result.js ***!
  \***************************************************************/
(function (module, __unused_webpack_exports, __webpack_require__) {
/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Tobias Koppers @sokra
*/

/**
 * @param {(string | number)[]} updatedModules updated modules
 * @param {(string | number)[] | null} renewedModules renewed modules
 */
module.exports = function (updatedModules, renewedModules) {
	var unacceptedModules = updatedModules.filter(function (moduleId) {
		return renewedModules && renewedModules.indexOf(moduleId) < 0;
	});
	var log = __webpack_require__(/*! ./log */ 3160);

	if (unacceptedModules.length > 0) {
		log(
			"warning",
			"[HMR] The following modules couldn't be hot updated: (They would need a full reload!)"
		);
		unacceptedModules.forEach(function (moduleId) {
			log("warning", "[HMR]  - " + moduleId);
		});
	}

	if (!renewedModules || renewedModules.length === 0) {
		log("info", "[HMR] Nothing hot updated.");
	} else {
		log("info", "[HMR] Updated modules:");
		renewedModules.forEach(function (moduleId) {
			if (typeof moduleId === "string" && moduleId.indexOf("!") !== -1) {
				var parts = moduleId.split("!");
				log.groupCollapsed("info", "[HMR]  - " + parts.pop());
				log("info", "[HMR]  - " + moduleId);
				log.groupEnd("info");
			} else {
				log("info", "[HMR]  - " + moduleId);
			}
		});
		var numberIds = renewedModules.every(function (moduleId) {
			return typeof moduleId === "number";
		});
		if (numberIds)
			log(
				"info",
				'[HMR] Consider using the optimization.moduleIds: "named" for module names.'
			);
	}
};


}),
3160: 
/*!**************************************************!*\
  !*** ../../node_modules/@rspack/core/hot/log.js ***!
  \**************************************************/
(function (module) {
/** @typedef {"info" | "warning" | "error"} LogLevel */

/** @type {LogLevel} */
var logLevel = "info";

function dummy() {}

/**
 * @param {LogLevel} level log level
 * @returns {boolean} true, if should log
 */
function shouldLog(level) {
	var shouldLog =
		(logLevel === "info" && level === "info") ||
		(["info", "warning"].indexOf(logLevel) >= 0 && level === "warning") ||
		(["info", "warning", "error"].indexOf(logLevel) >= 0 && level === "error");
	return shouldLog;
}

/**
 * @param {(msg?: string) => void} logFn log function
 * @returns {(level: LogLevel, msg?: string) => void} function that logs when log level is sufficient
 */
function logGroup(logFn) {
	return function (level, msg) {
		if (shouldLog(level)) {
			logFn(msg);
		}
	};
}

/**
 * @param {LogLevel} level log level
 * @param {string|Error} msg message
 */
module.exports = function (level, msg) {
	if (shouldLog(level)) {
		if (level === "info") {
			console.log(msg);
		} else if (level === "warning") {
			console.warn(msg);
		} else if (level === "error") {
			console.error(msg);
		}
	}
};

var group = console.group || dummy;
var groupCollapsed = console.groupCollapsed || dummy;
var groupEnd = console.groupEnd || dummy;

module.exports.group = logGroup(group);

module.exports.groupCollapsed = logGroup(groupCollapsed);

module.exports.groupEnd = logGroup(groupEnd);

/**
 * @param {LogLevel} level log level
 */
module.exports.setLogLevel = function (level) {
	logLevel = level;
};

/**
 * @param {Error} err error
 * @returns {string} formatted error
 */
module.exports.formatError = function (err) {
	var message = err.message;
	var stack = err.stack;
	if (!stack) {
		return message;
	} else if (stack.indexOf(message) < 0) {
		return message + "\n" + stack;
	} else {
		return stack;
	}
};


}),
2516: 
/*!******************************************************************************************************************************************************************************************************************!*\
  !*** ../../node_modules/@rspack/dev-server/client/index.js?protocol=ws&hostname=127.0.0.1&port=8091&pathname=%2Fws&logging=none&progress=false&overlay=false&reconnect=10&hot=true&live-reload=true + 5 modules ***!
  \******************************************************************************************************************************************************************************************************************/
(function (__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) {
"use strict";

// UNUSED EXPORTS: parseURL, createSocketURL, getCurrentScriptSource

// EXTERNAL MODULE: ../../node_modules/@rspack/core/hot/emitter.js
var emitter = __webpack_require__(360);
var emitter_default = /*#__PURE__*/__webpack_require__.n(emitter);
// EXTERNAL MODULE: ../../node_modules/@rspack/core/hot/log.js
var log = __webpack_require__(3160);
var log_default = /*#__PURE__*/__webpack_require__.n(log);
;// CONCATENATED MODULE: ../../node_modules/@rspack/dev-server/client/utils/ansiHTML.js
// Reference to https://github.com/sindresorhus/ansi-regex
var _regANSI = /(?:(?:\u001b\[)|\u009b)(?:(?:[0-9]{1,3})?(?:(?:;[0-9]{0,3})*)?[A-M|f-m])|\u001b[A-M]/;
var _defColors = {
    reset: ["fff", "000"],
    black: "000",
    red: "ff0000",
    green: "209805",
    yellow: "e8bf03",
    blue: "0000ff",
    magenta: "ff00ff",
    cyan: "00ffee",
    lightgrey: "f0f0f0",
    darkgrey: "888",
};
var _styles = {
    30: "black",
    31: "red",
    32: "green",
    33: "yellow",
    34: "blue",
    35: "magenta",
    36: "cyan",
    37: "lightgrey",
};
var _colorMode = {
    2: "rgb",
};
var _openTags = {
    1: "font-weight:bold",
    2: "opacity:0.5",
    3: "<i>",
    4: "<u>",
    8: "display:none",
    9: "<del>",
    38: function (match) {
        // color
        var mode = _colorMode[match[0]];
        if (mode === "rgb") {
            var r = match[1];
            var g = match[2];
            var b = match[3];
            match.advance(4);
            return "color: rgb(".concat(r, ",").concat(g, ",").concat(b, ")");
        }
    },
    48: function (match) {
        // background color
        var mode = _colorMode[match[0]];
        if (mode === "rgb") {
            var r = match[1];
            var g = match[2];
            var b = match[3];
            match.advance(4);
            return "background-color: rgb(".concat(r, ",").concat(g, ",").concat(b, ")");
        }
    },
};
var _openTagToCloseTag = {
    3: "23",
    4: "24",
    9: "29",
};
var _closeTags = {
    0: function (ansiCodes) {
        if (!ansiCodes)
            return "</span>";
        if (!ansiCodes.length)
            return "";
        var code;
        var ret = "";
        while ((code = ansiCodes.pop())) {
            var closeTag = _openTagToCloseTag[code];
            if (closeTag) {
                ret += _closeTags[closeTag];
                continue;
            }
            ret += "</span>";
        }
        return ret;
    },
    23: "</i>",
    24: "</u>",
    29: "</del>", // reset delete
};
for (var _i = 0, ansiHTML_a = [21, 22, 27, 28, 39, 49]; _i < ansiHTML_a.length; _i++) {
    var ansiHTML_n = ansiHTML_a[_i];
    _closeTags[ansiHTML_n] = "</span>";
}
/**
 * Normalize ';<seq>' | '<seq>' -> '<seq>'
 */
function normalizeSeq(seq) {
    if (seq === null || seq === undefined)
        return null;
    if (seq.startsWith(";")) {
        return seq.slice(1);
    }
    return seq;
}
/**
 * Converts text with ANSI color codes to HTML markup.
 */
function ansiHTML(text) {
    // Returns the text if the string has no ANSI escape code.
    if (!_regANSI.test(text)) {
        return text;
    }
    // Cache opened sequence.
    var ansiCodes = [];
    // Replace with markup.
    //@ts-ignore TS1487 error
    var ret = text.replace(/\033\[(?:[0-9]{1,3})?(?:(?:;[0-9]{0,3})*)?m/g, function (m) {
        var _a;
        var match = (_a = m.match(/(;?\d+)/g)) === null || _a === void 0 ? void 0 : _a.map(normalizeSeq);
        Object.defineProperty(match, "advance", {
            value: function (count) {
                this.splice(0, count);
            },
        });
        var rep = "";
        var seq;
        while ((seq = match[0])) {
            match.advance(1);
            rep += applySeq(seq);
        }
        return rep;
        function applySeq(seq) {
            var other = _openTags[seq];
            if (other &&
                (other =
                    typeof other === "function" ? other(match) : other)) {
                // If reset signal is encountered, we have to reset everything.
                var ret_1 = "";
                if (seq === "0") {
                    ret_1 += _closeTags[seq](ansiCodes);
                }
                // If current sequence has been opened, close it.
                if (ansiCodes.indexOf(seq) !== -1) {
                    ansiCodes.pop();
                    return "</span>";
                }
                // Open tag.
                ansiCodes.push(seq);
                return ret_1 + (other[0] === "<" ? other : "<span style=\"".concat(other, ";\">"));
            }
            var ct = _closeTags[seq];
            if (typeof ct === "function") {
                return ct(ansiCodes);
            }
            if (ct) {
                // Pop sequence
                ansiCodes.pop();
                return ct;
            }
            return "";
        }
    });
    // Make sure tags are closed.
    var l = ansiCodes.length;
    l > 0 && (ret += Array(l + 1).join("</span>"));
    return ret;
}
/**
 * Customize colors.
 * @param {Object} colors reference to _defColors
 */
ansiHTML.setColors = function (colors) {
    if (typeof colors !== "object") {
        throw new Error("`colors` parameter must be an Object.");
    }
    var _finalColors = {};
    for (var key in _defColors) {
        var hex = colors.hasOwnProperty(key) ? colors[key] : null;
        if (!hex) {
            _finalColors[key] = _defColors[key];
            continue;
        }
        if ("reset" === key) {
            if (typeof hex === "string") {
                hex = [hex];
            }
            if (!Array.isArray(hex) ||
                hex.length === 0 ||
                hex.some(function (h) { return typeof h !== "string"; })) {
                throw new Error("The value of `".concat(key, "` property must be an Array and each item could only be a hex string, e.g.: FF0000"));
            }
            var defHexColor = _defColors[key];
            if (!hex[0]) {
                hex[0] = defHexColor[0];
            }
            if (hex.length === 1 || !hex[1]) {
                hex = [hex[0]];
                hex.push(defHexColor[1]);
            }
            hex = hex.slice(0, 2);
        }
        else if (typeof hex !== "string") {
            throw new Error("The value of `".concat(key, "` property must be a hex string, e.g.: FF0000"));
        }
        _finalColors[key] = hex;
    }
    _setTags(_finalColors);
};
/**
 * Reset colors.
 */
ansiHTML.reset = function () {
    _setTags(_defColors);
};
/**
 * Expose tags, including open and close.
 * @type {Object}
 */
ansiHTML.tags = {};
if (Object.defineProperty) {
    Object.defineProperty(ansiHTML.tags, "open", {
        get: function () { return _openTags; },
    });
    Object.defineProperty(ansiHTML.tags, "close", {
        get: function () { return _closeTags; },
    });
}
else {
    ansiHTML.tags.open = _openTags;
    ansiHTML.tags.close = _closeTags;
}
function _setTags(colors) {
    // reset all
    _openTags["0"] =
        "font-weight:normal;opacity:1;color:#".concat(colors.reset[0], ";background:#").concat(colors.reset[1]);
    // inverse
    _openTags["7"] = "color:#".concat(colors.reset[1], ";background:#").concat(colors.reset[0]);
    // dark grey
    _openTags["90"] = "color:#".concat(colors.darkgrey);
    for (var code in _styles) {
        var color = _styles[code];
        var oriColor = colors[color] || "000";
        _openTags[code] = "color:#".concat(oriColor);
        var codeInt = Number.parseInt(code);
        _openTags[(codeInt + 10).toString()] = "background:#".concat(oriColor);
    }
}
ansiHTML.reset();

;// CONCATENATED MODULE: ../../node_modules/webpack-dev-server/client/overlay.js
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
// The error overlay is inspired (and mostly copied) from Create React App (https://github.com/facebookincubator/create-react-app)
// They, in turn, got inspired by webpack-hot-middleware (https://github.com/glenjamin/webpack-hot-middleware).



/**
 * @type {(input: string, position: number) => string}
 */
var getCodePoint = String.prototype.codePointAt ? function (input, position) {
  return input.codePointAt(position);
} : function (input, position) {
  return (input.charCodeAt(position) - 0xd800) * 0x400 + input.charCodeAt(position + 1) - 0xdc00 + 0x10000;
};

/**
 * @param {string} macroText
 * @param {RegExp} macroRegExp
 * @param {(input: string) => string} macroReplacer
 * @returns {string}
 */
var overlay_replaceUsingRegExp = function replaceUsingRegExp(macroText, macroRegExp, macroReplacer) {
  macroRegExp.lastIndex = 0;
  var replaceMatch = macroRegExp.exec(macroText);
  var replaceResult;
  if (replaceMatch) {
    replaceResult = "";
    var replaceLastIndex = 0;
    do {
      if (replaceLastIndex !== replaceMatch.index) {
        replaceResult += macroText.substring(replaceLastIndex, replaceMatch.index);
      }
      var replaceInput = replaceMatch[0];
      replaceResult += macroReplacer(replaceInput);
      replaceLastIndex = replaceMatch.index + replaceInput.length;
      // eslint-disable-next-line no-cond-assign
    } while (replaceMatch = macroRegExp.exec(macroText));
    if (replaceLastIndex !== macroText.length) {
      replaceResult += macroText.substring(replaceLastIndex);
    }
  } else {
    replaceResult = macroText;
  }
  return replaceResult;
};
var references = {
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&apos;",
  "&": "&amp;"
};

/**
 * @param {string} text text
 * @returns {string}
 */
function encode(text) {
  if (!text) {
    return "";
  }
  return overlay_replaceUsingRegExp(text, /[<>'"&]/g, function (input) {
    var result = references[input];
    if (!result) {
      var code = input.length > 1 ? getCodePoint(input, 0) : input.charCodeAt(0);
      result = "&#".concat(code, ";");
    }
    return result;
  });
}

/**
 * @typedef {Object} StateDefinitions
 * @property {{[event: string]: { target: string; actions?: Array<string> }}} [on]
 */

/**
 * @typedef {Object} Options
 * @property {{[state: string]: StateDefinitions}} states
 * @property {object} context;
 * @property {string} initial
 */

/**
 * @typedef {Object} Implementation
 * @property {{[actionName: string]: (ctx: object, event: any) => object}} actions
 */

/**
 * A simplified `createMachine` from `@xstate/fsm` with the following differences:
 *
 *  - the returned machine is technically a "service". No `interpret(machine).start()` is needed.
 *  - the state definition only support `on` and target must be declared with { target: 'nextState', actions: [] } explicitly.
 *  - event passed to `send` must be an object with `type` property.
 *  - actions implementation will be [assign action](https://xstate.js.org/docs/guides/context.html#assign-action) if you return any value.
 *  Do not return anything if you just want to invoke side effect.
 *
 * The goal of this custom function is to avoid installing the entire `'xstate/fsm'` package, while enabling modeling using
 * state machine. You can copy the first parameter into the editor at https://stately.ai/viz to visualize the state machine.
 *
 * @param {Options} options
 * @param {Implementation} implementation
 */
function createMachine(_ref, _ref2) {
  var states = _ref.states,
    context = _ref.context,
    initial = _ref.initial;
  var actions = _ref2.actions;
  var currentState = initial;
  var currentContext = context;
  return {
    send: function send(event) {
      var currentStateOn = states[currentState].on;
      var transitionConfig = currentStateOn && currentStateOn[event.type];
      if (transitionConfig) {
        currentState = transitionConfig.target;
        if (transitionConfig.actions) {
          transitionConfig.actions.forEach(function (actName) {
            var actionImpl = actions[actName];
            var nextContextValue = actionImpl && actionImpl(currentContext, event);
            if (nextContextValue) {
              currentContext = _objectSpread(_objectSpread({}, currentContext), nextContextValue);
            }
          });
        }
      }
    }
  };
}

/**
 * @typedef {Object} ShowOverlayData
 * @property {'warning' | 'error'} level
 * @property {Array<string  | { moduleIdentifier?: string, moduleName?: string, loc?: string, message?: string }>} messages
 * @property {'build' | 'runtime'} messageSource
 */

/**
 * @typedef {Object} CreateOverlayMachineOptions
 * @property {(data: ShowOverlayData) => void} showOverlay
 * @property {() => void} hideOverlay
 */

/**
 * @param {CreateOverlayMachineOptions} options
 */
var overlay_createOverlayMachine = function createOverlayMachine(options) {
  var hideOverlay = options.hideOverlay,
    showOverlay = options.showOverlay;
  return createMachine({
    initial: "hidden",
    context: {
      level: "error",
      messages: [],
      messageSource: "build"
    },
    states: {
      hidden: {
        on: {
          BUILD_ERROR: {
            target: "displayBuildError",
            actions: ["setMessages", "showOverlay"]
          },
          RUNTIME_ERROR: {
            target: "displayRuntimeError",
            actions: ["setMessages", "showOverlay"]
          }
        }
      },
      displayBuildError: {
        on: {
          DISMISS: {
            target: "hidden",
            actions: ["dismissMessages", "hideOverlay"]
          },
          BUILD_ERROR: {
            target: "displayBuildError",
            actions: ["appendMessages", "showOverlay"]
          }
        }
      },
      displayRuntimeError: {
        on: {
          DISMISS: {
            target: "hidden",
            actions: ["dismissMessages", "hideOverlay"]
          },
          RUNTIME_ERROR: {
            target: "displayRuntimeError",
            actions: ["appendMessages", "showOverlay"]
          },
          BUILD_ERROR: {
            target: "displayBuildError",
            actions: ["setMessages", "showOverlay"]
          }
        }
      }
    }
  }, {
    actions: {
      dismissMessages: function dismissMessages() {
        return {
          messages: [],
          level: "error",
          messageSource: "build"
        };
      },
      appendMessages: function appendMessages(context, event) {
        return {
          messages: context.messages.concat(event.messages),
          level: event.level || context.level,
          messageSource: event.type === "RUNTIME_ERROR" ? "runtime" : "build"
        };
      },
      setMessages: function setMessages(context, event) {
        return {
          messages: event.messages,
          level: event.level || context.level,
          messageSource: event.type === "RUNTIME_ERROR" ? "runtime" : "build"
        };
      },
      hideOverlay: hideOverlay,
      showOverlay: showOverlay
    }
  });
};

/**
 *
 * @param {Error} error
 */
var overlay_parseErrorToStacks = function parseErrorToStacks(error) {
  if (!error || !(error instanceof Error)) {
    throw new Error("parseErrorToStacks expects Error object");
  }
  if (typeof error.stack === "string") {
    return error.stack.split("\n").filter(function (stack) {
      return stack !== "Error: ".concat(error.message);
    });
  }
};

/**
 * @callback ErrorCallback
 * @param {ErrorEvent} error
 * @returns {void}
 */

/**
 * @param {ErrorCallback} callback
 */
var overlay_listenToRuntimeError = function listenToRuntimeError(callback) {
  window.addEventListener("error", callback);
  return function cleanup() {
    window.removeEventListener("error", callback);
  };
};

/**
 * @callback UnhandledRejectionCallback
 * @param {PromiseRejectionEvent} rejectionEvent
 * @returns {void}
 */

/**
 * @param {UnhandledRejectionCallback} callback
 */
var overlay_listenToUnhandledRejection = function listenToUnhandledRejection(callback) {
  window.addEventListener("unhandledrejection", callback);
  return function cleanup() {
    window.removeEventListener("unhandledrejection", callback);
  };
};

// Styles are inspired by `react-error-overlay`

var msgStyles = {
  error: {
    backgroundColor: "rgba(206, 17, 38, 0.1)",
    color: "#fccfcf"
  },
  warning: {
    backgroundColor: "rgba(251, 245, 180, 0.1)",
    color: "#fbf5b4"
  }
};
var iframeStyle = {
  position: "fixed",
  top: 0,
  left: 0,
  right: 0,
  bottom: 0,
  width: "100vw",
  height: "100vh",
  border: "none",
  "z-index": 9999999999
};
var containerStyle = {
  position: "fixed",
  boxSizing: "border-box",
  left: 0,
  top: 0,
  right: 0,
  bottom: 0,
  width: "100vw",
  height: "100vh",
  fontSize: "large",
  padding: "2rem 2rem 4rem 2rem",
  lineHeight: "1.2",
  whiteSpace: "pre-wrap",
  overflow: "auto",
  backgroundColor: "rgba(0, 0, 0, 0.9)",
  color: "white"
};
var headerStyle = {
  color: "#e83b46",
  fontSize: "2em",
  whiteSpace: "pre-wrap",
  fontFamily: "sans-serif",
  margin: "0 2rem 2rem 0",
  flex: "0 0 auto",
  maxHeight: "50%",
  overflow: "auto"
};
var dismissButtonStyle = {
  color: "#ffffff",
  lineHeight: "1rem",
  fontSize: "1.5rem",
  padding: "1rem",
  cursor: "pointer",
  position: "absolute",
  right: 0,
  top: 0,
  backgroundColor: "transparent",
  border: "none"
};
var msgTypeStyle = {
  color: "#e83b46",
  fontSize: "1.2em",
  marginBottom: "1rem",
  fontFamily: "sans-serif"
};
var msgTextStyle = {
  lineHeight: "1.5",
  fontSize: "1rem",
  fontFamily: "Menlo, Consolas, monospace"
};

// ANSI HTML

var overlay_colors = {
  reset: ["transparent", "transparent"],
  black: "181818",
  red: "E36049",
  green: "B3CB74",
  yellow: "FFD080",
  blue: "7CAFC2",
  magenta: "7FACCA",
  cyan: "C3C2EF",
  lightgrey: "EBE7E3",
  darkgrey: "6D7891"
};
ansiHTML.setColors(overlay_colors);

/**
 * @param {string} type
 * @param {string  | { file?: string, moduleName?: string, loc?: string, message?: string; stack?: string[] }} item
 * @returns {{ header: string, body: string }}
 */
var overlay_formatProblem = function formatProblem(type, item) {
  var header = type === "warning" ? "WARNING" : "ERROR";
  var body = "";
  if (typeof item === "string") {
    body += item;
  } else {
    var file = item.file || "";
    // eslint-disable-next-line no-nested-ternary
    var moduleName = item.moduleName ? item.moduleName.indexOf("!") !== -1 ? "".concat(item.moduleName.replace(/^(\s|\S)*!/, ""), " (").concat(item.moduleName, ")") : "".concat(item.moduleName) : "";
    var loc = item.loc;
    header += "".concat(moduleName || file ? " in ".concat(moduleName ? "".concat(moduleName).concat(file ? " (".concat(file, ")") : "") : file).concat(loc ? " ".concat(loc) : "") : "");
    body += item.message || "";
  }
  if (Array.isArray(item.stack)) {
    item.stack.forEach(function (stack) {
      if (typeof stack === "string") {
        body += "\r\n".concat(stack);
      }
    });
  }
  return {
    header: header,
    body: body
  };
};

/**
 * @typedef {Object} CreateOverlayOptions
 * @property {string | null} trustedTypesPolicyName
 * @property {boolean | (error: Error) => void} [catchRuntimeError]
 */

/**
 *
 * @param {CreateOverlayOptions} options
 */
var overlay_createOverlay = function createOverlay(options) {
  /** @type {HTMLIFrameElement | null | undefined} */
  var iframeContainerElement;
  /** @type {HTMLDivElement | null | undefined} */
  var containerElement;
  /** @type {HTMLDivElement | null | undefined} */
  var headerElement;
  /** @type {Array<(element: HTMLDivElement) => void>} */
  var onLoadQueue = [];
  /** @type {TrustedTypePolicy | undefined} */
  var overlayTrustedTypesPolicy;

  /**
   *
   * @param {HTMLElement} element
   * @param {CSSStyleDeclaration} style
   */
  function applyStyle(element, style) {
    Object.keys(style).forEach(function (prop) {
      element.style[prop] = style[prop];
    });
  }

  /**
   * @param {string | null} trustedTypesPolicyName
   */
  function createContainer(trustedTypesPolicyName) {
    // Enable Trusted Types if they are available in the current browser.
    if (window.trustedTypes) {
      overlayTrustedTypesPolicy = window.trustedTypes.createPolicy(trustedTypesPolicyName || "webpack-dev-server#overlay", {
        createHTML: function createHTML(value) {
          return value;
        }
      });
    }
    iframeContainerElement = document.createElement("iframe");
    iframeContainerElement.id = "webpack-dev-server-client-overlay";
    iframeContainerElement.src = "about:blank";
    applyStyle(iframeContainerElement, iframeStyle);
    iframeContainerElement.onload = function () {
      var contentElement = /** @type {Document} */
      (/** @type {HTMLIFrameElement} */
      iframeContainerElement.contentDocument).createElement("div");
      containerElement = /** @type {Document} */
      (/** @type {HTMLIFrameElement} */
      iframeContainerElement.contentDocument).createElement("div");
      contentElement.id = "webpack-dev-server-client-overlay-div";
      applyStyle(contentElement, containerStyle);
      headerElement = document.createElement("div");
      headerElement.innerText = "Compiled with problems:";
      applyStyle(headerElement, headerStyle);
      var closeButtonElement = document.createElement("button");
      applyStyle(closeButtonElement, dismissButtonStyle);
      closeButtonElement.innerText = "×";
      closeButtonElement.ariaLabel = "Dismiss";
      closeButtonElement.addEventListener("click", function () {
        // eslint-disable-next-line no-use-before-define
        overlayService.send({
          type: "DISMISS"
        });
      });
      contentElement.appendChild(headerElement);
      contentElement.appendChild(closeButtonElement);
      contentElement.appendChild(containerElement);

      /** @type {Document} */
      (/** @type {HTMLIFrameElement} */
      iframeContainerElement.contentDocument).body.appendChild(contentElement);
      onLoadQueue.forEach(function (onLoad) {
        onLoad(/** @type {HTMLDivElement} */contentElement);
      });
      onLoadQueue = [];

      /** @type {HTMLIFrameElement} */
      iframeContainerElement.onload = null;
    };
    document.body.appendChild(iframeContainerElement);
  }

  /**
   * @param {(element: HTMLDivElement) => void} callback
   * @param {string | null} trustedTypesPolicyName
   */
  function ensureOverlayExists(callback, trustedTypesPolicyName) {
    if (containerElement) {
      containerElement.innerHTML = overlayTrustedTypesPolicy ? overlayTrustedTypesPolicy.createHTML("") : "";
      // Everything is ready, call the callback right away.
      callback(containerElement);
      return;
    }
    onLoadQueue.push(callback);
    if (iframeContainerElement) {
      return;
    }
    createContainer(trustedTypesPolicyName);
  }

  // Successful compilation.
  function hide() {
    if (!iframeContainerElement) {
      return;
    }

    // Clean up and reset internal state.
    document.body.removeChild(iframeContainerElement);
    iframeContainerElement = null;
    containerElement = null;
  }

  // Compilation with errors (e.g. syntax error or missing modules).
  /**
   * @param {string} type
   * @param {Array<string  | { moduleIdentifier?: string, moduleName?: string, loc?: string, message?: string }>} messages
   * @param {string | null} trustedTypesPolicyName
   * @param {'build' | 'runtime'} messageSource
   */
  function show(type, messages, trustedTypesPolicyName, messageSource) {
    ensureOverlayExists(function () {
      headerElement.innerText = messageSource === "runtime" ? "Uncaught runtime errors:" : "Compiled with problems:";
      messages.forEach(function (message) {
        var entryElement = document.createElement("div");
        var msgStyle = type === "warning" ? msgStyles.warning : msgStyles.error;
        applyStyle(entryElement, _objectSpread(_objectSpread({}, msgStyle), {}, {
          padding: "1rem 1rem 1.5rem 1rem"
        }));
        var typeElement = document.createElement("div");
        var _formatProblem = overlay_formatProblem(type, message),
          header = _formatProblem.header,
          body = _formatProblem.body;
        typeElement.innerText = header;
        applyStyle(typeElement, msgTypeStyle);
        if (message.moduleIdentifier) {
          applyStyle(typeElement, {
            cursor: "pointer"
          });
          // element.dataset not supported in IE
          typeElement.setAttribute("data-can-open", true);
          typeElement.addEventListener("click", function () {
            fetch("/webpack-dev-server/open-editor?fileName=".concat(message.moduleIdentifier));
          });
        }

        // Make it look similar to our terminal.
        var text = ansiHTML(encode(body));
        var messageTextNode = document.createElement("div");
        applyStyle(messageTextNode, msgTextStyle);
        messageTextNode.innerHTML = overlayTrustedTypesPolicy ? overlayTrustedTypesPolicy.createHTML(text) : text;
        entryElement.appendChild(typeElement);
        entryElement.appendChild(messageTextNode);

        /** @type {HTMLDivElement} */
        containerElement.appendChild(entryElement);
      });
    }, trustedTypesPolicyName);
  }
  var overlayService = overlay_createOverlayMachine({
    showOverlay: function showOverlay(_ref3) {
      var _ref3$level = _ref3.level,
        level = _ref3$level === void 0 ? "error" : _ref3$level,
        messages = _ref3.messages,
        messageSource = _ref3.messageSource;
      return show(level, messages, options.trustedTypesPolicyName, messageSource);
    },
    hideOverlay: hide
  });
  if (options.catchRuntimeError) {
    /**
     * @param {Error | undefined} error
     * @param {string} fallbackMessage
     */
    var handleError = function handleError(error, fallbackMessage) {
      var errorObject = error instanceof Error ? error : new Error(error || fallbackMessage);
      var shouldDisplay = typeof options.catchRuntimeError === "function" ? options.catchRuntimeError(errorObject) : true;
      if (shouldDisplay) {
        overlayService.send({
          type: "RUNTIME_ERROR",
          messages: [{
            message: errorObject.message,
            stack: overlay_parseErrorToStacks(errorObject)
          }]
        });
      }
    };
    overlay_listenToRuntimeError(function (errorEvent) {
      // error property may be empty in older browser like IE
      var error = errorEvent.error,
        message = errorEvent.message;
      if (!error && !message) {
        return;
      }

      // if error stack indicates a React error boundary caught the error, do not show overlay.
      if (error && error.stack && error.stack.includes("invokeGuardedCallbackDev")) {
        return;
      }
      handleError(error, message);
    });
    overlay_listenToUnhandledRejection(function (promiseRejectionEvent) {
      var reason = promiseRejectionEvent.reason;
      handleError(reason, "Unknown promise rejection reason");
    });
  }
  return overlayService;
};

// EXTERNAL MODULE: ../../node_modules/webpack-dev-server/client/clients/WebSocketClient.js
var WebSocketClient = __webpack_require__(5110);
// EXTERNAL MODULE: ../../node_modules/webpack-dev-server/client/utils/log.js
var utils_log = __webpack_require__(6065);
;// CONCATENATED MODULE: ../../node_modules/webpack-dev-server/client/socket.js
/* provided dependency */ var __webpack_dev_server_client__ = __webpack_require__(/*! ../../node_modules/webpack-dev-server/client/clients/WebSocketClient.js */ 5110);
/* global __webpack_dev_server_client__ */




// this WebsocketClient is here as a default fallback, in case the client is not injected
/* eslint-disable camelcase */
var Client =
// eslint-disable-next-line no-nested-ternary
typeof __webpack_dev_server_client__ !== "undefined" ? typeof __webpack_dev_server_client__.default !== "undefined" ? __webpack_dev_server_client__.default : __webpack_dev_server_client__ : WebSocketClient["default"];
/* eslint-enable camelcase */

var retries = 0;
var maxRetries = 10;

// Initialized client is exported so external consumers can utilize the same instance
// It is mutable to enforce singleton
// eslint-disable-next-line import/no-mutable-exports
var client = null;
var timeout;

/**
 * @param {string} url
 * @param {{ [handler: string]: (data?: any, params?: any) => any }} handlers
 * @param {number} [reconnect]
 */
var socket = function initSocket(url, handlers, reconnect) {
  client = new Client(url);
  client.onOpen(function () {
    retries = 0;
    if (timeout) {
      clearTimeout(timeout);
    }
    if (typeof reconnect !== "undefined") {
      maxRetries = reconnect;
    }
  });
  client.onClose(function () {
    if (retries === 0) {
      handlers.close();
    }

    // Try to reconnect.
    client = null;

    // After 10 retries stop trying, to prevent logspam.
    if (retries < maxRetries) {
      // Exponentially increase timeout to reconnect.
      // Respectfully copied from the package `got`.
      // eslint-disable-next-line no-restricted-properties
      var retryInMs = 1000 * Math.pow(2, retries) + Math.random() * 100;
      retries += 1;
      utils_log.log.info("Trying to reconnect...");
      timeout = setTimeout(function () {
        socket(url, handlers, reconnect);
      }, retryInMs);
    }
  });
  client.onMessage(
  /**
   * @param {any} data
   */
  function (data) {
    var message = JSON.parse(data);
    if (handlers[message.type]) {
      handlers[message.type](message.data, message.params);
    }
  });
};
/* export default */ const client_socket = (socket);
;// CONCATENATED MODULE: ../../node_modules/webpack-dev-server/client/progress.js
function progress_typeof(o) { "@babel/helpers - typeof"; return progress_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, progress_typeof(o); }
function _classCallCheck(a, n) { if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function"); }
function _defineProperties(e, r) { for (var t = 0; t < r.length; t++) { var o = r[t]; o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, progress_toPropertyKey(o.key), o); } }
function _createClass(e, r, t) { return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e; }
function progress_toPropertyKey(t) { var i = progress_toPrimitive(t, "string"); return "symbol" == progress_typeof(i) ? i : i + ""; }
function progress_toPrimitive(t, r) { if ("object" != progress_typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != progress_typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function _callSuper(t, o, e) { return o = _getPrototypeOf(o), _possibleConstructorReturn(t, progress_isNativeReflectConstruct() ? Reflect.construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e)); }
function _possibleConstructorReturn(t, e) { if (e && ("object" == progress_typeof(e) || "function" == typeof e)) return e; if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined"); return _assertThisInitialized(t); }
function _assertThisInitialized(e) { if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); return e; }
function _inherits(t, e) { if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function"); t.prototype = Object.create(e && e.prototype, { constructor: { value: t, writable: !0, configurable: !0 } }), Object.defineProperty(t, "prototype", { writable: !1 }), e && _setPrototypeOf(t, e); }
function progress_wrapNativeSuper(t) { var r = "function" == typeof Map ? new Map() : void 0; return progress_wrapNativeSuper = function _wrapNativeSuper(t) { if (null === t || !_isNativeFunction(t)) return t; if ("function" != typeof t) throw new TypeError("Super expression must either be null or a function"); if (void 0 !== r) { if (r.has(t)) return r.get(t); r.set(t, Wrapper); } function Wrapper() { return _construct(t, arguments, _getPrototypeOf(this).constructor); } return Wrapper.prototype = Object.create(t.prototype, { constructor: { value: Wrapper, enumerable: !1, writable: !0, configurable: !0 } }), _setPrototypeOf(Wrapper, t); }, progress_wrapNativeSuper(t); }
function _construct(t, e, r) { if (progress_isNativeReflectConstruct()) return Reflect.construct.apply(null, arguments); var o = [null]; o.push.apply(o, e); var p = new (t.bind.apply(t, o))(); return r && _setPrototypeOf(p, r.prototype), p; }
function progress_isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); } catch (t) {} return (progress_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }
function _isNativeFunction(t) { try { return -1 !== Function.toString.call(t).indexOf("[native code]"); } catch (n) { return "function" == typeof t; } }
function _setPrototypeOf(t, e) { return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) { return t.__proto__ = e, t; }, _setPrototypeOf(t, e); }
function _getPrototypeOf(t) { return _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function (t) { return t.__proto__ || Object.getPrototypeOf(t); }, _getPrototypeOf(t); }
function _classPrivateMethodInitSpec(e, a) { _checkPrivateRedeclaration(e, a), a.add(e); }
function _checkPrivateRedeclaration(e, t) { if (t.has(e)) throw new TypeError("Cannot initialize the same private elements twice on an object"); }
function _assertClassBrand(e, t, n) { if ("function" == typeof e ? e === t : e.has(t)) return arguments.length < 3 ? t : n; throw new TypeError("Private element is not present on this object"); }
function isProgressSupported() {
  return "customElements" in self && !!HTMLElement.prototype.attachShadow;
}
function defineProgressElement() {
  var _WebpackDevServerProgress;
  if (customElements.get("wds-progress")) {
    return;
  }
  var _WebpackDevServerProgress_brand = /*#__PURE__*/new WeakSet();
  var WebpackDevServerProgress = /*#__PURE__*/function (_HTMLElement) {
    function WebpackDevServerProgress() {
      var _this;
      _classCallCheck(this, WebpackDevServerProgress);
      _this = _callSuper(this, WebpackDevServerProgress);
      _classPrivateMethodInitSpec(_this, _WebpackDevServerProgress_brand);
      _this.attachShadow({
        mode: "open"
      });
      _this.maxDashOffset = -219.99078369140625;
      _this.animationTimer = null;
      return _this;
    }
    _inherits(WebpackDevServerProgress, _HTMLElement);
    return _createClass(WebpackDevServerProgress, [{
      key: "connectedCallback",
      value: function connectedCallback() {
        _assertClassBrand(_WebpackDevServerProgress_brand, this, _reset).call(this);
      }
    }, {
      key: "attributeChangedCallback",
      value: function attributeChangedCallback(name, oldValue, newValue) {
        if (name === "progress") {
          _assertClassBrand(_WebpackDevServerProgress_brand, this, _update).call(this, Number(newValue));
        } else if (name === "type") {
          _assertClassBrand(_WebpackDevServerProgress_brand, this, _reset).call(this);
        }
      }
    }], [{
      key: "observedAttributes",
      get: function get() {
        return ["progress", "type"];
      }
    }]);
  }(/*#__PURE__*/progress_wrapNativeSuper(HTMLElement));
  _WebpackDevServerProgress = WebpackDevServerProgress;
  function _reset() {
    var _this$getAttribute, _Number;
    clearTimeout(this.animationTimer);
    this.animationTimer = null;
    var typeAttr = (_this$getAttribute = this.getAttribute("type")) === null || _this$getAttribute === void 0 ? void 0 : _this$getAttribute.toLowerCase();
    this.type = typeAttr === "circular" ? "circular" : "linear";
    var innerHTML = this.type === "circular" ? _circularTemplate.call(_WebpackDevServerProgress) : _linearTemplate.call(_WebpackDevServerProgress);
    this.shadowRoot.innerHTML = innerHTML;
    this.initialProgress = (_Number = Number(this.getAttribute("progress"))) !== null && _Number !== void 0 ? _Number : 0;
    _assertClassBrand(_WebpackDevServerProgress_brand, this, _update).call(this, this.initialProgress);
  }
  function _circularTemplate() {
    return "\n        <style>\n        :host {\n            width: 200px;\n            height: 200px;\n            position: fixed;\n            right: 5%;\n            top: 5%;\n            transition: opacity .25s ease-in-out;\n            z-index: 2147483645;\n        }\n\n        circle {\n            fill: #282d35;\n        }\n\n        path {\n            fill: rgba(0, 0, 0, 0);\n            stroke: rgb(186, 223, 172);\n            stroke-dasharray: 219.99078369140625;\n            stroke-dashoffset: -219.99078369140625;\n            stroke-width: 10;\n            transform: rotate(90deg) translate(0px, -80px);\n        }\n\n        text {\n            font-family: 'Open Sans', sans-serif;\n            font-size: 18px;\n            fill: #ffffff;\n            dominant-baseline: middle;\n            text-anchor: middle;\n        }\n\n        tspan#percent-super {\n            fill: #bdc3c7;\n            font-size: 0.45em;\n            baseline-shift: 10%;\n        }\n\n        @keyframes fade {\n            0% { opacity: 1; transform: scale(1); }\n            100% { opacity: 0; transform: scale(0); }\n        }\n\n        .disappear {\n            animation: fade 0.3s;\n            animation-fill-mode: forwards;\n            animation-delay: 0.5s;\n        }\n\n        .hidden {\n            display: none;\n        }\n        </style>\n        <svg id=\"progress\" class=\"hidden noselect\" viewBox=\"0 0 80 80\">\n        <circle cx=\"50%\" cy=\"50%\" r=\"35\"></circle>\n        <path d=\"M5,40a35,35 0 1,0 70,0a35,35 0 1,0 -70,0\"></path>\n        <text x=\"50%\" y=\"51%\">\n            <tspan id=\"percent-value\">0</tspan>\n            <tspan id=\"percent-super\">%</tspan>\n        </text>\n        </svg>\n      ";
  }
  function _linearTemplate() {
    return "\n        <style>\n        :host {\n            position: fixed;\n            top: 0;\n            left: 0;\n            height: 4px;\n            width: 100vw;\n            z-index: 2147483645;\n        }\n\n        #bar {\n            width: 0%;\n            height: 4px;\n            background-color: rgb(186, 223, 172);\n        }\n\n        @keyframes fade {\n            0% { opacity: 1; }\n            100% { opacity: 0; }\n        }\n\n        .disappear {\n            animation: fade 0.3s;\n            animation-fill-mode: forwards;\n            animation-delay: 0.5s;\n        }\n\n        .hidden {\n            display: none;\n        }\n        </style>\n        <div id=\"progress\"></div>\n        ";
  }
  function _update(percent) {
    var element = this.shadowRoot.querySelector("#progress");
    if (this.type === "circular") {
      var path = this.shadowRoot.querySelector("path");
      var value = this.shadowRoot.querySelector("#percent-value");
      var offset = (100 - percent) / 100 * this.maxDashOffset;
      path.style.strokeDashoffset = offset;
      value.textContent = percent;
    } else {
      element.style.width = "".concat(percent, "%");
    }
    if (percent >= 100) {
      _assertClassBrand(_WebpackDevServerProgress_brand, this, _hide).call(this);
    } else if (percent > 0) {
      _assertClassBrand(_WebpackDevServerProgress_brand, this, _show).call(this);
    }
  }
  function _show() {
    var element = this.shadowRoot.querySelector("#progress");
    element.classList.remove("hidden");
  }
  function _hide() {
    var _this2 = this;
    var element = this.shadowRoot.querySelector("#progress");
    if (this.type === "circular") {
      element.classList.add("disappear");
      element.addEventListener("animationend", function () {
        element.classList.add("hidden");
        _assertClassBrand(_WebpackDevServerProgress_brand, _this2, _update).call(_this2, 0);
      }, {
        once: true
      });
    } else if (this.type === "linear") {
      element.classList.add("disappear");
      this.animationTimer = setTimeout(function () {
        element.classList.remove("disappear");
        element.classList.add("hidden");
        element.style.width = "0%";
        _this2.animationTimer = null;
      }, 800);
    }
  }
  customElements.define("wds-progress", WebpackDevServerProgress);
}
;// CONCATENATED MODULE: ../../node_modules/webpack-dev-server/client/utils/sendMessage.js
/* global __resourceQuery WorkerGlobalScope */

// Send messages to the outside, so plugins can consume it.
/**
 * @param {string} type
 * @param {any} [data]
 */
function sendMsg(type, data) {
  if (typeof self !== "undefined" && (typeof WorkerGlobalScope === "undefined" || !(self instanceof WorkerGlobalScope))) {
    self.postMessage({
      type: "webpack".concat(type),
      data: data
    }, "*");
  }
}
/* export default */ const sendMessage = (sendMsg);
;// CONCATENATED MODULE: ../../node_modules/@rspack/dev-server/client/index.js?protocol=ws&hostname=127.0.0.1&port=8091&pathname=%2Fws&logging=none&progress=false&overlay=false&reconnect=10&hot=true&live-reload=true
var __resourceQuery = "?protocol=ws&hostname=127.0.0.1&port=8091&pathname=%2Fws&logging=none&progress=false&overlay=false&reconnect=10&hot=true&live-reload=true";
// @ts-nocheck
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};

/* global __resourceQuery, __webpack_hash__ */
/* Rspack dev server runtime client */
/// <reference types="webpack/module" />






/**
 * @typedef {Object} OverlayOptions
 * @property {boolean | (error: Error) => boolean} [warnings]
 * @property {boolean | (error: Error) => boolean} [errors]
 * @property {boolean | (error: Error) => boolean} [runtimeErrors]
 * @property {string} [trustedTypesPolicyName]
 */
/**
 * @typedef {Object} Options
 * @property {boolean} hot
 * @property {boolean} liveReload
 * @property {boolean} progress
 * @property {boolean | OverlayOptions} overlay
 * @property {string} [logging]
 * @property {number} [reconnect]
 */
/**
 * @typedef {Object} Status
 * @property {boolean} isUnloading
 * @property {string} currentHash
 * @property {string} [previousHash]
 */
/**
 * @param {boolean | { warnings?: boolean | string; errors?: boolean | string; runtimeErrors?: boolean | string; }} overlayOptions
 */
var decodeOverlayOptions = function (overlayOptions) {
    if (typeof overlayOptions === "object") {
        ["warnings", "errors", "runtimeErrors"].forEach(function (property) {
            if (typeof overlayOptions[property] === "string") {
                var overlayFilterFunctionString = decodeURIComponent(overlayOptions[property]);
                // eslint-disable-next-line no-new-func
                overlayOptions[property] = new Function("message", "var callback = ".concat(overlayFilterFunctionString, "\n\t\t\t\treturn callback(message)"));
            }
        });
    }
};
/**
 * @param {string} resourceQuery
 * @returns {{ [key: string]: string | boolean }}
 */
var parseURL = function (resourceQuery) {
    /** @type {{ [key: string]: string }} */
    var result = {};
    if (typeof resourceQuery === "string" && resourceQuery !== "") {
        var searchParams = resourceQuery.slice(1).split("&");
        for (var i = 0; i < searchParams.length; i++) {
            var pair = searchParams[i].split("=");
            result[pair[0]] = decodeURIComponent(pair[1]);
        }
    }
    else {
        // Else, get the url from the <script> this file was called with.
        var scriptSource = getCurrentScriptSource();
        var scriptSourceURL = void 0;
        try {
            // The placeholder `baseURL` with `window.location.href`,
            // is to allow parsing of path-relative or protocol-relative URLs,
            // and will have no effect if `scriptSource` is a fully valid URL.
            scriptSourceURL = new URL(scriptSource, self.location.href);
        }
        catch (error) {
            // URL parsing failed, do nothing.
            // We will still proceed to see if we can recover using `resourceQuery`
        }
        if (scriptSourceURL) {
            result = scriptSourceURL;
            result.fromCurrentScript = true;
        }
    }
    return result;
};
/**
 * @type {Status}
 */
var clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_status = {
    isUnloading: false,
    // eslint-disable-next-line camelcase
    currentHash: __webpack_require__.h(),
};
/**
 * @returns {string}
 */
var getCurrentScriptSource = function () {
    // `document.currentScript` is the most accurate way to find the current script,
    // but is not supported in all browsers.
    if (document.currentScript) {
        return document.currentScript.getAttribute("src");
    }
    // Fallback to getting all scripts running in the document.
    var scriptElements = document.scripts || [];
    var scriptElementsWithSrc = Array.prototype.filter.call(scriptElements, function (element) { return element.getAttribute("src"); });
    if (scriptElementsWithSrc.length > 0) {
        var currentScript = scriptElementsWithSrc[scriptElementsWithSrc.length - 1];
        return currentScript.getAttribute("src");
    }
    // Fail as there was no script to use.
    throw new Error("[webpack-dev-server] Failed to get current script source.");
};
var parsedResourceQuery = parseURL(__resourceQuery);
var enabledFeatures = {
    "Hot Module Replacement": false,
    "Live Reloading": false,
    Progress: false,
    Overlay: false,
};
/** @type {Options} */
var clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options = {
    hot: false,
    liveReload: false,
    progress: false,
    overlay: false,
};
if (parsedResourceQuery.hot === "true") {
    clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.hot = true;
    enabledFeatures["Hot Module Replacement"] = true;
}
if (parsedResourceQuery["live-reload"] === "true") {
    clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.liveReload = true;
    enabledFeatures["Live Reloading"] = true;
}
if (parsedResourceQuery.progress === "true") {
    clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.progress = true;
    enabledFeatures.Progress = true;
}
if (parsedResourceQuery.overlay) {
    try {
        clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.overlay = JSON.parse(parsedResourceQuery.overlay);
    }
    catch (e) {
        utils_log.log.error("Error parsing overlay options from resource query:", e);
    }
    // Fill in default "true" params for partially-specified objects.
    if (typeof clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.overlay === "object") {
        clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.overlay = __assign({ errors: true, warnings: true, runtimeErrors: true }, clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.overlay);
        decodeOverlayOptions(clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.overlay);
    }
    enabledFeatures.Overlay = clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.overlay !== false;
}
if (parsedResourceQuery.logging) {
    clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.logging = parsedResourceQuery.logging;
}
if (typeof parsedResourceQuery.reconnect !== "undefined") {
    clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.reconnect = Number(parsedResourceQuery.reconnect);
}
/**
 * @param {string} level
 */
var setAllLogLevel = function (level) {
    // This is needed because the HMR logger operate separately from dev server logger
    log_default().setLogLevel(level === "verbose" || level === "log" ? "info" : level);
    (0,utils_log.setLogLevel)(level);
};
if (clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.logging) {
    setAllLogLevel(clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.logging);
}
var logEnabledFeatures = function (features) {
    var listEnabledFeatures = Object.keys(features);
    if (!features || listEnabledFeatures.length === 0) {
        return;
    }
    var logString = "Server started:";
    // Server started: Hot Module Replacement enabled, Live Reloading enabled, Overlay disabled.
    for (var i = 0; i < listEnabledFeatures.length; i++) {
        var key = listEnabledFeatures[i];
        logString += " ".concat(key, " ").concat(features[key] ? "enabled" : "disabled", ",");
    }
    // replace last comma with a period
    logString = logString.slice(0, -1).concat(".");
    utils_log.log.info(logString);
};
logEnabledFeatures(enabledFeatures);
self.addEventListener("beforeunload", function () {
    clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_status.isUnloading = true;
});
var overlay = typeof window !== "undefined"
    ? overlay_createOverlay(typeof clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.overlay === "object"
        ? {
            trustedTypesPolicyName: clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.overlay.trustedTypesPolicyName,
            catchRuntimeError: clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.overlay.runtimeErrors,
        }
        : {
            trustedTypesPolicyName: false,
            catchRuntimeError: clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.overlay,
        })
    : { send: function () { } };
/**
 * @param {Options} options
 * @param {Status} currentStatus
 */
var reloadApp = function (_a, currentStatus) {
    var hot = _a.hot, liveReload = _a.liveReload;
    if (currentStatus.isUnloading) {
        return;
    }
    var currentHash = currentStatus.currentHash, previousHash = currentStatus.previousHash;
    var isInitial = currentHash.indexOf(/** @type {string} */ (previousHash)) >= 0;
    if (isInitial) {
        return;
    }
    /**
     * @param {Window} rootWindow
     * @param {number} intervalId
     */
    function applyReload(rootWindow, intervalId) {
        clearInterval(intervalId);
        utils_log.log.info("App updated. Reloading...");
        rootWindow.location.reload();
    }
    var search = self.location.search.toLowerCase();
    var allowToHot = search.indexOf("webpack-dev-server-hot=false") === -1;
    var allowToLiveReload = search.indexOf("webpack-dev-server-live-reload=false") === -1;
    if (hot && allowToHot) {
        utils_log.log.info("App hot update...");
        emitter_default().emit("webpackHotUpdate", currentStatus.currentHash);
        if (typeof self !== "undefined" && self.window) {
            // broadcast update to window
            self.postMessage("webpackHotUpdate".concat(currentStatus.currentHash), "*");
        }
    }
    // allow refreshing the page only if liveReload isn't disabled
    else if (liveReload && allowToLiveReload) {
        var rootWindow_1 = self;
        // use parent window for reload (in case we're in an iframe with no valid src)
        var intervalId_1 = self.setInterval(function () {
            if (rootWindow_1.location.protocol !== "about:") {
                // reload immediately if protocol is valid
                applyReload(rootWindow_1, intervalId_1);
            }
            else {
                rootWindow_1 = rootWindow_1.parent;
                if (rootWindow_1.parent === rootWindow_1) {
                    // if parent equals current window we've reached the root which would continue forever, so trigger a reload anyways
                    applyReload(rootWindow_1, intervalId_1);
                }
            }
        });
    }
};
var ansiRegex = new RegExp([
    "[\\u001B\\u009B][[\\]()#;?]*(?:(?:(?:(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]+)*|[a-zA-Z\\d]+(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]*)*)?\\u0007)",
    "(?:(?:\\d{1,4}(?:;\\d{0,4})*)?[\\dA-PR-TZcf-nq-uy=><~]))",
].join("|"), "g");
/**
 *
 * Strip [ANSI escape codes](https://en.wikipedia.org/wiki/ANSI_escape_code) from a string.
 * Adapted from code originally released by Sindre Sorhus
 * Licensed the MIT License
 *
 * @param {string} string
 * @return {string}
 */
var stripAnsi = function (string) {
    if (typeof string !== "string") {
        throw new TypeError("Expected a `string`, got `".concat(typeof string, "`"));
    }
    return string.replace(ansiRegex, "");
};
var onSocketMessage = {
    hot: function () {
        if (parsedResourceQuery.hot === "false") {
            return;
        }
        clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.hot = true;
    },
    liveReload: function () {
        if (parsedResourceQuery["live-reload"] === "false") {
            return;
        }
        clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.liveReload = true;
    },
    invalid: function () {
        utils_log.log.info("App updated. Recompiling...");
        // Fixes #1042. overlay doesn't clear if errors are fixed but warnings remain.
        if (clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.overlay) {
            overlay.send({ type: "DISMISS" });
        }
        sendMessage("Invalid");
    },
    /**
     * @param {string | undefined} hash
     */
    hash: function hash(_hash) {
        if (!_hash) {
            return;
        }
        clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_status.previousHash = clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_status.currentHash;
        clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_status.currentHash = _hash;
    },
    logging: setAllLogLevel,
    /**
     * @param {boolean} value
     */
    overlay: function (value) {
        if (typeof document === "undefined") {
            return;
        }
        clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.overlay = value;
        decodeOverlayOptions(clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.overlay);
    },
    /**
     * @param {number} value
     */
    reconnect: function (value) {
        if (parsedResourceQuery.reconnect === "false") {
            return;
        }
        clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.reconnect = value;
    },
    /**
     * @param {boolean} value
     */
    progress: function (value) {
        clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.progress = value;
    },
    /**
     * @param {{ pluginName?: string, percent: number, msg: string }} data
     */
    "progress-update": function progressUpdate(data) {
        if (clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.progress) {
            utils_log.log.info("".concat(data.pluginName ? "[".concat(data.pluginName, "] ") : "").concat(data.percent, "% - ").concat(data.msg, "."));
        }
        if (isProgressSupported()) {
            if (typeof clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.progress === "string") {
                var progress = document.querySelector("wds-progress");
                if (!progress) {
                    defineProgressElement();
                    progress = document.createElement("wds-progress");
                    document.body.appendChild(progress);
                }
                progress.setAttribute("progress", data.percent);
                progress.setAttribute("type", clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.progress);
            }
        }
        sendMessage("Progress", data);
    },
    "still-ok": function stillOk() {
        utils_log.log.info("Nothing changed.");
        if (clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.overlay) {
            overlay.send({ type: "DISMISS" });
        }
        sendMessage("StillOk");
    },
    ok: function () {
        sendMessage("Ok");
        if (clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.overlay) {
            overlay.send({ type: "DISMISS" });
        }
        reloadApp(clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options, clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_status);
    },
    /**
     * @param {string} file
     */
    "static-changed": function staticChanged(file) {
        utils_log.log.info("".concat(file ? "\"".concat(file, "\"") : "Content", " from static directory was changed. Reloading..."));
        self.location.reload();
    },
    /**
     * @param {Error[]} warnings
     * @param {any} params
     */
    warnings: function (warnings, params) {
        utils_log.log.warn("Warnings while compiling.");
        var printableWarnings = warnings.map(function (error) {
            var _a = overlay_formatProblem("warning", error), header = _a.header, body = _a.body;
            return "".concat(header, "\n").concat(stripAnsi(body));
        });
        sendMessage("Warnings", printableWarnings);
        for (var i = 0; i < printableWarnings.length; i++) {
            utils_log.log.warn(printableWarnings[i]);
        }
        var overlayWarningsSetting = typeof clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.overlay === "boolean"
            ? clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.overlay
            : clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.overlay && clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.overlay.warnings;
        if (overlayWarningsSetting) {
            var warningsToDisplay = typeof overlayWarningsSetting === "function"
                ? warnings.filter(overlayWarningsSetting)
                : warnings;
            if (warningsToDisplay.length) {
                overlay.send({
                    type: "BUILD_ERROR",
                    level: "warning",
                    messages: warnings,
                });
            }
        }
        if (params && params.preventReloading) {
            return;
        }
        reloadApp(clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options, clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_status);
    },
    /**
     * @param {Error[]} errors
     */
    errors: function (errors) {
        utils_log.log.error("Errors while compiling. Reload prevented.");
        var printableErrors = errors.map(function (error) {
            var _a = overlay_formatProblem("error", error), header = _a.header, body = _a.body;
            return "".concat(header, "\n").concat(stripAnsi(body));
        });
        sendMessage("Errors", printableErrors);
        for (var i = 0; i < printableErrors.length; i++) {
            utils_log.log.error(printableErrors[i]);
        }
        var overlayErrorsSettings = typeof clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.overlay === "boolean"
            ? clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.overlay
            : clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.overlay && clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.overlay.errors;
        if (overlayErrorsSettings) {
            var errorsToDisplay = typeof overlayErrorsSettings === "function"
                ? errors.filter(overlayErrorsSettings)
                : errors;
            if (errorsToDisplay.length) {
                overlay.send({
                    type: "BUILD_ERROR",
                    level: "error",
                    messages: errors,
                });
            }
        }
    },
    /**
     * @param {Error} error
     */
    error: function (error) {
        utils_log.log.error(error);
    },
    close: function () {
        utils_log.log.info("Disconnected!");
        if (clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.overlay) {
            overlay.send({ type: "DISMISS" });
        }
        sendMessage("Close");
    },
};
/**
 * @param {{ protocol?: string, auth?: string, hostname?: string, port?: string, pathname?: string, search?: string, hash?: string, slashes?: boolean }} objURL
 * @returns {string}
 */
var formatURL = function (objURL) {
    var protocol = objURL.protocol || "";
    if (protocol && protocol.substr(-1) !== ":") {
        protocol += ":";
    }
    var auth = objURL.auth || "";
    if (auth) {
        auth = encodeURIComponent(auth);
        auth = auth.replace(/%3A/i, ":");
        auth += "@";
    }
    var host = "";
    if (objURL.hostname) {
        host =
            auth +
                (objURL.hostname.indexOf(":") === -1
                    ? objURL.hostname
                    : "[".concat(objURL.hostname, "]"));
        if (objURL.port) {
            host += ":".concat(objURL.port);
        }
    }
    var pathname = objURL.pathname || "";
    if (objURL.slashes) {
        host = "//".concat(host || "");
        if (pathname && pathname.charAt(0) !== "/") {
            pathname = "/".concat(pathname);
        }
    }
    else if (!host) {
        host = "";
    }
    var search = objURL.search || "";
    if (search && search.charAt(0) !== "?") {
        search = "?".concat(search);
    }
    var hash = objURL.hash || "";
    if (hash && hash.charAt(0) !== "#") {
        hash = "#".concat(hash);
    }
    pathname = pathname.replace(/[?#]/g, 
    /**
     * @param {string} match
     * @returns {string}
     */
    function (match) { return encodeURIComponent(match); });
    search = search.replace("#", "%23");
    return "".concat(protocol).concat(host).concat(pathname).concat(search).concat(hash);
};
/**
 * @param {URL & { fromCurrentScript?: boolean }} parsedURL
 * @returns {string}
 */
var createSocketURL = function (parsedURL) {
    var hostname = parsedURL.hostname;
    // Node.js module parses it as `::`
    // `new URL(urlString, [baseURLString])` parses it as '[::]'
    var isInAddrAny = hostname === "0.0.0.0" || hostname === "::" || hostname === "[::]";
    // why do we need this check?
    // hostname n/a for file protocol (example, when using electron, ionic)
    // see: https://github.com/webpack/webpack-dev-server/pull/384
    if (isInAddrAny &&
        self.location.hostname &&
        self.location.protocol.indexOf("http") === 0) {
        hostname = self.location.hostname;
    }
    var socketURLProtocol = parsedURL.protocol || self.location.protocol;
    // When https is used in the app, secure web sockets are always necessary because the browser doesn't accept non-secure web sockets.
    if (socketURLProtocol === "auto:" ||
        (hostname && isInAddrAny && self.location.protocol === "https:")) {
        socketURLProtocol = self.location.protocol;
    }
    socketURLProtocol = socketURLProtocol.replace(/^(?:http|.+-extension|file)/i, "ws");
    var socketURLAuth = "";
    // `new URL(urlString, [baseURLstring])` doesn't have `auth` property
    // Parse authentication credentials in case we need them
    if (parsedURL.username) {
        socketURLAuth = parsedURL.username;
        // Since HTTP basic authentication does not allow empty username,
        // we only include password if the username is not empty.
        if (parsedURL.password) {
            // Result: <username>:<password>
            socketURLAuth = socketURLAuth.concat(":", parsedURL.password);
        }
    }
    // In case the host is a raw IPv6 address, it can be enclosed in
    // the brackets as the brackets are needed in the final URL string.
    // Need to remove those as url.format blindly adds its own set of brackets
    // if the host string contains colons. That would lead to non-working
    // double brackets (e.g. [[::]]) host
    //
    // All of these web socket url params are optionally passed in through resourceQuery,
    // so we need to fall back to the default if they are not provided
    var socketURLHostname = (hostname ||
        self.location.hostname ||
        "localhost").replace(/^\[(.*)\]$/, "$1");
    var socketURLPort = parsedURL.port;
    if (!socketURLPort || socketURLPort === "0") {
        socketURLPort = self.location.port;
    }
    // If path is provided it'll be passed in via the resourceQuery as a
    // query param so it has to be parsed out of the querystring in order for the
    // client to open the socket to the correct location.
    var socketURLPathname = "/ws";
    if (parsedURL.pathname && !parsedURL.fromCurrentScript) {
        socketURLPathname = parsedURL.pathname;
    }
    return formatURL({
        protocol: socketURLProtocol,
        auth: socketURLAuth,
        hostname: socketURLHostname,
        port: socketURLPort,
        pathname: socketURLPathname,
        slashes: true,
    });
};
var socketURL = createSocketURL(parsedResourceQuery);
client_socket(socketURL, onSocketMessage, clientprotocol_ws_hostname_127_0_0_1_port_8091_pathname_2Fws_logging_none_progress_false_overlay_false_reconnect_10_hot_true_live_reload_true_options.reconnect);



}),
9380: 
/*!***************************************************!*\
  !*** ./src/content/ContentApp.svelte + 4 modules ***!
  \***************************************************/
(function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ContentApp)
});

;// CONCATENATED MODULE: ../../node_modules/svelte/src/version.js
// generated during release, do not modify

/**
 * The current version, as set in package.json.
 * @type {string}
 */
const VERSION = '5.43.8';
const PUBLIC_VERSION = '5';

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/disclose-version.js


if (typeof window !== 'undefined') {
	// @ts-expect-error
	((window.__svelte ??= {}).v ??= new Set()).add(PUBLIC_VERSION);
}

// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/flags/index.js
var flags = __webpack_require__(9987);
;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/flags/legacy.js


(0,flags.enable_legacy_mode_flag)();

// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/index.js + 53 modules
var client = __webpack_require__(3781);
;// CONCATENATED MODULE: ./src/images/logo.png
const logo_namespaceObject = __webpack_require__.p + "assets/logo.png";
;// CONCATENATED MODULE: ./src/content/ContentApp.svelte
/* provided dependency */ var browser = __webpack_require__(/*! webextension-polyfill */ 222);



ContentApp[client.FILENAME] = 'templates/svelte/src/content/ContentApp.svelte';




var root = client.add_locations(client.from_html(`<button type="button" class="content_pill" aria-label="Open sidebar"><img class="content_pill_logo" alt="" aria-hidden="true"/> <span class="content_pill_text">Open sidebar</span></button>`), ContentApp[client.FILENAME], [[13, 0, [[19, 2], [20, 2]]]]);

function ContentApp($$anchor, $$props) {
	client.check_target(new.target);
	client.push($$props, false, ContentApp);

	function openSidebar() {
		if (client.strict_equals("edge", 'firefox')) {
			browser.runtime.sendMessage({ type: 'openSidebar' });
		} else {
			chrome.runtime.sendMessage({ type: 'openSidebar' });
		}
	}

	var $$exports = { ...client.legacy_api() };

	client.init();

	var button = root();
	var img = client.child(button);

	client.next(2);
	client.reset(button);
	client.template_effect(() => client.set_attribute(img, 'src', logo_namespaceObject));
	client.event('click', button, openSidebar);
	client.append($$anchor, button);

	return client.pop($$exports);
}

}),
222: 
/*!*************************************************************************!*\
  !*** ../../node_modules/webextension-polyfill/dist/browser-polyfill.js ***!
  \*************************************************************************/
(function (module, __unused_webpack_exports, __webpack_require__) {
/* module decorator */ module = __webpack_require__.nmd(module);
(function (global, factory) {
  if (typeof define === "function" && define.amd) {
    define("webextension-polyfill", ["module"], factory);
  } else if (true) {
    factory(module);
  } else { var mod }
})(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : this, function (module) {
  /* webextension-polyfill - v0.12.0 - Tue May 14 2024 18:01:29 */
  /* -*- Mode: indent-tabs-mode: nil; js-indent-level: 2 -*- */
  /* vim: set sts=2 sw=2 et tw=80: */
  /* This Source Code Form is subject to the terms of the Mozilla Public
   * License, v. 2.0. If a copy of the MPL was not distributed with this
   * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
  "use strict";

  if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
    throw new Error("This script should only be loaded in a browser extension.");
  }
  if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
    const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";

    // Wrapping the bulk of this polyfill in a one-time-use function is a minor
    // optimization for Firefox. Since Spidermonkey does not fully parse the
    // contents of a function until the first time it's called, and since it will
    // never actually need to be called, this allows the polyfill to be included
    // in Firefox nearly for free.
    const wrapAPIs = extensionAPIs => {
      // NOTE: apiMetadata is associated to the content of the api-metadata.json file
      // at build time by replacing the following "include" with the content of the
      // JSON file.
      const apiMetadata = {
        "alarms": {
          "clear": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "clearAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "get": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "bookmarks": {
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getChildren": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getRecent": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getSubTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTree": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "browserAction": {
          "disable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "enable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "getBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getBadgeText": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "openPopup": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setBadgeText": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "browsingData": {
          "remove": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "removeCache": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCookies": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeDownloads": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFormData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeHistory": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeLocalStorage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePasswords": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePluginData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "settings": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "commands": {
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "contextMenus": {
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "cookies": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAllCookieStores": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "set": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "devtools": {
          "inspectedWindow": {
            "eval": {
              "minArgs": 1,
              "maxArgs": 2,
              "singleCallbackArg": false
            }
          },
          "panels": {
            "create": {
              "minArgs": 3,
              "maxArgs": 3,
              "singleCallbackArg": true
            },
            "elements": {
              "createSidebarPane": {
                "minArgs": 1,
                "maxArgs": 1
              }
            }
          }
        },
        "downloads": {
          "cancel": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "download": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "erase": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFileIcon": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "open": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "pause": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFile": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "resume": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "extension": {
          "isAllowedFileSchemeAccess": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "isAllowedIncognitoAccess": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "history": {
          "addUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "deleteRange": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getVisits": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "i18n": {
          "detectLanguage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAcceptLanguages": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "identity": {
          "launchWebAuthFlow": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "idle": {
          "queryState": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "management": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getSelf": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setEnabled": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "uninstallSelf": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "notifications": {
          "clear": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPermissionLevel": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "pageAction": {
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "hide": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "permissions": {
          "contains": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "request": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "runtime": {
          "getBackgroundPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPlatformInfo": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "openOptionsPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "requestUpdateCheck": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "sendMessage": {
            "minArgs": 1,
            "maxArgs": 3
          },
          "sendNativeMessage": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "setUninstallURL": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "sessions": {
          "getDevices": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getRecentlyClosed": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "restore": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "storage": {
          "local": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          },
          "managed": {
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            }
          },
          "sync": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          }
        },
        "tabs": {
          "captureVisibleTab": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "detectLanguage": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "discard": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "duplicate": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "executeScript": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getZoom": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getZoomSettings": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goBack": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goForward": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "highlight": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "insertCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "query": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "reload": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "sendMessage": {
            "minArgs": 2,
            "maxArgs": 3
          },
          "setZoom": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "setZoomSettings": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "update": {
            "minArgs": 1,
            "maxArgs": 2
          }
        },
        "topSites": {
          "get": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "webNavigation": {
          "getAllFrames": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFrame": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "webRequest": {
          "handlerBehaviorChanged": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "windows": {
          "create": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getLastFocused": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        }
      };
      if (Object.keys(apiMetadata).length === 0) {
        throw new Error("api-metadata.json has not been included in browser-polyfill");
      }

      /**
       * A WeakMap subclass which creates and stores a value for any key which does
       * not exist when accessed, but behaves exactly as an ordinary WeakMap
       * otherwise.
       *
       * @param {function} createItem
       *        A function which will be called in order to create the value for any
       *        key which does not exist, the first time it is accessed. The
       *        function receives, as its only argument, the key being created.
       */
      class DefaultWeakMap extends WeakMap {
        constructor(createItem, items = undefined) {
          super(items);
          this.createItem = createItem;
        }
        get(key) {
          if (!this.has(key)) {
            this.set(key, this.createItem(key));
          }
          return super.get(key);
        }
      }

      /**
       * Returns true if the given object is an object with a `then` method, and can
       * therefore be assumed to behave as a Promise.
       *
       * @param {*} value The value to test.
       * @returns {boolean} True if the value is thenable.
       */
      const isThenable = value => {
        return value && typeof value === "object" && typeof value.then === "function";
      };

      /**
       * Creates and returns a function which, when called, will resolve or reject
       * the given promise based on how it is called:
       *
       * - If, when called, `chrome.runtime.lastError` contains a non-null object,
       *   the promise is rejected with that value.
       * - If the function is called with exactly one argument, the promise is
       *   resolved to that value.
       * - Otherwise, the promise is resolved to an array containing all of the
       *   function's arguments.
       *
       * @param {object} promise
       *        An object containing the resolution and rejection functions of a
       *        promise.
       * @param {function} promise.resolve
       *        The promise's resolution function.
       * @param {function} promise.reject
       *        The promise's rejection function.
       * @param {object} metadata
       *        Metadata about the wrapped method which has created the callback.
       * @param {boolean} metadata.singleCallbackArg
       *        Whether or not the promise is resolved with only the first
       *        argument of the callback, alternatively an array of all the
       *        callback arguments is resolved. By default, if the callback
       *        function is invoked with only a single argument, that will be
       *        resolved to the promise, while all arguments will be resolved as
       *        an array if multiple are given.
       *
       * @returns {function}
       *        The generated callback function.
       */
      const makeCallback = (promise, metadata) => {
        return (...callbackArgs) => {
          if (extensionAPIs.runtime.lastError) {
            promise.reject(new Error(extensionAPIs.runtime.lastError.message));
          } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
            promise.resolve(callbackArgs[0]);
          } else {
            promise.resolve(callbackArgs);
          }
        };
      };
      const pluralizeArguments = numArgs => numArgs == 1 ? "argument" : "arguments";

      /**
       * Creates a wrapper function for a method with the given name and metadata.
       *
       * @param {string} name
       *        The name of the method which is being wrapped.
       * @param {object} metadata
       *        Metadata about the method being wrapped.
       * @param {integer} metadata.minArgs
       *        The minimum number of arguments which must be passed to the
       *        function. If called with fewer than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {integer} metadata.maxArgs
       *        The maximum number of arguments which may be passed to the
       *        function. If called with more than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {boolean} metadata.singleCallbackArg
       *        Whether or not the promise is resolved with only the first
       *        argument of the callback, alternatively an array of all the
       *        callback arguments is resolved. By default, if the callback
       *        function is invoked with only a single argument, that will be
       *        resolved to the promise, while all arguments will be resolved as
       *        an array if multiple are given.
       *
       * @returns {function(object, ...*)}
       *       The generated wrapper function.
       */
      const wrapAsyncFunction = (name, metadata) => {
        return function asyncFunctionWrapper(target, ...args) {
          if (args.length < metadata.minArgs) {
            throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
          }
          if (args.length > metadata.maxArgs) {
            throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
          }
          return new Promise((resolve, reject) => {
            if (metadata.fallbackToNoCallback) {
              // This API method has currently no callback on Chrome, but it return a promise on Firefox,
              // and so the polyfill will try to call it with a callback first, and it will fallback
              // to not passing the callback if the first call fails.
              try {
                target[name](...args, makeCallback({
                  resolve,
                  reject
                }, metadata));
              } catch (cbError) {
                console.warn(`${name} API method doesn't seem to support the callback parameter, ` + "falling back to call it without a callback: ", cbError);
                target[name](...args);

                // Update the API method metadata, so that the next API calls will not try to
                // use the unsupported callback anymore.
                metadata.fallbackToNoCallback = false;
                metadata.noCallback = true;
                resolve();
              }
            } else if (metadata.noCallback) {
              target[name](...args);
              resolve();
            } else {
              target[name](...args, makeCallback({
                resolve,
                reject
              }, metadata));
            }
          });
        };
      };

      /**
       * Wraps an existing method of the target object, so that calls to it are
       * intercepted by the given wrapper function. The wrapper function receives,
       * as its first argument, the original `target` object, followed by each of
       * the arguments passed to the original method.
       *
       * @param {object} target
       *        The original target object that the wrapped method belongs to.
       * @param {function} method
       *        The method being wrapped. This is used as the target of the Proxy
       *        object which is created to wrap the method.
       * @param {function} wrapper
       *        The wrapper function which is called in place of a direct invocation
       *        of the wrapped method.
       *
       * @returns {Proxy<function>}
       *        A Proxy object for the given method, which invokes the given wrapper
       *        method in its place.
       */
      const wrapMethod = (target, method, wrapper) => {
        return new Proxy(method, {
          apply(targetMethod, thisObj, args) {
            return wrapper.call(thisObj, target, ...args);
          }
        });
      };
      let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);

      /**
       * Wraps an object in a Proxy which intercepts and wraps certain methods
       * based on the given `wrappers` and `metadata` objects.
       *
       * @param {object} target
       *        The target object to wrap.
       *
       * @param {object} [wrappers = {}]
       *        An object tree containing wrapper functions for special cases. Any
       *        function present in this object tree is called in place of the
       *        method in the same location in the `target` object tree. These
       *        wrapper methods are invoked as described in {@see wrapMethod}.
       *
       * @param {object} [metadata = {}]
       *        An object tree containing metadata used to automatically generate
       *        Promise-based wrapper functions for asynchronous. Any function in
       *        the `target` object tree which has a corresponding metadata object
       *        in the same location in the `metadata` tree is replaced with an
       *        automatically-generated wrapper function, as described in
       *        {@see wrapAsyncFunction}
       *
       * @returns {Proxy<object>}
       */
      const wrapObject = (target, wrappers = {}, metadata = {}) => {
        let cache = Object.create(null);
        let handlers = {
          has(proxyTarget, prop) {
            return prop in target || prop in cache;
          },
          get(proxyTarget, prop, receiver) {
            if (prop in cache) {
              return cache[prop];
            }
            if (!(prop in target)) {
              return undefined;
            }
            let value = target[prop];
            if (typeof value === "function") {
              // This is a method on the underlying object. Check if we need to do
              // any wrapping.

              if (typeof wrappers[prop] === "function") {
                // We have a special-case wrapper for this method.
                value = wrapMethod(target, target[prop], wrappers[prop]);
              } else if (hasOwnProperty(metadata, prop)) {
                // This is an async method that we have metadata for. Create a
                // Promise wrapper for it.
                let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                value = wrapMethod(target, target[prop], wrapper);
              } else {
                // This is a method that we don't know or care about. Return the
                // original method, bound to the underlying object.
                value = value.bind(target);
              }
            } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
              // This is an object that we need to do some wrapping for the children
              // of. Create a sub-object wrapper for it with the appropriate child
              // metadata.
              value = wrapObject(value, wrappers[prop], metadata[prop]);
            } else if (hasOwnProperty(metadata, "*")) {
              // Wrap all properties in * namespace.
              value = wrapObject(value, wrappers[prop], metadata["*"]);
            } else {
              // We don't need to do any wrapping for this property,
              // so just forward all access to the underlying object.
              Object.defineProperty(cache, prop, {
                configurable: true,
                enumerable: true,
                get() {
                  return target[prop];
                },
                set(value) {
                  target[prop] = value;
                }
              });
              return value;
            }
            cache[prop] = value;
            return value;
          },
          set(proxyTarget, prop, value, receiver) {
            if (prop in cache) {
              cache[prop] = value;
            } else {
              target[prop] = value;
            }
            return true;
          },
          defineProperty(proxyTarget, prop, desc) {
            return Reflect.defineProperty(cache, prop, desc);
          },
          deleteProperty(proxyTarget, prop) {
            return Reflect.deleteProperty(cache, prop);
          }
        };

        // Per contract of the Proxy API, the "get" proxy handler must return the
        // original value of the target if that value is declared read-only and
        // non-configurable. For this reason, we create an object with the
        // prototype set to `target` instead of using `target` directly.
        // Otherwise we cannot return a custom object for APIs that
        // are declared read-only and non-configurable, such as `chrome.devtools`.
        //
        // The proxy handlers themselves will still use the original `target`
        // instead of the `proxyTarget`, so that the methods and properties are
        // dereferenced via the original targets.
        let proxyTarget = Object.create(target);
        return new Proxy(proxyTarget, handlers);
      };

      /**
       * Creates a set of wrapper functions for an event object, which handles
       * wrapping of listener functions that those messages are passed.
       *
       * A single wrapper is created for each listener function, and stored in a
       * map. Subsequent calls to `addListener`, `hasListener`, or `removeListener`
       * retrieve the original wrapper, so that  attempts to remove a
       * previously-added listener work as expected.
       *
       * @param {DefaultWeakMap<function, function>} wrapperMap
       *        A DefaultWeakMap object which will create the appropriate wrapper
       *        for a given listener function when one does not exist, and retrieve
       *        an existing one when it does.
       *
       * @returns {object}
       */
      const wrapEvent = wrapperMap => ({
        addListener(target, listener, ...args) {
          target.addListener(wrapperMap.get(listener), ...args);
        },
        hasListener(target, listener) {
          return target.hasListener(wrapperMap.get(listener));
        },
        removeListener(target, listener) {
          target.removeListener(wrapperMap.get(listener));
        }
      });
      const onRequestFinishedWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }

        /**
         * Wraps an onRequestFinished listener function so that it will return a
         * `getContent()` property which returns a `Promise` rather than using a
         * callback API.
         *
         * @param {object} req
         *        The HAR entry object representing the network request.
         */
        return function onRequestFinished(req) {
          const wrappedReq = wrapObject(req, {} /* wrappers */, {
            getContent: {
              minArgs: 0,
              maxArgs: 0
            }
          });
          listener(wrappedReq);
        };
      });
      const onMessageWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }

        /**
         * Wraps a message listener function so that it may send responses based on
         * its return value, rather than by returning a sentinel value and calling a
         * callback. If the listener function returns a Promise, the response is
         * sent when the promise either resolves or rejects.
         *
         * @param {*} message
         *        The message sent by the other end of the channel.
         * @param {object} sender
         *        Details about the sender of the message.
         * @param {function(*)} sendResponse
         *        A callback which, when called with an arbitrary argument, sends
         *        that value as a response.
         * @returns {boolean}
         *        True if the wrapped listener returned a Promise, which will later
         *        yield a response. False otherwise.
         */
        return function onMessage(message, sender, sendResponse) {
          let didCallSendResponse = false;
          let wrappedSendResponse;
          let sendResponsePromise = new Promise(resolve => {
            wrappedSendResponse = function (response) {
              didCallSendResponse = true;
              resolve(response);
            };
          });
          let result;
          try {
            result = listener(message, sender, wrappedSendResponse);
          } catch (err) {
            result = Promise.reject(err);
          }
          const isResultThenable = result !== true && isThenable(result);

          // If the listener didn't returned true or a Promise, or called
          // wrappedSendResponse synchronously, we can exit earlier
          // because there will be no response sent from this listener.
          if (result !== true && !isResultThenable && !didCallSendResponse) {
            return false;
          }

          // A small helper to send the message if the promise resolves
          // and an error if the promise rejects (a wrapped sendMessage has
          // to translate the message into a resolved promise or a rejected
          // promise).
          const sendPromisedResult = promise => {
            promise.then(msg => {
              // send the message value.
              sendResponse(msg);
            }, error => {
              // Send a JSON representation of the error if the rejected value
              // is an instance of error, or the object itself otherwise.
              let message;
              if (error && (error instanceof Error || typeof error.message === "string")) {
                message = error.message;
              } else {
                message = "An unexpected error occurred";
              }
              sendResponse({
                __mozWebExtensionPolyfillReject__: true,
                message
              });
            }).catch(err => {
              // Print an error on the console if unable to send the response.
              console.error("Failed to send onMessage rejected reply", err);
            });
          };

          // If the listener returned a Promise, send the resolved value as a
          // result, otherwise wait the promise related to the wrappedSendResponse
          // callback to resolve and send it as a response.
          if (isResultThenable) {
            sendPromisedResult(result);
          } else {
            sendPromisedResult(sendResponsePromise);
          }

          // Let Chrome know that the listener is replying.
          return true;
        };
      });
      const wrappedSendMessageCallback = ({
        reject,
        resolve
      }, reply) => {
        if (extensionAPIs.runtime.lastError) {
          // Detect when none of the listeners replied to the sendMessage call and resolve
          // the promise to undefined as in Firefox.
          // See https://github.com/mozilla/webextension-polyfill/issues/130
          if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
            resolve();
          } else {
            reject(new Error(extensionAPIs.runtime.lastError.message));
          }
        } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
          // Convert back the JSON representation of the error into
          // an Error instance.
          reject(new Error(reply.message));
        } else {
          resolve(reply);
        }
      };
      const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
        if (args.length < metadata.minArgs) {
          throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
        }
        if (args.length > metadata.maxArgs) {
          throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
        }
        return new Promise((resolve, reject) => {
          const wrappedCb = wrappedSendMessageCallback.bind(null, {
            resolve,
            reject
          });
          args.push(wrappedCb);
          apiNamespaceObj.sendMessage(...args);
        });
      };
      const staticWrappers = {
        devtools: {
          network: {
            onRequestFinished: wrapEvent(onRequestFinishedWrappers)
          }
        },
        runtime: {
          onMessage: wrapEvent(onMessageWrappers),
          onMessageExternal: wrapEvent(onMessageWrappers),
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 1,
            maxArgs: 3
          })
        },
        tabs: {
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 2,
            maxArgs: 3
          })
        }
      };
      const settingMetadata = {
        clear: {
          minArgs: 1,
          maxArgs: 1
        },
        get: {
          minArgs: 1,
          maxArgs: 1
        },
        set: {
          minArgs: 1,
          maxArgs: 1
        }
      };
      apiMetadata.privacy = {
        network: {
          "*": settingMetadata
        },
        services: {
          "*": settingMetadata
        },
        websites: {
          "*": settingMetadata
        }
      };
      return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
    };

    // The build process adds a UMD wrapper around this file, which makes the
    // `module` variable available.
    module.exports = wrapAPIs(chrome);
  } else {
    module.exports = globalThis.browser;
  }
});
//# sourceMappingURL=browser-polyfill.js.map


}),
5110: 
/*!*******************************************************************************!*\
  !*** ../../node_modules/webpack-dev-server/client/clients/WebSocketClient.js ***!
  \*******************************************************************************/
(function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (WebSocketClient)
});
/* import */var _utils_log_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/log.js */ 6065);
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _classCallCheck(a, n) { if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function"); }
function _defineProperties(e, r) { for (var t = 0; t < r.length; t++) { var o = r[t]; o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o); } }
function _createClass(e, r, t) { return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }

var WebSocketClient = /*#__PURE__*/function () {
  /**
   * @param {string} url
   */
  function WebSocketClient(url) {
    _classCallCheck(this, WebSocketClient);
    this.client = new WebSocket(url);
    this.client.onerror = function (error) {
      _utils_log_js__WEBPACK_IMPORTED_MODULE_0__.log.error(error);
    };
  }

  /**
   * @param {(...args: any[]) => void} f
   */
  return _createClass(WebSocketClient, [{
    key: "onOpen",
    value: function onOpen(f) {
      this.client.onopen = f;
    }

    /**
     * @param {(...args: any[]) => void} f
     */
  }, {
    key: "onClose",
    value: function onClose(f) {
      this.client.onclose = f;
    }

    // call f with the message string as the first argument
    /**
     * @param {(...args: any[]) => void} f
     */
  }, {
    key: "onMessage",
    value: function onMessage(f) {
      this.client.onmessage = function (e) {
        f(e.data);
      };
    }
  }]);
}();


}),
3784: 
/*!****************************************************************************!*\
  !*** ../../node_modules/webpack-dev-server/client/modules/logger/index.js ***!
  \****************************************************************************/
(function (__unused_webpack_module, exports) {
/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./client-src/modules/logger/tapable.js":
/*!**********************************************!*\
  !*** ./client-src/modules/logger/tapable.js ***!
  \**********************************************/
/***/ (function(__unused_webpack_module, __nested_webpack_exports__, __nested_webpack_require_372_391__) {

__nested_webpack_require_372_391__.r(__nested_webpack_exports__);
/* harmony export */ __nested_webpack_require_372_391__.d(__nested_webpack_exports__, {
/* harmony export */   SyncBailHook: function() { return /* binding */ SyncBailHook; }
/* harmony export */ });
function SyncBailHook() {
  return {
    call: function call() {}
  };
}

/**
 * Client stub for tapable SyncBailHook
 */
// eslint-disable-next-line import/prefer-default-export


/***/ }),

/***/ "./node_modules/webpack/lib/logging/Logger.js":
/*!****************************************************!*\
  !*** ./node_modules/webpack/lib/logging/Logger.js ***!
  \****************************************************/
/***/ (function(module) {

/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Tobias Koppers @sokra
*/



function _typeof(o) {
  "@babel/helpers - typeof";

  return _typeof = "function" == typeof (typeof Symbol !== "undefined" ? Symbol : function (i) { return i; }) && "symbol" == typeof (typeof Symbol !== "undefined" ? Symbol : function (i) { return i; }).iterator ? function (o) {
    return typeof o;
  } : function (o) {
    return o && "function" == typeof (typeof Symbol !== "undefined" ? Symbol : function (i) { return i; }) && o.constructor === (typeof Symbol !== "undefined" ? Symbol : function (i) { return i; }) && o !== (typeof Symbol !== "undefined" ? Symbol : function (i) { return i; }).prototype ? "symbol" : typeof o;
  }, _typeof(o);
}
function _toConsumableArray(r) {
  return _arrayWithoutHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableSpread();
}
function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return _arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
  }
}
function _iterableToArray(r) {
  if ("undefined" != typeof (typeof Symbol !== "undefined" ? Symbol : function (i) { return i; }) && null != r[(typeof Symbol !== "undefined" ? Symbol : function (i) { return i; }).iterator] || null != r["@@iterator"]) return Array.from(r);
}
function _arrayWithoutHoles(r) {
  if (Array.isArray(r)) return _arrayLikeToArray(r);
}
function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}
function _classCallCheck(a, n) {
  if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties(e, r) {
  for (var t = 0; t < r.length; t++) {
    var o = r[t];
    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o);
  }
}
function _createClass(e, r, t) {
  return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", {
    writable: !1
  }), e;
}
function _toPropertyKey(t) {
  var i = _toPrimitive(t, "string");
  return "symbol" == _typeof(i) ? i : i + "";
}
function _toPrimitive(t, r) {
  if ("object" != _typeof(t) || !t) return t;
  var e = t[(typeof Symbol !== "undefined" ? Symbol : function (i) { return i; }).toPrimitive];
  if (void 0 !== e) {
    var i = e.call(t, r || "default");
    if ("object" != _typeof(i)) return i;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return ("string" === r ? String : Number)(t);
}
var LogType = Object.freeze({
  error: (/** @type {"error"} */"error"),
  // message, c style arguments
  warn: (/** @type {"warn"} */"warn"),
  // message, c style arguments
  info: (/** @type {"info"} */"info"),
  // message, c style arguments
  log: (/** @type {"log"} */"log"),
  // message, c style arguments
  debug: (/** @type {"debug"} */"debug"),
  // message, c style arguments

  trace: (/** @type {"trace"} */"trace"),
  // no arguments

  group: (/** @type {"group"} */"group"),
  // [label]
  groupCollapsed: (/** @type {"groupCollapsed"} */"groupCollapsed"),
  // [label]
  groupEnd: (/** @type {"groupEnd"} */"groupEnd"),
  // [label]

  profile: (/** @type {"profile"} */"profile"),
  // [profileName]
  profileEnd: (/** @type {"profileEnd"} */"profileEnd"),
  // [profileName]

  time: (/** @type {"time"} */"time"),
  // name, time as [seconds, nanoseconds]

  clear: (/** @type {"clear"} */"clear"),
  // no arguments
  status: (/** @type {"status"} */"status") // message, arguments
});
module.exports.LogType = LogType;

/** @typedef {typeof LogType[keyof typeof LogType]} LogTypeEnum */

var LOG_SYMBOL = (typeof Symbol !== "undefined" ? Symbol : function (i) { return i; })("webpack logger raw log method");
var TIMERS_SYMBOL = (typeof Symbol !== "undefined" ? Symbol : function (i) { return i; })("webpack logger times");
var TIMERS_AGGREGATES_SYMBOL = (typeof Symbol !== "undefined" ? Symbol : function (i) { return i; })("webpack logger aggregated times");
var WebpackLogger = /*#__PURE__*/function () {
  /**
   * @param {(type: LogTypeEnum, args?: EXPECTED_ANY[]) => void} log log function
   * @param {(name: string | (() => string)) => WebpackLogger} getChildLogger function to create child logger
   */
  function WebpackLogger(log, getChildLogger) {
    _classCallCheck(this, WebpackLogger);
    this[LOG_SYMBOL] = log;
    this.getChildLogger = getChildLogger;
  }

  /**
   * @param {...EXPECTED_ANY} args args
   */
  return _createClass(WebpackLogger, [{
    key: "error",
    value: function error() {
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      this[LOG_SYMBOL](LogType.error, args);
    }

    /**
     * @param {...EXPECTED_ANY} args args
     */
  }, {
    key: "warn",
    value: function warn() {
      for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
        args[_key2] = arguments[_key2];
      }
      this[LOG_SYMBOL](LogType.warn, args);
    }

    /**
     * @param {...EXPECTED_ANY} args args
     */
  }, {
    key: "info",
    value: function info() {
      for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
        args[_key3] = arguments[_key3];
      }
      this[LOG_SYMBOL](LogType.info, args);
    }

    /**
     * @param {...EXPECTED_ANY} args args
     */
  }, {
    key: "log",
    value: function log() {
      for (var _len4 = arguments.length, args = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
        args[_key4] = arguments[_key4];
      }
      this[LOG_SYMBOL](LogType.log, args);
    }

    /**
     * @param {...EXPECTED_ANY} args args
     */
  }, {
    key: "debug",
    value: function debug() {
      for (var _len5 = arguments.length, args = new Array(_len5), _key5 = 0; _key5 < _len5; _key5++) {
        args[_key5] = arguments[_key5];
      }
      this[LOG_SYMBOL](LogType.debug, args);
    }

    /**
     * @param {EXPECTED_ANY} assertion assertion
     * @param {...EXPECTED_ANY} args args
     */
  }, {
    key: "assert",
    value: function assert(assertion) {
      if (!assertion) {
        for (var _len6 = arguments.length, args = new Array(_len6 > 1 ? _len6 - 1 : 0), _key6 = 1; _key6 < _len6; _key6++) {
          args[_key6 - 1] = arguments[_key6];
        }
        this[LOG_SYMBOL](LogType.error, args);
      }
    }
  }, {
    key: "trace",
    value: function trace() {
      this[LOG_SYMBOL](LogType.trace, ["Trace"]);
    }
  }, {
    key: "clear",
    value: function clear() {
      this[LOG_SYMBOL](LogType.clear);
    }

    /**
     * @param {...EXPECTED_ANY} args args
     */
  }, {
    key: "status",
    value: function status() {
      for (var _len7 = arguments.length, args = new Array(_len7), _key7 = 0; _key7 < _len7; _key7++) {
        args[_key7] = arguments[_key7];
      }
      this[LOG_SYMBOL](LogType.status, args);
    }

    /**
     * @param {...EXPECTED_ANY} args args
     */
  }, {
    key: "group",
    value: function group() {
      for (var _len8 = arguments.length, args = new Array(_len8), _key8 = 0; _key8 < _len8; _key8++) {
        args[_key8] = arguments[_key8];
      }
      this[LOG_SYMBOL](LogType.group, args);
    }

    /**
     * @param {...EXPECTED_ANY} args args
     */
  }, {
    key: "groupCollapsed",
    value: function groupCollapsed() {
      for (var _len9 = arguments.length, args = new Array(_len9), _key9 = 0; _key9 < _len9; _key9++) {
        args[_key9] = arguments[_key9];
      }
      this[LOG_SYMBOL](LogType.groupCollapsed, args);
    }
  }, {
    key: "groupEnd",
    value: function groupEnd() {
      this[LOG_SYMBOL](LogType.groupEnd);
    }

    /**
     * @param {string=} label label
     */
  }, {
    key: "profile",
    value: function profile(label) {
      this[LOG_SYMBOL](LogType.profile, [label]);
    }

    /**
     * @param {string=} label label
     */
  }, {
    key: "profileEnd",
    value: function profileEnd(label) {
      this[LOG_SYMBOL](LogType.profileEnd, [label]);
    }

    /**
     * @param {string} label label
     */
  }, {
    key: "time",
    value: function time(label) {
      /** @type {Map<string | undefined, [number, number]>} */
      this[TIMERS_SYMBOL] = this[TIMERS_SYMBOL] || new Map();
      this[TIMERS_SYMBOL].set(label, process.hrtime());
    }

    /**
     * @param {string=} label label
     */
  }, {
    key: "timeLog",
    value: function timeLog(label) {
      var prev = this[TIMERS_SYMBOL] && this[TIMERS_SYMBOL].get(label);
      if (!prev) {
        throw new Error("No such label '".concat(label, "' for WebpackLogger.timeLog()"));
      }
      var time = process.hrtime(prev);
      this[LOG_SYMBOL](LogType.time, [label].concat(_toConsumableArray(time)));
    }

    /**
     * @param {string=} label label
     */
  }, {
    key: "timeEnd",
    value: function timeEnd(label) {
      var prev = this[TIMERS_SYMBOL] && this[TIMERS_SYMBOL].get(label);
      if (!prev) {
        throw new Error("No such label '".concat(label, "' for WebpackLogger.timeEnd()"));
      }
      var time = process.hrtime(prev);
      /** @type {Map<string | undefined, [number, number]>} */
      this[TIMERS_SYMBOL].delete(label);
      this[LOG_SYMBOL](LogType.time, [label].concat(_toConsumableArray(time)));
    }

    /**
     * @param {string=} label label
     */
  }, {
    key: "timeAggregate",
    value: function timeAggregate(label) {
      var prev = this[TIMERS_SYMBOL] && this[TIMERS_SYMBOL].get(label);
      if (!prev) {
        throw new Error("No such label '".concat(label, "' for WebpackLogger.timeAggregate()"));
      }
      var time = process.hrtime(prev);
      /** @type {Map<string | undefined, [number, number]>} */
      this[TIMERS_SYMBOL].delete(label);
      /** @type {Map<string | undefined, [number, number]>} */
      this[TIMERS_AGGREGATES_SYMBOL] = this[TIMERS_AGGREGATES_SYMBOL] || new Map();
      var current = this[TIMERS_AGGREGATES_SYMBOL].get(label);
      if (current !== undefined) {
        if (time[1] + current[1] > 1e9) {
          time[0] += current[0] + 1;
          time[1] = time[1] - 1e9 + current[1];
        } else {
          time[0] += current[0];
          time[1] += current[1];
        }
      }
      this[TIMERS_AGGREGATES_SYMBOL].set(label, time);
    }

    /**
     * @param {string=} label label
     */
  }, {
    key: "timeAggregateEnd",
    value: function timeAggregateEnd(label) {
      if (this[TIMERS_AGGREGATES_SYMBOL] === undefined) return;
      var time = this[TIMERS_AGGREGATES_SYMBOL].get(label);
      if (time === undefined) return;
      this[TIMERS_AGGREGATES_SYMBOL].delete(label);
      this[LOG_SYMBOL](LogType.time, [label].concat(_toConsumableArray(time)));
    }
  }]);
}();
module.exports.Logger = WebpackLogger;

/***/ }),

/***/ "./node_modules/webpack/lib/logging/createConsoleLogger.js":
/*!*****************************************************************!*\
  !*** ./node_modules/webpack/lib/logging/createConsoleLogger.js ***!
  \*****************************************************************/
/***/ (function(module, __unused_webpack_exports, __nested_webpack_require_12803_12822__) {

/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Tobias Koppers @sokra
*/



function _slicedToArray(r, e) {
  return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest();
}
function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _iterableToArrayLimit(r, l) {
  var t = null == r ? null : "undefined" != typeof (typeof Symbol !== "undefined" ? Symbol : function (i) { return i; }) && r[(typeof Symbol !== "undefined" ? Symbol : function (i) { return i; }).iterator] || r["@@iterator"];
  if (null != t) {
    var e,
      n,
      i,
      u,
      a = [],
      f = !0,
      o = !1;
    try {
      if (i = (t = t.call(r)).next, 0 === l) {
        if (Object(t) !== t) return;
        f = !1;
      } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
    } catch (r) {
      o = !0, n = r;
    } finally {
      try {
        if (!f && null != t.return && (u = t.return(), Object(u) !== u)) return;
      } finally {
        if (o) throw n;
      }
    }
    return a;
  }
}
function _arrayWithHoles(r) {
  if (Array.isArray(r)) return r;
}
function _toConsumableArray(r) {
  return _arrayWithoutHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableSpread();
}
function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return _arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
  }
}
function _iterableToArray(r) {
  if ("undefined" != typeof (typeof Symbol !== "undefined" ? Symbol : function (i) { return i; }) && null != r[(typeof Symbol !== "undefined" ? Symbol : function (i) { return i; }).iterator] || null != r["@@iterator"]) return Array.from(r);
}
function _arrayWithoutHoles(r) {
  if (Array.isArray(r)) return _arrayLikeToArray(r);
}
function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}
function _typeof(o) {
  "@babel/helpers - typeof";

  return _typeof = "function" == typeof (typeof Symbol !== "undefined" ? Symbol : function (i) { return i; }) && "symbol" == typeof (typeof Symbol !== "undefined" ? Symbol : function (i) { return i; }).iterator ? function (o) {
    return typeof o;
  } : function (o) {
    return o && "function" == typeof (typeof Symbol !== "undefined" ? Symbol : function (i) { return i; }) && o.constructor === (typeof Symbol !== "undefined" ? Symbol : function (i) { return i; }) && o !== (typeof Symbol !== "undefined" ? Symbol : function (i) { return i; }).prototype ? "symbol" : typeof o;
  }, _typeof(o);
}
var _require = __nested_webpack_require_12803_12822__(/*! ./Logger */ "./node_modules/webpack/lib/logging/Logger.js"),
  LogType = _require.LogType;

/** @typedef {import("../../declarations/WebpackOptions").FilterItemTypes} FilterItemTypes */
/** @typedef {import("../../declarations/WebpackOptions").FilterTypes} FilterTypes */
/** @typedef {import("./Logger").LogTypeEnum} LogTypeEnum */

/** @typedef {(item: string) => boolean} FilterFunction */
/** @typedef {(value: string, type: LogTypeEnum, args?: EXPECTED_ANY[]) => void} LoggingFunction */

/**
 * @typedef {object} LoggerConsole
 * @property {() => void} clear
 * @property {() => void} trace
 * @property {(...args: EXPECTED_ANY[]) => void} info
 * @property {(...args: EXPECTED_ANY[]) => void} log
 * @property {(...args: EXPECTED_ANY[]) => void} warn
 * @property {(...args: EXPECTED_ANY[]) => void} error
 * @property {(...args: EXPECTED_ANY[]) => void=} debug
 * @property {(...args: EXPECTED_ANY[]) => void=} group
 * @property {(...args: EXPECTED_ANY[]) => void=} groupCollapsed
 * @property {(...args: EXPECTED_ANY[]) => void=} groupEnd
 * @property {(...args: EXPECTED_ANY[]) => void=} status
 * @property {(...args: EXPECTED_ANY[]) => void=} profile
 * @property {(...args: EXPECTED_ANY[]) => void=} profileEnd
 * @property {(...args: EXPECTED_ANY[]) => void=} logTime
 */

/**
 * @typedef {object} LoggerOptions
 * @property {false|true|"none"|"error"|"warn"|"info"|"log"|"verbose"} level loglevel
 * @property {FilterTypes|boolean} debug filter for debug logging
 * @property {LoggerConsole} console the console to log to
 */

/**
 * @param {FilterItemTypes} item an input item
 * @returns {FilterFunction | undefined} filter function
 */
var filterToFunction = function filterToFunction(item) {
  if (typeof item === "string") {
    var regExp = new RegExp("[\\\\/]".concat(item.replace(/[-[\]{}()*+?.\\^$|]/g, "\\$&"), "([\\\\/]|$|!|\\?)"));
    return function (ident) {
      return regExp.test(ident);
    };
  }
  if (item && _typeof(item) === "object" && typeof item.test === "function") {
    return function (ident) {
      return item.test(ident);
    };
  }
  if (typeof item === "function") {
    return item;
  }
  if (typeof item === "boolean") {
    return function () {
      return item;
    };
  }
};

/**
 * @enum {number}
 */
var LogLevel = {
  none: 6,
  false: 6,
  error: 5,
  warn: 4,
  info: 3,
  log: 2,
  true: 2,
  verbose: 1
};

/**
 * @param {LoggerOptions} options options object
 * @returns {LoggingFunction} logging function
 */
module.exports = function (_ref) {
  var _ref$level = _ref.level,
    level = _ref$level === void 0 ? "info" : _ref$level,
    _ref$debug = _ref.debug,
    debug = _ref$debug === void 0 ? false : _ref$debug,
    console = _ref.console;
  var debugFilters = /** @type {FilterFunction[]} */

  typeof debug === "boolean" ? [function () {
    return debug;
  }] : /** @type {FilterItemTypes[]} */[].concat(debug).map(filterToFunction);
  var loglevel = LogLevel["".concat(level)] || 0;

  /**
   * @param {string} name name of the logger
   * @param {LogTypeEnum} type type of the log entry
   * @param {EXPECTED_ANY[]=} args arguments of the log entry
   * @returns {void}
   */
  var logger = function logger(name, type, args) {
    var labeledArgs = function labeledArgs() {
      if (Array.isArray(args)) {
        if (args.length > 0 && typeof args[0] === "string") {
          return ["[".concat(name, "] ").concat(args[0])].concat(_toConsumableArray(args.slice(1)));
        }
        return ["[".concat(name, "]")].concat(_toConsumableArray(args));
      }
      return [];
    };
    var debug = debugFilters.some(function (f) {
      return f(name);
    });
    switch (type) {
      case LogType.debug:
        if (!debug) return;
        if (typeof console.debug === "function") {
          console.debug.apply(console, _toConsumableArray(labeledArgs()));
        } else {
          console.log.apply(console, _toConsumableArray(labeledArgs()));
        }
        break;
      case LogType.log:
        if (!debug && loglevel > LogLevel.log) return;
        console.log.apply(console, _toConsumableArray(labeledArgs()));
        break;
      case LogType.info:
        if (!debug && loglevel > LogLevel.info) return;
        console.info.apply(console, _toConsumableArray(labeledArgs()));
        break;
      case LogType.warn:
        if (!debug && loglevel > LogLevel.warn) return;
        console.warn.apply(console, _toConsumableArray(labeledArgs()));
        break;
      case LogType.error:
        if (!debug && loglevel > LogLevel.error) return;
        console.error.apply(console, _toConsumableArray(labeledArgs()));
        break;
      case LogType.trace:
        if (!debug) return;
        console.trace();
        break;
      case LogType.groupCollapsed:
        if (!debug && loglevel > LogLevel.log) return;
        if (!debug && loglevel > LogLevel.verbose) {
          if (typeof console.groupCollapsed === "function") {
            console.groupCollapsed.apply(console, _toConsumableArray(labeledArgs()));
          } else {
            console.log.apply(console, _toConsumableArray(labeledArgs()));
          }
          break;
        }
      // falls through
      case LogType.group:
        if (!debug && loglevel > LogLevel.log) return;
        if (typeof console.group === "function") {
          console.group.apply(console, _toConsumableArray(labeledArgs()));
        } else {
          console.log.apply(console, _toConsumableArray(labeledArgs()));
        }
        break;
      case LogType.groupEnd:
        if (!debug && loglevel > LogLevel.log) return;
        if (typeof console.groupEnd === "function") {
          console.groupEnd();
        }
        break;
      case LogType.time:
        {
          if (!debug && loglevel > LogLevel.log) return;
          var _args = _slicedToArray(/** @type {[string, number, number]} */
            args, 3),
            label = _args[0],
            start = _args[1],
            end = _args[2];
          var ms = start * 1000 + end / 1000000;
          var msg = "[".concat(name, "] ").concat(label, ": ").concat(ms, " ms");
          if (typeof console.logTime === "function") {
            console.logTime(msg);
          } else {
            console.log(msg);
          }
          break;
        }
      case LogType.profile:
        if (typeof console.profile === "function") {
          console.profile.apply(console, _toConsumableArray(labeledArgs()));
        }
        break;
      case LogType.profileEnd:
        if (typeof console.profileEnd === "function") {
          console.profileEnd.apply(console, _toConsumableArray(labeledArgs()));
        }
        break;
      case LogType.clear:
        if (!debug && loglevel > LogLevel.log) return;
        if (typeof console.clear === "function") {
          console.clear();
        }
        break;
      case LogType.status:
        if (!debug && loglevel > LogLevel.info) return;
        if (typeof console.status === "function") {
          if (!args || args.length === 0) {
            console.status();
          } else {
            console.status.apply(console, _toConsumableArray(labeledArgs()));
          }
        } else if (args && args.length !== 0) {
          console.info.apply(console, _toConsumableArray(labeledArgs()));
        }
        break;
      default:
        throw new Error("Unexpected LogType ".concat(type));
    }
  };
  return logger;
};

/***/ }),

/***/ "./node_modules/webpack/lib/logging/runtime.js":
/*!*****************************************************!*\
  !*** ./node_modules/webpack/lib/logging/runtime.js ***!
  \*****************************************************/
/***/ (function(module, __unused_webpack_exports, __nested_webpack_require_23778_23797__) {

/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Tobias Koppers @sokra
*/



function _extends() {
  return _extends = Object.assign ? Object.assign.bind() : function (n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends.apply(null, arguments);
}
var _require = __nested_webpack_require_23778_23797__(/*! tapable */ "./client-src/modules/logger/tapable.js"),
  SyncBailHook = _require.SyncBailHook;
var _require2 = __nested_webpack_require_23778_23797__(/*! ./Logger */ "./node_modules/webpack/lib/logging/Logger.js"),
  Logger = _require2.Logger;
var createConsoleLogger = __nested_webpack_require_23778_23797__(/*! ./createConsoleLogger */ "./node_modules/webpack/lib/logging/createConsoleLogger.js");

/** @type {createConsoleLogger.LoggerOptions} */
var currentDefaultLoggerOptions = {
  level: "info",
  debug: false,
  console: console
};
var currentDefaultLogger = createConsoleLogger(currentDefaultLoggerOptions);

/**
 * @param {string} name name of the logger
 * @returns {Logger} a logger
 */
module.exports.getLogger = function (name) {
  return new Logger(function (type, args) {
    if (module.exports.hooks.log.call(name, type, args) === undefined) {
      currentDefaultLogger(name, type, args);
    }
  }, function (childName) {
    return module.exports.getLogger("".concat(name, "/").concat(childName));
  });
};

/**
 * @param {createConsoleLogger.LoggerOptions} options new options, merge with old options
 * @returns {void}
 */
module.exports.configureDefaultLogger = function (options) {
  _extends(currentDefaultLoggerOptions, options);
  currentDefaultLogger = createConsoleLogger(currentDefaultLoggerOptions);
};
module.exports.hooks = {
  log: new SyncBailHook(["origin", "type", "args"])
};

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __nested_webpack_require_25855__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __nested_webpack_require_25855__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	!function() {
/******/ 		// define getter functions for harmony exports
/******/ 		__nested_webpack_require_25855__.d = function(exports, definition) {
/******/ 			for(var key in definition) {
/******/ 				if(__nested_webpack_require_25855__.o(definition, key) && !__nested_webpack_require_25855__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	!function() {
/******/ 		__nested_webpack_require_25855__.o = function(obj, prop) { return Object.prototype.hasOwnProperty.call(obj, prop); }
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	!function() {
/******/ 		// define __esModule on exports
/******/ 		__nested_webpack_require_25855__.r = function(exports) {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	}();
/******/ 	
/************************************************************************/
var __nested_webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
!function() {
/*!********************************************!*\
  !*** ./client-src/modules/logger/index.js ***!
  \********************************************/
__nested_webpack_require_25855__.r(__nested_webpack_exports__);
/* harmony export */ __nested_webpack_require_25855__.d(__nested_webpack_exports__, {
/* harmony export */   "default": function() { return /* reexport default export from named module */ webpack_lib_logging_runtime_js__WEBPACK_IMPORTED_MODULE_0__; }
/* harmony export */ });
/* harmony import */ var webpack_lib_logging_runtime_js__WEBPACK_IMPORTED_MODULE_0__ = __nested_webpack_require_25855__(/*! webpack/lib/logging/runtime.js */ "./node_modules/webpack/lib/logging/runtime.js");

}();
var __webpack_export_target__ = exports;
for(var __webpack_i__ in __nested_webpack_exports__) __webpack_export_target__[__webpack_i__] = __nested_webpack_exports__[__webpack_i__];
if(__nested_webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ })()
;

}),
6065: 
/*!*****************************************************************!*\
  !*** ../../node_modules/webpack-dev-server/client/utils/log.js ***!
  \*****************************************************************/
(function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  log: () => (log),
  setLogLevel: () => (setLogLevel)
});
/* import */var _modules_logger_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../modules/logger/index.js */ 3784);
/* import */var _modules_logger_index_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_modules_logger_index_js__WEBPACK_IMPORTED_MODULE_0__);

var name = "webpack-dev-server";
// default level is set on the client side, so it does not need
// to be set by the CLI or API
var defaultLevel = "info";

// options new options, merge with old options
/**
 * @param {false | true | "none" | "error" | "warn" | "info" | "log" | "verbose"} level
 * @returns {void}
 */
function setLogLevel(level) {
  _modules_logger_index_js__WEBPACK_IMPORTED_MODULE_0___default().configureDefaultLogger({
    level: level
  });
}
setLogLevel(defaultLevel);
var log = _modules_logger_index_js__WEBPACK_IMPORTED_MODULE_0___default().getLogger(name);


}),
5640: 
/*!********************************!*\
  !*** ./src/content/styles.css ***!
  \********************************/
(function (module) {
"use strict";
module.exports = "data:text/css;base64,LmNvbnRlbnRfc2NyaXB0IHsKICBwb3NpdGlvbjogYWJzb2x1dGU7CiAgcmlnaHQ6IDAuNzVyZW07CiAgYm90dG9tOiAwLjc1cmVtOwogIHotaW5kZXg6IDk5OTk7Cn0KCi5jb250ZW50X3BpbGwgewogIC13ZWJraXQtZm9udC1zbW9vdGhpbmc6IGFudGlhbGlhc2VkOwogIC1tb3otb3N4LWZvbnQtc21vb3RoaW5nOiBncmF5c2NhbGU7CiAgYXBwZWFyYW5jZTogbm9uZTsKICBib3JkZXI6IG5vbmU7CiAgb3V0bGluZTogbm9uZTsKICBjdXJzb3I6IHBvaW50ZXI7CiAgZGlzcGxheTogaW5saW5lLWZsZXg7CiAgYWxpZ24taXRlbXM6IGNlbnRlcjsKICBnYXA6IDAuNXJlbTsKICBiYWNrZ3JvdW5kOiB2YXIoLS1zaWRlYmFyLWJnLCAjMGEwYzEwKTsKICBjb2xvcjogdmFyKC0tc2lkZWJhci10ZXh0LCAjYzljOWM5KTsKICBwYWRkaW5nOiAwLjVyZW0gMXJlbSAwLjVyZW0gMC41cmVtOwogIGJvcmRlci1yYWRpdXM6IDk5OTlweDsKICBib3gtc2hhZG93OiAwIDJweCAxMHB4IHJnYmEoMCwgMCwgMCwgMC4yNSk7Cn0KCi5jb250ZW50X3BpbGw6aG92ZXIgewogIGJhY2tncm91bmQ6ICMxMTE1MWM7Cn0KCi5jb250ZW50X3BpbGxfbG9nbyB7CiAgaGVpZ2h0OiAxLjVyZW07CiAgYm9yZGVyLXJhZGl1czogOTk5OXB4OwogIGJhY2tncm91bmQ6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC4wOCk7CiAgb2JqZWN0LWZpdDogY29udGFpbjsKICBhc3BlY3QtcmF0aW86IDEvMTsKICBwYWRkaW5nOiAwLjEyNXJlbTsKfQoKLmNvbnRlbnRfcGlsbF90ZXh0IHsKICBmb250LXNpemU6IDAuODVyZW07CiAgZm9udC13ZWlnaHQ6IDYwMDsKICBsaW5lLWhlaWdodDogMTsKICBmb250LWZhbWlseTogLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCAnU2Vnb2UgVUknLCBSb2JvdG8sCiAgICAnSGVsdmV0aWNhIE5ldWUnLCBBcmlhbCwgJ05vdG8gU2FucycsIHNhbnMtc2VyaWY7Cn0=";

}),
1987: 
/*!********************************!*\
  !*** ./src/content/scripts.ts ***!
  \********************************/
(function (module, __unused_webpack___webpack_exports__, __webpack_require__) {
"use strict";
if (true) {
    try {
        // Accept updates for HTML-attached scripts and clear common containers
        module.hot.accept();
        module.hot.dispose(function() {
            try {
                var clear = function(el) {
                    if (!el) return;
                    while(el.firstChild)el.removeChild(el.firstChild);
                };
                // Clear default template container
                clear(document.getElementById('app'));
                // Also clear any extension-root wrappers if present
                var roots = document.querySelectorAll('[data-extension-root]');
                roots.forEach(function(node) {
                    clear(node);
                });
            } catch (err) {
                // 'err' is local in this catch, keep for error clarity
                console.error('Error clearing HTML containers', err);
            }
        });
    } catch (error) {
        console.error('Error accepting HMR', error);
    }
}
/* extension.js content script proxy */ function loadInnerWrappedModule() {
    try {
        Promise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! ./src/content/scripts.ts?__extjs_inner=1 */ 135)).catch(function(e) {
            console.warn('[extension.js] content script failed to load. waiting for next successful compile', e);
        });
    } catch (e) {
        console.warn('[extension.js] content script failed to load. waiting for next successful compile', e);
    }
}
loadInnerWrappedModule();
if (true) {
    const hot = module.hot;
    if (typeof hot.accept === "function") hot.accept(()=>{
        loadInnerWrappedModule();
    });
    if (typeof hot.addStatusHandler === "function") hot.addStatusHandler((s)=>{
        if (s === "apply" || s === "idle") loadInnerWrappedModule();
    });
}



}),
135: 
/*!************************************************!*\
  !*** ./src/content/scripts.ts?__extjs_inner=1 ***!
  \************************************************/
(function (module, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* import */var svelte__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! svelte */ 193);
/* import */var _ContentApp_svelte__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ContentApp.svelte */ 9380);
/* import */var _styles_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles.css */ 5640);
if (true) {
    try {
        // Accept updates for HTML-attached scripts and clear common containers
        module.hot.accept();
        module.hot.dispose(function() {
            try {
                var clear = function(el) {
                    if (!el) return;
                    while(el.firstChild)el.removeChild(el.firstChild);
                };
                // Clear default template container
                clear(document.getElementById('app'));
                // Also clear any extension-root wrappers if present
                var roots = document.querySelectorAll('[data-extension-root]');
                roots.forEach(function(node) {
                    clear(node);
                });
            } catch (err) {
                // 'err' is local in this catch, keep for error clarity
                console.error('Error clearing HTML containers', err);
            }
        });
    } catch (error) {
        console.error('Error accepting HMR', error);
    }
}
function __EXTENSIONJS_mountWithHMR(mount) {
    var cleanup;
    function apply() {
        cleanup = mount();
    }
    function unmount() {
        if (typeof cleanup === 'function') cleanup();
    }
    function remount() {
        unmount();
        apply();
    }
    if (typeof document !== 'undefined') {
        if (document.readyState === 'complete') {
            apply();
        } else {
            var onReady = function() {
                if (document.readyState === 'complete') {
                    document.removeEventListener('readystatechange', onReady);
                    apply();
                }
            };
            document.addEventListener('readystatechange', onReady);
        }
    } else {
        apply();
    }
    if (true) {
        if (typeof module.hot.accept === "function") module.hot.accept();
        if (typeof module.hot.dispose === "function") module.hot.dispose(unmount);
        if (typeof module.hot.addStatusHandler === "function") {
            module.hot.addStatusHandler(function(s) {
                if (s === 'abort' || s === 'fail') {
                    console.warn('[extension.js] HMR status:', s);
                }
            });
        }
    }
    var cssEvt = '__EXTENSIONJS_CSS_UPDATE__';
    var onCss = function() {
        remount();
    };
    window.addEventListener(cssEvt, onCss);
    return function() {
        window.removeEventListener(cssEvt, onCss);
        unmount();
    };
}
// Extension.js content script template (JavaScript)
// - Export a default function (required in v3) that mounts your UI
// - Wrapper handles Shadow DOM isolation, CSS injection, HMR and cleanup
// - Avoid adding your own HMR code; dev warnings will be shown if detected
// Docs: https://extension.js.org/docs/content-scripts



const __EXTENSIONJS_default__ = function initial() {
    const rootDiv = document.createElement('div');
    rootDiv.setAttribute('data-extension-root', 'true');
    document.body.appendChild(rootDiv);
    // Injecting content_scripts inside a shadow dom
    // prevents conflicts with the host page's styles.
    // This way, styles from the extension won't leak into the host page.
    const shadowRoot = rootDiv.attachShadow({
        mode: 'open'
    });
    const styleElement = document.createElement('style');
    shadowRoot.appendChild(styleElement);
    fetchCSS().then((response)=>styleElement.textContent = response);
    // Create container for Svelte app
    const contentDiv = document.createElement('div');
    contentDiv.className = 'content_script';
    shadowRoot.appendChild(contentDiv);
    // Mount Svelte app using Svelte 5's mount function
    (0,svelte__WEBPACK_IMPORTED_MODULE_0__.mount)(_ContentApp_svelte__WEBPACK_IMPORTED_MODULE_1__["default"], {
        target: contentDiv
    });
    return ()=>{
        rootDiv.remove();
    };
};
async function fetchCSS() {
    const cssUrl = new URL(/* asset import */__webpack_require__(/*! ./styles.css */ 5640), __webpack_require__.b);
    const response = await fetch(cssUrl);
    const text = await response.text();
    return response.ok ? text : Promise.reject(text);
}
try {
    __EXTENSIONJS_mountWithHMR(__EXTENSIONJS_default__);
} catch  {}
try {
    if (true) {
        module.hot.accept(/*! ./styles.css */ 5640, function(__WEBPACK_OUTDATED_DEPENDENCIES__) {
/* import */_styles_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles.css */ 5640);
(()=>{
            try {
                window.dispatchEvent(new CustomEvent('__EXTENSIONJS_CSS_UPDATE__'));
            } catch  {}
        })(__WEBPACK_OUTDATED_DEPENDENCIES__); }.bind(this));
    }
} catch  {}
/* export default */ const __WEBPACK_DEFAULT_EXPORT__ = (__EXTENSIONJS_default__);


}),
3990: 
/*!*******************************************************!*\
  !*** ../../node_modules/esm-env/index.js + 2 modules ***!
  \*******************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  BROWSER: () => (/* reexport */ esm_env_true),
  DEV: () => (/* reexport */ dev_fallback)
});

// UNUSED EXPORTS: NODE

;// CONCATENATED MODULE: ../../node_modules/esm-env/true.js
/* export default */ const esm_env_true = (true);

;// CONCATENATED MODULE: ../../node_modules/esm-env/dev-fallback.js
const node_env = globalThis.process?.env?.NODE_ENV;
/* export default */ const dev_fallback = (node_env && !node_env.toLowerCase().startsWith('prod'));

;// CONCATENATED MODULE: ../../node_modules/esm-env/index.js





}),
7164: 
/*!**************************************************!*\
  !*** ../../node_modules/svelte/src/constants.js ***!
  \**************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  ATTACHMENT_KEY: () => (ATTACHMENT_KEY),
  EACH_INDEX_REACTIVE: () => (EACH_INDEX_REACTIVE),
  EACH_IS_ANIMATED: () => (EACH_IS_ANIMATED),
  EACH_IS_CONTROLLED: () => (EACH_IS_CONTROLLED),
  EACH_ITEM_IMMUTABLE: () => (EACH_ITEM_IMMUTABLE),
  EACH_ITEM_REACTIVE: () => (EACH_ITEM_REACTIVE),
  FILENAME: () => (FILENAME),
  HMR: () => (HMR),
  HYDRATION_END: () => (HYDRATION_END),
  HYDRATION_ERROR: () => (HYDRATION_ERROR),
  HYDRATION_START: () => (HYDRATION_START),
  HYDRATION_START_ELSE: () => (HYDRATION_START_ELSE),
  NAMESPACE_HTML: () => (NAMESPACE_HTML),
  NAMESPACE_MATHML: () => (NAMESPACE_MATHML),
  NAMESPACE_SVG: () => (NAMESPACE_SVG),
  PROPS_IS_BINDABLE: () => (PROPS_IS_BINDABLE),
  PROPS_IS_IMMUTABLE: () => (PROPS_IS_IMMUTABLE),
  PROPS_IS_LAZY_INITIAL: () => (PROPS_IS_LAZY_INITIAL),
  PROPS_IS_RUNES: () => (PROPS_IS_RUNES),
  PROPS_IS_UPDATED: () => (PROPS_IS_UPDATED),
  TEMPLATE_FRAGMENT: () => (TEMPLATE_FRAGMENT),
  TEMPLATE_USE_IMPORT_NODE: () => (TEMPLATE_USE_IMPORT_NODE),
  TEMPLATE_USE_MATHML: () => (TEMPLATE_USE_MATHML),
  TEMPLATE_USE_SVG: () => (TEMPLATE_USE_SVG),
  TRANSITION_GLOBAL: () => (TRANSITION_GLOBAL),
  TRANSITION_IN: () => (TRANSITION_IN),
  TRANSITION_OUT: () => (TRANSITION_OUT),
  UNINITIALIZED: () => (UNINITIALIZED)
});
const EACH_ITEM_REACTIVE = 1;
const EACH_INDEX_REACTIVE = 1 << 1;
/** See EachBlock interface metadata.is_controlled for an explanation what this is */
const EACH_IS_CONTROLLED = 1 << 2;
const EACH_IS_ANIMATED = 1 << 3;
const EACH_ITEM_IMMUTABLE = 1 << 4;

const PROPS_IS_IMMUTABLE = 1;
const PROPS_IS_RUNES = 1 << 1;
const PROPS_IS_UPDATED = 1 << 2;
const PROPS_IS_BINDABLE = 1 << 3;
const PROPS_IS_LAZY_INITIAL = 1 << 4;

const TRANSITION_IN = 1;
const TRANSITION_OUT = 1 << 1;
const TRANSITION_GLOBAL = 1 << 2;

const TEMPLATE_FRAGMENT = 1;
const TEMPLATE_USE_IMPORT_NODE = 1 << 1;
const TEMPLATE_USE_SVG = 1 << 2;
const TEMPLATE_USE_MATHML = 1 << 3;

const HYDRATION_START = '[';
/** used to indicate that an `{:else}...` block was rendered */
const HYDRATION_START_ELSE = '[!';
const HYDRATION_END = ']';
const HYDRATION_ERROR = {};

const ELEMENT_IS_NAMESPACED = 1;
const ELEMENT_PRESERVE_ATTRIBUTE_CASE = 1 << 1;
const ELEMENT_IS_INPUT = 1 << 2;

const UNINITIALIZED = Symbol();

// Dev-time component properties
const FILENAME = Symbol('filename');
const HMR = Symbol('hmr');

const NAMESPACE_HTML = 'http://www.w3.org/1999/xhtml';
const NAMESPACE_SVG = 'http://www.w3.org/2000/svg';
const NAMESPACE_MATHML = 'http://www.w3.org/1998/Math/MathML';

// we use a list of ignorable runtime warnings because not every runtime warning
// can be ignored and we want to keep the validation for svelte-ignore in place
const IGNORABLE_RUNTIME_WARNINGS = /** @type {const} */ ([
	'await_waterfall',
	'await_reactivity_loss',
	'state_snapshot_uncloneable',
	'binding_property_non_reactive',
	'hydration_attribute_changed',
	'hydration_html_changed',
	'ownership_invalid_binding',
	'ownership_invalid_mutation'
]);

/**
 * Whitespace inside one of these elements will not result in
 * a whitespace node being created in any circumstances. (This
 * list is almost certainly very incomplete)
 * TODO this is currently unused
 */
const ELEMENTS_WITHOUT_TEXT = ['audio', 'datalist', 'dl', 'optgroup', 'select', 'video'];

const ATTACHMENT_KEY = '@attach';


}),
193: 
/*!*****************************************************!*\
  !*** ../../node_modules/svelte/src/index-client.js ***!
  \*****************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  mount: () => (/* reexport safe */ _internal_client_render_js__WEBPACK_IMPORTED_MODULE_7__.mount),
  untrack: () => (/* reexport safe */ _internal_client_runtime_js__WEBPACK_IMPORTED_MODULE_0__.untrack)
});
/* import */var _internal_client_runtime_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./internal/client/runtime.js */ 5551);
/* import */var _internal_shared_utils_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./internal/shared/utils.js */ 2060);
/* import */var _internal_client_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./internal/client/index.js */ 3781);
/* import */var _internal_client_errors_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./internal/client/errors.js */ 1152);
/* import */var _internal_flags_index_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./internal/flags/index.js */ 9987);
/* import */var _internal_client_context_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./internal/client/context.js */ 2204);
/* import */var esm_env__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! esm-env */ 3990);
/* import */var _internal_client_reactivity_batch_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./internal/client/reactivity/batch.js */ 5812);
/* import */var _internal_client_render_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./internal/client/render.js */ 5891);
/* import */var _internal_client_dom_blocks_snippet_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./internal/client/dom/blocks/snippet.js */ 5954);
/** @import { ComponentContext, ComponentContextLegacy } from '#client' */
/** @import { EventDispatcher } from './index.js' */
/** @import { NotFunction } from './internal/types.js' */








if (esm_env__WEBPACK_IMPORTED_MODULE_5__.DEV) {
	/**
	 * @param {string} rune
	 */
	function throw_rune_error(rune) {
		if (!(rune in globalThis)) {
			// TODO if people start adjusting the "this can contain runes" config through v-p-s more, adjust this message
			/** @type {any} */
			let value; // let's hope noone modifies this global, but belts and braces
			Object.defineProperty(globalThis, rune, {
				configurable: true,
				// eslint-disable-next-line getter-return
				get: () => {
					if (value !== undefined) {
						return value;
					}

					_internal_client_errors_js__WEBPACK_IMPORTED_MODULE_3__.rune_outside_svelte(rune);
				},
				set: (v) => {
					value = v;
				}
			});
		}
	}

	throw_rune_error('$state');
	throw_rune_error('$effect');
	throw_rune_error('$derived');
	throw_rune_error('$inspect');
	throw_rune_error('$props');
	throw_rune_error('$bindable');
}

/**
 * Returns an [`AbortSignal`](https://developer.mozilla.org/en-US/docs/Web/API/AbortSignal) that aborts when the current [derived](https://svelte.dev/docs/svelte/$derived) or [effect](https://svelte.dev/docs/svelte/$effect) re-runs or is destroyed.
 *
 * Must be called while a derived or effect is running.
 *
 * ```svelte
 * <script>
 * 	import { getAbortSignal } from 'svelte';
 *
 * 	let { id } = $props();
 *
 * 	async function getData(id) {
 * 		const response = await fetch(`/items/${id}`, {
 * 			signal: getAbortSignal()
 * 		});
 *
 * 		return await response.json();
 * 	}
 *
 * 	const data = $derived(await getData(id));
 * </script>
 * ```
 */
function getAbortSignal() {
	if (_internal_client_runtime_js__WEBPACK_IMPORTED_MODULE_0__.active_reaction === null) {
		_internal_client_errors_js__WEBPACK_IMPORTED_MODULE_3__.get_abort_signal_outside_reaction();
	}

	return (_internal_client_runtime_js__WEBPACK_IMPORTED_MODULE_0__.active_reaction.ac ??= new AbortController()).signal;
}

/**
 * `onMount`, like [`$effect`](https://svelte.dev/docs/svelte/$effect), schedules a function to run as soon as the component has been mounted to the DOM.
 * Unlike `$effect`, the provided function only runs once.
 *
 * It must be called during the component's initialisation (but doesn't need to live _inside_ the component;
 * it can be called from an external module). If a function is returned _synchronously_ from `onMount`,
 * it will be called when the component is unmounted.
 *
 * `onMount` functions do not run during [server-side rendering](https://svelte.dev/docs/svelte/svelte-server#render).
 *
 * @template T
 * @param {() => NotFunction<T> | Promise<NotFunction<T>> | (() => any)} fn
 * @returns {void}
 */
function onMount(fn) {
	if (_internal_client_context_js__WEBPACK_IMPORTED_MODULE_4__.component_context === null) {
		_internal_client_errors_js__WEBPACK_IMPORTED_MODULE_3__.lifecycle_outside_component('onMount');
	}

	if (_internal_flags_index_js__WEBPACK_IMPORTED_MODULE_9__.legacy_mode_flag && _internal_client_context_js__WEBPACK_IMPORTED_MODULE_4__.component_context.l !== null) {
		init_update_callbacks(_internal_client_context_js__WEBPACK_IMPORTED_MODULE_4__.component_context).m.push(fn);
	} else {
		(0,_internal_client_index_js__WEBPACK_IMPORTED_MODULE_2__.user_effect)(() => {
			const cleanup = (0,_internal_client_runtime_js__WEBPACK_IMPORTED_MODULE_0__.untrack)(fn);
			if (typeof cleanup === 'function') return /** @type {() => void} */ (cleanup);
		});
	}
}

/**
 * Schedules a callback to run immediately before the component is unmounted.
 *
 * Out of `onMount`, `beforeUpdate`, `afterUpdate` and `onDestroy`, this is the
 * only one that runs inside a server-side component.
 *
 * @param {() => any} fn
 * @returns {void}
 */
function onDestroy(fn) {
	if (_internal_client_context_js__WEBPACK_IMPORTED_MODULE_4__.component_context === null) {
		_internal_client_errors_js__WEBPACK_IMPORTED_MODULE_3__.lifecycle_outside_component('onDestroy');
	}

	onMount(() => () => (0,_internal_client_runtime_js__WEBPACK_IMPORTED_MODULE_0__.untrack)(fn));
}

/**
 * @template [T=any]
 * @param {string} type
 * @param {T} [detail]
 * @param {any}params_0
 * @returns {CustomEvent<T>}
 */
function create_custom_event(type, detail, { bubbles = false, cancelable = false } = {}) {
	return new CustomEvent(type, { detail, bubbles, cancelable });
}

/**
 * Creates an event dispatcher that can be used to dispatch [component events](https://svelte.dev/docs/svelte/legacy-on#Component-events).
 * Event dispatchers are functions that can take two arguments: `name` and `detail`.
 *
 * Component events created with `createEventDispatcher` create a
 * [CustomEvent](https://developer.mozilla.org/en-US/docs/Web/API/CustomEvent).
 * These events do not [bubble](https://developer.mozilla.org/en-US/docs/Learn/JavaScript/Building_blocks/Events#Event_bubbling_and_capture).
 * The `detail` argument corresponds to the [CustomEvent.detail](https://developer.mozilla.org/en-US/docs/Web/API/CustomEvent/detail)
 * property and can contain any type of data.
 *
 * The event dispatcher can be typed to narrow the allowed event names and the type of the `detail` argument:
 * ```ts
 * const dispatch = createEventDispatcher<{
 *  loaded: null; // does not take a detail argument
 *  change: string; // takes a detail argument of type string, which is required
 *  optional: number | null; // takes an optional detail argument of type number
 * }>();
 * ```
 *
 * @deprecated Use callback props and/or the `$host()` rune instead — see [migration guide](https://svelte.dev/docs/svelte/v5-migration-guide#Event-changes-Component-events)
 * @template {Record<string, any>} [EventMap = any]
 * @returns {EventDispatcher<EventMap>}
 */
function createEventDispatcher() {
	const active_component_context = _internal_client_context_js__WEBPACK_IMPORTED_MODULE_4__.component_context;
	if (active_component_context === null) {
		_internal_client_errors_js__WEBPACK_IMPORTED_MODULE_3__.lifecycle_outside_component('createEventDispatcher');
	}

	/**
	 * @param [detail]
	 * @param [options]
	 */
	return (type, detail, options) => {
		const events = /** @type {Record<string, Function | Function[]>} */ (
			active_component_context.s.$$events
		)?.[/** @type {string} */ (type)];

		if (events) {
			const callbacks = (0,_internal_shared_utils_js__WEBPACK_IMPORTED_MODULE_1__.is_array)(events) ? events.slice() : [events];
			// TODO are there situations where events could be dispatched
			// in a server (non-DOM) environment?
			const event = create_custom_event(/** @type {string} */ (type), detail, options);
			for (const fn of callbacks) {
				fn.call(active_component_context.x, event);
			}
			return !event.defaultPrevented;
		}

		return true;
	};
}

// TODO mark beforeUpdate and afterUpdate as deprecated in Svelte 6

/**
 * Schedules a callback to run immediately before the component is updated after any state change.
 *
 * The first time the callback runs will be before the initial `onMount`.
 *
 * In runes mode use `$effect.pre` instead.
 *
 * @deprecated Use [`$effect.pre`](https://svelte.dev/docs/svelte/$effect#$effect.pre) instead
 * @param {() => void} fn
 * @returns {void}
 */
function beforeUpdate(fn) {
	if (_internal_client_context_js__WEBPACK_IMPORTED_MODULE_4__.component_context === null) {
		_internal_client_errors_js__WEBPACK_IMPORTED_MODULE_3__.lifecycle_outside_component('beforeUpdate');
	}

	if (_internal_client_context_js__WEBPACK_IMPORTED_MODULE_4__.component_context.l === null) {
		_internal_client_errors_js__WEBPACK_IMPORTED_MODULE_3__.lifecycle_legacy_only('beforeUpdate');
	}

	init_update_callbacks(_internal_client_context_js__WEBPACK_IMPORTED_MODULE_4__.component_context).b.push(fn);
}

/**
 * Schedules a callback to run immediately after the component has been updated.
 *
 * The first time the callback runs will be after the initial `onMount`.
 *
 * In runes mode use `$effect` instead.
 *
 * @deprecated Use [`$effect`](https://svelte.dev/docs/svelte/$effect) instead
 * @param {() => void} fn
 * @returns {void}
 */
function afterUpdate(fn) {
	if (_internal_client_context_js__WEBPACK_IMPORTED_MODULE_4__.component_context === null) {
		_internal_client_errors_js__WEBPACK_IMPORTED_MODULE_3__.lifecycle_outside_component('afterUpdate');
	}

	if (_internal_client_context_js__WEBPACK_IMPORTED_MODULE_4__.component_context.l === null) {
		_internal_client_errors_js__WEBPACK_IMPORTED_MODULE_3__.lifecycle_legacy_only('afterUpdate');
	}

	init_update_callbacks(_internal_client_context_js__WEBPACK_IMPORTED_MODULE_4__.component_context).a.push(fn);
}

/**
 * Legacy-mode: Init callbacks object for onMount/beforeUpdate/afterUpdate
 * @param {ComponentContext} context
 */
function init_update_callbacks(context) {
	var l = /** @type {ComponentContextLegacy} */ (context).l;
	return (l.u ??= { a: [], b: [], m: [] });
}








}),
5818: 
/*!******************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/constants.js ***!
  \******************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  ASYNC: () => (ASYNC),
  BLOCK_EFFECT: () => (BLOCK_EFFECT),
  BOUNDARY_EFFECT: () => (BOUNDARY_EFFECT),
  BRANCH_EFFECT: () => (BRANCH_EFFECT),
  CLEAN: () => (CLEAN),
  COMMENT_NODE: () => (COMMENT_NODE),
  CONNECTED: () => (CONNECTED),
  DERIVED: () => (DERIVED),
  DESTROYED: () => (DESTROYED),
  DIRTY: () => (DIRTY),
  DOCUMENT_FRAGMENT_NODE: () => (DOCUMENT_FRAGMENT_NODE),
  EAGER_EFFECT: () => (EAGER_EFFECT),
  EFFECT: () => (EFFECT),
  EFFECT_PRESERVED: () => (EFFECT_PRESERVED),
  EFFECT_RAN: () => (EFFECT_RAN),
  EFFECT_TRANSPARENT: () => (EFFECT_TRANSPARENT),
  ELEMENT_NODE: () => (ELEMENT_NODE),
  ERROR_VALUE: () => (ERROR_VALUE),
  HEAD_EFFECT: () => (HEAD_EFFECT),
  INERT: () => (INERT),
  LEGACY_PROPS: () => (LEGACY_PROPS),
  LOADING_ATTR_SYMBOL: () => (LOADING_ATTR_SYMBOL),
  MAYBE_DIRTY: () => (MAYBE_DIRTY),
  PROXY_PATH_SYMBOL: () => (PROXY_PATH_SYMBOL),
  REACTION_IS_UPDATING: () => (REACTION_IS_UPDATING),
  RENDER_EFFECT: () => (RENDER_EFFECT),
  ROOT_EFFECT: () => (ROOT_EFFECT),
  STALE_REACTION: () => (STALE_REACTION),
  STATE_SYMBOL: () => (STATE_SYMBOL),
  TEXT_NODE: () => (TEXT_NODE),
  USER_EFFECT: () => (USER_EFFECT),
  WAS_MARKED: () => (WAS_MARKED)
});
// General flags
const DERIVED = 1 << 1;
const EFFECT = 1 << 2;
const RENDER_EFFECT = 1 << 3;
const BLOCK_EFFECT = 1 << 4;
const BRANCH_EFFECT = 1 << 5;
const ROOT_EFFECT = 1 << 6;
const BOUNDARY_EFFECT = 1 << 7;
/**
 * Indicates that a reaction is connected to an effect root — either it is an effect,
 * or it is a derived that is depended on by at least one effect. If a derived has
 * no dependents, we can disconnect it from the graph, allowing it to either be
 * GC'd or reconnected later if an effect comes to depend on it again
 */
const CONNECTED = 1 << 9;
const CLEAN = 1 << 10;
const DIRTY = 1 << 11;
const MAYBE_DIRTY = 1 << 12;
const INERT = 1 << 13;
const DESTROYED = 1 << 14;

// Flags exclusive to effects
/** Set once an effect that should run synchronously has run */
const EFFECT_RAN = 1 << 15;
/**
 * 'Transparent' effects do not create a transition boundary.
 * This is on a block effect 99% of the time but may also be on a branch effect if its parent block effect was pruned
 */
const EFFECT_TRANSPARENT = 1 << 16;
const EAGER_EFFECT = 1 << 17;
const HEAD_EFFECT = 1 << 18;
const EFFECT_PRESERVED = 1 << 19;
const USER_EFFECT = 1 << 20;

// Flags exclusive to deriveds
/**
 * Tells that we marked this derived and its reactions as visited during the "mark as (maybe) dirty"-phase.
 * Will be lifted during execution of the derived and during checking its dirty state (both are necessary
 * because a derived might be checked but not executed).
 */
const WAS_MARKED = 1 << 15;

// Flags used for async
const REACTION_IS_UPDATING = 1 << 21;
const ASYNC = 1 << 22;

const ERROR_VALUE = 1 << 23;

const STATE_SYMBOL = Symbol('$state');
const LEGACY_PROPS = Symbol('legacy props');
const LOADING_ATTR_SYMBOL = Symbol('');
const PROXY_PATH_SYMBOL = Symbol('proxy path');

/** allow users to ignore aborted signal errors if `reason.name === 'StaleReactionError` */
const STALE_REACTION = new (class StaleReactionError extends Error {
	name = 'StaleReactionError';
	message = 'The reaction that called `getAbortSignal()` was re-run or destroyed';
})();

const ELEMENT_NODE = 1;
const TEXT_NODE = 3;
const COMMENT_NODE = 8;
const DOCUMENT_FRAGMENT_NODE = 11;


}),
2204: 
/*!****************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/context.js ***!
  \****************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  component_context: () => (component_context),
  dev_current_component_function: () => (dev_current_component_function),
  dev_stack: () => (dev_stack),
  is_runes: () => (is_runes),
  pop: () => (pop),
  push: () => (push),
  set_component_context: () => (set_component_context),
  set_dev_current_component_function: () => (set_dev_current_component_function),
  set_dev_stack: () => (set_dev_stack)
});
/* import */var esm_env__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! esm-env */ 3990);
/* import */var _errors_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./errors.js */ 1152);
/* import */var _runtime_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./runtime.js */ 5551);
/* import */var _reactivity_effects_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./reactivity/effects.js */ 7770);
/* import */var _flags_index_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../flags/index.js */ 9987);
/* import */var _constants_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../constants.js */ 7164);
/* import */var _constants_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./constants.js */ 5818);
/** @import { ComponentContext, DevStackEntry, Effect } from '#client' */








/** @type {ComponentContext | null} */
let component_context = null;

/** @param {ComponentContext | null} context */
function set_component_context(context) {
	component_context = context;
}

/** @type {DevStackEntry | null} */
let dev_stack = null;

/** @param {DevStackEntry | null} stack */
function set_dev_stack(stack) {
	dev_stack = stack;
}

/**
 * Execute a callback with a new dev stack entry
 * @param {() => any} callback - Function to execute
 * @param {DevStackEntry['type']} type - Type of block/component
 * @param {any} component - Component function
 * @param {number} line - Line number
 * @param {number} column - Column number
 * @param {Record<string, any>} [additional] - Any additional properties to add to the dev stack entry
 * @returns {any}
 */
function add_svelte_meta(callback, type, component, line, column, additional) {
	const parent = dev_stack;

	dev_stack = {
		type,
		file: component[_constants_js__WEBPACK_IMPORTED_MODULE_4__.FILENAME],
		line,
		column,
		parent,
		...additional
	};

	try {
		return callback();
	} finally {
		dev_stack = parent;
	}
}

/**
 * The current component function. Different from current component context:
 * ```html
 * <!-- App.svelte -->
 * <Foo>
 *   <Bar /> <!-- context == Foo.svelte, function == App.svelte -->
 * </Foo>
 * ```
 * @type {ComponentContext['function']}
 */
let dev_current_component_function = null;

/** @param {ComponentContext['function']} fn */
function set_dev_current_component_function(fn) {
	dev_current_component_function = fn;
}

/**
 * Returns a `[get, set]` pair of functions for working with context in a type-safe way.
 *
 * `get` will throw an error if no parent component called `set`.
 *
 * @template T
 * @returns {[() => T, (context: T) => T]}
 * @since 5.40.0
 */
function createContext() {
	const key = {};

	return [
		() => {
			if (!hasContext(key)) {
				_errors_js__WEBPACK_IMPORTED_MODULE_1__.missing_context();
			}

			return getContext(key);
		},
		(context) => setContext(key, context)
	];
}

/**
 * Retrieves the context that belongs to the closest parent component with the specified `key`.
 * Must be called during component initialisation.
 *
 * [`createContext`](https://svelte.dev/docs/svelte/svelte#createContext) is a type-safe alternative.
 *
 * @template T
 * @param {any} key
 * @returns {T}
 */
function getContext(key) {
	const context_map = get_or_init_context_map('getContext');
	const result = /** @type {T} */ (context_map.get(key));
	return result;
}

/**
 * Associates an arbitrary `context` object with the current component and the specified `key`
 * and returns that object. The context is then available to children of the component
 * (including slotted content) with `getContext`.
 *
 * Like lifecycle functions, this must be called during component initialisation.
 *
 * [`createContext`](https://svelte.dev/docs/svelte/svelte#createContext) is a type-safe alternative.
 *
 * @template T
 * @param {any} key
 * @param {T} context
 * @returns {T}
 */
function setContext(key, context) {
	const context_map = get_or_init_context_map('setContext');

	if (_flags_index_js__WEBPACK_IMPORTED_MODULE_6__.async_mode_flag) {
		var flags = /** @type {Effect} */ _runtime_js__WEBPACK_IMPORTED_MODULE_2__.active_effect.f;
		var valid =
			!_runtime_js__WEBPACK_IMPORTED_MODULE_2__.active_reaction &&
			(flags & _constants_js__WEBPACK_IMPORTED_MODULE_5__.BRANCH_EFFECT) !== 0 &&
			// pop() runs synchronously, so this indicates we're setting context after an await
			!(/** @type {ComponentContext} */ (component_context).i);

		if (!valid) {
			_errors_js__WEBPACK_IMPORTED_MODULE_1__.set_context_after_init();
		}
	}

	context_map.set(key, context);
	return context;
}

/**
 * Checks whether a given `key` has been set in the context of a parent component.
 * Must be called during component initialisation.
 *
 * @param {any} key
 * @returns {boolean}
 */
function hasContext(key) {
	const context_map = get_or_init_context_map('hasContext');
	return context_map.has(key);
}

/**
 * Retrieves the whole context map that belongs to the closest parent component.
 * Must be called during component initialisation. Useful, for example, if you
 * programmatically create a component and want to pass the existing context to it.
 *
 * @template {Map<any, any>} [T=Map<any, any>]
 * @returns {T}
 */
function getAllContexts() {
	const context_map = get_or_init_context_map('getAllContexts');
	return /** @type {T} */ (context_map);
}

/**
 * @param {Record<string, unknown>} props
 * @param {any} runes
 * @param {Function} [fn]
 * @returns {void}
 */
function push(props, runes = false, fn) {
	component_context = {
		p: component_context,
		i: false,
		c: null,
		e: null,
		s: props,
		x: null,
		l: _flags_index_js__WEBPACK_IMPORTED_MODULE_6__.legacy_mode_flag && !runes ? { s: null, u: null, $: [] } : null
	};

	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		// component function
		component_context.function = fn;
		dev_current_component_function = fn;
	}
}

/**
 * @template {Record<string, any>} T
 * @param {T} [component]
 * @returns {T}
 */
function pop(component) {
	var context = /** @type {ComponentContext} */ (component_context);
	var effects = context.e;

	if (effects !== null) {
		context.e = null;

		for (var fn of effects) {
			(0,_reactivity_effects_js__WEBPACK_IMPORTED_MODULE_3__.create_user_effect)(fn);
		}
	}

	if (component !== undefined) {
		context.x = component;
	}

	context.i = true;

	component_context = context.p;

	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		dev_current_component_function = component_context?.function ?? null;
	}

	return component ?? /** @type {T} */ ({});
}

/** @returns {boolean} */
function is_runes() {
	return !_flags_index_js__WEBPACK_IMPORTED_MODULE_6__.legacy_mode_flag || (component_context !== null && component_context.l === null);
}

/**
 * @param {string} name
 * @returns {Map<unknown, unknown>}
 */
function get_or_init_context_map(name) {
	if (component_context === null) {
		_errors_js__WEBPACK_IMPORTED_MODULE_1__.lifecycle_outside_component(name);
	}

	return (component_context.c ??= new Map(get_parent_context(component_context) || undefined));
}

/**
 * @param {ComponentContext} component_context
 * @returns {Map<unknown, unknown> | null}
 */
function get_parent_context(component_context) {
	let parent = component_context.p;
	while (parent !== null) {
		const context_map = parent.c;
		if (context_map !== null) {
			return context_map;
		}
		parent = parent.p;
	}
	return null;
}


}),
9911: 
/*!*********************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/dev/equality.js ***!
  \*********************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  init_array_prototype_warnings: () => (init_array_prototype_warnings),
  strict_equals: () => (strict_equals)
});
/* import */var _warnings_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../warnings.js */ 8658);
/* import */var _proxy_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../proxy.js */ 4899);



function init_array_prototype_warnings() {
	const array_prototype = Array.prototype;
	// The REPL ends up here over and over, and this prevents it from adding more and more patches
	// of the same kind to the prototype, which would slow down everything over time.
	// @ts-expect-error
	const cleanup = Array.__svelte_cleanup;
	if (cleanup) {
		cleanup();
	}

	const { indexOf, lastIndexOf, includes } = array_prototype;

	array_prototype.indexOf = function (item, from_index) {
		const index = indexOf.call(this, item, from_index);

		if (index === -1) {
			for (let i = from_index ?? 0; i < this.length; i += 1) {
				if ((0,_proxy_js__WEBPACK_IMPORTED_MODULE_1__.get_proxied_value)(this[i]) === item) {
					_warnings_js__WEBPACK_IMPORTED_MODULE_0__.state_proxy_equality_mismatch('array.indexOf(...)');
					break;
				}
			}
		}

		return index;
	};

	array_prototype.lastIndexOf = function (item, from_index) {
		// we need to specify this.length - 1 because it's probably using something like
		// `arguments` inside so passing undefined is different from not passing anything
		const index = lastIndexOf.call(this, item, from_index ?? this.length - 1);

		if (index === -1) {
			for (let i = 0; i <= (from_index ?? this.length - 1); i += 1) {
				if ((0,_proxy_js__WEBPACK_IMPORTED_MODULE_1__.get_proxied_value)(this[i]) === item) {
					_warnings_js__WEBPACK_IMPORTED_MODULE_0__.state_proxy_equality_mismatch('array.lastIndexOf(...)');
					break;
				}
			}
		}

		return index;
	};

	array_prototype.includes = function (item, from_index) {
		const has = includes.call(this, item, from_index);

		if (!has) {
			for (let i = 0; i < this.length; i += 1) {
				if ((0,_proxy_js__WEBPACK_IMPORTED_MODULE_1__.get_proxied_value)(this[i]) === item) {
					_warnings_js__WEBPACK_IMPORTED_MODULE_0__.state_proxy_equality_mismatch('array.includes(...)');
					break;
				}
			}
		}

		return has;
	};

	// @ts-expect-error
	Array.__svelte_cleanup = () => {
		array_prototype.indexOf = indexOf;
		array_prototype.lastIndexOf = lastIndexOf;
		array_prototype.includes = includes;
	};
}

/**
 * @param {any} a
 * @param {any} b
 * @param {boolean} equal
 * @returns {boolean}
 */
function strict_equals(a, b, equal = true) {
	// try-catch needed because this tries to read properties of `a` and `b`,
	// which could be disallowed for example in a secure context
	try {
		if ((a === b) !== ((0,_proxy_js__WEBPACK_IMPORTED_MODULE_1__.get_proxied_value)(a) === (0,_proxy_js__WEBPACK_IMPORTED_MODULE_1__.get_proxied_value)(b))) {
			_warnings_js__WEBPACK_IMPORTED_MODULE_0__.state_proxy_equality_mismatch(equal ? '===' : '!==');
		}
	} catch {}

	return (a === b) === equal;
}

/**
 * @param {any} a
 * @param {any} b
 * @param {boolean} equal
 * @returns {boolean}
 */
function equals(a, b, equal = true) {
	if ((a == b) !== ((0,_proxy_js__WEBPACK_IMPORTED_MODULE_1__.get_proxied_value)(a) == (0,_proxy_js__WEBPACK_IMPORTED_MODULE_1__.get_proxied_value)(b))) {
		_warnings_js__WEBPACK_IMPORTED_MODULE_0__.state_proxy_equality_mismatch(equal ? '==' : '!=');
	}

	return (a == b) === equal;
}


}),
6265: 
/*!********************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/dev/tracing.js ***!
  \********************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  get_stack: () => (get_stack),
  tag: () => (tag),
  tag_proxy: () => (tag_proxy),
  tracing_expressions: () => (tracing_expressions)
});
/* import */var _constants_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../constants.js */ 7164);
/* import */var _shared_clone_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../shared/clone.js */ 444);
/* import */var _shared_utils_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../shared/utils.js */ 2060);
/* import */var _client_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! #client/constants */ 5818);
/* import */var _reactivity_effects_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../reactivity/effects.js */ 7770);
/* import */var _runtime_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../runtime.js */ 5551);
/** @import { Derived, Reaction, Value } from '#client' */







/**
 * @typedef {{
 *   traces: Error[];
 * }} TraceEntry
 */

/** @type {{ reaction: Reaction | null, entries: Map<Value, TraceEntry> } | null} */
let tracing_expressions = null;

/**
 * @param {Value} signal
 * @param {TraceEntry} [entry]
 */
function log_entry(signal, entry) {
	const value = signal.v;

	if (value === _constants_js__WEBPACK_IMPORTED_MODULE_0__.UNINITIALIZED) {
		return;
	}

	const type = get_type(signal);
	const current_reaction = /** @type {Reaction} */ (_runtime_js__WEBPACK_IMPORTED_MODULE_5__.active_reaction);
	const dirty = signal.wv > current_reaction.wv || current_reaction.wv === 0;
	const style = dirty
		? 'color: CornflowerBlue; font-weight: bold'
		: 'color: grey; font-weight: normal';

	// eslint-disable-next-line no-console
	console.groupCollapsed(
		signal.label ? `%c${type}%c ${signal.label}` : `%c${type}%c`,
		style,
		dirty ? 'font-weight: normal' : style,
		typeof value === 'object' && value !== null && _client_constants__WEBPACK_IMPORTED_MODULE_3__.STATE_SYMBOL in value
			? (0,_shared_clone_js__WEBPACK_IMPORTED_MODULE_1__.snapshot)(value, true)
			: value
	);

	if (type === '$derived') {
		const deps = new Set(/** @type {Derived} */ (signal).deps);
		for (const dep of deps) {
			log_entry(dep);
		}
	}

	if (signal.created) {
		// eslint-disable-next-line no-console
		console.log(signal.created);
	}

	if (dirty && signal.updated) {
		for (const updated of signal.updated.values()) {
			// eslint-disable-next-line no-console
			console.log(updated.error);
		}
	}

	if (entry) {
		for (var trace of entry.traces) {
			// eslint-disable-next-line no-console
			console.log(trace);
		}
	}

	// eslint-disable-next-line no-console
	console.groupEnd();
}

/**
 * @param {Value} signal
 * @returns {'$state' | '$derived' | 'store'}
 */
function get_type(signal) {
	if ((signal.f & (_client_constants__WEBPACK_IMPORTED_MODULE_3__.DERIVED | _client_constants__WEBPACK_IMPORTED_MODULE_3__.ASYNC)) !== 0) return '$derived';
	return signal.label?.startsWith('$') ? 'store' : '$state';
}

/**
 * @template T
 * @param {() => string} label
 * @param {() => T} fn
 */
function trace(label, fn) {
	var previously_tracing_expressions = tracing_expressions;

	try {
		tracing_expressions = { entries: new Map(), reaction: _runtime_js__WEBPACK_IMPORTED_MODULE_5__.active_reaction };

		var start = performance.now();
		var value = fn();
		var time = (performance.now() - start).toFixed(2);

		var prefix = (0,_runtime_js__WEBPACK_IMPORTED_MODULE_5__.untrack)(label);

		if (!(0,_reactivity_effects_js__WEBPACK_IMPORTED_MODULE_4__.effect_tracking)()) {
			// eslint-disable-next-line no-console
			console.log(`${prefix} %cran outside of an effect (${time}ms)`, 'color: grey');
		} else if (tracing_expressions.entries.size === 0) {
			// eslint-disable-next-line no-console
			console.log(`${prefix} %cno reactive dependencies (${time}ms)`, 'color: grey');
		} else {
			// eslint-disable-next-line no-console
			console.group(`${prefix} %c(${time}ms)`, 'color: grey');

			var entries = tracing_expressions.entries;

			(0,_runtime_js__WEBPACK_IMPORTED_MODULE_5__.untrack)(() => {
				for (const [signal, traces] of entries) {
					log_entry(signal, traces);
				}
			});

			tracing_expressions = null;

			// eslint-disable-next-line no-console
			console.groupEnd();
		}

		return value;
	} finally {
		tracing_expressions = previously_tracing_expressions;
	}
}

/**
 * @param {string} label
 * @returns {Error & { stack: string } | null}
 */
function get_stack(label) {
	// @ts-ignore stackTraceLimit doesn't exist everywhere
	const limit = Error.stackTraceLimit;

	// @ts-ignore
	Error.stackTraceLimit = Infinity;
	let error = Error();

	// @ts-ignore
	Error.stackTraceLimit = limit;

	const stack = error.stack;

	if (!stack) return null;

	const lines = stack.split('\n');
	const new_lines = ['\n'];

	for (let i = 0; i < lines.length; i++) {
		const line = lines[i];
		const posixified = line.replaceAll('\\', '/');

		if (line === 'Error') {
			continue;
		}

		if (line.includes('validate_each_keys')) {
			return null;
		}

		if (posixified.includes('svelte/src/internal') || posixified.includes('node_modules/.vite')) {
			continue;
		}

		new_lines.push(line);
	}

	if (new_lines.length === 1) {
		return null;
	}

	(0,_shared_utils_js__WEBPACK_IMPORTED_MODULE_2__.define_property)(error, 'stack', {
		value: new_lines.join('\n')
	});

	(0,_shared_utils_js__WEBPACK_IMPORTED_MODULE_2__.define_property)(error, 'name', {
		value: label
	});

	return /** @type {Error & { stack: string }} */ (error);
}

/**
 * @param {Value} source
 * @param {string} label
 */
function tag(source, label) {
	source.label = label;
	tag_proxy(source.v, label);

	return source;
}

/**
 * @param {unknown} value
 * @param {string} label
 */
function tag_proxy(value, label) {
	// @ts-expect-error
	value?.[_client_constants__WEBPACK_IMPORTED_MODULE_3__.PROXY_PATH_SYMBOL]?.(label);
	return value;
}

/**
 * @param {unknown} value
 */
function label(value) {
	if (typeof value === 'symbol') return `Symbol(${value.description})`;
	if (typeof value === 'function') return '<function>';
	if (typeof value === 'object' && value) return '<object>';
	return String(value);
}


}),
9478: 
/*!****************************************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/dom/blocks/boundary.js + 1 modules ***!
  \****************************************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  boundary: () => (/* binding */ boundary_boundary),
  get_boundary: () => (/* binding */ get_boundary)
});

// UNUSED EXPORTS: Boundary, pending

// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/constants.js
var constants = __webpack_require__(5818);
// EXTERNAL MODULE: ../../node_modules/svelte/src/constants.js
var src_constants = __webpack_require__(7164);
// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/context.js
var context = __webpack_require__(2204);
// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/error-handling.js
var error_handling = __webpack_require__(2219);
// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/reactivity/effects.js
var effects = __webpack_require__(7770);
// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/runtime.js
var runtime = __webpack_require__(5551);
// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/dom/hydration.js
var hydration = __webpack_require__(5742);
// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/dom/task.js
var task = __webpack_require__(7643);
// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/errors.js
var errors = __webpack_require__(1152);
// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/warnings.js
var warnings = __webpack_require__(8658);
// EXTERNAL MODULE: ../../node_modules/esm-env/index.js + 2 modules
var esm_env = __webpack_require__(3990);
// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/reactivity/batch.js
var batch = __webpack_require__(5812);
// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/reactivity/sources.js
var sources = __webpack_require__(6718);
// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/dev/tracing.js
var tracing = __webpack_require__(6265);
;// CONCATENATED MODULE: ../../node_modules/svelte/src/reactivity/create-subscriber.js







/**
 * Returns a `subscribe` function that integrates external event-based systems with Svelte's reactivity.
 * It's particularly useful for integrating with web APIs like `MediaQuery`, `IntersectionObserver`, or `WebSocket`.
 *
 * If `subscribe` is called inside an effect (including indirectly, for example inside a getter),
 * the `start` callback will be called with an `update` function. Whenever `update` is called, the effect re-runs.
 *
 * If `start` returns a cleanup function, it will be called when the effect is destroyed.
 *
 * If `subscribe` is called in multiple effects, `start` will only be called once as long as the effects
 * are active, and the returned teardown function will only be called when all effects are destroyed.
 *
 * It's best understood with an example. Here's an implementation of [`MediaQuery`](https://svelte.dev/docs/svelte/svelte-reactivity#MediaQuery):
 *
 * ```js
 * import { createSubscriber } from 'svelte/reactivity';
 * import { on } from 'svelte/events';
 *
 * export class MediaQuery {
 * 	#query;
 * 	#subscribe;
 *
 * 	constructor(query) {
 * 		this.#query = window.matchMedia(`(${query})`);
 *
 * 		this.#subscribe = createSubscriber((update) => {
 * 			// when the `change` event occurs, re-run any effects that read `this.current`
 * 			const off = on(this.#query, 'change', update);
 *
 * 			// stop listening when all the effects are destroyed
 * 			return () => off();
 * 		});
 * 	}
 *
 * 	get current() {
 * 		// This makes the getter reactive, if read in an effect
 * 		this.#subscribe();
 *
 * 		// Return the current state of the query, whether or not we're in an effect
 * 		return this.#query.matches;
 * 	}
 * }
 * ```
 * @param {(update: () => void) => (() => void) | void} start
 * @since 5.7.0
 */
function createSubscriber(start) {
	let subscribers = 0;
	let version = (0,sources.source)(0);
	/** @type {(() => void) | void} */
	let stop;

	if (esm_env.DEV) {
		(0,tracing.tag)(version, 'createSubscriber version');
	}

	return () => {
		if ((0,effects.effect_tracking)()) {
			(0,runtime.get)(version);

			(0,effects.render_effect)(() => {
				if (subscribers === 0) {
					stop = (0,runtime.untrack)(() => start(() => (0,sources.increment)(version)));
				}

				subscribers += 1;

				return () => {
					(0,task.queue_micro_task)(() => {
						// Only count down after a microtask, else we would reach 0 before our own render effect reruns,
						// but reach 1 again when the tick callback of the prior teardown runs. That would mean we
						// re-subcribe unnecessarily and create a memory leak because the old subscription is never cleaned up.
						subscribers -= 1;

						if (subscribers === 0) {
							stop?.();
							stop = undefined;
							// Increment the version to ensure any dependent deriveds are marked dirty when the subscription is picked up again later.
							// If we didn't do this then the comparison of write versions would determine that the derived has a later version than
							// the subscriber, and it would not be re-run.
							(0,sources.increment)(version);
						}
					});
				};
			});
		}
	};
}

// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/dom/operations.js
var operations = __webpack_require__(6756);
;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/blocks/boundary.js
/** @import { Effect, Source, TemplateNode, } from '#client' */

















/**
 * @typedef {{
 * 	 onerror?: (error: unknown, reset: () => void) => void;
 *   failed?: (anchor: Node, error: () => unknown, reset: () => () => void) => void;
 *   pending?: (anchor: Node) => void;
 * }} BoundaryProps
 */

var flags = constants.EFFECT_TRANSPARENT | constants.EFFECT_PRESERVED | constants.BOUNDARY_EFFECT;

/**
 * @param {TemplateNode} node
 * @param {BoundaryProps} props
 * @param {((anchor: Node) => void)} children
 * @returns {void}
 */
function boundary_boundary(node, props, children) {
	new Boundary(node, props, children);
}

class Boundary {
	/** @type {Boundary | null} */
	parent;

	#pending = false;

	/** @type {TemplateNode} */
	#anchor;

	/** @type {TemplateNode | null} */
	#hydrate_open = hydration.hydrating ? hydration.hydrate_node : null;

	/** @type {BoundaryProps} */
	#props;

	/** @type {((anchor: Node) => void)} */
	#children;

	/** @type {Effect} */
	#effect;

	/** @type {Effect | null} */
	#main_effect = null;

	/** @type {Effect | null} */
	#pending_effect = null;

	/** @type {Effect | null} */
	#failed_effect = null;

	/** @type {DocumentFragment | null} */
	#offscreen_fragment = null;

	/** @type {TemplateNode | null} */
	#pending_anchor = null;

	#local_pending_count = 0;
	#pending_count = 0;

	#is_creating_fallback = false;

	/**
	 * A source containing the number of pending async deriveds/expressions.
	 * Only created if `$effect.pending()` is used inside the boundary,
	 * otherwise updating the source results in needless `Batch.ensure()`
	 * calls followed by no-op flushes
	 * @type {Source<number> | null}
	 */
	#effect_pending = null;

	#effect_pending_subscriber = createSubscriber(() => {
		this.#effect_pending = (0,sources.source)(this.#local_pending_count);

		if (esm_env.DEV) {
			(0,tracing.tag)(this.#effect_pending, '$effect.pending()');
		}

		return () => {
			this.#effect_pending = null;
		};
	});

	/**
	 * @param {TemplateNode} node
	 * @param {BoundaryProps} props
	 * @param {((anchor: Node) => void)} children
	 */
	constructor(node, props, children) {
		this.#anchor = node;
		this.#props = props;
		this.#children = children;

		this.parent = /** @type {Effect} */ runtime.active_effect.b;

		this.#pending = !!this.#props.pending;

		this.#effect = (0,effects.block)(() => {
			/** @type {Effect} */ runtime.active_effect.b = this;

			if (hydration.hydrating) {
				const comment = this.#hydrate_open;
				(0,hydration.hydrate_next)();

				const server_rendered_pending =
					/** @type {Comment} */ (comment).nodeType === constants.COMMENT_NODE &&
					/** @type {Comment} */ (comment).data === src_constants.HYDRATION_START_ELSE;

				if (server_rendered_pending) {
					this.#hydrate_pending_content();
				} else {
					this.#hydrate_resolved_content();
				}
			} else {
				var anchor = this.#get_anchor();

				try {
					this.#main_effect = (0,effects.branch)(() => children(anchor));
				} catch (error) {
					this.error(error);
				}

				if (this.#pending_count > 0) {
					this.#show_pending_snippet();
				} else {
					this.#pending = false;
				}
			}

			return () => {
				this.#pending_anchor?.remove();
			};
		}, flags);

		if (hydration.hydrating) {
			this.#anchor = hydration.hydrate_node;
		}
	}

	#hydrate_resolved_content() {
		try {
			this.#main_effect = (0,effects.branch)(() => this.#children(this.#anchor));
		} catch (error) {
			this.error(error);
		}

		// Since server rendered resolved content, we never show pending state
		// Even if client-side async operations are still running, the content is already displayed
		this.#pending = false;
	}

	#hydrate_pending_content() {
		const pending = this.#props.pending;
		if (!pending) {
			return;
		}
		this.#pending_effect = (0,effects.branch)(() => pending(this.#anchor));

		batch.Batch.enqueue(() => {
			var anchor = this.#get_anchor();

			this.#main_effect = this.#run(() => {
				batch.Batch.ensure();
				return (0,effects.branch)(() => this.#children(anchor));
			});

			if (this.#pending_count > 0) {
				this.#show_pending_snippet();
			} else {
				(0,effects.pause_effect)(/** @type {Effect} */ (this.#pending_effect), () => {
					this.#pending_effect = null;
				});

				this.#pending = false;
			}
		});
	}

	#get_anchor() {
		var anchor = this.#anchor;

		if (this.#pending) {
			this.#pending_anchor = (0,operations.create_text)();
			this.#anchor.before(this.#pending_anchor);

			anchor = this.#pending_anchor;
		}

		return anchor;
	}

	/**
	 * Returns `true` if the effect exists inside a boundary whose pending snippet is shown
	 * @returns {boolean}
	 */
	is_pending() {
		return this.#pending || (!!this.parent && this.parent.is_pending());
	}

	has_pending_snippet() {
		return !!this.#props.pending;
	}

	/**
	 * @param {() => Effect | null} fn
	 */
	#run(fn) {
		var previous_effect = runtime.active_effect;
		var previous_reaction = runtime.active_reaction;
		var previous_ctx = context.component_context;

		(0,runtime.set_active_effect)(this.#effect);
		(0,runtime.set_active_reaction)(this.#effect);
		(0,context.set_component_context)(this.#effect.ctx);

		try {
			return fn();
		} catch (e) {
			(0,error_handling.handle_error)(e);
			return null;
		} finally {
			(0,runtime.set_active_effect)(previous_effect);
			(0,runtime.set_active_reaction)(previous_reaction);
			(0,context.set_component_context)(previous_ctx);
		}
	}

	#show_pending_snippet() {
		const pending = /** @type {(anchor: Node) => void} */ (this.#props.pending);

		if (this.#main_effect !== null) {
			this.#offscreen_fragment = document.createDocumentFragment();
			this.#offscreen_fragment.append(/** @type {TemplateNode} */ (this.#pending_anchor));
			(0,effects.move_effect)(this.#main_effect, this.#offscreen_fragment);
		}

		if (this.#pending_effect === null) {
			this.#pending_effect = (0,effects.branch)(() => pending(this.#anchor));
		}
	}

	/**
	 * Updates the pending count associated with the currently visible pending snippet,
	 * if any, such that we can replace the snippet with content once work is done
	 * @param {1 | -1} d
	 */
	#update_pending_count(d) {
		if (!this.has_pending_snippet()) {
			if (this.parent) {
				this.parent.#update_pending_count(d);
			}

			// if there's no parent, we're in a scope with no pending snippet
			return;
		}

		this.#pending_count += d;

		if (this.#pending_count === 0) {
			this.#pending = false;

			if (this.#pending_effect) {
				(0,effects.pause_effect)(this.#pending_effect, () => {
					this.#pending_effect = null;
				});
			}

			if (this.#offscreen_fragment) {
				this.#anchor.before(this.#offscreen_fragment);
				this.#offscreen_fragment = null;
			}
		}
	}

	/**
	 * Update the source that powers `$effect.pending()` inside this boundary,
	 * and controls when the current `pending` snippet (if any) is removed.
	 * Do not call from inside the class
	 * @param {1 | -1} d
	 */
	update_pending_count(d) {
		this.#update_pending_count(d);

		this.#local_pending_count += d;

		if (this.#effect_pending) {
			(0,sources.internal_set)(this.#effect_pending, this.#local_pending_count);
		}
	}

	get_effect_pending() {
		this.#effect_pending_subscriber();
		return (0,runtime.get)(/** @type {Source<number>} */ (this.#effect_pending));
	}

	/** @param {unknown} error */
	error(error) {
		var onerror = this.#props.onerror;
		let failed = this.#props.failed;

		// If we have nothing to capture the error, or if we hit an error while
		// rendering the fallback, re-throw for another boundary to handle
		if (this.#is_creating_fallback || (!onerror && !failed)) {
			throw error;
		}

		if (this.#main_effect) {
			(0,effects.destroy_effect)(this.#main_effect);
			this.#main_effect = null;
		}

		if (this.#pending_effect) {
			(0,effects.destroy_effect)(this.#pending_effect);
			this.#pending_effect = null;
		}

		if (this.#failed_effect) {
			(0,effects.destroy_effect)(this.#failed_effect);
			this.#failed_effect = null;
		}

		if (hydration.hydrating) {
			(0,hydration.set_hydrate_node)(/** @type {TemplateNode} */ (this.#hydrate_open));
			(0,hydration.next)();
			(0,hydration.set_hydrate_node)((0,hydration.skip_nodes)());
		}

		var did_reset = false;
		var calling_on_error = false;

		const reset = () => {
			if (did_reset) {
				warnings.svelte_boundary_reset_noop();
				return;
			}

			did_reset = true;

			if (calling_on_error) {
				errors.svelte_boundary_reset_onerror();
			}

			// If the failure happened while flushing effects, current_batch can be null
			batch.Batch.ensure();

			this.#local_pending_count = 0;

			if (this.#failed_effect !== null) {
				(0,effects.pause_effect)(this.#failed_effect, () => {
					this.#failed_effect = null;
				});
			}

			// we intentionally do not try to find the nearest pending boundary. If this boundary has one, we'll render it on reset
			// but it would be really weird to show the parent's boundary on a child reset.
			this.#pending = this.has_pending_snippet();

			this.#main_effect = this.#run(() => {
				this.#is_creating_fallback = false;
				return (0,effects.branch)(() => this.#children(this.#anchor));
			});

			if (this.#pending_count > 0) {
				this.#show_pending_snippet();
			} else {
				this.#pending = false;
			}
		};

		var previous_reaction = runtime.active_reaction;

		try {
			(0,runtime.set_active_reaction)(null);
			calling_on_error = true;
			onerror?.(error, reset);
			calling_on_error = false;
		} catch (error) {
			(0,error_handling.invoke_error_boundary)(error, this.#effect && this.#effect.parent);
		} finally {
			(0,runtime.set_active_reaction)(previous_reaction);
		}

		if (failed) {
			(0,task.queue_micro_task)(() => {
				this.#failed_effect = this.#run(() => {
					batch.Batch.ensure();
					this.#is_creating_fallback = true;

					try {
						return (0,effects.branch)(() => {
							failed(
								this.#anchor,
								() => error,
								() => reset
							);
						});
					} catch (error) {
						(0,error_handling.invoke_error_boundary)(error, /** @type {Effect} */ (this.#effect.parent));
						return null;
					} finally {
						this.#is_creating_fallback = false;
					}
				});
			});
		}
	}
}

function get_boundary() {
	return /** @type {Boundary} */ (/** @type {Effect} */ runtime.active_effect.b);
}

function boundary_pending() {
	if (runtime.active_effect === null) {
		errors.effect_pending_outside_reaction();
	}

	var boundary = runtime.active_effect.b;

	if (boundary === null) {
		return 0; // TODO eventually we will need this to be global
	}

	return boundary.get_effect_pending();
}


}),
5783: 
/*!****************************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/dom/blocks/branches.js ***!
  \****************************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  BranchManager: () => (BranchManager)
});
/* import */var _reactivity_batch_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../reactivity/batch.js */ 5812);
/* import */var _reactivity_effects_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../reactivity/effects.js */ 7770);
/* import */var _hydration_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../hydration.js */ 5742);
/* import */var _operations_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../operations.js */ 6756);
/** @import { Effect, TemplateNode } from '#client' */





/**
 * @typedef {{ effect: Effect, fragment: DocumentFragment }} Branch
 */

/**
 * @template Key
 */
class BranchManager {
	/** @type {TemplateNode} */
	anchor;

	/** @type {Map<Batch, Key>} */
	#batches = new Map();

	/** @type {Map<Key, Effect>} */
	#onscreen = new Map();

	/** @type {Map<Key, Branch>} */
	#offscreen = new Map();

	/**
	 * Whether to pause (i.e. outro) on change, or destroy immediately.
	 * This is necessary for `<svelte:element>`
	 */
	#transition = true;

	/**
	 * @param {TemplateNode} anchor
	 * @param {boolean} transition
	 */
	constructor(anchor, transition = true) {
		this.anchor = anchor;
		this.#transition = transition;
	}

	#commit = () => {
		var batch = /** @type {Batch} */ (_reactivity_batch_js__WEBPACK_IMPORTED_MODULE_0__.current_batch);

		// if this batch was made obsolete, bail
		if (!this.#batches.has(batch)) return;

		var key = /** @type {Key} */ (this.#batches.get(batch));

		var onscreen = this.#onscreen.get(key);

		if (onscreen) {
			// effect is already in the DOM — abort any current outro
			(0,_reactivity_effects_js__WEBPACK_IMPORTED_MODULE_1__.resume_effect)(onscreen);
		} else {
			// effect is currently offscreen. put it in the DOM
			var offscreen = this.#offscreen.get(key);

			if (offscreen) {
				this.#onscreen.set(key, offscreen.effect);
				this.#offscreen.delete(key);

				// remove the anchor...
				/** @type {TemplateNode} */ (offscreen.fragment.lastChild).remove();

				// ...and append the fragment
				this.anchor.before(offscreen.fragment);
				onscreen = offscreen.effect;
			}
		}

		for (const [b, k] of this.#batches) {
			this.#batches.delete(b);

			if (b === batch) {
				// keep values for newer batches
				break;
			}

			const offscreen = this.#offscreen.get(k);

			if (offscreen) {
				// for older batches, destroy offscreen effects
				// as they will never be committed
				(0,_reactivity_effects_js__WEBPACK_IMPORTED_MODULE_1__.destroy_effect)(offscreen.effect);
				this.#offscreen.delete(k);
			}
		}

		// outro/destroy all onscreen effects...
		for (const [k, effect] of this.#onscreen) {
			// ...except the one that was just committed
			if (k === key) continue;

			const on_destroy = () => {
				const keys = Array.from(this.#batches.values());

				if (keys.includes(k)) {
					// keep the effect offscreen, as another batch will need it
					var fragment = document.createDocumentFragment();
					(0,_reactivity_effects_js__WEBPACK_IMPORTED_MODULE_1__.move_effect)(effect, fragment);

					fragment.append((0,_operations_js__WEBPACK_IMPORTED_MODULE_3__.create_text)()); // TODO can we avoid this?

					this.#offscreen.set(k, { effect, fragment });
				} else {
					(0,_reactivity_effects_js__WEBPACK_IMPORTED_MODULE_1__.destroy_effect)(effect);
				}

				this.#onscreen.delete(k);
			};

			if (this.#transition || !onscreen) {
				(0,_reactivity_effects_js__WEBPACK_IMPORTED_MODULE_1__.pause_effect)(effect, on_destroy, false);
			} else {
				on_destroy();
			}
		}
	};

	/**
	 * @param {Batch} batch
	 */
	#discard = (batch) => {
		this.#batches.delete(batch);

		const keys = Array.from(this.#batches.values());

		for (const [k, branch] of this.#offscreen) {
			if (!keys.includes(k)) {
				(0,_reactivity_effects_js__WEBPACK_IMPORTED_MODULE_1__.destroy_effect)(branch.effect);
				this.#offscreen.delete(k);
			}
		}
	};

	/**
	 *
	 * @param {any} key
	 * @param {null | ((target: TemplateNode) => void)} fn
	 */
	ensure(key, fn) {
		var batch = /** @type {Batch} */ (_reactivity_batch_js__WEBPACK_IMPORTED_MODULE_0__.current_batch);
		var defer = (0,_operations_js__WEBPACK_IMPORTED_MODULE_3__.should_defer_append)();

		if (fn && !this.#onscreen.has(key) && !this.#offscreen.has(key)) {
			if (defer) {
				var fragment = document.createDocumentFragment();
				var target = (0,_operations_js__WEBPACK_IMPORTED_MODULE_3__.create_text)();

				fragment.append(target);

				this.#offscreen.set(key, {
					effect: (0,_reactivity_effects_js__WEBPACK_IMPORTED_MODULE_1__.branch)(() => fn(target)),
					fragment
				});
			} else {
				this.#onscreen.set(
					key,
					(0,_reactivity_effects_js__WEBPACK_IMPORTED_MODULE_1__.branch)(() => fn(this.anchor))
				);
			}
		}

		this.#batches.set(batch, key);

		if (defer) {
			for (const [k, effect] of this.#onscreen) {
				if (k === key) {
					batch.skipped_effects.delete(effect);
				} else {
					batch.skipped_effects.add(effect);
				}
			}

			for (const [k, branch] of this.#offscreen) {
				if (k === key) {
					batch.skipped_effects.delete(branch.effect);
				} else {
					batch.skipped_effects.add(branch.effect);
				}
			}

			batch.oncommit(this.#commit);
			batch.ondiscard(this.#discard);
		} else {
			if (_hydration_js__WEBPACK_IMPORTED_MODULE_2__.hydrating) {
				this.anchor = _hydration_js__WEBPACK_IMPORTED_MODULE_2__.hydrate_node;
			}

			this.#commit();
		}
	}
}


}),
5954: 
/*!***************************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/dom/blocks/snippet.js ***!
  \***************************************************************************/
(function (__unused_webpack___webpack_module__, __unused_webpack___webpack_exports__, __webpack_require__) {
"use strict";
/* import */var _client_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! #client/constants */ 5818);
/* import */var _reactivity_effects_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../reactivity/effects.js */ 7770);
/* import */var _context_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../context.js */ 2204);
/* import */var _hydration_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../hydration.js */ 5742);
/* import */var _reconciler_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../reconciler.js */ 1876);
/* import */var _template_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../template.js */ 2752);
/* import */var _warnings_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../warnings.js */ 8658);
/* import */var _errors_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../errors.js */ 1152);
/* import */var esm_env__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! esm-env */ 3990);
/* import */var _operations_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../operations.js */ 6756);
/* import */var _shared_validate_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../shared/validate.js */ 987);
/* import */var _branches_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./branches.js */ 5783);
/** @import { Snippet } from 'svelte' */
/** @import { TemplateNode } from '#client' */
/** @import { Getters } from '#shared' */













/**
 * @template {(node: TemplateNode, ...args: any[]) => void} SnippetFn
 * @param {TemplateNode} node
 * @param {() => SnippetFn | null | undefined} get_snippet
 * @param {(() => any)[]} args
 * @returns {void}
 */
function snippet(node, get_snippet, ...args) {
	var branches = new _branches_js__WEBPACK_IMPORTED_MODULE_10__.BranchManager(node);

	(0,_reactivity_effects_js__WEBPACK_IMPORTED_MODULE_1__.block)(() => {
		const snippet = get_snippet() ?? null;

		if (esm_env__WEBPACK_IMPORTED_MODULE_7__.DEV && snippet == null) {
			_errors_js__WEBPACK_IMPORTED_MODULE_6__.invalid_snippet();
		}

		branches.ensure(snippet, snippet && ((anchor) => snippet(anchor, ...args)));
	}, _client_constants__WEBPACK_IMPORTED_MODULE_0__.EFFECT_TRANSPARENT);
}

/**
 * In development, wrap the snippet function so that it passes validation, and so that the
 * correct component context is set for ownership checks
 * @param {any} component
 * @param {(node: TemplateNode, ...args: any[]) => void} fn
 */
function wrap_snippet(component, fn) {
	const snippet = (/** @type {TemplateNode} */ node, /** @type {any[]} */ ...args) => {
		var previous_component_function = _context_js__WEBPACK_IMPORTED_MODULE_2__.dev_current_component_function;
		(0,_context_js__WEBPACK_IMPORTED_MODULE_2__.set_dev_current_component_function)(component);

		try {
			return fn(node, ...args);
		} finally {
			(0,_context_js__WEBPACK_IMPORTED_MODULE_2__.set_dev_current_component_function)(previous_component_function);
		}
	};

	(0,_shared_validate_js__WEBPACK_IMPORTED_MODULE_9__.prevent_snippet_stringification)(snippet);

	return snippet;
}

/**
 * Create a snippet programmatically
 * @template {unknown[]} Params
 * @param {(...params: Getters<Params>) => {
 *   render: () => string
 *   setup?: (element: Element) => void | (() => void)
 * }} fn
 * @returns {Snippet<Params>}
 */
function createRawSnippet(fn) {
	// @ts-expect-error the types are a lie
	return (/** @type {TemplateNode} */ anchor, /** @type {Getters<Params>} */ ...params) => {
		var snippet = fn(...params);

		/** @type {Element} */
		var element;

		if (_hydration_js__WEBPACK_IMPORTED_MODULE_3__.hydrating) {
			element = /** @type {Element} */ (_hydration_js__WEBPACK_IMPORTED_MODULE_3__.hydrate_node);
			(0,_hydration_js__WEBPACK_IMPORTED_MODULE_3__.hydrate_next)();
		} else {
			var html = snippet.render().trim();
			var fragment = (0,_reconciler_js__WEBPACK_IMPORTED_MODULE_11__.create_fragment_from_html)(html);
			element = /** @type {Element} */ ((0,_operations_js__WEBPACK_IMPORTED_MODULE_8__.get_first_child)(fragment));

			if (esm_env__WEBPACK_IMPORTED_MODULE_7__.DEV && ((0,_operations_js__WEBPACK_IMPORTED_MODULE_8__.get_next_sibling)(element) !== null || element.nodeType !== _client_constants__WEBPACK_IMPORTED_MODULE_0__.ELEMENT_NODE)) {
				_warnings_js__WEBPACK_IMPORTED_MODULE_5__.invalid_raw_snippet_render();
			}

			anchor.before(element);
		}

		const result = snippet.setup?.(element);
		(0,_template_js__WEBPACK_IMPORTED_MODULE_4__.assign_nodes)(element, element);

		if (typeof result === 'function') {
			(0,_reactivity_effects_js__WEBPACK_IMPORTED_MODULE_1__.teardown)(result);
		}
	};
}


}),
6766: 
/*!*************************************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/dom/elements/bindings/shared.js ***!
  \*************************************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  listen: () => (listen),
  listen_to_event_and_reset_event: () => (listen_to_event_and_reset_event),
  without_reactive_context: () => (without_reactive_context)
});
/* import */var _reactivity_effects_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../reactivity/effects.js */ 7770);
/* import */var _runtime_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../runtime.js */ 5551);
/* import */var _misc_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../misc.js */ 5030);




/**
 * Fires the handler once immediately (unless corresponding arg is set to `false`),
 * then listens to the given events until the render effect context is destroyed
 * @param {EventTarget} target
 * @param {Array<string>} events
 * @param {(event?: Event) => void} handler
 * @param {any} call_handler_immediately
 */
function listen(target, events, handler, call_handler_immediately = true) {
	if (call_handler_immediately) {
		handler();
	}

	for (var name of events) {
		target.addEventListener(name, handler);
	}

	(0,_reactivity_effects_js__WEBPACK_IMPORTED_MODULE_0__.teardown)(() => {
		for (var name of events) {
			target.removeEventListener(name, handler);
		}
	});
}

/**
 * @template T
 * @param {() => T} fn
 */
function without_reactive_context(fn) {
	var previous_reaction = _runtime_js__WEBPACK_IMPORTED_MODULE_1__.active_reaction;
	var previous_effect = _runtime_js__WEBPACK_IMPORTED_MODULE_1__.active_effect;
	(0,_runtime_js__WEBPACK_IMPORTED_MODULE_1__.set_active_reaction)(null);
	(0,_runtime_js__WEBPACK_IMPORTED_MODULE_1__.set_active_effect)(null);
	try {
		return fn();
	} finally {
		(0,_runtime_js__WEBPACK_IMPORTED_MODULE_1__.set_active_reaction)(previous_reaction);
		(0,_runtime_js__WEBPACK_IMPORTED_MODULE_1__.set_active_effect)(previous_effect);
	}
}

/**
 * Listen to the given event, and then instantiate a global form reset listener if not already done,
 * to notify all bindings when the form is reset
 * @param {HTMLElement} element
 * @param {string} event
 * @param {(is_reset?: true) => void} handler
 * @param {(is_reset?: true) => void} [on_reset]
 */
function listen_to_event_and_reset_event(element, event, handler, on_reset = handler) {
	element.addEventListener(event, () => without_reactive_context(handler));
	// @ts-expect-error
	const prev = element.__on_r;
	if (prev) {
		// special case for checkbox that can have multiple binds (group & checked)
		// @ts-expect-error
		element.__on_r = () => {
			prev();
			on_reset(true);
		};
	} else {
		// @ts-expect-error
		element.__on_r = () => on_reset(true);
	}

	(0,_misc_js__WEBPACK_IMPORTED_MODULE_2__.add_form_reset_listener)();
}


}),
5311: 
/*!****************************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/dom/elements/events.js ***!
  \****************************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  all_registered_events: () => (all_registered_events),
  create_event: () => (create_event),
  delegate: () => (delegate),
  event: () => (event),
  handle_event_propagation: () => (handle_event_propagation),
  on: () => (on),
  root_event_handles: () => (root_event_handles)
});
/* import */var _reactivity_effects_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../reactivity/effects.js */ 7770);
/* import */var _shared_utils_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../shared/utils.js */ 2060);
/* import */var _hydration_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../hydration.js */ 5742);
/* import */var _task_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../task.js */ 7643);
/* import */var _constants_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../constants.js */ 7164);
/* import */var _warnings_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../warnings.js */ 8658);
/* import */var _runtime_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../runtime.js */ 5551);
/* import */var _bindings_shared_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./bindings/shared.js */ 6766);









/** @type {Set<string>} */
const all_registered_events = new Set();

/** @type {Set<(events: Array<string>) => void>} */
const root_event_handles = new Set();

/**
 * SSR adds onload and onerror attributes to catch those events before the hydration.
 * This function detects those cases, removes the attributes and replays the events.
 * @param {HTMLElement} dom
 */
function replay_events(dom) {
	if (!_hydration_js__WEBPACK_IMPORTED_MODULE_2__.hydrating) return;

	dom.removeAttribute('onload');
	dom.removeAttribute('onerror');
	// @ts-expect-error
	const event = dom.__e;
	if (event !== undefined) {
		// @ts-expect-error
		dom.__e = undefined;
		queueMicrotask(() => {
			if (dom.isConnected) {
				dom.dispatchEvent(event);
			}
		});
	}
}

/**
 * @param {string} event_name
 * @param {EventTarget} dom
 * @param {EventListener} [handler]
 * @param {AddEventListenerOptions} [options]
 */
function create_event(event_name, dom, handler, options = {}) {
	/**
	 * @this {EventTarget}
	 */
	function target_handler(/** @type {Event} */ event) {
		if (!options.capture) {
			// Only call in the bubble phase, else delegated events would be called before the capturing events
			handle_event_propagation.call(dom, event);
		}
		if (!event.cancelBubble) {
			return (0,_bindings_shared_js__WEBPACK_IMPORTED_MODULE_7__.without_reactive_context)(() => {
				return handler?.call(this, event);
			});
		}
	}

	// Chrome has a bug where pointer events don't work when attached to a DOM element that has been cloned
	// with cloneNode() and the DOM element is disconnected from the document. To ensure the event works, we
	// defer the attachment till after it's been appended to the document. TODO: remove this once Chrome fixes
	// this bug. The same applies to wheel events and touch events.
	if (
		event_name.startsWith('pointer') ||
		event_name.startsWith('touch') ||
		event_name === 'wheel'
	) {
		(0,_task_js__WEBPACK_IMPORTED_MODULE_3__.queue_micro_task)(() => {
			dom.addEventListener(event_name, target_handler, options);
		});
	} else {
		dom.addEventListener(event_name, target_handler, options);
	}

	return target_handler;
}

/**
 * Attaches an event handler to an element and returns a function that removes the handler. Using this
 * rather than `addEventListener` will preserve the correct order relative to handlers added declaratively
 * (with attributes like `onclick`), which use event delegation for performance reasons
 *
 * @param {EventTarget} element
 * @param {string} type
 * @param {EventListener} handler
 * @param {AddEventListenerOptions} [options]
 */
function on(element, type, handler, options = {}) {
	var target_handler = create_event(type, element, handler, options);

	return () => {
		element.removeEventListener(type, target_handler, options);
	};
}

/**
 * @param {string} event_name
 * @param {Element} dom
 * @param {EventListener} [handler]
 * @param {boolean} [capture]
 * @param {boolean} [passive]
 * @returns {void}
 */
function event(event_name, dom, handler, capture, passive) {
	var options = { capture, passive };
	var target_handler = create_event(event_name, dom, handler, options);

	if (
		dom === document.body ||
		// @ts-ignore
		dom === window ||
		// @ts-ignore
		dom === document ||
		// Firefox has quirky behavior, it can happen that we still get "canplay" events when the element is already removed
		dom instanceof HTMLMediaElement
	) {
		(0,_reactivity_effects_js__WEBPACK_IMPORTED_MODULE_0__.teardown)(() => {
			dom.removeEventListener(event_name, target_handler, options);
		});
	}
}

/**
 * @param {Array<string>} events
 * @returns {void}
 */
function delegate(events) {
	for (var i = 0; i < events.length; i++) {
		all_registered_events.add(events[i]);
	}

	for (var fn of root_event_handles) {
		fn(events);
	}
}

// used to store the reference to the currently propagated event
// to prevent garbage collection between microtasks in Firefox
// If the event object is GCed too early, the expando __root property
// set on the event object is lost, causing the event delegation
// to process the event twice
let last_propagated_event = null;

/**
 * @this {EventTarget}
 * @param {Event} event
 * @returns {void}
 */
function handle_event_propagation(event) {
	var handler_element = this;
	var owner_document = /** @type {Node} */ (handler_element).ownerDocument;
	var event_name = event.type;
	var path = event.composedPath?.() || [];
	var current_target = /** @type {null | Element} */ (path[0] || event.target);

	last_propagated_event = event;

	// composedPath contains list of nodes the event has propagated through.
	// We check __root to skip all nodes below it in case this is a
	// parent of the __root node, which indicates that there's nested
	// mounted apps. In this case we don't want to trigger events multiple times.
	var path_idx = 0;

	// the `last_propagated_event === event` check is redundant, but
	// without it the variable will be DCE'd and things will
	// fail mysteriously in Firefox
	// @ts-expect-error is added below
	var handled_at = last_propagated_event === event && event.__root;

	if (handled_at) {
		var at_idx = path.indexOf(handled_at);
		if (
			at_idx !== -1 &&
			(handler_element === document || handler_element === /** @type {any} */ (window))
		) {
			// This is the fallback document listener or a window listener, but the event was already handled
			// -> ignore, but set handle_at to document/window so that we're resetting the event
			// chain in case someone manually dispatches the same event object again.
			// @ts-expect-error
			event.__root = handler_element;
			return;
		}

		// We're deliberately not skipping if the index is higher, because
		// someone could create an event programmatically and emit it multiple times,
		// in which case we want to handle the whole propagation chain properly each time.
		// (this will only be a false negative if the event is dispatched multiple times and
		// the fallback document listener isn't reached in between, but that's super rare)
		var handler_idx = path.indexOf(handler_element);
		if (handler_idx === -1) {
			// handle_idx can theoretically be -1 (happened in some JSDOM testing scenarios with an event listener on the window object)
			// so guard against that, too, and assume that everything was handled at this point.
			return;
		}

		if (at_idx <= handler_idx) {
			path_idx = at_idx;
		}
	}

	current_target = /** @type {Element} */ (path[path_idx] || event.target);
	// there can only be one delegated event per element, and we either already handled the current target,
	// or this is the very first target in the chain which has a non-delegated listener, in which case it's safe
	// to handle a possible delegated event on it later (through the root delegation listener for example).
	if (current_target === handler_element) return;

	// Proxy currentTarget to correct target
	(0,_shared_utils_js__WEBPACK_IMPORTED_MODULE_1__.define_property)(event, 'currentTarget', {
		configurable: true,
		get() {
			return current_target || owner_document;
		}
	});

	// This started because of Chromium issue https://chromestatus.com/feature/5128696823545856,
	// where removal or moving of of the DOM can cause sync `blur` events to fire, which can cause logic
	// to run inside the current `active_reaction`, which isn't what we want at all. However, on reflection,
	// it's probably best that all event handled by Svelte have this behaviour, as we don't really want
	// an event handler to run in the context of another reaction or effect.
	var previous_reaction = _runtime_js__WEBPACK_IMPORTED_MODULE_6__.active_reaction;
	var previous_effect = _runtime_js__WEBPACK_IMPORTED_MODULE_6__.active_effect;
	(0,_runtime_js__WEBPACK_IMPORTED_MODULE_6__.set_active_reaction)(null);
	(0,_runtime_js__WEBPACK_IMPORTED_MODULE_6__.set_active_effect)(null);

	try {
		/**
		 * @type {unknown}
		 */
		var throw_error;
		/**
		 * @type {unknown[]}
		 */
		var other_errors = [];

		while (current_target !== null) {
			/** @type {null | Element} */
			var parent_element =
				current_target.assignedSlot ||
				current_target.parentNode ||
				/** @type {any} */ (current_target).host ||
				null;

			try {
				// @ts-expect-error
				var delegated = current_target['__' + event_name];

				if (
					delegated != null &&
					(!(/** @type {any} */ (current_target).disabled) ||
						// DOM could've been updated already by the time this is reached, so we check this as well
						// -> the target could not have been disabled because it emits the event in the first place
						event.target === current_target)
				) {
					delegated.call(current_target, event);
				}
			} catch (error) {
				if (throw_error) {
					other_errors.push(error);
				} else {
					throw_error = error;
				}
			}
			if (event.cancelBubble || parent_element === handler_element || parent_element === null) {
				break;
			}
			current_target = parent_element;
		}

		if (throw_error) {
			for (let error of other_errors) {
				// Throw the rest of the errors, one-by-one on a microtask
				queueMicrotask(() => {
					throw error;
				});
			}
			throw throw_error;
		}
	} finally {
		// @ts-expect-error is used above
		event.__root = handler_element;
		// @ts-ignore remove proxy on currentTarget
		delete event.currentTarget;
		(0,_runtime_js__WEBPACK_IMPORTED_MODULE_6__.set_active_reaction)(previous_reaction);
		(0,_runtime_js__WEBPACK_IMPORTED_MODULE_6__.set_active_effect)(previous_effect);
	}
}

/**
 * In dev, warn if an event handler is not a function, as it means the
 * user probably called the handler or forgot to add a `() =>`
 * @param {() => (event: Event, ...args: any) => void} thunk
 * @param {EventTarget} element
 * @param {[Event, ...any]} args
 * @param {any} component
 * @param {[number, number]} [loc]
 * @param {boolean} [remove_parens]
 */
function apply(
	thunk,
	element,
	args,
	component,
	loc,
	has_side_effects = false,
	remove_parens = false
) {
	let handler;
	let error;

	try {
		handler = thunk();
	} catch (e) {
		error = e;
	}

	if (typeof handler !== 'function' && (has_side_effects || handler != null || error)) {
		const filename = component?.[_constants_js__WEBPACK_IMPORTED_MODULE_4__.FILENAME];
		const location = loc ? ` at ${filename}:${loc[0]}:${loc[1]}` : ` in ${filename}`;
		const phase = args[0]?.eventPhase < Event.BUBBLING_PHASE ? 'capture' : '';
		const event_name = args[0]?.type + phase;
		const description = `\`${event_name}\` handler${location}`;
		const suggestion = remove_parens ? 'remove the trailing `()`' : 'add a leading `() =>`';

		_warnings_js__WEBPACK_IMPORTED_MODULE_5__.event_handler_invalid(description, suggestion);

		if (error) {
			throw error;
		}
	}
	handler?.apply(element, args);
}


}),
5030: 
/*!**************************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/dom/elements/misc.js ***!
  \**************************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  add_form_reset_listener: () => (add_form_reset_listener),
  autofocus: () => (autofocus)
});
/* import */var _hydration_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../hydration.js */ 5742);
/* import */var _operations_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../operations.js */ 6756);
/* import */var _task_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../task.js */ 7643);




/**
 * @param {HTMLElement} dom
 * @param {boolean} value
 * @returns {void}
 */
function autofocus(dom, value) {
	if (value) {
		const body = document.body;
		dom.autofocus = true;

		(0,_task_js__WEBPACK_IMPORTED_MODULE_2__.queue_micro_task)(() => {
			if (document.activeElement === body) {
				dom.focus();
			}
		});
	}
}

/**
 * The child of a textarea actually corresponds to the defaultValue property, so we need
 * to remove it upon hydration to avoid a bug when someone resets the form value.
 * @param {HTMLTextAreaElement} dom
 * @returns {void}
 */
function remove_textarea_child(dom) {
	if (_hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrating && (0,_operations_js__WEBPACK_IMPORTED_MODULE_1__.get_first_child)(dom) !== null) {
		(0,_operations_js__WEBPACK_IMPORTED_MODULE_1__.clear_text_content)(dom);
	}
}

let listening_to_form_reset = false;

function add_form_reset_listener() {
	if (!listening_to_form_reset) {
		listening_to_form_reset = true;
		document.addEventListener(
			'reset',
			(evt) => {
				// Needs to happen one tick later or else the dom properties of the form
				// elements have not updated to their reset values yet
				Promise.resolve().then(() => {
					if (!evt.defaultPrevented) {
						for (const e of /**@type {HTMLFormElement} */ (evt.target).elements) {
							// @ts-expect-error
							e.__on_r?.();
						}
					}
				});
			},
			// In the capture phase to guarantee we get noticed of it (no possiblity of stopPropagation)
			{ capture: true }
		);
	}
}


}),
5742: 
/*!**********************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/dom/hydration.js ***!
  \**********************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  hydrate_next: () => (hydrate_next),
  hydrate_node: () => (hydrate_node),
  hydrating: () => (hydrating),
  next: () => (next),
  read_hydration_instruction: () => (read_hydration_instruction),
  reset: () => (reset),
  set_hydrate_node: () => (set_hydrate_node),
  set_hydrating: () => (set_hydrating),
  skip_nodes: () => (skip_nodes)
});
/* import */var _client_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! #client/constants */ 5818);
/* import */var _constants_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../constants.js */ 7164);
/* import */var _warnings_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../warnings.js */ 8658);
/* import */var _operations_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./operations.js */ 6756);
/** @import { TemplateNode } from '#client' */






/**
 * Use this variable to guard everything related to hydration code so it can be treeshaken out
 * if the user doesn't use the `hydrate` method and these code paths are therefore not needed.
 */
let hydrating = false;

/** @param {boolean} value */
function set_hydrating(value) {
	hydrating = value;
}

/**
 * The node that is currently being hydrated. This starts out as the first node inside the opening
 * <!--[--> comment, and updates each time a component calls `$.child(...)` or `$.sibling(...)`.
 * When entering a block (e.g. `{#if ...}`), `hydrate_node` is the block opening comment; by the
 * time we leave the block it is the closing comment, which serves as the block's anchor.
 * @type {TemplateNode}
 */
let hydrate_node;

/** @param {TemplateNode} node */
function set_hydrate_node(node) {
	if (node === null) {
		_warnings_js__WEBPACK_IMPORTED_MODULE_2__.hydration_mismatch();
		throw _constants_js__WEBPACK_IMPORTED_MODULE_1__.HYDRATION_ERROR;
	}

	return (hydrate_node = node);
}

function hydrate_next() {
	return set_hydrate_node(/** @type {TemplateNode} */ ((0,_operations_js__WEBPACK_IMPORTED_MODULE_3__.get_next_sibling)(hydrate_node)));
}

/** @param {TemplateNode} node */
function reset(node) {
	if (!hydrating) return;

	// If the node has remaining siblings, something has gone wrong
	if ((0,_operations_js__WEBPACK_IMPORTED_MODULE_3__.get_next_sibling)(hydrate_node) !== null) {
		_warnings_js__WEBPACK_IMPORTED_MODULE_2__.hydration_mismatch();
		throw _constants_js__WEBPACK_IMPORTED_MODULE_1__.HYDRATION_ERROR;
	}

	hydrate_node = node;
}

/**
 * @param {HTMLTemplateElement} template
 */
function hydrate_template(template) {
	if (hydrating) {
		// @ts-expect-error TemplateNode doesn't include DocumentFragment, but it's actually fine
		hydrate_node = template.content;
	}
}

function next(count = 1) {
	if (hydrating) {
		var i = count;
		var node = hydrate_node;

		while (i--) {
			node = /** @type {TemplateNode} */ ((0,_operations_js__WEBPACK_IMPORTED_MODULE_3__.get_next_sibling)(node));
		}

		hydrate_node = node;
	}
}

/**
 * Skips or removes (depending on {@link remove}) all nodes starting at `hydrate_node` up until the next hydration end comment
 * @param {boolean} remove
 */
function skip_nodes(remove = true) {
	var depth = 0;
	var node = hydrate_node;

	while (true) {
		if (node.nodeType === _client_constants__WEBPACK_IMPORTED_MODULE_0__.COMMENT_NODE) {
			var data = /** @type {Comment} */ (node).data;

			if (data === _constants_js__WEBPACK_IMPORTED_MODULE_1__.HYDRATION_END) {
				if (depth === 0) return node;
				depth -= 1;
			} else if (data === _constants_js__WEBPACK_IMPORTED_MODULE_1__.HYDRATION_START || data === _constants_js__WEBPACK_IMPORTED_MODULE_1__.HYDRATION_START_ELSE) {
				depth += 1;
			}
		}

		var next = /** @type {TemplateNode} */ ((0,_operations_js__WEBPACK_IMPORTED_MODULE_3__.get_next_sibling)(node));
		if (remove) node.remove();
		node = next;
	}
}

/**
 *
 * @param {TemplateNode} node
 */
function read_hydration_instruction(node) {
	if (!node || node.nodeType !== _client_constants__WEBPACK_IMPORTED_MODULE_0__.COMMENT_NODE) {
		_warnings_js__WEBPACK_IMPORTED_MODULE_2__.hydration_mismatch();
		throw _constants_js__WEBPACK_IMPORTED_MODULE_1__.HYDRATION_ERROR;
	}

	return /** @type {Comment} */ (node).data;
}


}),
6756: 
/*!***********************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/dom/operations.js ***!
  \***********************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  child: () => (child),
  clear_text_content: () => (clear_text_content),
  create_comment: () => (create_comment),
  create_element: () => (create_element),
  create_fragment: () => (create_fragment),
  create_text: () => (create_text),
  get_first_child: () => (get_first_child),
  get_next_sibling: () => (get_next_sibling),
  init_operations: () => (init_operations),
  is_firefox: () => (is_firefox),
  set_attribute: () => (set_attribute),
  should_defer_append: () => (should_defer_append),
  sibling: () => (sibling)
});
/* import */var _hydration_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./hydration.js */ 5742);
/* import */var esm_env__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! esm-env */ 3990);
/* import */var _dev_equality_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../dev/equality.js */ 9911);
/* import */var _shared_utils_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/utils.js */ 2060);
/* import */var _runtime_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../runtime.js */ 5551);
/* import */var _flags_index_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../flags/index.js */ 9987);
/* import */var _client_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! #client/constants */ 5818);
/* import */var _reactivity_batch_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../reactivity/batch.js */ 5812);
/** @import { Effect, TemplateNode } from '#client' */









// export these for reference in the compiled code, making global name deduplication unnecessary
/** @type {Window} */
var $window;

/** @type {Document} */
var $document;

/** @type {boolean} */
var is_firefox;

/** @type {() => Node | null} */
var first_child_getter;
/** @type {() => Node | null} */
var next_sibling_getter;

/**
 * Initialize these lazily to avoid issues when using the runtime in a server context
 * where these globals are not available while avoiding a separate server entry point
 */
function init_operations() {
	if ($window !== undefined) {
		return;
	}

	$window = window;
	$document = document;
	is_firefox = /Firefox/.test(navigator.userAgent);

	var element_prototype = Element.prototype;
	var node_prototype = Node.prototype;
	var text_prototype = Text.prototype;

	// @ts-ignore
	first_child_getter = (0,_shared_utils_js__WEBPACK_IMPORTED_MODULE_3__.get_descriptor)(node_prototype, 'firstChild').get;
	// @ts-ignore
	next_sibling_getter = (0,_shared_utils_js__WEBPACK_IMPORTED_MODULE_3__.get_descriptor)(node_prototype, 'nextSibling').get;

	if ((0,_shared_utils_js__WEBPACK_IMPORTED_MODULE_3__.is_extensible)(element_prototype)) {
		// the following assignments improve perf of lookups on DOM nodes
		// @ts-expect-error
		element_prototype.__click = undefined;
		// @ts-expect-error
		element_prototype.__className = undefined;
		// @ts-expect-error
		element_prototype.__attributes = null;
		// @ts-expect-error
		element_prototype.__style = undefined;
		// @ts-expect-error
		element_prototype.__e = undefined;
	}

	if ((0,_shared_utils_js__WEBPACK_IMPORTED_MODULE_3__.is_extensible)(text_prototype)) {
		// @ts-expect-error
		text_prototype.__t = undefined;
	}

	if (esm_env__WEBPACK_IMPORTED_MODULE_1__.DEV) {
		// @ts-expect-error
		element_prototype.__svelte_meta = null;

		(0,_dev_equality_js__WEBPACK_IMPORTED_MODULE_2__.init_array_prototype_warnings)();
	}
}

/**
 * @param {string} value
 * @returns {Text}
 */
function create_text(value = '') {
	return document.createTextNode(value);
}

/**
 * @template {Node} N
 * @param {N} node
 * @returns {Node | null}
 */
/*@__NO_SIDE_EFFECTS__*/
function get_first_child(node) {
	return first_child_getter.call(node);
}

/**
 * @template {Node} N
 * @param {N} node
 * @returns {Node | null}
 */
/*@__NO_SIDE_EFFECTS__*/
function get_next_sibling(node) {
	return next_sibling_getter.call(node);
}

/**
 * Don't mark this as side-effect-free, hydration needs to walk all nodes
 * @template {Node} N
 * @param {N} node
 * @param {boolean} is_text
 * @returns {Node | null}
 */
function child(node, is_text) {
	if (!_hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrating) {
		return get_first_child(node);
	}

	var child = /** @type {TemplateNode} */ (get_first_child(_hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrate_node));

	// Child can be null if we have an element with a single child, like `<p>{text}</p>`, where `text` is empty
	if (child === null) {
		child = _hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrate_node.appendChild(create_text());
	} else if (is_text && child.nodeType !== _client_constants__WEBPACK_IMPORTED_MODULE_5__.TEXT_NODE) {
		var text = create_text();
		child?.before(text);
		(0,_hydration_js__WEBPACK_IMPORTED_MODULE_0__.set_hydrate_node)(text);
		return text;
	}

	(0,_hydration_js__WEBPACK_IMPORTED_MODULE_0__.set_hydrate_node)(child);
	return child;
}

/**
 * Don't mark this as side-effect-free, hydration needs to walk all nodes
 * @param {DocumentFragment | TemplateNode | TemplateNode[]} fragment
 * @param {boolean} [is_text]
 * @returns {Node | null}
 */
function first_child(fragment, is_text = false) {
	if (!_hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrating) {
		// when not hydrating, `fragment` is a `DocumentFragment` (the result of calling `open_frag`)
		var first = /** @type {DocumentFragment} */ (get_first_child(/** @type {Node} */ (fragment)));

		// TODO prevent user comments with the empty string when preserveComments is true
		if (first instanceof Comment && first.data === '') return get_next_sibling(first);

		return first;
	}

	// if an {expression} is empty during SSR, there might be no
	// text node to hydrate — we must therefore create one
	if (is_text && _hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrate_node?.nodeType !== _client_constants__WEBPACK_IMPORTED_MODULE_5__.TEXT_NODE) {
		var text = create_text();

		_hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrate_node?.before(text);
		(0,_hydration_js__WEBPACK_IMPORTED_MODULE_0__.set_hydrate_node)(text);
		return text;
	}

	return _hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrate_node;
}

/**
 * Don't mark this as side-effect-free, hydration needs to walk all nodes
 * @param {TemplateNode} node
 * @param {number} count
 * @param {boolean} is_text
 * @returns {Node | null}
 */
function sibling(node, count = 1, is_text = false) {
	let next_sibling = _hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrating ? _hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrate_node : node;
	var last_sibling;

	while (count--) {
		last_sibling = next_sibling;
		next_sibling = /** @type {TemplateNode} */ (get_next_sibling(next_sibling));
	}

	if (!_hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrating) {
		return next_sibling;
	}

	// if a sibling {expression} is empty during SSR, there might be no
	// text node to hydrate — we must therefore create one
	if (is_text && next_sibling?.nodeType !== _client_constants__WEBPACK_IMPORTED_MODULE_5__.TEXT_NODE) {
		var text = create_text();
		// If the next sibling is `null` and we're handling text then it's because
		// the SSR content was empty for the text, so we need to generate a new text
		// node and insert it after the last sibling
		if (next_sibling === null) {
			last_sibling?.after(text);
		} else {
			next_sibling.before(text);
		}
		(0,_hydration_js__WEBPACK_IMPORTED_MODULE_0__.set_hydrate_node)(text);
		return text;
	}

	(0,_hydration_js__WEBPACK_IMPORTED_MODULE_0__.set_hydrate_node)(next_sibling);
	return /** @type {TemplateNode} */ (next_sibling);
}

/**
 * @template {Node} N
 * @param {N} node
 * @returns {void}
 */
function clear_text_content(node) {
	node.textContent = '';
}

/**
 * Returns `true` if we're updating the current block, for example `condition` in
 * an `{#if condition}` block just changed. In this case, the branch should be
 * appended (or removed) at the same time as other updates within the
 * current `<svelte:boundary>`
 */
function should_defer_append() {
	if (!_flags_index_js__WEBPACK_IMPORTED_MODULE_7__.async_mode_flag) return false;
	if (_reactivity_batch_js__WEBPACK_IMPORTED_MODULE_6__.eager_block_effects !== null) return false;

	var flags = /** @type {Effect} */ _runtime_js__WEBPACK_IMPORTED_MODULE_4__.active_effect.f;
	return (flags & _client_constants__WEBPACK_IMPORTED_MODULE_5__.EFFECT_RAN) !== 0;
}

/**
 *
 * @param {string} tag
 * @param {string} [namespace]
 * @param {string} [is]
 * @returns
 */
function create_element(tag, namespace, is) {
	let options = is ? { is } : undefined;
	if (namespace) {
		return document.createElementNS(namespace, tag, options);
	}
	return document.createElement(tag, options);
}

function create_fragment() {
	return document.createDocumentFragment();
}

/**
 * @param {string} data
 * @returns
 */
function create_comment(data = '') {
	return document.createComment(data);
}

/**
 * @param {Element} element
 * @param {string} key
 * @param {string} value
 * @returns
 */
function set_attribute(element, key, value = '') {
	if (key.startsWith('xlink:')) {
		element.setAttributeNS('http://www.w3.org/1999/xlink', key, value);
		return;
	}
	return element.setAttribute(key, value);
}


}),
1876: 
/*!***********************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/dom/reconciler.js ***!
  \***********************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  create_fragment_from_html: () => (create_fragment_from_html)
});
/** @param {string} html */
function create_fragment_from_html(html) {
	var elem = document.createElement('template');
	elem.innerHTML = html.replaceAll('<!>', '<!---->'); // XHTML compliance
	return elem.content;
}


}),
7643: 
/*!*****************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/dom/task.js ***!
  \*****************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  flush_tasks: () => (flush_tasks),
  queue_micro_task: () => (queue_micro_task)
});
/* import */var _shared_utils_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../shared/utils.js */ 2060);
/* import */var _reactivity_batch_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../reactivity/batch.js */ 5812);



/** @type {Array<() => void>} */
let micro_tasks = [];

function run_micro_tasks() {
	var tasks = micro_tasks;
	micro_tasks = [];
	(0,_shared_utils_js__WEBPACK_IMPORTED_MODULE_0__.run_all)(tasks);
}

/**
 * @param {() => void} fn
 */
function queue_micro_task(fn) {
	if (micro_tasks.length === 0 && !_reactivity_batch_js__WEBPACK_IMPORTED_MODULE_1__.is_flushing_sync) {
		var tasks = micro_tasks;
		queueMicrotask(() => {
			// If this is false, a flushSync happened in the meantime. Do _not_ run new scheduled microtasks in that case
			// as the ordering of microtasks would be broken at that point - consider this case:
			// - queue_micro_task schedules microtask A to flush task X
			// - synchronously after, flushSync runs, processing task X
			// - synchronously after, some other microtask B is scheduled, but not through queue_micro_task but for example a Promise.resolve() in user code
			// - synchronously after, queue_micro_task schedules microtask C to flush task Y
			// - one tick later, microtask A now resolves, flushing task Y before microtask B, which is incorrect
			// This if check prevents that race condition (that realistically will only happen in tests)
			if (tasks === micro_tasks) run_micro_tasks();
		});
	}

	micro_tasks.push(fn);
}

/**
 * Synchronously run any queued tasks.
 */
function flush_tasks() {
	while (micro_tasks.length > 0) {
		run_micro_tasks();
	}
}


}),
2752: 
/*!*********************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/dom/template.js ***!
  \*********************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  append: () => (append),
  assign_nodes: () => (assign_nodes),
  from_html: () => (from_html)
});
/* import */var _hydration_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./hydration.js */ 5742);
/* import */var _operations_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./operations.js */ 6756);
/* import */var _reconciler_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./reconciler.js */ 1876);
/* import */var _runtime_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../runtime.js */ 5551);
/* import */var _constants_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../constants.js */ 7164);
/* import */var _client_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! #client/constants */ 5818);
/** @import { Effect, TemplateNode } from '#client' */
/** @import { TemplateStructure } from './types' */







/**
 * @param {TemplateNode} start
 * @param {TemplateNode | null} end
 */
function assign_nodes(start, end) {
	var effect = /** @type {Effect} */ (_runtime_js__WEBPACK_IMPORTED_MODULE_2__.active_effect);
	if (effect.nodes_start === null) {
		effect.nodes_start = start;
		effect.nodes_end = end;
	}
}

/**
 * @param {string} content
 * @param {number} flags
 * @returns {() => Node | Node[]}
 */
/*#__NO_SIDE_EFFECTS__*/
function from_html(content, flags) {
	var is_fragment = (flags & _constants_js__WEBPACK_IMPORTED_MODULE_3__.TEMPLATE_FRAGMENT) !== 0;
	var use_import_node = (flags & _constants_js__WEBPACK_IMPORTED_MODULE_3__.TEMPLATE_USE_IMPORT_NODE) !== 0;

	/** @type {Node} */
	var node;

	/**
	 * Whether or not the first item is a text/element node. If not, we need to
	 * create an additional comment node to act as `effect.nodes.start`
	 */
	var has_start = !content.startsWith('<!>');

	return () => {
		if (_hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrating) {
			assign_nodes(_hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrate_node, null);
			return _hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrate_node;
		}

		if (node === undefined) {
			node = (0,_reconciler_js__WEBPACK_IMPORTED_MODULE_5__.create_fragment_from_html)(has_start ? content : '<!>' + content);
			if (!is_fragment) node = /** @type {Node} */ ((0,_operations_js__WEBPACK_IMPORTED_MODULE_1__.get_first_child)(node));
		}

		var clone = /** @type {TemplateNode} */ (
			use_import_node || _operations_js__WEBPACK_IMPORTED_MODULE_1__.is_firefox ? document.importNode(node, true) : node.cloneNode(true)
		);

		if (is_fragment) {
			var start = /** @type {TemplateNode} */ ((0,_operations_js__WEBPACK_IMPORTED_MODULE_1__.get_first_child)(clone));
			var end = /** @type {TemplateNode} */ (clone.lastChild);

			assign_nodes(start, end);
		} else {
			assign_nodes(clone, clone);
		}

		return clone;
	};
}

/**
 * @param {string} content
 * @param {number} flags
 * @param {'svg' | 'math'} ns
 * @returns {() => Node | Node[]}
 */
/*#__NO_SIDE_EFFECTS__*/
function from_namespace(content, flags, ns = 'svg') {
	/**
	 * Whether or not the first item is a text/element node. If not, we need to
	 * create an additional comment node to act as `effect.nodes.start`
	 */
	var has_start = !content.startsWith('<!>');

	var is_fragment = (flags & _constants_js__WEBPACK_IMPORTED_MODULE_3__.TEMPLATE_FRAGMENT) !== 0;
	var wrapped = `<${ns}>${has_start ? content : '<!>' + content}</${ns}>`;

	/** @type {Element | DocumentFragment} */
	var node;

	return () => {
		if (_hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrating) {
			assign_nodes(_hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrate_node, null);
			return _hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrate_node;
		}

		if (!node) {
			var fragment = /** @type {DocumentFragment} */ ((0,_reconciler_js__WEBPACK_IMPORTED_MODULE_5__.create_fragment_from_html)(wrapped));
			var root = /** @type {Element} */ ((0,_operations_js__WEBPACK_IMPORTED_MODULE_1__.get_first_child)(fragment));

			if (is_fragment) {
				node = document.createDocumentFragment();
				while ((0,_operations_js__WEBPACK_IMPORTED_MODULE_1__.get_first_child)(root)) {
					node.appendChild(/** @type {Node} */ ((0,_operations_js__WEBPACK_IMPORTED_MODULE_1__.get_first_child)(root)));
				}
			} else {
				node = /** @type {Element} */ ((0,_operations_js__WEBPACK_IMPORTED_MODULE_1__.get_first_child)(root));
			}
		}

		var clone = /** @type {TemplateNode} */ (node.cloneNode(true));

		if (is_fragment) {
			var start = /** @type {TemplateNode} */ ((0,_operations_js__WEBPACK_IMPORTED_MODULE_1__.get_first_child)(clone));
			var end = /** @type {TemplateNode} */ (clone.lastChild);

			assign_nodes(start, end);
		} else {
			assign_nodes(clone, clone);
		}

		return clone;
	};
}

/**
 * @param {string} content
 * @param {number} flags
 */
/*#__NO_SIDE_EFFECTS__*/
function from_svg(content, flags) {
	return from_namespace(content, flags, 'svg');
}

/**
 * @param {string} content
 * @param {number} flags
 */
/*#__NO_SIDE_EFFECTS__*/
function from_mathml(content, flags) {
	return from_namespace(content, flags, 'math');
}

/**
 * @param {TemplateStructure[]} structure
 * @param {typeof NAMESPACE_SVG | typeof NAMESPACE_MATHML | undefined} [ns]
 */
function fragment_from_tree(structure, ns) {
	var fragment = (0,_operations_js__WEBPACK_IMPORTED_MODULE_1__.create_fragment)();

	for (var item of structure) {
		if (typeof item === 'string') {
			fragment.append((0,_operations_js__WEBPACK_IMPORTED_MODULE_1__.create_text)(item));
			continue;
		}

		// if `preserveComments === true`, comments are represented as `['// <data>']`
		if (item === undefined || item[0][0] === '/') {
			fragment.append((0,_operations_js__WEBPACK_IMPORTED_MODULE_1__.create_comment)(item ? item[0].slice(3) : ''));
			continue;
		}

		const [name, attributes, ...children] = item;

		const namespace = name === 'svg' ? _constants_js__WEBPACK_IMPORTED_MODULE_3__.NAMESPACE_SVG : name === 'math' ? _constants_js__WEBPACK_IMPORTED_MODULE_3__.NAMESPACE_MATHML : ns;

		var element = (0,_operations_js__WEBPACK_IMPORTED_MODULE_1__.create_element)(name, namespace, attributes?.is);

		for (var key in attributes) {
			(0,_operations_js__WEBPACK_IMPORTED_MODULE_1__.set_attribute)(element, key, attributes[key]);
		}

		if (children.length > 0) {
			var target =
				element.tagName === 'TEMPLATE'
					? /** @type {HTMLTemplateElement} */ (element).content
					: element;

			target.append(
				fragment_from_tree(children, element.tagName === 'foreignObject' ? undefined : namespace)
			);
		}

		fragment.append(element);
	}

	return fragment;
}

/**
 * @param {TemplateStructure[]} structure
 * @param {number} flags
 * @returns {() => Node | Node[]}
 */
/*#__NO_SIDE_EFFECTS__*/
function from_tree(structure, flags) {
	var is_fragment = (flags & _constants_js__WEBPACK_IMPORTED_MODULE_3__.TEMPLATE_FRAGMENT) !== 0;
	var use_import_node = (flags & _constants_js__WEBPACK_IMPORTED_MODULE_3__.TEMPLATE_USE_IMPORT_NODE) !== 0;

	/** @type {Node} */
	var node;

	return () => {
		if (_hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrating) {
			assign_nodes(_hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrate_node, null);
			return _hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrate_node;
		}

		if (node === undefined) {
			const ns =
				(flags & _constants_js__WEBPACK_IMPORTED_MODULE_3__.TEMPLATE_USE_SVG) !== 0
					? _constants_js__WEBPACK_IMPORTED_MODULE_3__.NAMESPACE_SVG
					: (flags & _constants_js__WEBPACK_IMPORTED_MODULE_3__.TEMPLATE_USE_MATHML) !== 0
						? _constants_js__WEBPACK_IMPORTED_MODULE_3__.NAMESPACE_MATHML
						: undefined;

			node = fragment_from_tree(structure, ns);
			if (!is_fragment) node = /** @type {Node} */ ((0,_operations_js__WEBPACK_IMPORTED_MODULE_1__.get_first_child)(node));
		}

		var clone = /** @type {TemplateNode} */ (
			use_import_node || _operations_js__WEBPACK_IMPORTED_MODULE_1__.is_firefox ? document.importNode(node, true) : node.cloneNode(true)
		);

		if (is_fragment) {
			var start = /** @type {TemplateNode} */ ((0,_operations_js__WEBPACK_IMPORTED_MODULE_1__.get_first_child)(clone));
			var end = /** @type {TemplateNode} */ (clone.lastChild);

			assign_nodes(start, end);
		} else {
			assign_nodes(clone, clone);
		}

		return clone;
	};
}

/**
 * @param {() => Element | DocumentFragment} fn
 */
function with_script(fn) {
	return () => run_scripts(fn());
}

/**
 * Creating a document fragment from HTML that contains script tags will not execute
 * the scripts. We need to replace the script tags with new ones so that they are executed.
 * @param {Element | DocumentFragment} node
 * @returns {Node | Node[]}
 */
function run_scripts(node) {
	// scripts were SSR'd, in which case they will run
	if (_hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrating) return node;

	const is_fragment = node.nodeType === _client_constants__WEBPACK_IMPORTED_MODULE_4__.DOCUMENT_FRAGMENT_NODE;
	const scripts =
		/** @type {HTMLElement} */ (node).tagName === 'SCRIPT'
			? [/** @type {HTMLScriptElement} */ (node)]
			: node.querySelectorAll('script');
	const effect = /** @type {Effect} */ (_runtime_js__WEBPACK_IMPORTED_MODULE_2__.active_effect);

	for (const script of scripts) {
		const clone = document.createElement('script');
		for (var attribute of script.attributes) {
			clone.setAttribute(attribute.name, attribute.value);
		}

		clone.textContent = script.textContent;

		// The script has changed - if it's at the edges, the effect now points at dead nodes
		if (is_fragment ? node.firstChild === script : node === script) {
			effect.nodes_start = clone;
		}
		if (is_fragment ? node.lastChild === script : node === script) {
			effect.nodes_end = clone;
		}

		script.replaceWith(clone);
	}
	return node;
}

/**
 * Don't mark this as side-effect-free, hydration needs to walk all nodes
 * @param {any} value
 */
function text(value = '') {
	if (!_hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrating) {
		var t = (0,_operations_js__WEBPACK_IMPORTED_MODULE_1__.create_text)(value + '');
		assign_nodes(t, t);
		return t;
	}

	var node = _hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrate_node;

	if (node.nodeType !== _client_constants__WEBPACK_IMPORTED_MODULE_4__.TEXT_NODE) {
		// if an {expression} is empty during SSR, we need to insert an empty text node
		node.before((node = (0,_operations_js__WEBPACK_IMPORTED_MODULE_1__.create_text)()));
		(0,_hydration_js__WEBPACK_IMPORTED_MODULE_0__.set_hydrate_node)(node);
	}

	assign_nodes(node, node);
	return node;
}

/**
 * @returns {TemplateNode | DocumentFragment}
 */
function comment() {
	// we're not delegating to `template` here for performance reasons
	if (_hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrating) {
		assign_nodes(_hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrate_node, null);
		return _hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrate_node;
	}

	var frag = document.createDocumentFragment();
	var start = document.createComment('');
	var anchor = (0,_operations_js__WEBPACK_IMPORTED_MODULE_1__.create_text)();
	frag.append(start, anchor);

	assign_nodes(start, anchor);

	return frag;
}

/**
 * Assign the created (or in hydration mode, traversed) dom elements to the current block
 * and insert the elements into the dom (in client mode).
 * @param {Text | Comment | Element} anchor
 * @param {DocumentFragment | Element} dom
 */
function append(anchor, dom) {
	if (_hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrating) {
		var effect = /** @type {Effect} */ (_runtime_js__WEBPACK_IMPORTED_MODULE_2__.active_effect);
		// When hydrating and outer component and an inner component is async, i.e. blocked on a promise,
		// then by the time the inner resolves we have already advanced to the end of the hydrated nodes
		// of the parent component. Check for defined for that reason to avoid rewinding the parent's end marker.
		if ((effect.f & _client_constants__WEBPACK_IMPORTED_MODULE_4__.EFFECT_RAN) === 0 || effect.nodes_end === null) {
			effect.nodes_end = _hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrate_node;
		}
		(0,_hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrate_next)();
		return;
	}

	if (anchor === null) {
		// edge case — void `<svelte:element>` with content
		return;
	}

	anchor.before(/** @type {Node} */ (dom));
}

/**
 * Create (or hydrate) an unique UID for the component instance.
 */
function props_id() {
	if (
		_hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrating &&
		_hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrate_node &&
		_hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrate_node.nodeType === _client_constants__WEBPACK_IMPORTED_MODULE_4__.COMMENT_NODE &&
		_hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrate_node.textContent?.startsWith(`$`)
	) {
		const id = _hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrate_node.textContent.substring(1);
		(0,_hydration_js__WEBPACK_IMPORTED_MODULE_0__.hydrate_next)();
		return id;
	}

	// @ts-expect-error This way we ensure the id is unique even across Svelte runtimes
	(window.__svelte ??= {}).uid ??= 1;

	// @ts-expect-error
	return `c${window.__svelte.uid++}`;
}


}),
2219: 
/*!***********************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/error-handling.js ***!
  \***********************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  handle_error: () => (handle_error),
  invoke_error_boundary: () => (invoke_error_boundary)
});
/* import */var esm_env__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! esm-env */ 3990);
/* import */var _constants_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../constants.js */ 7164);
/* import */var _dom_operations_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./dom/operations.js */ 6756);
/* import */var _constants_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./constants.js */ 5818);
/* import */var _shared_utils_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../shared/utils.js */ 2060);
/* import */var _runtime_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./runtime.js */ 5551);
/** @import { Derived, Effect } from '#client' */
/** @import { Boundary } from './dom/blocks/boundary.js' */







const adjustments = new WeakMap();

/**
 * @param {unknown} error
 */
function handle_error(error) {
	var effect = _runtime_js__WEBPACK_IMPORTED_MODULE_5__.active_effect;

	// for unowned deriveds, don't throw until we read the value
	if (effect === null) {
		/** @type {Derived} */ _runtime_js__WEBPACK_IMPORTED_MODULE_5__.active_reaction.f |= _constants_js__WEBPACK_IMPORTED_MODULE_3__.ERROR_VALUE;
		return error;
	}

	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV && error instanceof Error && !adjustments.has(error)) {
		adjustments.set(error, get_adjustments(error, effect));
	}

	if ((effect.f & _constants_js__WEBPACK_IMPORTED_MODULE_3__.EFFECT_RAN) === 0) {
		// if the error occurred while creating this subtree, we let it
		// bubble up until it hits a boundary that can handle it
		if ((effect.f & _constants_js__WEBPACK_IMPORTED_MODULE_3__.BOUNDARY_EFFECT) === 0) {
			if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV && !effect.parent && error instanceof Error) {
				apply_adjustments(error);
			}

			throw error;
		}

		/** @type {Boundary} */ (effect.b).error(error);
	} else {
		// otherwise we bubble up the effect tree ourselves
		invoke_error_boundary(error, effect);
	}
}

/**
 * @param {unknown} error
 * @param {Effect | null} effect
 */
function invoke_error_boundary(error, effect) {
	while (effect !== null) {
		if ((effect.f & _constants_js__WEBPACK_IMPORTED_MODULE_3__.BOUNDARY_EFFECT) !== 0) {
			try {
				/** @type {Boundary} */ (effect.b).error(error);
				return;
			} catch (e) {
				error = e;
			}
		}

		effect = effect.parent;
	}

	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV && error instanceof Error) {
		apply_adjustments(error);
	}

	throw error;
}

/**
 * Add useful information to the error message/stack in development
 * @param {Error} error
 * @param {Effect} effect
 */
function get_adjustments(error, effect) {
	const message_descriptor = (0,_shared_utils_js__WEBPACK_IMPORTED_MODULE_4__.get_descriptor)(error, 'message');

	// if the message was already changed and it's not configurable we can't change it
	// or it will throw a different error swallowing the original error
	if (message_descriptor && !message_descriptor.configurable) return;

	var indent = _dom_operations_js__WEBPACK_IMPORTED_MODULE_2__.is_firefox ? '  ' : '\t';
	var component_stack = `\n${indent}in ${effect.fn?.name || '<unknown>'}`;
	var context = effect.ctx;

	while (context !== null) {
		component_stack += `\n${indent}in ${context.function?.[_constants_js__WEBPACK_IMPORTED_MODULE_1__.FILENAME].split('/').pop()}`;
		context = context.p;
	}

	return {
		message: error.message + `\n${component_stack}\n`,
		stack: error.stack
			?.split('\n')
			.filter((line) => !line.includes('svelte/src/internal'))
			.join('\n')
	};
}

/**
 * @param {Error} error
 */
function apply_adjustments(error) {
	const adjusted = adjustments.get(error);

	if (adjusted) {
		(0,_shared_utils_js__WEBPACK_IMPORTED_MODULE_4__.define_property)(error, 'message', {
			value: adjusted.message
		});

		(0,_shared_utils_js__WEBPACK_IMPORTED_MODULE_4__.define_property)(error, 'stack', {
			value: adjusted.stack
		});
	}
}


}),
1152: 
/*!***************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/errors.js ***!
  \***************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  async_derived_orphan: () => (async_derived_orphan),
  bind_invalid_checkbox_value: () => (bind_invalid_checkbox_value),
  component_api_changed: () => (component_api_changed),
  component_api_invalid_new: () => (component_api_invalid_new),
  derived_references_self: () => (derived_references_self),
  each_key_duplicate: () => (each_key_duplicate),
  effect_in_teardown: () => (effect_in_teardown),
  effect_in_unowned_derived: () => (effect_in_unowned_derived),
  effect_orphan: () => (effect_orphan),
  effect_pending_outside_reaction: () => (effect_pending_outside_reaction),
  effect_update_depth_exceeded: () => (effect_update_depth_exceeded),
  experimental_async_fork: () => (experimental_async_fork),
  flush_sync_in_effect: () => (flush_sync_in_effect),
  fork_discarded: () => (fork_discarded),
  fork_timing: () => (fork_timing),
  get_abort_signal_outside_reaction: () => (get_abort_signal_outside_reaction),
  hydration_failed: () => (hydration_failed),
  invalid_snippet: () => (invalid_snippet),
  invalid_snippet_arguments: () => (/* reexport safe */ _shared_errors_js__WEBPACK_IMPORTED_MODULE_1__.invalid_snippet_arguments),
  lifecycle_legacy_only: () => (lifecycle_legacy_only),
  lifecycle_outside_component: () => (/* reexport safe */ _shared_errors_js__WEBPACK_IMPORTED_MODULE_1__.lifecycle_outside_component),
  missing_context: () => (/* reexport safe */ _shared_errors_js__WEBPACK_IMPORTED_MODULE_1__.missing_context),
  props_invalid_value: () => (props_invalid_value),
  props_rest_readonly: () => (props_rest_readonly),
  rune_outside_svelte: () => (rune_outside_svelte),
  set_context_after_init: () => (set_context_after_init),
  state_descriptors_fixed: () => (state_descriptors_fixed),
  state_prototype_fixed: () => (state_prototype_fixed),
  state_unsafe_mutation: () => (state_unsafe_mutation),
  svelte_boundary_reset_onerror: () => (svelte_boundary_reset_onerror)
});
/* import */var esm_env__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! esm-env */ 3990);
/* import */var _shared_errors_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../shared/errors.js */ 4934);
/* This file is generated by scripts/process-messages/index.js. Do not edit! */





/**
 * Cannot create a `$derived(...)` with an `await` expression outside of an effect tree
 * @returns {never}
 */
function async_derived_orphan() {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`async_derived_orphan\nCannot create a \`$derived(...)\` with an \`await\` expression outside of an effect tree\nhttps://svelte.dev/e/async_derived_orphan`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/async_derived_orphan`);
	}
}

/**
 * Using `bind:value` together with a checkbox input is not allowed. Use `bind:checked` instead
 * @returns {never}
 */
function bind_invalid_checkbox_value() {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`bind_invalid_checkbox_value\nUsing \`bind:value\` together with a checkbox input is not allowed. Use \`bind:checked\` instead\nhttps://svelte.dev/e/bind_invalid_checkbox_value`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/bind_invalid_checkbox_value`);
	}
}

/**
 * Component %component% has an export named `%key%` that a consumer component is trying to access using `bind:%key%`, which is disallowed. Instead, use `bind:this` (e.g. `<%name% bind:this={component} />`) and then access the property on the bound component instance (e.g. `component.%key%`)
 * @param {string} component
 * @param {string} key
 * @param {string} name
 * @returns {never}
 */
function bind_invalid_export(component, key, name) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`bind_invalid_export\nComponent ${component} has an export named \`${key}\` that a consumer component is trying to access using \`bind:${key}\`, which is disallowed. Instead, use \`bind:this\` (e.g. \`<${name} bind:this={component} />\`) and then access the property on the bound component instance (e.g. \`component.${key}\`)\nhttps://svelte.dev/e/bind_invalid_export`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/bind_invalid_export`);
	}
}

/**
 * A component is attempting to bind to a non-bindable property `%key%` belonging to %component% (i.e. `<%name% bind:%key%={...}>`). To mark a property as bindable: `let { %key% = $bindable() } = $props()`
 * @param {string} key
 * @param {string} component
 * @param {string} name
 * @returns {never}
 */
function bind_not_bindable(key, component, name) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`bind_not_bindable\nA component is attempting to bind to a non-bindable property \`${key}\` belonging to ${component} (i.e. \`<${name} bind:${key}={...}>\`). To mark a property as bindable: \`let { ${key} = $bindable() } = $props()\`\nhttps://svelte.dev/e/bind_not_bindable`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/bind_not_bindable`);
	}
}

/**
 * Calling `%method%` on a component instance (of %component%) is no longer valid in Svelte 5
 * @param {string} method
 * @param {string} component
 * @returns {never}
 */
function component_api_changed(method, component) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`component_api_changed\nCalling \`${method}\` on a component instance (of ${component}) is no longer valid in Svelte 5\nhttps://svelte.dev/e/component_api_changed`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/component_api_changed`);
	}
}

/**
 * Attempted to instantiate %component% with `new %name%`, which is no longer valid in Svelte 5. If this component is not under your control, set the `compatibility.componentApi` compiler option to `4` to keep it working.
 * @param {string} component
 * @param {string} name
 * @returns {never}
 */
function component_api_invalid_new(component, name) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`component_api_invalid_new\nAttempted to instantiate ${component} with \`new ${name}\`, which is no longer valid in Svelte 5. If this component is not under your control, set the \`compatibility.componentApi\` compiler option to \`4\` to keep it working.\nhttps://svelte.dev/e/component_api_invalid_new`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/component_api_invalid_new`);
	}
}

/**
 * A derived value cannot reference itself recursively
 * @returns {never}
 */
function derived_references_self() {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`derived_references_self\nA derived value cannot reference itself recursively\nhttps://svelte.dev/e/derived_references_self`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/derived_references_self`);
	}
}

/**
 * Keyed each block has duplicate key `%value%` at indexes %a% and %b%
 * @param {string} a
 * @param {string} b
 * @param {string | undefined | null} [value]
 * @returns {never}
 */
function each_key_duplicate(a, b, value) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`each_key_duplicate\n${value
			? `Keyed each block has duplicate key \`${value}\` at indexes ${a} and ${b}`
			: `Keyed each block has duplicate key at indexes ${a} and ${b}`}\nhttps://svelte.dev/e/each_key_duplicate`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/each_key_duplicate`);
	}
}

/**
 * `%rune%` cannot be used inside an effect cleanup function
 * @param {string} rune
 * @returns {never}
 */
function effect_in_teardown(rune) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`effect_in_teardown\n\`${rune}\` cannot be used inside an effect cleanup function\nhttps://svelte.dev/e/effect_in_teardown`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/effect_in_teardown`);
	}
}

/**
 * Effect cannot be created inside a `$derived` value that was not itself created inside an effect
 * @returns {never}
 */
function effect_in_unowned_derived() {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`effect_in_unowned_derived\nEffect cannot be created inside a \`$derived\` value that was not itself created inside an effect\nhttps://svelte.dev/e/effect_in_unowned_derived`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/effect_in_unowned_derived`);
	}
}

/**
 * `%rune%` can only be used inside an effect (e.g. during component initialisation)
 * @param {string} rune
 * @returns {never}
 */
function effect_orphan(rune) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`effect_orphan\n\`${rune}\` can only be used inside an effect (e.g. during component initialisation)\nhttps://svelte.dev/e/effect_orphan`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/effect_orphan`);
	}
}

/**
 * `$effect.pending()` can only be called inside an effect or derived
 * @returns {never}
 */
function effect_pending_outside_reaction() {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`effect_pending_outside_reaction\n\`$effect.pending()\` can only be called inside an effect or derived\nhttps://svelte.dev/e/effect_pending_outside_reaction`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/effect_pending_outside_reaction`);
	}
}

/**
 * Maximum update depth exceeded. This typically indicates that an effect reads and writes the same piece of state
 * @returns {never}
 */
function effect_update_depth_exceeded() {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`effect_update_depth_exceeded\nMaximum update depth exceeded. This typically indicates that an effect reads and writes the same piece of state\nhttps://svelte.dev/e/effect_update_depth_exceeded`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/effect_update_depth_exceeded`);
	}
}

/**
 * Cannot use `fork(...)` unless the `experimental.async` compiler option is `true`
 * @returns {never}
 */
function experimental_async_fork() {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`experimental_async_fork\nCannot use \`fork(...)\` unless the \`experimental.async\` compiler option is \`true\`\nhttps://svelte.dev/e/experimental_async_fork`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/experimental_async_fork`);
	}
}

/**
 * Cannot use `flushSync` inside an effect
 * @returns {never}
 */
function flush_sync_in_effect() {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`flush_sync_in_effect\nCannot use \`flushSync\` inside an effect\nhttps://svelte.dev/e/flush_sync_in_effect`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/flush_sync_in_effect`);
	}
}

/**
 * Cannot commit a fork that was already discarded
 * @returns {never}
 */
function fork_discarded() {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`fork_discarded\nCannot commit a fork that was already discarded\nhttps://svelte.dev/e/fork_discarded`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/fork_discarded`);
	}
}

/**
 * Cannot create a fork inside an effect or when state changes are pending
 * @returns {never}
 */
function fork_timing() {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`fork_timing\nCannot create a fork inside an effect or when state changes are pending\nhttps://svelte.dev/e/fork_timing`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/fork_timing`);
	}
}

/**
 * `getAbortSignal()` can only be called inside an effect or derived
 * @returns {never}
 */
function get_abort_signal_outside_reaction() {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`get_abort_signal_outside_reaction\n\`getAbortSignal()\` can only be called inside an effect or derived\nhttps://svelte.dev/e/get_abort_signal_outside_reaction`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/get_abort_signal_outside_reaction`);
	}
}

/**
 * Failed to hydrate the application
 * @returns {never}
 */
function hydration_failed() {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`hydration_failed\nFailed to hydrate the application\nhttps://svelte.dev/e/hydration_failed`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/hydration_failed`);
	}
}

/**
 * Could not `{@render}` snippet due to the expression being `null` or `undefined`. Consider using optional chaining `{@render snippet?.()}`
 * @returns {never}
 */
function invalid_snippet() {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`invalid_snippet\nCould not \`{@render}\` snippet due to the expression being \`null\` or \`undefined\`. Consider using optional chaining \`{@render snippet?.()}\`\nhttps://svelte.dev/e/invalid_snippet`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/invalid_snippet`);
	}
}

/**
 * `%name%(...)` cannot be used in runes mode
 * @param {string} name
 * @returns {never}
 */
function lifecycle_legacy_only(name) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`lifecycle_legacy_only\n\`${name}(...)\` cannot be used in runes mode\nhttps://svelte.dev/e/lifecycle_legacy_only`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/lifecycle_legacy_only`);
	}
}

/**
 * Cannot do `bind:%key%={undefined}` when `%key%` has a fallback value
 * @param {string} key
 * @returns {never}
 */
function props_invalid_value(key) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`props_invalid_value\nCannot do \`bind:${key}={undefined}\` when \`${key}\` has a fallback value\nhttps://svelte.dev/e/props_invalid_value`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/props_invalid_value`);
	}
}

/**
 * Rest element properties of `$props()` such as `%property%` are readonly
 * @param {string} property
 * @returns {never}
 */
function props_rest_readonly(property) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`props_rest_readonly\nRest element properties of \`$props()\` such as \`${property}\` are readonly\nhttps://svelte.dev/e/props_rest_readonly`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/props_rest_readonly`);
	}
}

/**
 * The `%rune%` rune is only available inside `.svelte` and `.svelte.js/ts` files
 * @param {string} rune
 * @returns {never}
 */
function rune_outside_svelte(rune) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`rune_outside_svelte\nThe \`${rune}\` rune is only available inside \`.svelte\` and \`.svelte.js/ts\` files\nhttps://svelte.dev/e/rune_outside_svelte`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/rune_outside_svelte`);
	}
}

/**
 * `setContext` must be called when a component first initializes, not in a subsequent effect or after an `await` expression
 * @returns {never}
 */
function set_context_after_init() {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`set_context_after_init\n\`setContext\` must be called when a component first initializes, not in a subsequent effect or after an \`await\` expression\nhttps://svelte.dev/e/set_context_after_init`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/set_context_after_init`);
	}
}

/**
 * Property descriptors defined on `$state` objects must contain `value` and always be `enumerable`, `configurable` and `writable`.
 * @returns {never}
 */
function state_descriptors_fixed() {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`state_descriptors_fixed\nProperty descriptors defined on \`$state\` objects must contain \`value\` and always be \`enumerable\`, \`configurable\` and \`writable\`.\nhttps://svelte.dev/e/state_descriptors_fixed`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/state_descriptors_fixed`);
	}
}

/**
 * Cannot set prototype of `$state` object
 * @returns {never}
 */
function state_prototype_fixed() {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`state_prototype_fixed\nCannot set prototype of \`$state\` object\nhttps://svelte.dev/e/state_prototype_fixed`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/state_prototype_fixed`);
	}
}

/**
 * Updating state inside `$derived(...)`, `$inspect(...)` or a template expression is forbidden. If the value should not be reactive, declare it without `$state`
 * @returns {never}
 */
function state_unsafe_mutation() {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`state_unsafe_mutation\nUpdating state inside \`$derived(...)\`, \`$inspect(...)\` or a template expression is forbidden. If the value should not be reactive, declare it without \`$state\`\nhttps://svelte.dev/e/state_unsafe_mutation`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/state_unsafe_mutation`);
	}
}

/**
 * A `<svelte:boundary>` `reset` function cannot be called while an error is still being handled
 * @returns {never}
 */
function svelte_boundary_reset_onerror() {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`svelte_boundary_reset_onerror\nA \`<svelte:boundary>\` \`reset\` function cannot be called while an error is still being handled\nhttps://svelte.dev/e/svelte_boundary_reset_onerror`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/svelte_boundary_reset_onerror`);
	}
}

}),
3781: 
/*!***************************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/index.js + 53 modules ***!
  \***************************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  noop: () => (/* reexport */ shared_utils.noop),
  user_effect: () => (/* reexport */ reactivity_effects.user_effect),
  template_effect: () => (/* reexport */ reactivity_effects.template_effect),
  pop: () => (/* reexport */ client_context.pop),
  check_target: () => (/* reexport */ check_target),
  reset: () => (/* reexport */ hydration.reset),
  render_effect: () => (/* reexport */ reactivity_effects.render_effect),
  sibling: () => (/* reexport */ operations.sibling),
  set_attribute: () => (/* reexport */ set_attribute),
  append: () => (/* reexport */ template.append),
  FILENAME: () => (/* reexport */ constants.FILENAME),
  legacy_api: () => (/* reexport */ legacy_api),
  strict_equals: () => (/* reexport */ dev_equality.strict_equals),
  event: () => (/* reexport */ elements_events.event),
  init: () => (/* reexport */ init),
  add_locations: () => (/* reexport */ add_locations),
  push: () => (/* reexport */ client_context.push),
  child: () => (/* reexport */ operations.child),
  from_html: () => (/* reexport */ template.from_html),
  next: () => (/* reexport */ hydration.next)
});

// UNUSED EXPORTS: action, get, bind_value, create_ownership_validator, bind_buffered, eager, reactive_import, cleanup_styles, spread_props, create_custom_element, attr, mutable_source, bind_paused, append_styles, bind_resize_observer, bind_property, bind_seekable, css_props, invalidate_inner_signals, pending, assign_nullish, legacy_rest_props, bind_files, update, mutate, props_id, bind_select_value, bind_this, attach, set_class, text, run_after_blockers, sanitize_slots, each, effect_root, inspect, track_reactivity_loss, animation, autofocus, update_pre, once, async_derived, snippet, apply, transition, store_set, async_body, validate_store, store_mutate, validate_void_dynamic_element, invoke_error_boundary, remove_input_defaults, document, replay_events, STYLE, set_checked, set_text, window, key, set_style, head, hmr, update_store, bind_window_size, assign, invalid_default_snippet, deferred_template_effect, boundary, bind_muted, fallback, tag_proxy, validate_each_keys, update_legacy_props, prop, mark_store_binding, delegate, add_svelte_meta, if, from_mathml, for_await_track_reactivity_loss, set_custom_element_data, preventDefault, bind_current_time, remove_textarea_child, add_legacy_event_listener, bind_checked, bind_window_scroll, user_pre_effect, aborted, bind_playback_rate, deep_read_state, set_default_value, bind_ended, state, trusted, validate_binding, bind_content_editable, element, with_script, bind_group, deep_read, bind_volume, derived, flush, invalidate_store, run, bind_prop, store_unsub, validate_dynamic_element_tag, bind_focused, tag, bubble_event, exclude_from_object, CLASS, bind_active_element, untrack, update_prop, bind_online, effect, snapshot, to_array, from_svg, select_option, assign_or, trace, set_value, validate_snippet_args, from_tree, first_child, legacy_pre_effect, assign_and, hydrate_template, slot, effect_tracking, legacy_pre_effect_reset, store_get, component, active_effect, bind_element_size, log_if_contains_state, save, derived_safe_equal, HMR, set_xlink_attribute, comment, raf, setup_stores, NAMESPACE_SVG, stopPropagation, update_pre_store, rest_props, attribute_effect, update_pre_prop, set_selected, tick, await, bind_seeking, equals, init_select, attachment, proxy, async, prevent_snippet_stringification, self, set_default_checked, bind_ready_state, set, index, bind_played, clsx, wrap_snippet, html, stopImmediatePropagation, safe_get

// EXTERNAL MODULE: ../../node_modules/svelte/src/constants.js
var constants = __webpack_require__(7164);
// EXTERNAL MODULE: ../../node_modules/svelte/src/index-client.js
var index_client = __webpack_require__(193);
// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/reactivity/effects.js
var reactivity_effects = __webpack_require__(7770);
;// CONCATENATED MODULE: ../../node_modules/svelte/src/attachments/index.js
/** @import { Action, ActionReturn } from '../action/public' */
/** @import { Attachment } from './public' */





/**
 * Creates an object key that will be recognised as an attachment when the object is spread onto an element,
 * as a programmatic alternative to using `{@attach ...}`. This can be useful for library authors, though
 * is generally not needed when building an app.
 *
 * ```svelte
 * <script>
 * 	import { createAttachmentKey } from 'svelte/attachments';
 *
 * 	const props = {
 * 		class: 'cool',
 * 		onclick: () => alert('clicked'),
 * 		[createAttachmentKey()]: (node) => {
 * 			node.textContent = 'attached!';
 * 		}
 * 	};
 * </script>
 *
 * <button {...props}>click me</button>
 * ```
 * @since 5.29
 */
function createAttachmentKey() {
	return Symbol(constants.ATTACHMENT_KEY);
}

/**
 * Converts an [action](https://svelte.dev/docs/svelte/use) into an [attachment](https://svelte.dev/docs/svelte/@attach) keeping the same behavior.
 * It's useful if you want to start using attachments on components but you have actions provided by a library.
 *
 * Note that the second argument, if provided, must be a function that _returns_ the argument to the
 * action function, not the argument itself.
 *
 * ```svelte
 * <!-- with an action -->
 * <div use:foo={bar}>...</div>
 *
 * <!-- with an attachment -->
 * <div {@attach fromAction(foo, () => bar)}>...</div>
 * ```
 * @template {EventTarget} E
 * @template {unknown} T
 * @overload
 * @param {Action<E, T> | ((element: E, arg: T) => void | ActionReturn<T>)} action The action function
 * @param {() => T} fn A function that returns the argument for the action
 * @returns {Attachment<E>}
 */
/**
 * Converts an [action](https://svelte.dev/docs/svelte/use) into an [attachment](https://svelte.dev/docs/svelte/@attach) keeping the same behavior.
 * It's useful if you want to start using attachments on components but you have actions provided by a library.
 *
 * Note that the second argument, if provided, must be a function that _returns_ the argument to the
 * action function, not the argument itself.
 *
 * ```svelte
 * <!-- with an action -->
 * <div use:foo={bar}>...</div>
 *
 * <!-- with an attachment -->
 * <div {@attach fromAction(foo, () => bar)}>...</div>
 * ```
 * @template {EventTarget} E
 * @overload
 * @param {Action<E, void> | ((element: E) => void | ActionReturn<void>)} action The action function
 * @returns {Attachment<E>}
 */
/**
 * Converts an [action](https://svelte.dev/docs/svelte/use) into an [attachment](https://svelte.dev/docs/svelte/@attach) keeping the same behavior.
 * It's useful if you want to start using attachments on components but you have actions provided by a library.
 *
 * Note that the second argument, if provided, must be a function that _returns_ the argument to the
 * action function, not the argument itself.
 *
 * ```svelte
 * <!-- with an action -->
 * <div use:foo={bar}>...</div>
 *
 * <!-- with an attachment -->
 * <div {@attach fromAction(foo, () => bar)}>...</div>
 * ```
 *
 * @template {EventTarget} E
 * @template {unknown} T
 * @param {Action<E, T> | ((element: E, arg: T) => void | ActionReturn<T>)} action The action function
 * @param {() => T} fn A function that returns the argument for the action
 * @returns {Attachment<E>}
 * @since 5.32
 */
function fromAction(action, fn = /** @type {() => T} */ (shared_utils.noop)) {
	return (element) => {
		const { update, destroy } = (0,index_client.untrack)(() => action(element, fn()) ?? {});

		if (update) {
			var ran = false;
			(0,reactivity_effects.render_effect)(() => {
				const arg = fn();
				if (ran) update(arg);
			});
			ran = true;
		}

		if (destroy) {
			(0,reactivity_effects.teardown)(destroy);
		}
	};
}

// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/context.js
var client_context = __webpack_require__(2204);
// EXTERNAL MODULE: ../../node_modules/svelte/src/utils.js
var utils = __webpack_require__(9264);
// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/runtime.js
var runtime = __webpack_require__(5551);
// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/warnings.js
var warnings = __webpack_require__(8658);
;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dev/assign.js




/**
 *
 * @param {any} a
 * @param {any} b
 * @param {string} property
 * @param {string} location
 */
function compare(a, b, property, location) {
	if (a !== b) {
		warnings.assignment_value_stale(property, /** @type {string} */ ((0,utils.sanitize_location)(location)));
	}

	return a;
}

/**
 * @param {any} object
 * @param {string} property
 * @param {any} value
 * @param {string} location
 */
function assign_assign(object, property, value, location) {
	return compare(
		(object[property] = value),
		(0,runtime.untrack)(() => object[property]),
		property,
		location
	);
}

/**
 * @param {any} object
 * @param {string} property
 * @param {any} value
 * @param {string} location
 */
function assign_and(object, property, value, location) {
	return compare(
		(object[property] &&= value),
		(0,runtime.untrack)(() => object[property]),
		property,
		location
	);
}

/**
 * @param {any} object
 * @param {string} property
 * @param {any} value
 * @param {string} location
 */
function assign_or(object, property, value, location) {
	return compare(
		(object[property] ||= value),
		(0,runtime.untrack)(() => object[property]),
		property,
		location
	);
}

/**
 * @param {any} object
 * @param {string} property
 * @param {any} value
 * @param {string} location
 */
function assign_nullish(object, property, value, location) {
	return compare(
		(object[property] ??= value),
		(0,runtime.untrack)(() => object[property]),
		property,
		location
	);
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dev/css.js
/** @type {Map<String, Set<HTMLStyleElement>>} */
var all_styles = new Map();

/**
 * @param {String} hash
 * @param {HTMLStyleElement} style
 */
function register_style(hash, style) {
	var styles = all_styles.get(hash);

	if (!styles) {
		styles = new Set();
		all_styles.set(hash, styles);
	}

	styles.add(style);
}

/**
 * @param {String} hash
 */
function cleanup_styles(hash) {
	var styles = all_styles.get(hash);
	if (!styles) return;

	for (const style of styles) {
		style.remove();
	}

	all_styles.delete(hash);
}

// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/constants.js
var client_constants = __webpack_require__(5818);
// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/dom/hydration.js
var hydration = __webpack_require__(5742);
;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dev/elements.js
/** @import { SourceLocation } from '#client' */





/**
 * @param {any} fn
 * @param {string} filename
 * @param {SourceLocation[]} locations
 * @returns {any}
 */
function add_locations(fn, filename, locations) {
	return (/** @type {any[]} */ ...args) => {
		const dom = fn(...args);

		var node = hydration.hydrating ? dom : dom.nodeType === client_constants.DOCUMENT_FRAGMENT_NODE ? dom.firstChild : dom;
		assign_locations(node, filename, locations);

		return dom;
	};
}

/**
 * @param {Element} element
 * @param {string} filename
 * @param {SourceLocation} location
 */
function assign_location(element, filename, location) {
	// @ts-expect-error
	element.__svelte_meta = {
		parent: client_context.dev_stack,
		loc: { file: filename, line: location[0], column: location[1] }
	};

	if (location[2]) {
		assign_locations(element.firstChild, filename, location[2]);
	}
}

/**
 * @param {Node | null} node
 * @param {string} filename
 * @param {SourceLocation[]} locations
 */
function assign_locations(node, filename, locations) {
	var i = 0;
	var depth = 0;

	while (node && i < locations.length) {
		if (hydration.hydrating && node.nodeType === client_constants.COMMENT_NODE) {
			var comment = /** @type {Comment} */ (node);
			if (comment.data === constants.HYDRATION_START || comment.data === constants.HYDRATION_START_ELSE) depth += 1;
			else if (comment.data[0] === constants.HYDRATION_END) depth -= 1;
		}

		if (depth === 0 && node.nodeType === client_constants.ELEMENT_NODE) {
			assign_location(/** @type {Element} */ (node), filename, locations[i++]);
		}

		node = node.nextSibling;
	}
}

// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/reactivity/sources.js
var reactivity_sources = __webpack_require__(6718);
// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/render.js
var render = __webpack_require__(5891);
;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dev/hmr.js
/** @import { Source, Effect, TemplateNode } from '#client' */








/**
 * @template {(anchor: Comment, props: any) => any} Component
 * @param {Component} original
 * @param {() => Source<Component>} get_source
 */
function hmr(original, get_source) {
	/**
	 * @param {TemplateNode} anchor
	 * @param {any} props
	 */
	function wrapper(anchor, props) {
		let instance = {};

		/** @type {Effect} */
		let effect;

		let ran = false;

		(0,reactivity_effects.block)(() => {
			const source = get_source();
			const component = (0,runtime.get)(source);

			if (effect) {
				// @ts-ignore
				for (var k in instance) delete instance[k];
				(0,reactivity_effects.destroy_effect)(effect);
			}

			effect = (0,reactivity_effects.branch)(() => {
				// when the component is invalidated, replace it without transitions
				if (ran) (0,render.set_should_intro)(false);

				// preserve getters/setters
				Object.defineProperties(
					instance,
					Object.getOwnPropertyDescriptors(
						// @ts-expect-error
						new.target ? new component(anchor, props) : component(anchor, props)
					)
				);

				if (ran) (0,render.set_should_intro)(true);
			});
		}, client_constants.EFFECT_TRANSPARENT);

		ran = true;

		if (hydration.hydrating) {
			anchor = hydration.hydrate_node;
		}

		return instance;
	}

	// @ts-expect-error
	wrapper[constants.FILENAME] = original[constants.FILENAME];

	// @ts-ignore
	wrapper[constants.HMR] = {
		// When we accept an update, we set the original source to the new component
		original,
		// The `get_source` parameter reads `wrapper[HMR].source`, but in the `accept`
		// function we always replace it with `previous[HMR].source`, which in practice
		// means we only ever update the original
		source: (0,reactivity_sources.source)(original)
	};

	return wrapper;
}

// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/shared/utils.js
var shared_utils = __webpack_require__(2060);
;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dev/ownership.js
/** @typedef {{ file: string, line: number, column: number }} Location */








/**
 * Sets up a validator that
 * - traverses the path of a prop to find out if it is allowed to be mutated
 * - checks that the binding chain is not interrupted
 * @param {Record<string, any>} props
 */
function create_ownership_validator(props) {
	const component = client_context.component_context?.function;
	const parent = client_context.component_context?.p?.function;

	return {
		/**
		 * @param {string} prop
		 * @param {any[]} path
		 * @param {any} result
		 * @param {number} line
		 * @param {number} column
		 */
		mutation: (prop, path, result, line, column) => {
			const name = path[0];
			if (is_bound_or_unset(props, name) || !parent) {
				return result;
			}

			/** @type {any} */
			let value = props;

			for (let i = 0; i < path.length - 1; i++) {
				value = value[path[i]];
				if (!value?.[client_constants.STATE_SYMBOL]) {
					return result;
				}
			}

			const location = (0,utils.sanitize_location)(`${component[constants.FILENAME]}:${line}:${column}`);

			warnings.ownership_invalid_mutation(name, location, prop, parent[constants.FILENAME]);

			return result;
		},
		/**
		 * @param {any} key
		 * @param {any} child_component
		 * @param {() => any} value
		 */
		binding: (key, child_component, value) => {
			if (!is_bound_or_unset(props, key) && parent && value()?.[client_constants.STATE_SYMBOL]) {
				warnings.ownership_invalid_binding(
					component[constants.FILENAME],
					key,
					child_component[constants.FILENAME],
					parent[constants.FILENAME]
				);
			}
		}
	};
}

/**
 * @param {Record<string, any>} props
 * @param {string} prop_name
 */
function is_bound_or_unset(props, prop_name) {
	// Can be the case when someone does `mount(Component, props)` with `let props = $state({...})`
	// or `createClassComponent(Component, props)`
	const is_entry_props = client_constants.STATE_SYMBOL in props || client_constants.LEGACY_PROPS in props;
	return (
		!!(0,shared_utils.get_descriptor)(props, prop_name)?.set ||
		(is_entry_props && prop_name in props) ||
		!(prop_name in props)
	);
}

// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/errors.js
var client_errors = __webpack_require__(1152);
;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dev/legacy.js




/** @param {Function & { [FILENAME]: string }} target */
function check_target(target) {
	if (target) {
		client_errors.component_api_invalid_new(target[constants.FILENAME] ?? 'a component', target.name);
	}
}

function legacy_api() {
	const component = client_context.component_context?.function;

	/** @param {string} method */
	function error(method) {
		client_errors.component_api_changed(method, component[constants.FILENAME]);
	}

	return {
		$destroy: () => error('$destroy()'),
		$on: () => error('$on(...)'),
		$set: () => error('$set(...)')
	};
}

// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/dev/tracing.js
var tracing = __webpack_require__(6265);
// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/shared/clone.js
var clone = __webpack_require__(444);
;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dev/inspect.js






/**
 * @param {() => any[]} get_value
 * @param {Function} inspector
 * @param {boolean} show_stack
 */
function inspect(get_value, inspector, show_stack = false) {
	(0,reactivity_effects.validate_effect)('$inspect');

	let initial = true;
	let error = /** @type {any} */ (constants.UNINITIALIZED);

	// Inspect effects runs synchronously so that we can capture useful
	// stack traces. As a consequence, reading the value might result
	// in an error (an `$inspect(object.property)` will run before the
	// `{#if object}...{/if}` that contains it)
	(0,reactivity_effects.eager_effect)(() => {
		try {
			var value = get_value();
		} catch (e) {
			error = e;
			return;
		}

		var snap = (0,clone.snapshot)(value, true, true);
		(0,runtime.untrack)(() => {
			if (show_stack) {
				inspector(...snap);

				if (!initial) {
					const stack = (0,tracing.get_stack)('$inspect(...)');
					// eslint-disable-next-line no-console

					if (stack) {
						// eslint-disable-next-line no-console
						console.groupCollapsed('stack trace');
						// eslint-disable-next-line no-console
						console.log(stack);
						// eslint-disable-next-line no-console
						console.groupEnd();
					}
				}
			} else {
				inspector(initial ? 'init' : 'update', ...snap);
			}
		});

		initial = false;
	});

	// If an error occurs, we store it (along with its stack trace).
	// If the render effect subsequently runs, we log the error,
	// but if it doesn't run it's because the `$inspect` was
	// destroyed, meaning we don't need to bother
	(0,reactivity_effects.render_effect)(() => {
		try {
			// call `get_value` so that this runs alongside the inspect effect
			get_value();
		} catch {
			// ignore
		}

		if (error !== constants.UNINITIALIZED) {
			// eslint-disable-next-line no-console
			console.error(error);
			error = constants.UNINITIALIZED;
		}
	});
}

// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/reactivity/async.js
var reactivity_async = __webpack_require__(8771);
// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/reactivity/batch.js
var reactivity_batch = __webpack_require__(5812);
// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/dom/blocks/boundary.js + 1 modules
var blocks_boundary = __webpack_require__(9478);
;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/blocks/async.js
/** @import { TemplateNode, Value } from '#client' */






/**
 * @param {TemplateNode} node
 * @param {Array<Promise<void>>} blockers
 * @param {Array<() => Promise<any>>} expressions
 * @param {(anchor: TemplateNode, ...deriveds: Value[]) => void} fn
 */
function async_async(node, blockers = [], expressions = [], fn) {
	var boundary = (0,blocks_boundary.get_boundary)();
	var batch = /** @type {Batch} */ (reactivity_batch.current_batch);
	var blocking = !boundary.is_pending();

	boundary.update_pending_count(1);
	batch.increment(blocking);

	var was_hydrating = hydration.hydrating;

	if (was_hydrating) {
		(0,hydration.hydrate_next)();

		var previous_hydrate_node = hydration.hydrate_node;
		var end = (0,hydration.skip_nodes)(false);
		(0,hydration.set_hydrate_node)(end);
	}

	(0,reactivity_async.flatten)(blockers, [], expressions, (values) => {
		if (was_hydrating) {
			(0,hydration.set_hydrating)(true);
			(0,hydration.set_hydrate_node)(previous_hydrate_node);
		}

		try {
			// get values eagerly to avoid creating blocks if they reject
			for (const d of values) (0,runtime.get)(d);

			fn(node, ...values);
		} finally {
			if (was_hydrating) {
				(0,hydration.set_hydrating)(false);
			}

			boundary.update_pending_count(-1);
			batch.decrement(blocking);
		}
	});
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dev/validation.js

/**
 * @param {Node} anchor
 * @param {...(()=>any)[]} args
 */
function validate_snippet_args(anchor, ...args) {
	if (typeof anchor !== 'object' || !(anchor instanceof Node)) {
		client_errors.invalid_snippet_arguments();
	}

	for (let arg of args) {
		if (typeof arg !== 'function') {
			client_errors.invalid_snippet_arguments();
		}
	}
}

// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/dom/task.js
var dom_task = __webpack_require__(7643);
// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/dom/blocks/branches.js
var blocks_branches = __webpack_require__(5783);
;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/blocks/await.js
/** @import { Source, TemplateNode } from '#client' */











const PENDING = 0;
const THEN = 1;
const CATCH = 2;

/** @typedef {typeof PENDING | typeof THEN | typeof CATCH} AwaitState */

/**
 * @template V
 * @param {TemplateNode} node
 * @param {(() => any)} get_input
 * @param {null | ((anchor: Node) => void)} pending_fn
 * @param {null | ((anchor: Node, value: Source<V>) => void)} then_fn
 * @param {null | ((anchor: Node, error: unknown) => void)} catch_fn
 * @returns {void}
 */
function await_block(node, get_input, pending_fn, then_fn, catch_fn) {
	if (hydration.hydrating) {
		(0,hydration.hydrate_next)();
	}

	var runes = (0,client_context.is_runes)();

	var v = /** @type {V} */ (constants.UNINITIALIZED);
	var value = runes ? (0,reactivity_sources.source)(v) : (0,reactivity_sources.mutable_source)(v, false, false);
	var error = runes ? (0,reactivity_sources.source)(v) : (0,reactivity_sources.mutable_source)(v, false, false);

	var branches = new blocks_branches.BranchManager(node);

	(0,reactivity_effects.block)(() => {
		var input = get_input();
		var destroyed = false;

		/** Whether or not there was a hydration mismatch. Needs to be a `let` or else it isn't treeshaken out */
		// @ts-ignore coercing `node` to a `Comment` causes TypeScript and Prettier to fight
		let mismatch = hydration.hydrating && (0,shared_utils.is_promise)(input) === (node.data === constants.HYDRATION_START_ELSE);

		if (mismatch) {
			// Hydration mismatch: remove everything inside the anchor and start fresh
			(0,hydration.set_hydrate_node)((0,hydration.skip_nodes)());
			(0,hydration.set_hydrating)(false);
		}

		if ((0,shared_utils.is_promise)(input)) {
			var restore = (0,reactivity_async.capture)();
			var resolved = false;

			/**
			 * @param {() => void} fn
			 */
			const resolve = (fn) => {
				if (destroyed) return;

				resolved = true;
				// We don't want to restore the previous batch here; {#await} blocks don't follow the async logic
				// we have elsewhere, instead pending/resolve/fail states are each their own batch so to speak.
				restore(false);
				// Make sure we have a batch, since the branch manager expects one to exist
				reactivity_batch.Batch.ensure();

				if (hydration.hydrating) {
					// `restore()` could set `hydrating` to `true`, which we very much
					// don't want — we want to restore everything _except_ this
					(0,hydration.set_hydrating)(false);
				}

				try {
					fn();
				} finally {
					(0,reactivity_async.unset_context)();

					// without this, the DOM does not update until two ticks after the promise
					// resolves, which is unexpected behaviour (and somewhat irksome to test)
					if (!reactivity_batch.is_flushing_sync) (0,reactivity_batch.flushSync)();
				}
			};

			input.then(
				(v) => {
					resolve(() => {
						(0,reactivity_sources.internal_set)(value, v);
						branches.ensure(THEN, then_fn && ((target) => then_fn(target, value)));
					});
				},
				(e) => {
					resolve(() => {
						(0,reactivity_sources.internal_set)(error, e);
						branches.ensure(THEN, catch_fn && ((target) => catch_fn(target, error)));

						if (!catch_fn) {
							// Rethrow the error if no catch block exists
							throw error.v;
						}
					});
				}
			);

			if (hydration.hydrating) {
				branches.ensure(PENDING, pending_fn);
			} else {
				// Wait a microtask before checking if we should show the pending state as
				// the promise might have resolved by then
				(0,dom_task.queue_micro_task)(() => {
					if (!resolved) {
						resolve(() => {
							branches.ensure(PENDING, pending_fn);
						});
					}
				});
			}
		} else {
			(0,reactivity_sources.internal_set)(value, input);
			branches.ensure(THEN, then_fn && ((target) => then_fn(target, value)));
		}

		if (mismatch) {
			// continue in hydration mode
			(0,hydration.set_hydrating)(true);
		}

		return () => {
			destroyed = true;
		};
	});
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/blocks/if.js
/** @import { TemplateNode } from '#client' */






// TODO reinstate https://github.com/sveltejs/svelte/pull/15250

/**
 * @param {TemplateNode} node
 * @param {(branch: (fn: (anchor: Node) => void, flag?: boolean) => void) => void} fn
 * @param {boolean} [elseif] True if this is an `{:else if ...}` block rather than an `{#if ...}`, as that affects which transitions are considered 'local'
 * @returns {void}
 */
function if_block(node, fn, elseif = false) {
	if (hydration.hydrating) {
		(0,hydration.hydrate_next)();
	}

	var branches = new blocks_branches.BranchManager(node);
	var flags = elseif ? client_constants.EFFECT_TRANSPARENT : 0;

	/**
	 * @param {boolean} condition,
	 * @param {null | ((anchor: Node) => void)} fn
	 */
	function update_branch(condition, fn) {
		if (hydration.hydrating) {
			const is_else = (0,hydration.read_hydration_instruction)(node) === constants.HYDRATION_START_ELSE;

			if (condition === is_else) {
				// Hydration mismatch: remove everything inside the anchor and start fresh.
				// This could happen with `{#if browser}...{/if}`, for example
				var anchor = (0,hydration.skip_nodes)();

				(0,hydration.set_hydrate_node)(anchor);
				branches.anchor = anchor;

				(0,hydration.set_hydrating)(false);
				branches.ensure(condition, fn);
				(0,hydration.set_hydrating)(true);

				return;
			}
		}

		branches.ensure(condition, fn);
	}

	(0,reactivity_effects.block)(() => {
		var has_branch = false;

		fn((fn, flag = true) => {
			has_branch = true;
			update_branch(flag, fn);
		});

		if (!has_branch) {
			update_branch(false, null);
		}
	}, flags);
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/blocks/key.js
/** @import { TemplateNode } from '#client' */





/**
 * @template V
 * @param {TemplateNode} node
 * @param {() => V} get_key
 * @param {(anchor: Node) => TemplateNode | void} render_fn
 * @returns {void}
 */
function key_key(node, get_key, render_fn) {
	if (hydration.hydrating) {
		(0,hydration.hydrate_next)();
	}

	var branches = new blocks_branches.BranchManager(node);

	var legacy = !(0,client_context.is_runes)();

	(0,reactivity_effects.block)(() => {
		var key = get_key();

		// key blocks in Svelte <5 had stupid semantics
		if (legacy && key !== null && typeof key === 'object') {
			key = /** @type {V} */ ({});
		}

		branches.ensure(key, render_fn);
	});
}

// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/dom/operations.js
var operations = __webpack_require__(6756);
;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/blocks/css-props.js
/** @import { TemplateNode } from '#client' */




/**
 * @param {HTMLDivElement | SVGGElement} element
 * @param {() => Record<string, string>} get_styles
 * @returns {void}
 */
function css_props(element, get_styles) {
	if (hydration.hydrating) {
		(0,hydration.set_hydrate_node)(/** @type {TemplateNode} */ ((0,operations.get_first_child)(element)));
	}

	(0,reactivity_effects.render_effect)(() => {
		var styles = get_styles();

		for (var key in styles) {
			var value = styles[key];

			if (value) {
				element.style.setProperty(key, value);
			} else {
				element.style.removeProperty(key);
			}
		}
	});
}

// EXTERNAL MODULE: ../../node_modules/esm-env/index.js + 2 modules
var esm_env = __webpack_require__(3990);
// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/reactivity/deriveds.js
var deriveds = __webpack_require__(6064);
;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/blocks/each.js
/** @import { EachItem, EachState, Effect, MaybeSource, Source, TemplateNode, TransitionManager, Value } from '#client' */
/** @import { Batch } from '../../reactivity/batch.js'; */













/**
 * The row of a keyed each block that is currently updating. We track this
 * so that `animate:` directives have something to attach themselves to
 * @type {EachItem | null}
 */
let current_each_item = null;

/** @param {EachItem | null} item */
function set_current_each_item(item) {
	current_each_item = item;
}

/**
 * @param {any} _
 * @param {number} i
 */
function each_index(_, i) {
	return i;
}

/**
 * Pause multiple effects simultaneously, and coordinate their
 * subsequent destruction. Used in each blocks
 * @param {EachState} state
 * @param {EachItem[]} to_destroy
 * @param {null | Node} controlled_anchor
 */
function pause_effects(state, to_destroy, controlled_anchor) {
	/** @type {TransitionManager[]} */
	var transitions = [];
	var length = to_destroy.length;

	for (var i = 0; i < length; i++) {
		(0,reactivity_effects.pause_children)(to_destroy[i].e, transitions, true);
	}

	(0,reactivity_effects.run_out_transitions)(transitions, () => {
		// If we're in a controlled each block (i.e. the block is the only child of an
		// element), and we are removing all items, _and_ there are no out transitions,
		// we can use the fast path — emptying the element and replacing the anchor
		var fast_path = transitions.length === 0 && controlled_anchor !== null;

		// TODO only destroy effects if no pending batch needs them. otherwise,
		// just set `item.o` back to `false`

		if (fast_path) {
			var anchor = /** @type {Element} */ (controlled_anchor);
			var parent_node = /** @type {Element} */ (anchor.parentNode);

			(0,operations.clear_text_content)(parent_node);
			parent_node.append(anchor);

			state.items.clear();
			each_link(state, to_destroy[0].prev, to_destroy[length - 1].next);
		}

		for (var i = 0; i < length; i++) {
			var item = to_destroy[i];

			if (!fast_path) {
				state.items.delete(item.k);
				each_link(state, item.prev, item.next);
			}

			(0,reactivity_effects.destroy_effect)(item.e, !fast_path);
		}

		if (state.first === to_destroy[0]) {
			state.first = to_destroy[0].prev;
		}
	});
}

/**
 * @template V
 * @param {Element | Comment} node The next sibling node, or the parent node if this is a 'controlled' block
 * @param {number} flags
 * @param {() => V[]} get_collection
 * @param {(value: V, index: number) => any} get_key
 * @param {(anchor: Node, item: MaybeSource<V>, index: MaybeSource<number>) => void} render_fn
 * @param {null | ((anchor: Node) => void)} fallback_fn
 * @returns {void}
 */
function each(node, flags, get_collection, get_key, render_fn, fallback_fn = null) {
	var anchor = node;

	/** @type {EachState} */
	var state = { flags, items: new Map(), first: null };

	var is_controlled = (flags & constants.EACH_IS_CONTROLLED) !== 0;
	var is_reactive_value = (flags & constants.EACH_ITEM_REACTIVE) !== 0;
	var is_reactive_index = (flags & constants.EACH_INDEX_REACTIVE) !== 0;

	if (is_controlled) {
		var parent_node = /** @type {Element} */ (node);

		anchor = hydration.hydrating
			? (0,hydration.set_hydrate_node)(/** @type {Comment | Text} */ ((0,operations.get_first_child)(parent_node)))
			: parent_node.appendChild((0,operations.create_text)());
	}

	if (hydration.hydrating) {
		(0,hydration.hydrate_next)();
	}

	/** @type {{ fragment: DocumentFragment | null, effect: Effect } | null} */
	var fallback = null;

	// TODO: ideally we could use derived for runes mode but because of the ability
	// to use a store which can be mutated, we can't do that here as mutating a store
	// will still result in the collection array being the same from the store
	var each_array = (0,deriveds.derived_safe_equal)(() => {
		var collection = get_collection();

		return (0,shared_utils.is_array)(collection) ? collection : collection == null ? [] : (0,shared_utils.array_from)(collection);
	});

	/** @type {V[]} */
	var array;

	var first_run = true;

	function commit() {
		reconcile(each_effect, array, state, anchor, flags, get_key);

		if (fallback !== null) {
			if (array.length === 0) {
				if (fallback.fragment) {
					anchor.before(fallback.fragment);
					fallback.fragment = null;
				} else {
					(0,reactivity_effects.resume_effect)(fallback.effect);
				}

				each_effect.first = fallback.effect;
			} else {
				(0,reactivity_effects.pause_effect)(fallback.effect, () => {
					// TODO only null out if no pending batch needs it,
					// otherwise re-add `fallback.fragment` and move the
					// effect into it
					fallback = null;
				});
			}
		}
	}

	var each_effect = (0,reactivity_effects.block)(() => {
		array = /** @type {V[]} */ ((0,runtime.get)(each_array));
		var length = array.length;

		/** `true` if there was a hydration mismatch. Needs to be a `let` or else it isn't treeshaken out */
		let mismatch = false;

		if (hydration.hydrating) {
			var is_else = (0,hydration.read_hydration_instruction)(anchor) === constants.HYDRATION_START_ELSE;

			if (is_else !== (length === 0)) {
				// hydration mismatch — remove the server-rendered DOM and start over
				anchor = (0,hydration.skip_nodes)();

				(0,hydration.set_hydrate_node)(anchor);
				(0,hydration.set_hydrating)(false);
				mismatch = true;
			}
		}

		var keys = new Set();
		var batch = /** @type {Batch} */ (reactivity_batch.current_batch);
		var prev = null;
		var defer = (0,operations.should_defer_append)();

		for (var i = 0; i < length; i += 1) {
			if (
				hydration.hydrating &&
				hydration.hydrate_node.nodeType === client_constants.COMMENT_NODE &&
				/** @type {Comment} */ hydration.hydrate_node.data === constants.HYDRATION_END
			) {
				// The server rendered fewer items than expected,
				// so break out and continue appending non-hydrated items
				anchor = /** @type {Comment} */ (hydration.hydrate_node);
				mismatch = true;
				(0,hydration.set_hydrating)(false);
			}

			var value = array[i];
			var key = get_key(value, i);

			var item = first_run ? null : state.items.get(key);

			if (item) {
				// update before reconciliation, to trigger any async updates
				if (is_reactive_value) {
					(0,reactivity_sources.internal_set)(item.v, value);
				}

				if (is_reactive_index) {
					(0,reactivity_sources.internal_set)(/** @type {Value<number>} */ (item.i), i);
				} else {
					item.i = i;
				}

				batch.skipped_effects.delete(item.e);
			} else {
				item = create_item(
					first_run ? anchor : null,
					prev,
					value,
					key,
					i,
					render_fn,
					flags,
					get_collection
				);

				if (first_run) {
					item.o = true;

					if (prev === null) {
						state.first = item;
					} else {
						prev.next = item;
					}

					prev = item;
				}

				state.items.set(key, item);
			}

			keys.add(key);
		}

		if (length === 0 && fallback_fn && !fallback) {
			if (first_run) {
				fallback = {
					fragment: null,
					effect: (0,reactivity_effects.branch)(() => fallback_fn(anchor))
				};
			} else {
				var fragment = document.createDocumentFragment();
				var target = (0,operations.create_text)();
				fragment.append(target);

				fallback = {
					fragment,
					effect: (0,reactivity_effects.branch)(() => fallback_fn(target))
				};
			}
		}

		// remove excess nodes
		if (hydration.hydrating && length > 0) {
			(0,hydration.set_hydrate_node)((0,hydration.skip_nodes)());
		}

		for (const [key, item] of state.items) {
			if (!keys.has(key)) {
				batch.skipped_effects.add(item.e);
			}
		}

		if (!first_run) {
			if (defer) {
				batch.oncommit(commit);
				batch.ondiscard(() => {
					// TODO presumably we need to do something here?
				});
			} else {
				commit();
			}
		}

		if (mismatch) {
			// continue in hydration mode
			(0,hydration.set_hydrating)(true);
		}

		// When we mount the each block for the first time, the collection won't be
		// connected to this effect as the effect hasn't finished running yet and its deps
		// won't be assigned. However, it's possible that when reconciling the each block
		// that a mutation occurred and it's made the collection MAYBE_DIRTY, so reading the
		// collection again can provide consistency to the reactive graph again as the deriveds
		// will now be `CLEAN`.
		(0,runtime.get)(each_array);
	});

	first_run = false;

	if (hydration.hydrating) {
		anchor = hydration.hydrate_node;
	}
}

/**
 * Add, remove, or reorder items output by an each block as its input changes
 * @template V
 * @param {Effect} each_effect
 * @param {Array<V>} array
 * @param {EachState} state
 * @param {Element | Comment | Text} anchor
 * @param {number} flags
 * @param {(value: V, index: number) => any} get_key
 * @returns {void}
 */
function reconcile(each_effect, array, state, anchor, flags, get_key) {
	var is_animated = (flags & constants.EACH_IS_ANIMATED) !== 0;

	var length = array.length;
	var items = state.items;
	var current = state.first;

	/** @type {undefined | Set<EachItem>} */
	var seen;

	/** @type {EachItem | null} */
	var prev = null;

	/** @type {undefined | Set<EachItem>} */
	var to_animate;

	/** @type {EachItem[]} */
	var matched = [];

	/** @type {EachItem[]} */
	var stashed = [];

	/** @type {V} */
	var value;

	/** @type {any} */
	var key;

	/** @type {EachItem | undefined} */
	var item;

	/** @type {number} */
	var i;

	if (is_animated) {
		for (i = 0; i < length; i += 1) {
			value = array[i];
			key = get_key(value, i);
			item = /** @type {EachItem} */ (items.get(key));

			item.a?.measure();
			(to_animate ??= new Set()).add(item);
		}
	}

	for (i = 0; i < length; i += 1) {
		value = array[i];
		key = get_key(value, i);

		item = /** @type {EachItem} */ (items.get(key));

		state.first ??= item;

		if (!item.o) {
			item.o = true;

			var next = prev ? prev.next : current;

			each_link(state, prev, item);
			each_link(state, item, next);

			move(item, next, anchor);
			prev = item;

			matched = [];
			stashed = [];

			current = prev.next;
			continue;
		}

		if ((item.e.f & client_constants.INERT) !== 0) {
			(0,reactivity_effects.resume_effect)(item.e);
			if (is_animated) {
				item.a?.unfix();
				(to_animate ??= new Set()).delete(item);
			}
		}

		if (item !== current) {
			if (seen !== undefined && seen.has(item)) {
				if (matched.length < stashed.length) {
					// more efficient to move later items to the front
					var start = stashed[0];
					var j;

					prev = start.prev;

					var a = matched[0];
					var b = matched[matched.length - 1];

					for (j = 0; j < matched.length; j += 1) {
						move(matched[j], start, anchor);
					}

					for (j = 0; j < stashed.length; j += 1) {
						seen.delete(stashed[j]);
					}

					each_link(state, a.prev, b.next);
					each_link(state, prev, a);
					each_link(state, b, start);

					current = start;
					prev = b;
					i -= 1;

					matched = [];
					stashed = [];
				} else {
					// more efficient to move earlier items to the back
					seen.delete(item);
					move(item, current, anchor);

					each_link(state, item.prev, item.next);
					each_link(state, item, prev === null ? state.first : prev.next);
					each_link(state, prev, item);

					prev = item;
				}

				continue;
			}

			matched = [];
			stashed = [];

			while (current !== null && current.k !== key) {
				// If the each block isn't inert and an item has an effect that is already inert,
				// skip over adding it to our seen Set as the item is already being handled
				if ((current.e.f & client_constants.INERT) === 0) {
					(seen ??= new Set()).add(current);
				}
				stashed.push(current);
				current = current.next;
			}

			if (current === null) {
				continue;
			}

			item = current;
		}

		matched.push(item);
		prev = item;
		current = item.next;
	}

	if (current !== null || seen !== undefined) {
		var to_destroy = seen === undefined ? [] : (0,shared_utils.array_from)(seen);

		while (current !== null) {
			// If the each block isn't inert, then inert effects are currently outroing and will be removed once the transition is finished
			if ((current.e.f & client_constants.INERT) === 0) {
				to_destroy.push(current);
			}
			current = current.next;
		}

		var destroy_length = to_destroy.length;

		if (destroy_length > 0) {
			var controlled_anchor = (flags & constants.EACH_IS_CONTROLLED) !== 0 && length === 0 ? anchor : null;

			if (is_animated) {
				for (i = 0; i < destroy_length; i += 1) {
					to_destroy[i].a?.measure();
				}

				for (i = 0; i < destroy_length; i += 1) {
					to_destroy[i].a?.fix();
				}
			}

			pause_effects(state, to_destroy, controlled_anchor);
		}
	}

	if (is_animated) {
		(0,dom_task.queue_micro_task)(() => {
			if (to_animate === undefined) return;
			for (item of to_animate) {
				item.a?.apply();
			}
		});
	}

	// TODO i have an inkling that the rest of this function is wrong...
	// the offscreen items need to be linked, so that they all update correctly.
	// the last onscreen item should link to the first offscreen item, etc
	each_effect.first = state.first && state.first.e;
	each_effect.last = prev && prev.e;

	if (prev) {
		prev.e.next = null;
	}
}

/**
 * @template V
 * @param {Node | null} anchor
 * @param {EachItem | null} prev
 * @param {V} value
 * @param {unknown} key
 * @param {number} index
 * @param {(anchor: Node, item: V | Source<V>, index: number | Value<number>, collection: () => V[]) => void} render_fn
 * @param {number} flags
 * @param {() => V[]} get_collection
 * @returns {EachItem}
 */
function create_item(anchor, prev, value, key, index, render_fn, flags, get_collection) {
	var previous_each_item = current_each_item;
	var reactive = (flags & constants.EACH_ITEM_REACTIVE) !== 0;
	var mutable = (flags & constants.EACH_ITEM_IMMUTABLE) === 0;

	var v = reactive ? (mutable ? (0,reactivity_sources.mutable_source)(value, false, false) : (0,reactivity_sources.source)(value)) : value;
	var i = (flags & constants.EACH_INDEX_REACTIVE) === 0 ? index : (0,reactivity_sources.source)(index);

	if (esm_env.DEV && reactive) {
		// For tracing purposes, we need to link the source signal we create with the
		// collection + index so that tracing works as intended
		/** @type {Value} */ (v).trace = () => {
			var collection_index = typeof i === 'number' ? index : i.v;
			// eslint-disable-next-line @typescript-eslint/no-unused-expressions
			get_collection()[collection_index];
		};
	}

	/** @type {EachItem} */
	var item = {
		i,
		v,
		k: key,
		a: null,
		// @ts-expect-error
		e: null,
		o: false,
		prev,
		next: null
	};

	current_each_item = item;

	try {
		if (anchor === null) {
			var fragment = document.createDocumentFragment();
			fragment.append((anchor = (0,operations.create_text)()));
		}

		item.e = (0,reactivity_effects.branch)(() => render_fn(/** @type {Node} */ (anchor), v, i, get_collection));

		item.e.prev = prev && prev.e;

		if (prev !== null) {
			prev.next = item;
			prev.e.next = item.e;
		}

		return item;
	} finally {
		current_each_item = previous_each_item;
	}
}

/**
 * @param {EachItem} item
 * @param {EachItem | null} next
 * @param {Text | Element | Comment} anchor
 */
function move(item, next, anchor) {
	var end = item.next ? /** @type {TemplateNode} */ (item.next.e.nodes_start) : anchor;

	var dest = next ? /** @type {TemplateNode} */ (next.e.nodes_start) : anchor;
	var node = /** @type {TemplateNode} */ (item.e.nodes_start);

	while (node !== null && node !== end) {
		var next_node = /** @type {TemplateNode} */ ((0,operations.get_next_sibling)(node));
		dest.before(node);
		node = next_node;
	}
}

/**
 * @param {EachState} state
 * @param {EachItem | null} prev
 * @param {EachItem | null} next
 */
function each_link(state, prev, next) {
	if (prev === null) {
		state.first = next;
	} else {
		prev.next = next;
		prev.e.next = next && next.e;
	}

	if (next !== null) {
		next.prev = prev;
		next.e.prev = prev && prev.e;
	}
}

// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/dom/reconciler.js
var reconciler = __webpack_require__(1876);
// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/dom/template.js
var template = __webpack_require__(2752);
;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/blocks/html.js
/** @import { Effect, TemplateNode } from '#client' */













/**
 * @param {Element} element
 * @param {string | null} server_hash
 * @param {string} value
 */
function check_hash(element, server_hash, value) {
	if (!server_hash || server_hash === (0,utils.hash)(String(value ?? ''))) return;

	let location;

	// @ts-expect-error
	const loc = element.__svelte_meta?.loc;
	if (loc) {
		location = `near ${loc.file}:${loc.line}:${loc.column}`;
	} else if (client_context.dev_current_component_function?.[constants.FILENAME]) {
		location = `in ${client_context.dev_current_component_function[constants.FILENAME]}`;
	}

	warnings.hydration_html_changed((0,utils.sanitize_location)(location));
}

/**
 * @param {Element | Text | Comment} node
 * @param {() => string} get_value
 * @param {boolean} [svg]
 * @param {boolean} [mathml]
 * @param {boolean} [skip_warning]
 * @returns {void}
 */
function html_html(node, get_value, svg = false, mathml = false, skip_warning = false) {
	var anchor = node;

	var value = '';

	(0,reactivity_effects.template_effect)(() => {
		var effect = /** @type {Effect} */ (runtime.active_effect);

		if (value === (value = get_value() ?? '')) {
			if (hydration.hydrating) (0,hydration.hydrate_next)();
			return;
		}

		if (effect.nodes_start !== null) {
			(0,reactivity_effects.remove_effect_dom)(effect.nodes_start, /** @type {TemplateNode} */ (effect.nodes_end));
			effect.nodes_start = effect.nodes_end = null;
		}

		if (value === '') return;

		if (hydration.hydrating) {
			// We're deliberately not trying to repair mismatches between server and client,
			// as it's costly and error-prone (and it's an edge case to have a mismatch anyway)
			var hash = /** @type {Comment} */ hydration.hydrate_node.data;
			var next = (0,hydration.hydrate_next)();
			var last = next;

			while (
				next !== null &&
				(next.nodeType !== client_constants.COMMENT_NODE || /** @type {Comment} */ (next).data !== '')
			) {
				last = next;
				next = /** @type {TemplateNode} */ ((0,operations.get_next_sibling)(next));
			}

			if (next === null) {
				warnings.hydration_mismatch();
				throw constants.HYDRATION_ERROR;
			}

			if (esm_env.DEV && !skip_warning) {
				check_hash(/** @type {Element} */ (next.parentNode), hash, value);
			}

			(0,template.assign_nodes)(hydration.hydrate_node, last);
			anchor = (0,hydration.set_hydrate_node)(next);
			return;
		}

		var html = value + '';
		if (svg) html = `<svg>${html}</svg>`;
		else if (mathml) html = `<math>${html}</math>`;

		// Don't use create_fragment_with_script_from_html here because that would mean script tags are executed.
		// @html is basically `.innerHTML = ...` and that doesn't execute scripts either due to security reasons.
		/** @type {DocumentFragment | Element} */
		var node = (0,reconciler.create_fragment_from_html)(html);

		if (svg || mathml) {
			node = /** @type {Element} */ ((0,operations.get_first_child)(node));
		}

		(0,template.assign_nodes)(
			/** @type {TemplateNode} */ ((0,operations.get_first_child)(node)),
			/** @type {TemplateNode} */ (node.lastChild)
		);

		if (svg || mathml) {
			while ((0,operations.get_first_child)(node)) {
				anchor.before(/** @type {Node} */ ((0,operations.get_first_child)(node)));
			}
		} else {
			anchor.before(node);
		}
	});
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/blocks/slot.js


/**
 * @param {Comment} anchor
 * @param {Record<string, any>} $$props
 * @param {string} name
 * @param {Record<string, unknown>} slot_props
 * @param {null | ((anchor: Comment) => void)} fallback_fn
 */
function slot_slot(anchor, $$props, name, slot_props, fallback_fn) {
	if (hydration.hydrating) {
		(0,hydration.hydrate_next)();
	}

	var slot_fn = $$props.$$slots?.[name];
	// Interop: Can use snippets to fill slots
	var is_interop = false;
	if (slot_fn === true) {
		slot_fn = $$props[name === 'default' ? 'children' : name];
		is_interop = true;
	}

	if (slot_fn === undefined) {
		if (fallback_fn !== null) {
			fallback_fn(anchor);
		}
	} else {
		slot_fn(anchor, is_interop ? () => slot_props : slot_props);
	}
}

/**
 * @param {Record<string, any>} props
 * @returns {Record<string, boolean>}
 */
function sanitize_slots(props) {
	/** @type {Record<string, boolean>} */
	const sanitized = {};
	if (props.children) sanitized.default = true;
	for (const key in props.$$slots) {
		sanitized[key] = true;
	}
	return sanitized;
}

// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/dom/blocks/snippet.js
var snippet = __webpack_require__(5954);
;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/blocks/svelte-component.js
/** @import { TemplateNode, Dom } from '#client' */





/**
 * @template P
 * @template {(props: P) => void} C
 * @param {TemplateNode} node
 * @param {() => C} get_component
 * @param {(anchor: TemplateNode, component: C) => Dom | void} render_fn
 * @returns {void}
 */
function svelte_component_component(node, get_component, render_fn) {
	if (hydration.hydrating) {
		(0,hydration.hydrate_next)();
	}

	var branches = new blocks_branches.BranchManager(node);

	(0,reactivity_effects.block)(() => {
		var component = get_component() ?? null;
		branches.ensure(component, component && ((target) => render_fn(target, component)));
	}, client_constants.EFFECT_TRANSPARENT);
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/blocks/svelte-element.js
/** @import { Effect, TemplateNode } from '#client' */














/**
 * @param {Comment | Element} node
 * @param {() => string} get_tag
 * @param {boolean} is_svg
 * @param {undefined | ((element: Element, anchor: Node | null) => void)} render_fn,
 * @param {undefined | (() => string)} get_namespace
 * @param {undefined | [number, number]} location
 * @returns {void}
 */
function svelte_element_element(node, get_tag, is_svg, render_fn, get_namespace, location) {
	let was_hydrating = hydration.hydrating;

	if (hydration.hydrating) {
		(0,hydration.hydrate_next)();
	}

	var filename = esm_env.DEV && location && client_context.component_context?.function[constants.FILENAME];

	/** @type {null | Element} */
	var element = null;

	if (hydration.hydrating && hydration.hydrate_node.nodeType === client_constants.ELEMENT_NODE) {
		element = /** @type {Element} */ (hydration.hydrate_node);
		(0,hydration.hydrate_next)();
	}

	var anchor = /** @type {TemplateNode} */ (hydration.hydrating ? hydration.hydrate_node : node);

	/**
	 * The keyed `{#each ...}` item block, if any, that this element is inside.
	 * We track this so we can set it when changing the element, allowing any
	 * `animate:` directive to bind itself to the correct block
	 */
	var each_item_block = current_each_item;

	var branches = new blocks_branches.BranchManager(anchor, false);

	(0,reactivity_effects.block)(() => {
		const next_tag = get_tag() || null;
		var ns = get_namespace ? get_namespace() : is_svg || next_tag === 'svg' ? constants.NAMESPACE_SVG : null;

		if (next_tag === null) {
			branches.ensure(null, null);
			(0,render.set_should_intro)(true);
			return;
		}

		branches.ensure(next_tag, (anchor) => {
			// See explanation of `each_item_block` above
			var previous_each_item = current_each_item;
			set_current_each_item(each_item_block);

			if (next_tag) {
				element = hydration.hydrating
					? /** @type {Element} */ (element)
					: ns
						? document.createElementNS(ns, next_tag)
						: document.createElement(next_tag);

				if (esm_env.DEV && location) {
					// @ts-expect-error
					element.__svelte_meta = {
						parent: client_context.dev_stack,
						loc: {
							file: filename,
							line: location[0],
							column: location[1]
						}
					};
				}

				(0,template.assign_nodes)(element, element);

				if (render_fn) {
					if (hydration.hydrating && (0,utils.is_raw_text_element)(next_tag)) {
						// prevent hydration glitches
						element.append(document.createComment(''));
					}

					// If hydrating, use the existing ssr comment as the anchor so that the
					// inner open and close methods can pick up the existing nodes correctly
					var child_anchor = /** @type {TemplateNode} */ (
						hydration.hydrating ? (0,operations.get_first_child)(element) : element.appendChild((0,operations.create_text)())
					);

					if (hydration.hydrating) {
						if (child_anchor === null) {
							(0,hydration.set_hydrating)(false);
						} else {
							(0,hydration.set_hydrate_node)(child_anchor);
						}
					}

					// `child_anchor` is undefined if this is a void element, but we still
					// need to call `render_fn` in order to run actions etc. If the element
					// contains children, it's a user error (which is warned on elsewhere)
					// and the DOM will be silently discarded
					render_fn(element, child_anchor);
				}

				// we do this after calling `render_fn` so that child effects don't override `nodes.end`
				/** @type {Effect} */ runtime.active_effect.nodes_end = element;

				anchor.before(element);
			}

			set_current_each_item(previous_each_item);

			if (hydration.hydrating) {
				(0,hydration.set_hydrate_node)(anchor);
			}
		});

		// revert to the default state after the effect has been created
		(0,render.set_should_intro)(true);

		return () => {
			if (next_tag) {
				// if we're in this callback because we're re-running the effect,
				// disable intros (unless no element is currently displayed)
				(0,render.set_should_intro)(false);
			}
		};
	}, client_constants.EFFECT_TRANSPARENT);

	(0,reactivity_effects.teardown)(() => {
		(0,render.set_should_intro)(true);
	});

	if (was_hydrating) {
		(0,hydration.set_hydrating)(true);
		(0,hydration.set_hydrate_node)(anchor);
	}
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/blocks/svelte-head.js
/** @import { TemplateNode } from '#client' */





/**
 * @param {string} hash
 * @param {(anchor: Node) => void} render_fn
 * @returns {void}
 */
function head(hash, render_fn) {
	// The head function may be called after the first hydration pass and ssr comment nodes may still be present,
	// therefore we need to skip that when we detect that we're not in hydration mode.
	let previous_hydrate_node = null;
	let was_hydrating = hydration.hydrating;

	/** @type {Comment | Text} */
	var anchor;

	if (hydration.hydrating) {
		previous_hydrate_node = hydration.hydrate_node;

		var head_anchor = /** @type {TemplateNode} */ ((0,operations.get_first_child)(document.head));

		// There might be multiple head blocks in our app, and they could have been
		// rendered in an arbitrary order — find one corresponding to this component
		while (
			head_anchor !== null &&
			(head_anchor.nodeType !== client_constants.COMMENT_NODE || /** @type {Comment} */ (head_anchor).data !== hash)
		) {
			head_anchor = /** @type {TemplateNode} */ ((0,operations.get_next_sibling)(head_anchor));
		}

		// If we can't find an opening hydration marker, skip hydration (this can happen
		// if a framework rendered body but not head content)
		if (head_anchor === null) {
			(0,hydration.set_hydrating)(false);
		} else {
			var start = /** @type {TemplateNode} */ ((0,operations.get_next_sibling)(head_anchor));
			head_anchor.remove(); // in case this component is repeated

			(0,hydration.set_hydrate_node)(start);
		}
	}

	if (!hydration.hydrating) {
		anchor = document.head.appendChild((0,operations.create_text)());
	}

	try {
		(0,reactivity_effects.block)(() => render_fn(anchor), client_constants.HEAD_EFFECT);
	} finally {
		if (was_hydrating) {
			(0,hydration.set_hydrating)(true);
			(0,hydration.set_hydrate_node)(/** @type {TemplateNode} */ (previous_hydrate_node));
		}
	}
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/css.js




/**
 * @param {Node} anchor
 * @param {{ hash: string, code: string }} css
 */
function append_styles(anchor, css) {
	// Use `queue_micro_task` to ensure `anchor` is in the DOM, otherwise getRootNode() will yield wrong results
	(0,reactivity_effects.effect)(() => {
		var root = anchor.getRootNode();

		var target = /** @type {ShadowRoot} */ (root).host
			? /** @type {ShadowRoot} */ (root)
			: /** @type {Document} */ (root).head ?? /** @type {Document} */ (root.ownerDocument).head;

		// Always querying the DOM is roughly the same perf as additionally checking for presence in a map first assuming
		// that you'll get cache hits half of the time, so we just always query the dom for simplicity and code savings.
		if (!target.querySelector('#' + css.hash)) {
			const style = document.createElement('style');
			style.id = css.hash;
			style.textContent = css.code;

			target.appendChild(style);

			if (esm_env.DEV) {
				register_style(css.hash, style);
			}
		}
	});
}

// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/reactivity/equality.js
var equality = __webpack_require__(7566);
;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/elements/actions.js
/** @import { ActionPayload } from '#client' */




/**
 * @template P
 * @param {Element} dom
 * @param {(dom: Element, value?: P) => ActionPayload<P>} action
 * @param {() => P} [get_value]
 * @returns {void}
 */
function actions_action(dom, action, get_value) {
	(0,reactivity_effects.effect)(() => {
		var payload = (0,runtime.untrack)(() => action(dom, get_value?.()) || {});

		if (get_value && payload?.update) {
			var inited = false;
			/** @type {P} */
			var prev = /** @type {any} */ ({}); // initialize with something so it's never equal on first run

			(0,reactivity_effects.render_effect)(() => {
				var value = get_value();

				// Action's update method is coarse-grained, i.e. when anything in the passed value changes, update.
				// This works in legacy mode because of mutable_source being updated as a whole, but when using $state
				// together with actions and mutation, it wouldn't notice the change without a deep read.
				(0,runtime.deep_read_state)(value);

				if (inited && (0,equality.safe_not_equal)(prev, value)) {
					prev = value;
					/** @type {Function} */ (payload.update)(value);
				}
			});

			inited = true;
		}

		if (payload?.destroy) {
			return () => /** @type {Function} */ (payload.destroy)();
		}
	});
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/elements/attachments.js
/** @import { Effect } from '#client' */


// TODO in 6.0 or 7.0, when we remove legacy mode, we can simplify this by
// getting rid of the block/branch stuff and just letting the effect rip.
// see https://github.com/sveltejs/svelte/pull/15962

/**
 * @param {Element} node
 * @param {() => (node: Element) => void} get_fn
 */
function attach(node, get_fn) {
	/** @type {false | undefined | ((node: Element) => void)} */
	var fn = undefined;

	/** @type {Effect | null} */
	var e;

	(0,reactivity_effects.block)(() => {
		if (fn !== (fn = get_fn())) {
			if (e) {
				(0,reactivity_effects.destroy_effect)(e);
				e = null;
			}

			if (fn) {
				e = (0,reactivity_effects.branch)(() => {
					(0,reactivity_effects.effect)(() => /** @type {(node: Element) => void} */ (fn)(node));
				});
			}
		}
	});
}

// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/dom/elements/events.js
var elements_events = __webpack_require__(5311);
// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/dom/elements/misc.js
var misc = __webpack_require__(5030);
;// CONCATENATED MODULE: ../../node_modules/svelte/src/escaping.js
const ATTR_REGEX = /[&"<]/g;
const CONTENT_REGEX = /[&<]/g;

/**
 * @template V
 * @param {V} value
 * @param {boolean} [is_attr]
 */
function escape_html(value, is_attr) {
	const str = String(value ?? '');

	const pattern = is_attr ? ATTR_REGEX : CONTENT_REGEX;
	pattern.lastIndex = 0;

	let escaped = '';
	let last = 0;

	while (pattern.test(str)) {
		const i = pattern.lastIndex - 1;
		const ch = str[i];
		escaped += str.substring(last, i) + (ch === '&' ? '&amp;' : ch === '"' ? '&quot;' : '&lt;');
		last = i + 1;
	}

	return escaped + str.substring(last);
}

;// CONCATENATED MODULE: ../../node_modules/clsx/dist/clsx.mjs
function r(e){var t,f,n="";if("string"==typeof e||"number"==typeof e)n+=e;else if("object"==typeof e)if(Array.isArray(e)){var o=e.length;for(t=0;t<o;t++)e[t]&&(f=r(e[t]))&&(n&&(n+=" "),n+=f)}else for(f in e)e[f]&&(n&&(n+=" "),n+=f);return n}function clsx(){for(var e,t,f=0,n="",o=arguments.length;f<o;f++)(e=arguments[f])&&(t=r(e))&&(n&&(n+=" "),n+=t);return n}/* export default */ const dist_clsx = (clsx);
;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/shared/attributes.js



/**
 * `<div translate={false}>` should be rendered as `<div translate="no">` and _not_
 * `<div translate="false">`, which is equivalent to `<div translate="yes">`. There
 * may be other odd cases that need to be added to this list in future
 * @type {Record<string, Map<any, string>>}
 */
const replacements = {
	translate: new Map([
		[true, 'yes'],
		[false, 'no']
	])
};

/**
 * @template V
 * @param {string} name
 * @param {V} value
 * @param {boolean} [is_boolean]
 * @returns {string}
 */
function attributes_attr(name, value, is_boolean = false) {
	// attribute hidden for values other than "until-found" behaves like a boolean attribute
	if (name === 'hidden' && value !== 'until-found') {
		is_boolean = true;
	}
	if (value == null || (!value && is_boolean)) return '';
	const normalized = (name in replacements && replacements[name].get(value)) || value;
	const assignment = is_boolean ? '' : `="${escape_html(normalized, true)}"`;
	return ` ${name}${assignment}`;
}

/**
 * Small wrapper around clsx to preserve Svelte's (weird) handling of falsy values.
 * TODO Svelte 6 revisit this, and likely turn all falsy values into the empty string (what clsx also does)
 * @param  {any} value
 */
function attributes_clsx(value) {
	if (typeof value === 'object') {
		return clsx(value);
	} else {
		return value ?? '';
	}
}

const whitespace = [...' \t\n\r\f\u00a0\u000b\ufeff'];

/**
 * @param {any} value
 * @param {string | null} [hash]
 * @param {Record<string, boolean>} [directives]
 * @returns {string | null}
 */
function to_class(value, hash, directives) {
	var classname = value == null ? '' : '' + value;

	if (hash) {
		classname = classname ? classname + ' ' + hash : hash;
	}

	if (directives) {
		for (var key in directives) {
			if (directives[key]) {
				classname = classname ? classname + ' ' + key : key;
			} else if (classname.length) {
				var len = key.length;
				var a = 0;

				while ((a = classname.indexOf(key, a)) >= 0) {
					var b = a + len;

					if (
						(a === 0 || whitespace.includes(classname[a - 1])) &&
						(b === classname.length || whitespace.includes(classname[b]))
					) {
						classname = (a === 0 ? '' : classname.substring(0, a)) + classname.substring(b + 1);
					} else {
						a = b;
					}
				}
			}
		}
	}

	return classname === '' ? null : classname;
}

/**
 *
 * @param {Record<string,any>} styles
 * @param {boolean} important
 */
function attributes_append_styles(styles, important = false) {
	var separator = important ? ' !important;' : ';';
	var css = '';

	for (var key in styles) {
		var value = styles[key];
		if (value != null && value !== '') {
			css += ' ' + key + ': ' + value + separator;
		}
	}

	return css;
}

/**
 * @param {string} name
 * @returns {string}
 */
function to_css_name(name) {
	if (name[0] !== '-' || name[1] !== '-') {
		return name.toLowerCase();
	}
	return name;
}

/**
 * @param {any} value
 * @param {Record<string, any> | [Record<string, any>, Record<string, any>]} [styles]
 * @returns {string | null}
 */
function to_style(value, styles) {
	if (styles) {
		var new_style = '';

		/** @type {Record<string,any> | undefined} */
		var normal_styles;

		/** @type {Record<string,any> | undefined} */
		var important_styles;

		if (Array.isArray(styles)) {
			normal_styles = styles[0];
			important_styles = styles[1];
		} else {
			normal_styles = styles;
		}

		if (value) {
			value = String(value)
				.replaceAll(/\s*\/\*.*?\*\/\s*/g, '')
				.trim();

			/** @type {boolean | '"' | "'"} */
			var in_str = false;
			var in_apo = 0;
			var in_comment = false;

			var reserved_names = [];

			if (normal_styles) {
				reserved_names.push(...Object.keys(normal_styles).map(to_css_name));
			}
			if (important_styles) {
				reserved_names.push(...Object.keys(important_styles).map(to_css_name));
			}

			var start_index = 0;
			var name_index = -1;

			const len = value.length;
			for (var i = 0; i < len; i++) {
				var c = value[i];

				if (in_comment) {
					if (c === '/' && value[i - 1] === '*') {
						in_comment = false;
					}
				} else if (in_str) {
					if (in_str === c) {
						in_str = false;
					}
				} else if (c === '/' && value[i + 1] === '*') {
					in_comment = true;
				} else if (c === '"' || c === "'") {
					in_str = c;
				} else if (c === '(') {
					in_apo++;
				} else if (c === ')') {
					in_apo--;
				}

				if (!in_comment && in_str === false && in_apo === 0) {
					if (c === ':' && name_index === -1) {
						name_index = i;
					} else if (c === ';' || i === len - 1) {
						if (name_index !== -1) {
							var name = to_css_name(value.substring(start_index, name_index).trim());

							if (!reserved_names.includes(name)) {
								if (c !== ';') {
									i++;
								}

								var property = value.substring(start_index, i).trim();
								new_style += ' ' + property + ';';
							}
						}

						start_index = i + 1;
						name_index = -1;
					}
				}
			}
		}

		if (normal_styles) {
			new_style += attributes_append_styles(normal_styles);
		}

		if (important_styles) {
			new_style += attributes_append_styles(important_styles, true);
		}

		new_style = new_style.trim();
		return new_style === '' ? null : new_style;
	}

	return value == null ? null : String(value);
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/elements/class.js



/**
 * @param {Element} dom
 * @param {boolean | number} is_html
 * @param {string | null} value
 * @param {string} [hash]
 * @param {Record<string, any>} [prev_classes]
 * @param {Record<string, any>} [next_classes]
 * @returns {Record<string, boolean> | undefined}
 */
function set_class(dom, is_html, value, hash, prev_classes, next_classes) {
	// @ts-expect-error need to add __className to patched prototype
	var prev = dom.__className;

	if (
		hydration.hydrating ||
		prev !== value ||
		prev === undefined // for edge case of `class={undefined}`
	) {
		var next_class_name = to_class(value, hash, next_classes);

		if (!hydration.hydrating || next_class_name !== dom.getAttribute('class')) {
			// Removing the attribute when the value is only an empty string causes
			// performance issues vs simply making the className an empty string. So
			// we should only remove the class if the value is nullish
			// and there no hash/directives :
			if (next_class_name == null) {
				dom.removeAttribute('class');
			} else if (is_html) {
				dom.className = next_class_name;
			} else {
				dom.setAttribute('class', next_class_name);
			}
		}

		// @ts-expect-error need to add __className to patched prototype
		dom.__className = value;
	} else if (next_classes && prev_classes !== next_classes) {
		for (var key in next_classes) {
			var is_present = !!next_classes[key];

			if (prev_classes == null || is_present !== !!prev_classes[key]) {
				dom.classList.toggle(key, is_present);
			}
		}
	}

	return next_classes;
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/elements/style.js



/**
 * @param {Element & ElementCSSInlineStyle} dom
 * @param {Record<string, any>} prev
 * @param {Record<string, any>} next
 * @param {string} [priority]
 */
function update_styles(dom, prev = {}, next, priority) {
	for (var key in next) {
		var value = next[key];

		if (prev[key] !== value) {
			if (next[key] == null) {
				dom.style.removeProperty(key);
			} else {
				dom.style.setProperty(key, value, priority);
			}
		}
	}
}

/**
 * @param {Element & ElementCSSInlineStyle} dom
 * @param {string | null} value
 * @param {Record<string, any> | [Record<string, any>, Record<string, any>]} [prev_styles]
 * @param {Record<string, any> | [Record<string, any>, Record<string, any>]} [next_styles]
 */
function set_style(dom, value, prev_styles, next_styles) {
	// @ts-expect-error
	var prev = dom.__style;

	if (hydration.hydrating || prev !== value) {
		var next_style_attr = to_style(value, next_styles);

		if (!hydration.hydrating || next_style_attr !== dom.getAttribute('style')) {
			if (next_style_attr == null) {
				dom.removeAttribute('style');
			} else {
				dom.style.cssText = next_style_attr;
			}
		}

		// @ts-expect-error
		dom.__style = value;
	} else if (next_styles) {
		if (Array.isArray(next_styles)) {
			update_styles(dom, prev_styles?.[0], next_styles[0]);
			update_styles(dom, prev_styles?.[1], next_styles[1], 'important');
		} else {
			update_styles(dom, prev_styles, next_styles);
		}
	}

	return next_styles;
}

// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/dom/elements/bindings/shared.js
var shared = __webpack_require__(6766);
// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/proxy.js
var proxy = __webpack_require__(4899);
;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/elements/bindings/select.js







/**
 * Selects the correct option(s) (depending on whether this is a multiple select)
 * @template V
 * @param {HTMLSelectElement} select
 * @param {V} value
 * @param {boolean} mounting
 */
function select_option(select, value, mounting = false) {
	if (select.multiple) {
		// If value is null or undefined, keep the selection as is
		if (value == undefined) {
			return;
		}

		// If not an array, warn and keep the selection as is
		if (!(0,shared_utils.is_array)(value)) {
			return warnings.select_multiple_invalid_value();
		}

		// Otherwise, update the selection
		for (var option of select.options) {
			option.selected = value.includes(get_option_value(option));
		}

		return;
	}

	for (option of select.options) {
		var option_value = get_option_value(option);
		if ((0,proxy.is)(option_value, value)) {
			option.selected = true;
			return;
		}
	}

	if (!mounting || value !== undefined) {
		select.selectedIndex = -1; // no option should be selected
	}
}

/**
 * Selects the correct option(s) if `value` is given,
 * and then sets up a mutation observer to sync the
 * current selection to the dom when it changes. Such
 * changes could for example occur when options are
 * inside an `#each` block.
 * @param {HTMLSelectElement} select
 */
function init_select(select) {
	var observer = new MutationObserver(() => {
		// @ts-ignore
		select_option(select, select.__value);
		// Deliberately don't update the potential binding value,
		// the model should be preserved unless explicitly changed
	});

	observer.observe(select, {
		// Listen to option element changes
		childList: true,
		subtree: true, // because of <optgroup>
		// Listen to option element value attribute changes
		// (doesn't get notified of select value changes,
		// because that property is not reflected as an attribute)
		attributes: true,
		attributeFilter: ['value']
	});

	(0,reactivity_effects.teardown)(() => {
		observer.disconnect();
	});
}

/**
 * @param {HTMLSelectElement} select
 * @param {() => unknown} get
 * @param {(value: unknown) => void} set
 * @returns {void}
 */
function bind_select_value(select, get, set = get) {
	var batches = new WeakSet();
	var mounting = true;

	(0,shared.listen_to_event_and_reset_event)(select, 'change', (is_reset) => {
		var query = is_reset ? '[selected]' : ':checked';
		/** @type {unknown} */
		var value;

		if (select.multiple) {
			value = [].map.call(select.querySelectorAll(query), get_option_value);
		} else {
			/** @type {HTMLOptionElement | null} */
			var selected_option =
				select.querySelector(query) ??
				// will fall back to first non-disabled option if no option is selected
				select.querySelector('option:not([disabled])');
			value = selected_option && get_option_value(selected_option);
		}

		set(value);

		if (reactivity_batch.current_batch !== null) {
			batches.add(reactivity_batch.current_batch);
		}
	});

	// Needs to be an effect, not a render_effect, so that in case of each loops the logic runs after the each block has updated
	(0,reactivity_effects.effect)(() => {
		var value = get();

		if (select === document.activeElement) {
			// we need both, because in non-async mode, render effects run before previous_batch is set
			var batch = /** @type {Batch} */ (reactivity_batch.previous_batch ?? reactivity_batch.current_batch);

			// Don't update the <select> if it is focused. We can get here if, for example,
			// an update is deferred because of async work depending on the select:
			//
			// <select bind:value={selected}>...</select>
			// <p>{await find(selected)}</p>
			if (batches.has(batch)) {
				return;
			}
		}

		select_option(select, value, mounting);

		// Mounting and value undefined -> take selection from dom
		if (mounting && value === undefined) {
			/** @type {HTMLOptionElement | null} */
			var selected_option = select.querySelector(':checked');
			if (selected_option !== null) {
				value = get_option_value(selected_option);
				set(value);
			}
		}

		// @ts-ignore
		select.__value = value;
		mounting = false;
	});

	init_select(select);
}

/** @param {HTMLOptionElement} option */
function get_option_value(option) {
	// __value only exists if the <option> has a value attribute
	if ('__value' in option) {
		return option.__value;
	} else {
		return option.value;
	}
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/elements/attributes.js
/** @import { Effect } from '#client' */



















const CLASS = Symbol('class');
const STYLE = Symbol('style');

const IS_CUSTOM_ELEMENT = Symbol('is custom element');
const IS_HTML = Symbol('is html');

/**
 * The value/checked attribute in the template actually corresponds to the defaultValue property, so we need
 * to remove it upon hydration to avoid a bug when someone resets the form value.
 * @param {HTMLInputElement} input
 * @returns {void}
 */
function remove_input_defaults(input) {
	if (!hydration.hydrating) return;

	var already_removed = false;

	// We try and remove the default attributes later, rather than sync during hydration.
	// Doing it sync during hydration has a negative impact on performance, but deferring the
	// work in an idle task alleviates this greatly. If a form reset event comes in before
	// the idle callback, then we ensure the input defaults are cleared just before.
	var remove_defaults = () => {
		if (already_removed) return;
		already_removed = true;

		// Remove the attributes but preserve the values
		if (input.hasAttribute('value')) {
			var value = input.value;
			set_attribute(input, 'value', null);
			input.value = value;
		}

		if (input.hasAttribute('checked')) {
			var checked = input.checked;
			set_attribute(input, 'checked', null);
			input.checked = checked;
		}
	};

	// @ts-expect-error
	input.__on_r = remove_defaults;
	(0,dom_task.queue_micro_task)(remove_defaults);
	(0,misc.add_form_reset_listener)();
}

/**
 * @param {Element} element
 * @param {any} value
 */
function set_value(element, value) {
	var attributes = get_attributes(element);

	if (
		attributes.value ===
			(attributes.value =
				// treat null and undefined the same for the initial value
				value ?? undefined) ||
		// @ts-expect-error
		// `progress` elements always need their value set when it's `0`
		(element.value === value && (value !== 0 || element.nodeName !== 'PROGRESS'))
	) {
		return;
	}

	// @ts-expect-error
	element.value = value ?? '';
}

/**
 * @param {Element} element
 * @param {boolean} checked
 */
function set_checked(element, checked) {
	var attributes = get_attributes(element);

	if (
		attributes.checked ===
		(attributes.checked =
			// treat null and undefined the same for the initial value
			checked ?? undefined)
	) {
		return;
	}

	// @ts-expect-error
	element.checked = checked;
}

/**
 * Sets the `selected` attribute on an `option` element.
 * Not set through the property because that doesn't reflect to the DOM,
 * which means it wouldn't be taken into account when a form is reset.
 * @param {HTMLOptionElement} element
 * @param {boolean} selected
 */
function set_selected(element, selected) {
	if (selected) {
		// The selected option could've changed via user selection, and
		// setting the value without this check would set it back.
		if (!element.hasAttribute('selected')) {
			element.setAttribute('selected', '');
		}
	} else {
		element.removeAttribute('selected');
	}
}

/**
 * Applies the default checked property without influencing the current checked property.
 * @param {HTMLInputElement} element
 * @param {boolean} checked
 */
function set_default_checked(element, checked) {
	const existing_value = element.checked;
	element.defaultChecked = checked;
	element.checked = existing_value;
}

/**
 * Applies the default value property without influencing the current value property.
 * @param {HTMLInputElement | HTMLTextAreaElement} element
 * @param {string} value
 */
function set_default_value(element, value) {
	const existing_value = element.value;
	element.defaultValue = value;
	element.value = existing_value;
}

/**
 * @param {Element} element
 * @param {string} attribute
 * @param {string | null} value
 * @param {boolean} [skip_warning]
 */
function set_attribute(element, attribute, value, skip_warning) {
	var attributes = get_attributes(element);

	if (hydration.hydrating) {
		attributes[attribute] = element.getAttribute(attribute);

		if (
			attribute === 'src' ||
			attribute === 'srcset' ||
			(attribute === 'href' && element.nodeName === 'LINK')
		) {
			if (!skip_warning) {
				check_src_in_dev_hydration(element, attribute, value ?? '');
			}

			// If we reset these attributes, they would result in another network request, which we want to avoid.
			// We assume they are the same between client and server as checking if they are equal is expensive
			// (we can't just compare the strings as they can be different between client and server but result in the
			// same url, so we would need to create hidden anchor elements to compare them)
			return;
		}
	}

	if (attributes[attribute] === (attributes[attribute] = value)) return;

	if (attribute === 'loading') {
		// @ts-expect-error
		element[client_constants.LOADING_ATTR_SYMBOL] = value;
	}

	if (value == null) {
		element.removeAttribute(attribute);
	} else if (typeof value !== 'string' && get_setters(element).includes(attribute)) {
		// @ts-ignore
		element[attribute] = value;
	} else {
		element.setAttribute(attribute, value);
	}
}

/**
 * @param {Element} dom
 * @param {string} attribute
 * @param {string} value
 */
function set_xlink_attribute(dom, attribute, value) {
	dom.setAttributeNS('http://www.w3.org/1999/xlink', attribute, value);
}

/**
 * @param {HTMLElement} node
 * @param {string} prop
 * @param {any} value
 */
function set_custom_element_data(node, prop, value) {
	// We need to ensure that setting custom element props, which can
	// invoke lifecycle methods on other custom elements, does not also
	// associate those lifecycle methods with the current active reaction
	// or effect
	var previous_reaction = runtime.active_reaction;
	var previous_effect = runtime.active_effect;

	// If we're hydrating but the custom element is from Svelte, and it already scaffolded,
	// then it might run block logic in hydration mode, which we have to prevent.
	let was_hydrating = hydration.hydrating;
	if (hydration.hydrating) {
		(0,hydration.set_hydrating)(false);
	}

	(0,runtime.set_active_reaction)(null);
	(0,runtime.set_active_effect)(null);

	try {
		if (
			// `style` should use `set_attribute` rather than the setter
			prop !== 'style' &&
			// Don't compute setters for custom elements while they aren't registered yet,
			// because during their upgrade/instantiation they might add more setters.
			// Instead, fall back to a simple "an object, then set as property" heuristic.
			(setters_cache.has(node.getAttribute('is') || node.nodeName) ||
			// customElements may not be available in browser extension contexts
			!customElements ||
			customElements.get(node.getAttribute('is') || node.tagName.toLowerCase())
				? get_setters(node).includes(prop)
				: value && typeof value === 'object')
		) {
			// @ts-expect-error
			node[prop] = value;
		} else {
			// We did getters etc checks already, stringify before passing to set_attribute
			// to ensure it doesn't invoke the same logic again, and potentially populating
			// the setters cache too early.
			set_attribute(node, prop, value == null ? value : String(value));
		}
	} finally {
		(0,runtime.set_active_reaction)(previous_reaction);
		(0,runtime.set_active_effect)(previous_effect);
		if (was_hydrating) {
			(0,hydration.set_hydrating)(true);
		}
	}
}

/**
 * Spreads attributes onto a DOM element, taking into account the currently set attributes
 * @param {Element & ElementCSSInlineStyle} element
 * @param {Record<string | symbol, any> | undefined} prev
 * @param {Record<string | symbol, any>} next New attributes - this function mutates this object
 * @param {string} [css_hash]
 * @param {boolean} [should_remove_defaults]
 * @param {boolean} [skip_warning]
 * @returns {Record<string, any>}
 */
function set_attributes(
	element,
	prev,
	next,
	css_hash,
	should_remove_defaults = false,
	skip_warning = false
) {
	if (hydration.hydrating && should_remove_defaults && element.tagName === 'INPUT') {
		var input = /** @type {HTMLInputElement} */ (element);
		var attribute = input.type === 'checkbox' ? 'defaultChecked' : 'defaultValue';

		if (!(attribute in next)) {
			remove_input_defaults(input);
		}
	}

	var attributes = get_attributes(element);

	var is_custom_element = attributes[IS_CUSTOM_ELEMENT];
	var preserve_attribute_case = !attributes[IS_HTML];

	// If we're hydrating but the custom element is from Svelte, and it already scaffolded,
	// then it might run block logic in hydration mode, which we have to prevent.
	let is_hydrating_custom_element = hydration.hydrating && is_custom_element;
	if (is_hydrating_custom_element) {
		(0,hydration.set_hydrating)(false);
	}

	var current = prev || {};
	var is_option_element = element.tagName === 'OPTION';

	for (var key in prev) {
		if (!(key in next)) {
			next[key] = null;
		}
	}

	if (next.class) {
		next.class = attributes_clsx(next.class);
	} else if (css_hash || next[CLASS]) {
		next.class = null; /* force call to set_class() */
	}

	if (next[STYLE]) {
		next.style ??= null; /* force call to set_style() */
	}

	var setters = get_setters(element);

	// since key is captured we use const
	for (const key in next) {
		// let instead of var because referenced in a closure
		let value = next[key];

		// Up here because we want to do this for the initial value, too, even if it's undefined,
		// and this wouldn't be reached in case of undefined because of the equality check below
		if (is_option_element && key === 'value' && value == null) {
			// The <option> element is a special case because removing the value attribute means
			// the value is set to the text content of the option element, and setting the value
			// to null or undefined means the value is set to the string "null" or "undefined".
			// To align with how we handle this case in non-spread-scenarios, this logic is needed.
			// There's a super-edge-case bug here that is left in in favor of smaller code size:
			// Because of the "set missing props to null" logic above, we can't differentiate
			// between a missing value and an explicitly set value of null or undefined. That means
			// that once set, the value attribute of an <option> element can't be removed. This is
			// a very rare edge case, and removing the attribute altogether isn't possible either
			// for the <option value={undefined}> case, so we're not losing any functionality here.
			// @ts-ignore
			element.value = element.__value = '';
			current[key] = value;
			continue;
		}

		if (key === 'class') {
			var is_html = element.namespaceURI === 'http://www.w3.org/1999/xhtml';
			set_class(element, is_html, value, css_hash, prev?.[CLASS], next[CLASS]);
			current[key] = value;
			current[CLASS] = next[CLASS];
			continue;
		}

		if (key === 'style') {
			set_style(element, value, prev?.[STYLE], next[STYLE]);
			current[key] = value;
			current[STYLE] = next[STYLE];
			continue;
		}

		var prev_value = current[key];

		// Skip if value is unchanged, unless it's `undefined` and the element still has the attribute
		if (value === prev_value && !(value === undefined && element.hasAttribute(key))) {
			continue;
		}

		current[key] = value;

		var prefix = key[0] + key[1]; // this is faster than key.slice(0, 2)
		if (prefix === '$$') continue;

		if (prefix === 'on') {
			/** @type {{ capture?: true }} */
			const opts = {};
			const event_handle_key = '$$' + key;
			let event_name = key.slice(2);
			var delegated = (0,utils.can_delegate_event)(event_name);

			if ((0,utils.is_capture_event)(event_name)) {
				event_name = event_name.slice(0, -7);
				opts.capture = true;
			}

			if (!delegated && prev_value) {
				// Listening to same event but different handler -> our handle function below takes care of this
				// If we were to remove and add listeners in this case, it could happen that the event is "swallowed"
				// (the browser seems to not know yet that a new one exists now) and doesn't reach the handler
				// https://github.com/sveltejs/svelte/issues/11903
				if (value != null) continue;

				element.removeEventListener(event_name, current[event_handle_key], opts);
				current[event_handle_key] = null;
			}

			if (value != null) {
				if (!delegated) {
					/**
					 * @this {any}
					 * @param {Event} evt
					 */
					function handle(evt) {
						current[key].call(this, evt);
					}

					current[event_handle_key] = (0,elements_events.create_event)(event_name, element, handle, opts);
				} else {
					// @ts-ignore
					element[`__${event_name}`] = value;
					(0,elements_events.delegate)([event_name]);
				}
			} else if (delegated) {
				// @ts-ignore
				element[`__${event_name}`] = undefined;
			}
		} else if (key === 'style') {
			// avoid using the setter
			set_attribute(element, key, value);
		} else if (key === 'autofocus') {
			(0,misc.autofocus)(/** @type {HTMLElement} */ (element), Boolean(value));
		} else if (!is_custom_element && (key === '__value' || (key === 'value' && value != null))) {
			// @ts-ignore We're not running this for custom elements because __value is actually
			// how Lit stores the current value on the element, and messing with that would break things.
			element.value = element.__value = value;
		} else if (key === 'selected' && is_option_element) {
			set_selected(/** @type {HTMLOptionElement} */ (element), value);
		} else {
			var name = key;
			if (!preserve_attribute_case) {
				name = (0,utils.normalize_attribute)(name);
			}

			var is_default = name === 'defaultValue' || name === 'defaultChecked';

			if (value == null && !is_custom_element && !is_default) {
				attributes[key] = null;

				if (name === 'value' || name === 'checked') {
					// removing value/checked also removes defaultValue/defaultChecked — preserve
					let input = /** @type {HTMLInputElement} */ (element);
					const use_default = prev === undefined;
					if (name === 'value') {
						let previous = input.defaultValue;
						input.removeAttribute(name);
						input.defaultValue = previous;
						// @ts-ignore
						input.value = input.__value = use_default ? previous : null;
					} else {
						let previous = input.defaultChecked;
						input.removeAttribute(name);
						input.defaultChecked = previous;
						input.checked = use_default ? previous : false;
					}
				} else {
					element.removeAttribute(key);
				}
			} else if (
				is_default ||
				(setters.includes(name) && (is_custom_element || typeof value !== 'string'))
			) {
				// @ts-ignore
				element[name] = value;
				// remove it from attributes's cache
				if (name in attributes) attributes[name] = constants.UNINITIALIZED;
			} else if (typeof value !== 'function') {
				set_attribute(element, name, value, skip_warning);
			}
		}
	}

	if (is_hydrating_custom_element) {
		(0,hydration.set_hydrating)(true);
	}

	return current;
}

/**
 * @param {Element & ElementCSSInlineStyle} element
 * @param {(...expressions: any) => Record<string | symbol, any>} fn
 * @param {Array<() => any>} sync
 * @param {Array<() => Promise<any>>} async
 * @param {Array<Promise<void>>} blockers
 * @param {string} [css_hash]
 * @param {boolean} [should_remove_defaults]
 * @param {boolean} [skip_warning]
 */
function attribute_effect(
	element,
	fn,
	sync = [],
	async = [],
	blockers = [],
	css_hash,
	should_remove_defaults = false,
	skip_warning = false
) {
	(0,reactivity_async.flatten)(blockers, sync, async, (values) => {
		/** @type {Record<string | symbol, any> | undefined} */
		var prev = undefined;

		/** @type {Record<symbol, Effect>} */
		var effects = {};

		var is_select = element.nodeName === 'SELECT';
		var inited = false;

		(0,reactivity_effects.block)(() => {
			var next = fn(...values.map(runtime.get));
			/** @type {Record<string | symbol, any>} */
			var current = set_attributes(
				element,
				prev,
				next,
				css_hash,
				should_remove_defaults,
				skip_warning
			);

			if (inited && is_select && 'value' in next) {
				select_option(/** @type {HTMLSelectElement} */ (element), next.value);
			}

			for (let symbol of Object.getOwnPropertySymbols(effects)) {
				if (!next[symbol]) (0,reactivity_effects.destroy_effect)(effects[symbol]);
			}

			for (let symbol of Object.getOwnPropertySymbols(next)) {
				var n = next[symbol];

				if (symbol.description === constants.ATTACHMENT_KEY && (!prev || n !== prev[symbol])) {
					if (effects[symbol]) (0,reactivity_effects.destroy_effect)(effects[symbol]);
					effects[symbol] = (0,reactivity_effects.branch)(() => attach(element, () => n));
				}

				current[symbol] = n;
			}

			prev = current;
		});

		if (is_select) {
			var select = /** @type {HTMLSelectElement} */ (element);

			(0,reactivity_effects.effect)(() => {
				select_option(select, /** @type {Record<string | symbol, any>} */ (prev).value, true);
				init_select(select);
			});
		}

		inited = true;
	});
}

/**
 *
 * @param {Element} element
 */
function get_attributes(element) {
	return /** @type {Record<string | symbol, unknown>} **/ (
		// @ts-expect-error
		element.__attributes ??= {
			[IS_CUSTOM_ELEMENT]: element.nodeName.includes('-'),
			[IS_HTML]: element.namespaceURI === constants.NAMESPACE_HTML
		}
	);
}

/** @type {Map<string, string[]>} */
var setters_cache = new Map();

/** @param {Element} element */
function get_setters(element) {
	var cache_key = element.getAttribute('is') || element.nodeName;
	var setters = setters_cache.get(cache_key);
	if (setters) return setters;
	setters_cache.set(cache_key, (setters = []));

	var descriptors;
	var proto = element; // In the case of custom elements there might be setters on the instance
	var element_proto = Element.prototype;

	// Stop at Element, from there on there's only unnecessary setters we're not interested in
	// Do not use contructor.name here as that's unreliable in some browser environments
	while (element_proto !== proto) {
		descriptors = (0,shared_utils.get_descriptors)(proto);

		for (var key in descriptors) {
			if (descriptors[key].set) {
				setters.push(key);
			}
		}

		proto = (0,shared_utils.get_prototype_of)(proto);
	}

	return setters;
}

/**
 * @param {any} element
 * @param {string} attribute
 * @param {string} value
 */
function check_src_in_dev_hydration(element, attribute, value) {
	if (!esm_env.DEV) return;
	if (attribute === 'srcset' && srcset_url_equal(element, value)) return;
	if (src_url_equal(element.getAttribute(attribute) ?? '', value)) return;

	warnings.hydration_attribute_changed(
		attribute,
		element.outerHTML.replace(element.innerHTML, element.innerHTML && '...'),
		String(value)
	);
}

/**
 * @param {string} element_src
 * @param {string} url
 * @returns {boolean}
 */
function src_url_equal(element_src, url) {
	if (element_src === url) return true;
	return new URL(element_src, document.baseURI).href === new URL(url, document.baseURI).href;
}

/** @param {string} srcset */
function split_srcset(srcset) {
	return srcset.split(',').map((src) => src.trim().split(' ').filter(Boolean));
}

/**
 * @param {HTMLSourceElement | HTMLImageElement} element
 * @param {string} srcset
 * @returns {boolean}
 */
function srcset_url_equal(element, srcset) {
	var element_urls = split_srcset(element.srcset);
	var urls = split_srcset(srcset);

	return (
		urls.length === element_urls.length &&
		urls.every(
			([url, width], i) =>
				width === element_urls[i][1] &&
				// We need to test both ways because Vite will create an a full URL with
				// `new URL(asset, import.meta.url).href` for the client when `base: './'`, and the
				// relative URLs inside srcset are not automatically resolved to absolute URLs by
				// browsers (in contrast to img.src). This means both SSR and DOM code could
				// contain relative or absolute URLs.
				(src_url_equal(element_urls[i][0], url) || src_url_equal(url, element_urls[i][0]))
		)
	);
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/timing.js
/** @import { Raf } from '#client' */




const timing_now = esm_env.BROWSER ? () => performance.now() : () => Date.now();

/** @type {Raf} */
const raf = {
	// don't access requestAnimationFrame eagerly outside method
	// this allows basic testing of user code without JSDOM
	// bunder will eval and remove ternary when the user's app is built
	tick: /** @param {any} _ */ (_) => (esm_env.BROWSER ? requestAnimationFrame : shared_utils.noop)(_),
	now: () => timing_now(),
	tasks: new Set()
};

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/loop.js
/** @import { TaskCallback, Task, TaskEntry } from '#client' */


// TODO move this into timing.js where it probably belongs

/**
 * @returns {void}
 */
function run_tasks() {
	// use `raf.now()` instead of the `requestAnimationFrame` callback argument, because
	// otherwise things can get wonky https://github.com/sveltejs/svelte/pull/14541
	const now = raf.now();

	raf.tasks.forEach((task) => {
		if (!task.c(now)) {
			raf.tasks["delete"](task);
			task.f();
		}
	});

	if (raf.tasks.size !== 0) {
		raf.tick(run_tasks);
	}
}

/**
 * Creates a new task that runs on each raf frame
 * until it returns a falsy value or is aborted
 * @param {TaskCallback} callback
 * @returns {Task}
 */
function loop(callback) {
	/** @type {TaskEntry} */
	let task;

	if (raf.tasks.size === 0) {
		raf.tick(run_tasks);
	}

	return {
		promise: new Promise((fulfill) => {
			raf.tasks.add((task = { c: callback, f: fulfill }));
		}),
		abort() {
			raf.tasks["delete"](task);
		}
	};
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/elements/transitions.js
/** @import { AnimateFn, Animation, AnimationConfig, EachItem, Effect, TransitionFn, TransitionManager } from '#client' */











/**
 * @param {Element} element
 * @param {'introstart' | 'introend' | 'outrostart' | 'outroend'} type
 * @returns {void}
 */
function dispatch_event(element, type) {
	(0,shared.without_reactive_context)(() => {
		element.dispatchEvent(new CustomEvent(type));
	});
}

/**
 * Converts a property to the camel-case format expected by Element.animate(), KeyframeEffect(), and KeyframeEffect.setKeyframes().
 * @param {string} style
 * @returns {string}
 */
function css_property_to_camelcase(style) {
	// in compliance with spec
	if (style === 'float') return 'cssFloat';
	if (style === 'offset') return 'cssOffset';

	// do not rename custom @properties
	if (style.startsWith('--')) return style;

	const parts = style.split('-');
	if (parts.length === 1) return parts[0];
	return (
		parts[0] +
		parts
			.slice(1)
			.map(/** @param {any} word */ (word) => word[0].toUpperCase() + word.slice(1))
			.join('')
	);
}

/**
 * @param {string} css
 * @returns {Keyframe}
 */
function css_to_keyframe(css) {
	/** @type {Keyframe} */
	const keyframe = {};
	const parts = css.split(';');
	for (const part of parts) {
		const [property, value] = part.split(':');
		if (!property || value === undefined) break;

		const formatted_property = css_property_to_camelcase(property.trim());
		keyframe[formatted_property] = value.trim();
	}
	return keyframe;
}

/** @param {number} t */
const linear = (t) => t;

/**
 * Called inside keyed `{#each ...}` blocks (as `$.animation(...)`). This creates an animation manager
 * and attaches it to the block, so that moves can be animated following reconciliation.
 * @template P
 * @param {Element} element
 * @param {() => AnimateFn<P | undefined>} get_fn
 * @param {(() => P) | null} get_params
 */
function transitions_animation(element, get_fn, get_params) {
	var item = /** @type {EachItem} */ (current_each_item);

	/** @type {DOMRect} */
	var from;

	/** @type {DOMRect} */
	var to;

	/** @type {Animation | undefined} */
	var animation;

	/** @type {null | { position: string, width: string, height: string, transform: string }} */
	var original_styles = null;

	item.a ??= {
		element,
		measure() {
			from = this.element.getBoundingClientRect();
		},
		apply() {
			animation?.abort();

			to = this.element.getBoundingClientRect();

			if (
				from.left !== to.left ||
				from.right !== to.right ||
				from.top !== to.top ||
				from.bottom !== to.bottom
			) {
				const options = get_fn()(this.element, { from, to }, get_params?.());

				animation = animate(this.element, options, undefined, 1, () => {
					animation?.abort();
					animation = undefined;
				});
			}
		},
		fix() {
			// If an animation is already running, transforming the element is likely to fail,
			// because the styles applied by the animation take precedence. In the case of crossfade,
			// that means the `translate(...)` of the crossfade transition overrules the `translate(...)`
			// we would apply below, leading to the element jumping somewhere to the top left.
			if (element.getAnimations().length) return;

			// It's important to destructure these to get fixed values - the object itself has getters,
			// and changing the style to 'absolute' can for example influence the width.
			var { position, width, height } = getComputedStyle(element);

			if (position !== 'absolute' && position !== 'fixed') {
				var style = /** @type {HTMLElement | SVGElement} */ (element).style;

				original_styles = {
					position: style.position,
					width: style.width,
					height: style.height,
					transform: style.transform
				};

				style.position = 'absolute';
				style.width = width;
				style.height = height;
				var to = element.getBoundingClientRect();

				if (from.left !== to.left || from.top !== to.top) {
					var transform = `translate(${from.left - to.left}px, ${from.top - to.top}px)`;
					style.transform = style.transform ? `${style.transform} ${transform}` : transform;
				}
			}
		},
		unfix() {
			if (original_styles) {
				var style = /** @type {HTMLElement | SVGElement} */ (element).style;

				style.position = original_styles.position;
				style.width = original_styles.width;
				style.height = original_styles.height;
				style.transform = original_styles.transform;
			}
		}
	};

	// in the case of a `<svelte:element>`, it's possible for `$.animation(...)` to be called
	// when an animation manager already exists, if the tag changes. in that case, we need to
	// swap out the element rather than creating a new manager, in case it happened at the same
	// moment as a reconciliation
	item.a.element = element;
}

/**
 * Called inside block effects as `$.transition(...)`. This creates a transition manager and
 * attaches it to the current effect — later, inside `pause_effect` and `resume_effect`, we
 * use this to create `intro` and `outro` transitions.
 * @template P
 * @param {number} flags
 * @param {HTMLElement} element
 * @param {() => TransitionFn<P | undefined>} get_fn
 * @param {(() => P) | null} get_params
 * @returns {void}
 */
function transitions_transition(flags, element, get_fn, get_params) {
	var is_intro = (flags & constants.TRANSITION_IN) !== 0;
	var is_outro = (flags & constants.TRANSITION_OUT) !== 0;
	var is_both = is_intro && is_outro;
	var is_global = (flags & constants.TRANSITION_GLOBAL) !== 0;

	/** @type {'in' | 'out' | 'both'} */
	var direction = is_both ? 'both' : is_intro ? 'in' : 'out';

	/** @type {AnimationConfig | ((opts: { direction: 'in' | 'out' }) => AnimationConfig) | undefined} */
	var current_options;

	var inert = element.inert;

	/**
	 * The default overflow style, stashed so we can revert changes during the transition
	 * that are necessary to work around a Safari <18 bug
	 * TODO 6.0 remove this, if older versions of Safari have died out enough
	 */
	var overflow = element.style.overflow;

	/** @type {Animation | undefined} */
	var intro;

	/** @type {Animation | undefined} */
	var outro;

	function get_options() {
		return (0,shared.without_reactive_context)(() => {
			// If a transition is still ongoing, we use the existing options rather than generating
			// new ones. This ensures that reversible transitions reverse smoothly, rather than
			// jumping to a new spot because (for example) a different `duration` was used
			return (current_options ??= get_fn()(element, get_params?.() ?? /** @type {P} */ ({}), {
				direction
			}));
		});
	}

	/** @type {TransitionManager} */
	var transition = {
		is_global,
		in() {
			element.inert = inert;

			if (!is_intro) {
				outro?.abort();
				outro?.reset?.();
				return;
			}

			if (!is_outro) {
				// if we intro then outro then intro again, we want to abort the first intro,
				// if it's not a bidirectional transition
				intro?.abort();
			}

			dispatch_event(element, 'introstart');

			intro = animate(element, get_options(), outro, 1, () => {
				dispatch_event(element, 'introend');

				// Ensure we cancel the animation to prevent leaking
				intro?.abort();
				intro = current_options = undefined;

				element.style.overflow = overflow;
			});
		},
		out(fn) {
			if (!is_outro) {
				fn?.();
				current_options = undefined;
				return;
			}

			element.inert = true;

			dispatch_event(element, 'outrostart');

			outro = animate(element, get_options(), intro, 0, () => {
				dispatch_event(element, 'outroend');
				fn?.();
			});
		},
		stop: () => {
			intro?.abort();
			outro?.abort();
		}
	};

	var e = /** @type {Effect} */ (runtime.active_effect);

	(e.transitions ??= []).push(transition);

	// if this is a local transition, we only want to run it if the parent (branch) effect's
	// parent (block) effect is where the state change happened. we can determine that by
	// looking at whether the block effect is currently initializing
	if (is_intro && render.should_intro) {
		var run = is_global;

		if (!run) {
			var block = /** @type {Effect | null} */ (e.parent);

			// skip over transparent blocks (e.g. snippets, else-if blocks)
			while (block && (block.f & client_constants.EFFECT_TRANSPARENT) !== 0) {
				while ((block = block.parent)) {
					if ((block.f & client_constants.BLOCK_EFFECT) !== 0) break;
				}
			}

			run = !block || (block.f & client_constants.EFFECT_RAN) !== 0;
		}

		if (run) {
			(0,reactivity_effects.effect)(() => {
				(0,runtime.untrack)(() => transition.in());
			});
		}
	}
}

/**
 * Animates an element, according to the provided configuration
 * @param {Element} element
 * @param {AnimationConfig | ((opts: { direction: 'in' | 'out' }) => AnimationConfig)} options
 * @param {Animation | undefined} counterpart The corresponding intro/outro to this outro/intro
 * @param {number} t2 The target `t` value — `1` for intro, `0` for outro
 * @param {(() => void)} on_finish Called after successfully completing the animation
 * @returns {Animation}
 */
function animate(element, options, counterpart, t2, on_finish) {
	var is_intro = t2 === 1;

	if ((0,shared_utils.is_function)(options)) {
		// In the case of a deferred transition (such as `crossfade`), `option` will be
		// a function rather than an `AnimationConfig`. We need to call this function
		// once the DOM has been updated...
		/** @type {Animation} */
		var a;
		var aborted = false;

		(0,dom_task.queue_micro_task)(() => {
			if (aborted) return;
			var o = options({ direction: is_intro ? 'in' : 'out' });
			a = animate(element, o, counterpart, t2, on_finish);
		});

		// ...but we want to do so without using `async`/`await` everywhere, so
		// we return a facade that allows everything to remain synchronous
		return {
			abort: () => {
				aborted = true;
				a?.abort();
			},
			deactivate: () => a.deactivate(),
			reset: () => a.reset(),
			t: () => a.t()
		};
	}

	counterpart?.deactivate();

	if (!options?.duration) {
		on_finish();

		return {
			abort: shared_utils.noop,
			deactivate: shared_utils.noop,
			reset: shared_utils.noop,
			t: () => t2
		};
	}

	const { delay = 0, css, tick, easing = linear } = options;

	var keyframes = [];

	if (is_intro && counterpart === undefined) {
		if (tick) {
			tick(0, 1); // TODO put in nested effect, to avoid interleaved reads/writes?
		}

		if (css) {
			var styles = css_to_keyframe(css(0, 1));
			keyframes.push(styles, styles);
		}
	}

	var get_t = () => 1 - t2;

	// create a dummy animation that lasts as long as the delay (but with whatever devtools
	// multiplier is in effect). in the common case that it is `0`, we keep it anyway so that
	// the CSS keyframes aren't created until the DOM is updated
	//
	// fill forwards to prevent the element from rendering without styles applied
	// see https://github.com/sveltejs/svelte/issues/14732
	var animation = element.animate(keyframes, { duration: delay, fill: 'forwards' });

	animation.onfinish = () => {
		// remove dummy animation from the stack to prevent conflict with main animation
		animation.cancel();

		// for bidirectional transitions, we start from the current position,
		// rather than doing a full intro/outro
		var t1 = counterpart?.t() ?? 1 - t2;
		counterpart?.abort();

		var delta = t2 - t1;
		var duration = /** @type {number} */ (options.duration) * Math.abs(delta);
		var keyframes = [];

		if (duration > 0) {
			/**
			 * Whether or not the CSS includes `overflow: hidden`, in which case we need to
			 * add it as an inline style to work around a Safari <18 bug
			 * TODO 6.0 remove this, if possible
			 */
			var needs_overflow_hidden = false;

			if (css) {
				var n = Math.ceil(duration / (1000 / 60)); // `n` must be an integer, or we risk missing the `t2` value

				for (var i = 0; i <= n; i += 1) {
					var t = t1 + delta * easing(i / n);
					var styles = css_to_keyframe(css(t, 1 - t));
					keyframes.push(styles);

					needs_overflow_hidden ||= styles.overflow === 'hidden';
				}
			}

			if (needs_overflow_hidden) {
				/** @type {HTMLElement} */ (element).style.overflow = 'hidden';
			}

			get_t = () => {
				var time = /** @type {number} */ (
					/** @type {globalThis.Animation} */ (animation).currentTime
				);

				return t1 + delta * easing(time / duration);
			};

			if (tick) {
				loop(() => {
					if (animation.playState !== 'running') return false;

					var t = get_t();
					tick(t, 1 - t);

					return true;
				});
			}
		}

		animation = element.animate(keyframes, { duration, fill: 'forwards' });

		animation.onfinish = () => {
			get_t = () => t2;
			tick?.(t2, 1 - t2);
			on_finish();
		};
	};

	return {
		abort: () => {
			if (animation) {
				animation.cancel();
				// This prevents memory leaks in Chromium
				animation.effect = null;
				// This prevents onfinish to be launched after cancel(),
				// which can happen in some rare cases
				// see https://github.com/sveltejs/svelte/issues/13681
				animation.onfinish = shared_utils.noop;
			}
		},
		deactivate: () => {
			on_finish = shared_utils.noop;
		},
		reset: () => {
			if (t2 === 0) {
				tick?.(1, 0);
			}
		},
		t: () => get_t()
	};
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/elements/bindings/document.js


/**
 * @param {(activeElement: Element | null) => void} update
 * @returns {void}
 */
function bind_active_element(update) {
	(0,shared.listen)(document, ['focusin', 'focusout'], (event) => {
		if (event && event.type === 'focusout' && /** @type {FocusEvent} */ (event).relatedTarget) {
			// The tests still pass if we remove this, because of JSDOM limitations, but it is necessary
			// to avoid temporarily resetting to `document.body`
			return;
		}

		update(document.activeElement);
	});
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/elements/bindings/input.js
/** @import { Batch } from '../../../reactivity/batch.js' */











/**
 * @param {HTMLInputElement} input
 * @param {() => unknown} get
 * @param {(value: unknown) => void} set
 * @returns {void}
 */
function bind_value(input, get, set = get) {
	var batches = new WeakSet();

	(0,shared.listen_to_event_and_reset_event)(input, 'input', async (is_reset) => {
		if (esm_env.DEV && input.type === 'checkbox') {
			// TODO should this happen in prod too?
			client_errors.bind_invalid_checkbox_value();
		}

		/** @type {any} */
		var value = is_reset ? input.defaultValue : input.value;
		value = is_numberlike_input(input) ? to_number(value) : value;
		set(value);

		if (reactivity_batch.current_batch !== null) {
			batches.add(reactivity_batch.current_batch);
		}

		// Because `{#each ...}` blocks work by updating sources inside the flush,
		// we need to wait a tick before checking to see if we should forcibly
		// update the input and reset the selection state
		await (0,runtime.tick)();

		// Respect any validation in accessors
		if (value !== (value = get())) {
			var start = input.selectionStart;
			var end = input.selectionEnd;
			var length = input.value.length;

			// the value is coerced on assignment
			input.value = value ?? '';

			// Restore selection
			if (end !== null) {
				var new_length = input.value.length;
				// If cursor was at end and new input is longer, move cursor to new end
				if (start === end && end === length && new_length > length) {
					input.selectionStart = new_length;
					input.selectionEnd = new_length;
				} else {
					input.selectionStart = start;
					input.selectionEnd = Math.min(end, new_length);
				}
			}
		}
	});

	if (
		// If we are hydrating and the value has since changed,
		// then use the updated value from the input instead.
		(hydration.hydrating && input.defaultValue !== input.value) ||
		// If defaultValue is set, then value == defaultValue
		// TODO Svelte 6: remove input.value check and set to empty string?
		((0,runtime.untrack)(get) == null && input.value)
	) {
		set(is_numberlike_input(input) ? to_number(input.value) : input.value);

		if (reactivity_batch.current_batch !== null) {
			batches.add(reactivity_batch.current_batch);
		}
	}

	(0,reactivity_effects.render_effect)(() => {
		if (esm_env.DEV && input.type === 'checkbox') {
			// TODO should this happen in prod too?
			client_errors.bind_invalid_checkbox_value();
		}

		var value = get();

		if (input === document.activeElement) {
			// we need both, because in non-async mode, render effects run before previous_batch is set
			var batch = /** @type {Batch} */ (reactivity_batch.previous_batch ?? reactivity_batch.current_batch);

			// Never rewrite the contents of a focused input. We can get here if, for example,
			// an update is deferred because of async work depending on the input:
			//
			// <input bind:value={query}>
			// <p>{await find(query)}</p>
			if (batches.has(batch)) {
				return;
			}
		}

		if (is_numberlike_input(input) && value === to_number(input.value)) {
			// handles 0 vs 00 case (see https://github.com/sveltejs/svelte/issues/9959)
			return;
		}

		if (input.type === 'date' && !value && !input.value) {
			// Handles the case where a temporarily invalid date is set (while typing, for example with a leading 0 for the day)
			// and prevents this state from clearing the other parts of the date input (see https://github.com/sveltejs/svelte/issues/7897)
			return;
		}

		// don't set the value of the input if it's the same to allow
		// minlength to work properly
		if (value !== input.value) {
			// @ts-expect-error the value is coerced on assignment
			input.value = value ?? '';
		}
	});
}

/** @type {Set<HTMLInputElement[]>} */
const input_pending = new Set();

/**
 * @param {HTMLInputElement[]} inputs
 * @param {null | [number]} group_index
 * @param {HTMLInputElement} input
 * @param {() => unknown} get
 * @param {(value: unknown) => void} set
 * @returns {void}
 */
function bind_group(inputs, group_index, input, get, set = get) {
	var is_checkbox = input.getAttribute('type') === 'checkbox';
	var binding_group = inputs;

	// needs to be let or related code isn't treeshaken out if it's always false
	let hydration_mismatch = false;

	if (group_index !== null) {
		for (var index of group_index) {
			// @ts-expect-error
			binding_group = binding_group[index] ??= [];
		}
	}

	binding_group.push(input);

	(0,shared.listen_to_event_and_reset_event)(
		input,
		'change',
		() => {
			// @ts-ignore
			var value = input.__value;

			if (is_checkbox) {
				value = get_binding_group_value(binding_group, value, input.checked);
			}

			set(value);
		},
		// TODO better default value handling
		() => set(is_checkbox ? [] : null)
	);

	(0,reactivity_effects.render_effect)(() => {
		var value = get();

		// If we are hydrating and the value has since changed, then use the update value
		// from the input instead.
		if (hydration.hydrating && input.defaultChecked !== input.checked) {
			hydration_mismatch = true;
			return;
		}

		if (is_checkbox) {
			value = value || [];
			// @ts-ignore
			input.checked = value.includes(input.__value);
		} else {
			// @ts-ignore
			input.checked = (0,proxy.is)(input.__value, value);
		}
	});

	(0,reactivity_effects.teardown)(() => {
		var index = binding_group.indexOf(input);

		if (index !== -1) {
			binding_group.splice(index, 1);
		}
	});

	if (!input_pending.has(binding_group)) {
		input_pending.add(binding_group);

		(0,dom_task.queue_micro_task)(() => {
			// necessary to maintain binding group order in all insertion scenarios
			binding_group.sort((a, b) => (a.compareDocumentPosition(b) === 4 ? -1 : 1));
			input_pending.delete(binding_group);
		});
	}

	(0,dom_task.queue_micro_task)(() => {
		if (hydration_mismatch) {
			var value;

			if (is_checkbox) {
				value = get_binding_group_value(binding_group, value, input.checked);
			} else {
				var hydration_input = binding_group.find((input) => input.checked);
				// @ts-ignore
				value = hydration_input?.__value;
			}

			set(value);
		}
	});
}

/**
 * @param {HTMLInputElement} input
 * @param {() => unknown} get
 * @param {(value: unknown) => void} set
 * @returns {void}
 */
function bind_checked(input, get, set = get) {
	(0,shared.listen_to_event_and_reset_event)(input, 'change', (is_reset) => {
		var value = is_reset ? input.defaultChecked : input.checked;
		set(value);
	});

	if (
		// If we are hydrating and the value has since changed,
		// then use the update value from the input instead.
		(hydration.hydrating && input.defaultChecked !== input.checked) ||
		// If defaultChecked is set, then checked == defaultChecked
		(0,runtime.untrack)(get) == null
	) {
		set(input.checked);
	}

	(0,reactivity_effects.render_effect)(() => {
		var value = get();
		input.checked = Boolean(value);
	});
}

/**
 * @template V
 * @param {Array<HTMLInputElement>} group
 * @param {V} __value
 * @param {boolean} checked
 * @returns {V[]}
 */
function get_binding_group_value(group, __value, checked) {
	/** @type {Set<V>} */
	var value = new Set();

	for (var i = 0; i < group.length; i += 1) {
		if (group[i].checked) {
			// @ts-ignore
			value.add(group[i].__value);
		}
	}

	if (!checked) {
		value.delete(__value);
	}

	return Array.from(value);
}

/**
 * @param {HTMLInputElement} input
 */
function is_numberlike_input(input) {
	var type = input.type;
	return type === 'number' || type === 'range';
}

/**
 * @param {string} value
 */
function to_number(value) {
	return value === '' ? null : +value;
}

/**
 * @param {HTMLInputElement} input
 * @param {() => FileList | null} get
 * @param {(value: FileList | null) => void} set
 */
function bind_files(input, get, set = get) {
	(0,shared.listen_to_event_and_reset_event)(input, 'change', () => {
		set(input.files);
	});

	if (
		// If we are hydrating and the value has since changed,
		// then use the updated value from the input instead.
		hydration.hydrating &&
		input.files
	) {
		set(input.files);
	}

	(0,reactivity_effects.render_effect)(() => {
		input.files = get();
	});
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/elements/bindings/media.js



/** @param {TimeRanges} ranges */
function time_ranges_to_array(ranges) {
	var array = [];

	for (var i = 0; i < ranges.length; i += 1) {
		array.push({ start: ranges.start(i), end: ranges.end(i) });
	}

	return array;
}

/**
 * @param {HTMLVideoElement | HTMLAudioElement} media
 * @param {() => number | undefined} get
 * @param {(value: number) => void} set
 * @returns {void}
 */
function bind_current_time(media, get, set = get) {
	/** @type {number} */
	var raf_id;
	/** @type {number} */
	var value;

	// Ideally, listening to timeupdate would be enough, but it fires too infrequently for the currentTime
	// binding, which is why we use a raf loop, too. We additionally still listen to timeupdate because
	// the user could be scrubbing through the video using the native controls when the media is paused.
	var callback = () => {
		cancelAnimationFrame(raf_id);

		if (!media.paused) {
			raf_id = requestAnimationFrame(callback);
		}

		var next_value = media.currentTime;
		if (value !== next_value) {
			set((value = next_value));
		}
	};

	raf_id = requestAnimationFrame(callback);
	media.addEventListener('timeupdate', callback);

	(0,reactivity_effects.render_effect)(() => {
		var next_value = Number(get());

		if (value !== next_value && !isNaN(/** @type {any} */ (next_value))) {
			media.currentTime = value = next_value;
		}
	});

	(0,reactivity_effects.teardown)(() => {
		cancelAnimationFrame(raf_id);
		media.removeEventListener('timeupdate', callback);
	});
}

/**
 * @param {HTMLVideoElement | HTMLAudioElement} media
 * @param {(array: Array<{ start: number; end: number }>) => void} set
 */
function bind_buffered(media, set) {
	/** @type {{ start: number; end: number; }[]} */
	var current;

	// `buffered` can update without emitting any event, so we check it on various events.
	// By specs, `buffered` always returns a new object, so we have to compare deeply.
	(0,shared.listen)(media, ['loadedmetadata', 'progress', 'timeupdate', 'seeking'], () => {
		var ranges = media.buffered;

		if (
			!current ||
			current.length !== ranges.length ||
			current.some((range, i) => ranges.start(i) !== range.start || ranges.end(i) !== range.end)
		) {
			current = time_ranges_to_array(ranges);
			set(current);
		}
	});
}

/**
 * @param {HTMLVideoElement | HTMLAudioElement} media
 * @param {(array: Array<{ start: number; end: number }>) => void} set
 */
function bind_seekable(media, set) {
	(0,shared.listen)(media, ['loadedmetadata'], () => set(time_ranges_to_array(media.seekable)));
}

/**
 * @param {HTMLVideoElement | HTMLAudioElement} media
 * @param {(array: Array<{ start: number; end: number }>) => void} set
 */
function bind_played(media, set) {
	(0,shared.listen)(media, ['timeupdate'], () => set(time_ranges_to_array(media.played)));
}

/**
 * @param {HTMLVideoElement | HTMLAudioElement} media
 * @param {(seeking: boolean) => void} set
 */
function bind_seeking(media, set) {
	(0,shared.listen)(media, ['seeking', 'seeked'], () => set(media.seeking));
}

/**
 * @param {HTMLVideoElement | HTMLAudioElement} media
 * @param {(seeking: boolean) => void} set
 */
function bind_ended(media, set) {
	(0,shared.listen)(media, ['timeupdate', 'ended'], () => set(media.ended));
}

/**
 * @param {HTMLVideoElement | HTMLAudioElement} media
 * @param {(ready_state: number) => void} set
 */
function bind_ready_state(media, set) {
	(0,shared.listen)(
		media,
		['loadedmetadata', 'loadeddata', 'canplay', 'canplaythrough', 'playing', 'waiting', 'emptied'],
		() => set(media.readyState)
	);
}

/**
 * @param {HTMLVideoElement | HTMLAudioElement} media
 * @param {() => number | undefined} get
 * @param {(playback_rate: number) => void} set
 */
function bind_playback_rate(media, get, set = get) {
	// Needs to happen after element is inserted into the dom (which is guaranteed by using effect),
	// else playback will be set back to 1 by the browser
	(0,reactivity_effects.effect)(() => {
		var value = Number(get());

		if (value !== media.playbackRate && !isNaN(value)) {
			media.playbackRate = value;
		}
	});

	// Start listening to ratechange events after the element is inserted into the dom,
	// else playback will be set to 1 by the browser
	(0,reactivity_effects.effect)(() => {
		(0,shared.listen)(media, ['ratechange'], () => {
			set(media.playbackRate);
		});
	});
}

/**
 * @param {HTMLVideoElement | HTMLAudioElement} media
 * @param {() => boolean | undefined} get
 * @param {(paused: boolean) => void} set
 */
function bind_paused(media, get, set = get) {
	var paused = get();

	var update = () => {
		if (paused !== media.paused) {
			set((paused = media.paused));
		}
	};

	// If someone switches the src while media is playing, the player will pause.
	// Listen to the canplay event to get notified of this situation.
	(0,shared.listen)(media, ['play', 'pause', 'canplay'], update, paused == null);

	// Needs to be an effect to ensure media element is mounted: else, if paused is `false` (i.e. should play right away)
	// a "The play() request was interrupted by a new load request" error would be thrown because the resource isn't loaded yet.
	(0,reactivity_effects.effect)(() => {
		if ((paused = !!get()) !== media.paused) {
			if (paused) {
				media.pause();
			} else {
				media.play().catch(() => {
					set((paused = true));
				});
			}
		}
	});
}

/**
 * @param {HTMLVideoElement | HTMLAudioElement} media
 * @param {() => number | undefined} get
 * @param {(volume: number) => void} set
 */
function bind_volume(media, get, set = get) {
	var callback = () => {
		set(media.volume);
	};

	if (get() == null) {
		callback();
	}

	(0,shared.listen)(media, ['volumechange'], callback, false);

	(0,reactivity_effects.render_effect)(() => {
		var value = Number(get());

		if (value !== media.volume && !isNaN(value)) {
			media.volume = value;
		}
	});
}

/**
 * @param {HTMLVideoElement | HTMLAudioElement} media
 * @param {() => boolean | undefined} get
 * @param {(muted: boolean) => void} set
 */
function bind_muted(media, get, set = get) {
	var callback = () => {
		set(media.muted);
	};

	if (get() == null) {
		callback();
	}

	(0,shared.listen)(media, ['volumechange'], callback, false);

	(0,reactivity_effects.render_effect)(() => {
		var value = !!get();

		if (media.muted !== value) media.muted = value;
	});
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/elements/bindings/navigator.js


/**
 * @param {(online: boolean) => void} update
 * @returns {void}
 */
function bind_online(update) {
	(0,shared.listen)(window, ['online', 'offline'], () => {
		update(navigator.onLine);
	});
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/elements/bindings/props.js



/**
 * Makes an `export`ed (non-prop) variable available on the `$$props` object
 * so that consumers can do `bind:x` on the component.
 * @template V
 * @param {Record<string, unknown>} props
 * @param {string} prop
 * @param {V} value
 * @returns {void}
 */
function bind_prop(props, prop, value) {
	var desc = (0,shared_utils.get_descriptor)(props, prop);

	if (desc && desc.set) {
		props[prop] = value;
		(0,reactivity_effects.teardown)(() => {
			props[prop] = null;
		});
	}
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/elements/bindings/size.js



/**
 * Resize observer singleton.
 * One listener per element only!
 * https://groups.google.com/a/chromium.org/g/blink-dev/c/z6ienONUb5A/m/F5-VcUZtBAAJ
 */
class ResizeObserverSingleton {
	/** */
	#listeners = new WeakMap();

	/** @type {ResizeObserver | undefined} */
	#observer;

	/** @type {ResizeObserverOptions} */
	#options;

	/** @static */
	static entries = new WeakMap();

	/** @param {ResizeObserverOptions} options */
	constructor(options) {
		this.#options = options;
	}

	/**
	 * @param {Element} element
	 * @param {(entry: ResizeObserverEntry) => any} listener
	 */
	observe(element, listener) {
		var listeners = this.#listeners.get(element) || new Set();
		listeners.add(listener);

		this.#listeners.set(element, listeners);
		this.#getObserver().observe(element, this.#options);

		return () => {
			var listeners = this.#listeners.get(element);
			listeners.delete(listener);

			if (listeners.size === 0) {
				this.#listeners.delete(element);
				/** @type {ResizeObserver} */ (this.#observer).unobserve(element);
			}
		};
	}

	#getObserver() {
		return (
			this.#observer ??
			(this.#observer = new ResizeObserver(
				/** @param {any} entries */ (entries) => {
					for (var entry of entries) {
						ResizeObserverSingleton.entries.set(entry.target, entry);
						for (var listener of this.#listeners.get(entry.target) || []) {
							listener(entry);
						}
					}
				}
			))
		);
	}
}

var resize_observer_content_box = /* @__PURE__ */ new ResizeObserverSingleton({
	box: 'content-box'
});

var resize_observer_border_box = /* @__PURE__ */ new ResizeObserverSingleton({
	box: 'border-box'
});

var resize_observer_device_pixel_content_box = /* @__PURE__ */ new ResizeObserverSingleton({
	box: 'device-pixel-content-box'
});

/**
 * @param {Element} element
 * @param {'contentRect' | 'contentBoxSize' | 'borderBoxSize' | 'devicePixelContentBoxSize'} type
 * @param {(entry: keyof ResizeObserverEntry) => void} set
 */
function bind_resize_observer(element, type, set) {
	var observer =
		type === 'contentRect' || type === 'contentBoxSize'
			? resize_observer_content_box
			: type === 'borderBoxSize'
				? resize_observer_border_box
				: resize_observer_device_pixel_content_box;

	var unsub = observer.observe(element, /** @param {any} entry */ (entry) => set(entry[type]));
	(0,reactivity_effects.teardown)(unsub);
}

/**
 * @param {HTMLElement} element
 * @param {'clientWidth' | 'clientHeight' | 'offsetWidth' | 'offsetHeight'} type
 * @param {(size: number) => void} set
 */
function bind_element_size(element, type, set) {
	var unsub = resize_observer_border_box.observe(element, () => set(element[type]));

	(0,reactivity_effects.effect)(() => {
		// The update could contain reads which should be ignored
		(0,runtime.untrack)(() => set(element[type]));
		return unsub;
	});
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/elements/bindings/this.js





/**
 * @param {any} bound_value
 * @param {Element} element_or_component
 * @returns {boolean}
 */
function is_bound_this(bound_value, element_or_component) {
	return (
		bound_value === element_or_component || bound_value?.[client_constants.STATE_SYMBOL] === element_or_component
	);
}

/**
 * @param {any} element_or_component
 * @param {(value: unknown, ...parts: unknown[]) => void} update
 * @param {(...parts: unknown[]) => unknown} get_value
 * @param {() => unknown[]} [get_parts] Set if the this binding is used inside an each block,
 * 										returns all the parts of the each block context that are used in the expression
 * @returns {void}
 */
function bind_this(element_or_component = {}, update, get_value, get_parts) {
	(0,reactivity_effects.effect)(() => {
		/** @type {unknown[]} */
		var old_parts;

		/** @type {unknown[]} */
		var parts;

		(0,reactivity_effects.render_effect)(() => {
			old_parts = parts;
			// We only track changes to the parts, not the value itself to avoid unnecessary reruns.
			parts = get_parts?.() || [];

			(0,runtime.untrack)(() => {
				if (element_or_component !== get_value(...parts)) {
					update(element_or_component, ...parts);
					// If this is an effect rerun (cause: each block context changes), then nullfiy the binding at
					// the previous position if it isn't already taken over by a different effect.
					if (old_parts && is_bound_this(get_value(...old_parts), element_or_component)) {
						update(null, ...old_parts);
					}
				}
			});
		});

		return () => {
			// We cannot use effects in the teardown phase, we we use a microtask instead.
			(0,dom_task.queue_micro_task)(() => {
				if (parts && is_bound_this(get_value(...parts), element_or_component)) {
					update(null, ...parts);
				}
			});
		};
	});

	return element_or_component;
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/elements/bindings/universal.js



/**
 * @param {'innerHTML' | 'textContent' | 'innerText'} property
 * @param {HTMLElement} element
 * @param {() => unknown} get
 * @param {(value: unknown) => void} set
 * @returns {void}
 */
function bind_content_editable(property, element, get, set = get) {
	element.addEventListener('input', () => {
		// @ts-ignore
		set(element[property]);
	});

	(0,reactivity_effects.render_effect)(() => {
		var value = get();

		if (element[property] !== value) {
			if (value == null) {
				// @ts-ignore
				var non_null_value = element[property];
				set(non_null_value);
			} else {
				// @ts-ignore
				element[property] = value + '';
			}
		}
	});
}

/**
 * @param {string} property
 * @param {string} event_name
 * @param {Element} element
 * @param {(value: unknown) => void} set
 * @param {() => unknown} [get]
 * @returns {void}
 */
function bind_property(property, event_name, element, set, get) {
	var handler = () => {
		// @ts-ignore
		set(element[property]);
	};

	element.addEventListener(event_name, handler);

	if (get) {
		(0,reactivity_effects.render_effect)(() => {
			// @ts-ignore
			element[property] = get();
		});
	} else {
		handler();
	}

	// @ts-ignore
	if (element === document.body || element === window || element === document) {
		(0,reactivity_effects.teardown)(() => {
			element.removeEventListener(event_name, handler);
		});
	}
}

/**
 * @param {HTMLElement} element
 * @param {(value: unknown) => void} set
 * @returns {void}
 */
function bind_focused(element, set) {
	(0,shared.listen)(element, ['focus', 'blur'], () => {
		set(element === document.activeElement);
	});
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/elements/bindings/window.js



/**
 * @param {'x' | 'y'} type
 * @param {() => number} get
 * @param {(value: number) => void} set
 * @returns {void}
 */
function bind_window_scroll(type, get, set = get) {
	var is_scrolling_x = type === 'x';

	var target_handler = () =>
		(0,shared.without_reactive_context)(() => {
			scrolling = true;
			clearTimeout(timeout);
			timeout = setTimeout(clear, 100); // TODO use scrollend event if supported (or when supported everywhere?)

			set(window[is_scrolling_x ? 'scrollX' : 'scrollY']);
		});

	addEventListener('scroll', target_handler, {
		passive: true
	});

	var scrolling = false;

	/** @type {ReturnType<typeof setTimeout>} */
	var timeout;
	var clear = () => {
		scrolling = false;
	};
	var first = true;

	(0,reactivity_effects.render_effect)(() => {
		var latest_value = get();
		// Don't scroll to the initial value for accessibility reasons
		if (first) {
			first = false;
		} else if (!scrolling && latest_value != null) {
			scrolling = true;
			clearTimeout(timeout);
			if (is_scrolling_x) {
				scrollTo(latest_value, window.scrollY);
			} else {
				scrollTo(window.scrollX, latest_value);
			}
			timeout = setTimeout(clear, 100);
		}
	});

	// Browsers don't fire the scroll event for the initial scroll position when scroll style isn't set to smooth
	(0,reactivity_effects.effect)(target_handler);

	(0,reactivity_effects.teardown)(() => {
		removeEventListener('scroll', target_handler);
	});
}

/**
 * @param {'innerWidth' | 'innerHeight' | 'outerWidth' | 'outerHeight'} type
 * @param {(size: number) => void} set
 */
function bind_window_size(type, set) {
	(0,shared.listen)(window, ['resize'], () => (0,shared.without_reactive_context)(() => set(window[type])));
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/legacy/event-modifiers.js




/**
 * Substitute for the `trusted` event modifier
 * @deprecated
 * @param {(event: Event, ...args: Array<unknown>) => void} fn
 * @returns {(event: Event, ...args: unknown[]) => void}
 */
function trusted(fn) {
	return function (...args) {
		var event = /** @type {Event} */ (args[0]);
		if (event.isTrusted) {
			// @ts-ignore
			fn?.apply(this, args);
		}
	};
}

/**
 * Substitute for the `self` event modifier
 * @deprecated
 * @param {(event: Event, ...args: Array<unknown>) => void} fn
 * @returns {(event: Event, ...args: unknown[]) => void}
 */
function event_modifiers_self(fn) {
	return function (...args) {
		var event = /** @type {Event} */ (args[0]);
		// @ts-ignore
		if (event.target === this) {
			// @ts-ignore
			fn?.apply(this, args);
		}
	};
}

/**
 * Substitute for the `stopPropagation` event modifier
 * @deprecated
 * @param {(event: Event, ...args: Array<unknown>) => void} fn
 * @returns {(event: Event, ...args: unknown[]) => void}
 */
function stopPropagation(fn) {
	return function (...args) {
		var event = /** @type {Event} */ (args[0]);
		event.stopPropagation();
		// @ts-ignore
		return fn?.apply(this, args);
	};
}

/**
 * Substitute for the `once` event modifier
 * @deprecated
 * @param {(event: Event, ...args: Array<unknown>) => void} fn
 * @returns {(event: Event, ...args: unknown[]) => void}
 */
function once(fn) {
	var ran = false;

	return function (...args) {
		if (ran) return;
		ran = true;

		// @ts-ignore
		return fn?.apply(this, args);
	};
}

/**
 * Substitute for the `stopImmediatePropagation` event modifier
 * @deprecated
 * @param {(event: Event, ...args: Array<unknown>) => void} fn
 * @returns {(event: Event, ...args: unknown[]) => void}
 */
function event_modifiers_stopImmediatePropagation(fn) {
	return function (...args) {
		var event = /** @type {Event} */ (args[0]);
		event.stopImmediatePropagation();
		// @ts-ignore
		return fn?.apply(this, args);
	};
}

/**
 * Substitute for the `preventDefault` event modifier
 * @deprecated
 * @param {(event: Event, ...args: Array<unknown>) => void} fn
 * @returns {(event: Event, ...args: unknown[]) => void}
 */
function preventDefault(fn) {
	return function (...args) {
		var event = /** @type {Event} */ (args[0]);
		event.preventDefault();
		// @ts-ignore
		return fn?.apply(this, args);
	};
}

/**
 * Substitute for the `passive` event modifier, implemented as an action
 * @deprecated
 * @param {HTMLElement} node
 * @param {[event: string, handler: () => EventListener]} options
 */
function passive(node, [event, handler]) {
	(0,reactivity_effects.user_pre_effect)(() => {
		return (0,elements_events.on)(node, event, handler() ?? shared_utils.noop, {
			passive: true
		});
	});
}

/**
 * Substitute for the `nonpassive` event modifier, implemented as an action
 * @deprecated
 * @param {HTMLElement} node
 * @param {[event: string, handler: () => EventListener]} options
 */
function nonpassive(node, [event, handler]) {
	(0,reactivity_effects.user_pre_effect)(() => {
		return (0,elements_events.on)(node, event, handler() ?? shared_utils.noop, {
			passive: false
		});
	});
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/legacy/lifecycle.js
/** @import { ComponentContextLegacy } from '#client' */






/**
 * Legacy-mode only: Call `onMount` callbacks and set up `beforeUpdate`/`afterUpdate` effects
 * @param {boolean} [immutable]
 */
function init(immutable = false) {
	const context = /** @type {ComponentContextLegacy} */ (client_context.component_context);

	const callbacks = context.l.u;
	if (!callbacks) return;

	let props = () => (0,runtime.deep_read_state)(context.s);

	if (immutable) {
		let version = 0;
		let prev = /** @type {Record<string, any>} */ ({});

		// In legacy immutable mode, before/afterUpdate only fire if the object identity of a prop changes
		const d = (0,deriveds.derived)(() => {
			let changed = false;
			const props = context.s;
			for (const key in props) {
				if (props[key] !== prev[key]) {
					prev[key] = props[key];
					changed = true;
				}
			}
			if (changed) version++;
			return version;
		});

		props = () => (0,runtime.get)(d);
	}

	// beforeUpdate
	if (callbacks.b.length) {
		(0,reactivity_effects.user_pre_effect)(() => {
			observe_all(context, props);
			(0,shared_utils.run_all)(callbacks.b);
		});
	}

	// onMount (must run before afterUpdate)
	(0,reactivity_effects.user_effect)(() => {
		const fns = (0,runtime.untrack)(() => callbacks.m.map(shared_utils.run));
		return () => {
			for (const fn of fns) {
				if (typeof fn === 'function') {
					fn();
				}
			}
		};
	});

	// afterUpdate
	if (callbacks.a.length) {
		(0,reactivity_effects.user_effect)(() => {
			observe_all(context, props);
			(0,shared_utils.run_all)(callbacks.a);
		});
	}
}

/**
 * Invoke the getter of all signals associated with a component
 * so they can be registered to the effect this function is called in.
 * @param {ComponentContextLegacy} context
 * @param {(() => void)} props
 */
function observe_all(context, props) {
	if (context.l.s) {
		for (const signal of context.l.s) (0,runtime.get)(signal);
	}

	props();
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/legacy/misc.js




/**
 * Under some circumstances, imports may be reactive in legacy mode. In that case,
 * they should be using `reactive_import` as part of the transformation
 * @param {() => any} fn
 */
function reactive_import(fn) {
	var s = (0,reactivity_sources.source)(0);

	return function () {
		if (arguments.length === 1) {
			(0,reactivity_sources.set)(s, (0,runtime.get)(s) + 1);
			return arguments[0];
		} else {
			(0,runtime.get)(s);
			return fn();
		}
	};
}

/**
 * @this {any}
 * @param {Record<string, unknown>} $$props
 * @param {Event} event
 * @returns {void}
 */
function bubble_event($$props, event) {
	var events = /** @type {Record<string, Function[] | Function>} */ ($$props.$$events)?.[
		event.type
	];

	var callbacks = (0,shared_utils.is_array)(events) ? events.slice() : events == null ? [] : [events];

	for (var fn of callbacks) {
		// Preserve "this" context
		fn.call(this, event);
	}
}

/**
 * Used to simulate `$on` on a component instance when `compatibility.componentApi === 4`
 * @param {Record<string, any>} $$props
 * @param {string} event_name
 * @param {Function} event_callback
 */
function add_legacy_event_listener($$props, event_name, event_callback) {
	$$props.$$events ||= {};
	$$props.$$events[event_name] ||= [];
	$$props.$$events[event_name].push(event_callback);
}

/**
 * Used to simulate `$set` on a component instance when `compatibility.componentApi === 4`.
 * Needs component accessors so that it can call the setter of the prop. Therefore doesn't
 * work for updating props in `$$props` or `$$restProps`.
 * @this {Record<string, any>}
 * @param {Record<string, any>} $$new_props
 */
function update_legacy_props($$new_props) {
	for (var key in $$new_props) {
		if (key in this) {
			this[key] = $$new_props[key];
		}
	}
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/store/utils.js
/** @import { Readable } from './public' */



/**
 * @template T
 * @param {Readable<T> | null | undefined} store
 * @param {(value: T) => void} run
 * @param {(value: T) => void} [invalidate]
 * @returns {() => void}
 */
function subscribe_to_store(store, run, invalidate) {
	if (store == null) {
		// @ts-expect-error
		run(undefined);

		// @ts-expect-error
		if (invalidate) invalidate(undefined);

		return shared_utils.noop;
	}

	// Svelte store takes a private second argument
	// StartStopNotifier could mutate state, and we want to silence the corresponding validation error
	const unsub = (0,index_client.untrack)(() =>
		store.subscribe(
			run,
			// @ts-expect-error
			invalidate
		)
	);

	// Also support RxJS
	// @ts-expect-error TODO fix this in the types?
	return unsub.unsubscribe ? () => unsub.unsubscribe() : unsub;
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/store/shared/index.js
/** @import { Readable, StartStopNotifier, Subscriber, Unsubscriber, Updater, Writable } from '../public.js' */
/** @import { Stores, StoresValues, SubscribeInvalidateTuple } from '../private.js' */




/**
 * @type {Array<SubscribeInvalidateTuple<any> | any>}
 */
const subscriber_queue = [];

/**
 * Creates a `Readable` store that allows reading by subscription.
 *
 * @template T
 * @param {T} [value] initial value
 * @param {StartStopNotifier<T>} [start]
 * @returns {Readable<T>}
 */
function readable(value, start) {
	return {
		subscribe: writable(value, start).subscribe
	};
}

/**
 * Create a `Writable` store that allows both updating and reading by subscription.
 *
 * @template T
 * @param {T} [value] initial value
 * @param {StartStopNotifier<T>} [start]
 * @returns {Writable<T>}
 */
function writable(value, start = shared_utils.noop) {
	/** @type {Unsubscriber | null} */
	let stop = null;

	/** @type {Set<SubscribeInvalidateTuple<T>>} */
	const subscribers = new Set();

	/**
	 * @param {T} new_value
	 * @returns {void}
	 */
	function set(new_value) {
		if ((0,equality.safe_not_equal)(value, new_value)) {
			value = new_value;
			if (stop) {
				// store is ready
				const run_queue = !subscriber_queue.length;
				for (const subscriber of subscribers) {
					subscriber[1]();
					subscriber_queue.push(subscriber, value);
				}
				if (run_queue) {
					for (let i = 0; i < subscriber_queue.length; i += 2) {
						subscriber_queue[i][0](subscriber_queue[i + 1]);
					}
					subscriber_queue.length = 0;
				}
			}
		}
	}

	/**
	 * @param {Updater<T>} fn
	 * @returns {void}
	 */
	function update(fn) {
		set(fn(/** @type {T} */ (value)));
	}

	/**
	 * @param {Subscriber<T>} run
	 * @param {() => void} [invalidate]
	 * @returns {Unsubscriber}
	 */
	function subscribe(run, invalidate = shared_utils.noop) {
		/** @type {SubscribeInvalidateTuple<T>} */
		const subscriber = [run, invalidate];
		subscribers.add(subscriber);
		if (subscribers.size === 1) {
			stop = start(set, update) || shared_utils.noop;
		}
		run(/** @type {T} */ (value));
		return () => {
			subscribers.delete(subscriber);
			if (subscribers.size === 0 && stop) {
				stop();
				stop = null;
			}
		};
	}
	return { set, update, subscribe };
}

/**
 * Derived value store by synchronizing one or more readable stores and
 * applying an aggregation function over its input values.
 *
 * @template {Stores} S
 * @template T
 * @overload
 * @param {S} stores
 * @param {(values: StoresValues<S>, set: (value: T) => void, update: (fn: Updater<T>) => void) => Unsubscriber | void} fn
 * @param {T} [initial_value]
 * @returns {Readable<T>}
 */
/**
 * Derived value store by synchronizing one or more readable stores and
 * applying an aggregation function over its input values.
 *
 * @template {Stores} S
 * @template T
 * @overload
 * @param {S} stores
 * @param {(values: StoresValues<S>) => T} fn
 * @param {T} [initial_value]
 * @returns {Readable<T>}
 */
/**
 * @template {Stores} S
 * @template T
 * @param {S} stores
 * @param {Function} fn
 * @param {T} [initial_value]
 * @returns {Readable<T>}
 */
function derived(stores, fn, initial_value) {
	const single = !Array.isArray(stores);
	/** @type {Array<Readable<any>>} */
	const stores_array = single ? [stores] : stores;
	if (!stores_array.every(Boolean)) {
		throw new Error('derived() expects stores as input, got a falsy value');
	}
	const auto = fn.length < 2;
	return readable(initial_value, (set, update) => {
		let started = false;
		/** @type {T[]} */
		const values = [];
		let pending = 0;
		let cleanup = shared_utils.noop;
		const sync = () => {
			if (pending) {
				return;
			}
			cleanup();
			const result = fn(single ? values[0] : values, set, update);
			if (auto) {
				set(result);
			} else {
				cleanup = typeof result === 'function' ? result : shared_utils.noop;
			}
		};
		const unsubscribers = stores_array.map((store, i) =>
			subscribe_to_store(
				store,
				(value) => {
					values[i] = value;
					pending &= ~(1 << i);
					if (started) {
						sync();
					}
				},
				() => {
					pending |= 1 << i;
				}
			)
		);
		started = true;
		sync();
		return function stop() {
			(0,shared_utils.run_all)(unsubscribers);
			cleanup();
			// We need to set this to false because callbacks can still happen despite having unsubscribed:
			// Callbacks might already be placed in the queue which doesn't know it should no longer
			// invoke this derived store.
			started = false;
		};
	});
}

/**
 * Takes a store and returns a new one derived from the old one that is readable.
 *
 * @template T
 * @param {Readable<T>} store  - store to make readonly
 * @returns {Readable<T>}
 */
function readonly(store) {
	return {
		// @ts-expect-error TODO i suspect the bind is unnecessary
		subscribe: store.subscribe.bind(store)
	};
}

/**
 * Get the current value from a store by subscribing and immediately unsubscribing.
 *
 * @template T
 * @param {Readable<T>} store
 * @returns {T}
 */
function shared_get(store) {
	let value;
	subscribe_to_store(store, (_) => (value = _))();
	// @ts-expect-error
	return value;
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/reactivity/store.js
/** @import { StoreReferencesContainer } from '#client' */
/** @import { Store } from '#shared' */








/**
 * Whether or not the prop currently being read is a store binding, as in
 * `<Child bind:x={$y} />`. If it is, we treat the prop as mutable even in
 * runes mode, and skip `binding_property_non_reactive` validation
 */
let is_store_binding = false;

let IS_UNMOUNTED = Symbol();

/**
 * Gets the current value of a store. If the store isn't subscribed to yet, it will create a proxy
 * signal that will be updated when the store is. The store references container is needed to
 * track reassignments to stores and to track the correct component context.
 * @template V
 * @param {Store<V> | null | undefined} store
 * @param {string} store_name
 * @param {StoreReferencesContainer} stores
 * @returns {V}
 */
function store_get(store, store_name, stores) {
	const entry = (stores[store_name] ??= {
		store: null,
		source: (0,reactivity_sources.mutable_source)(undefined),
		unsubscribe: shared_utils.noop
	});

	if (esm_env.DEV) {
		entry.source.label = store_name;
	}

	// if the component that setup this is already unmounted we don't want to register a subscription
	if (entry.store !== store && !(IS_UNMOUNTED in stores)) {
		entry.unsubscribe();
		entry.store = store ?? null;

		if (store == null) {
			entry.source.v = undefined; // see synchronous callback comment below
			entry.unsubscribe = shared_utils.noop;
		} else {
			var is_synchronous_callback = true;

			entry.unsubscribe = subscribe_to_store(store, (v) => {
				if (is_synchronous_callback) {
					// If the first updates to the store value (possibly multiple of them) are synchronously
					// inside a derived, we will hit the `state_unsafe_mutation` error if we `set` the value
					entry.source.v = v;
				} else {
					(0,reactivity_sources.set)(entry.source, v);
				}
			});

			is_synchronous_callback = false;
		}
	}

	// if the component that setup this stores is already unmounted the source will be out of sync
	// so we just use the `get` for the stores, less performant but it avoids to create a memory leak
	// and it will keep the value consistent
	if (store && IS_UNMOUNTED in stores) {
		return shared_get(store);
	}

	return (0,runtime.get)(entry.source);
}

/**
 * Unsubscribe from a store if it's not the same as the one in the store references container.
 * We need this in addition to `store_get` because someone could unsubscribe from a store but
 * then never subscribe to the new one (if any), causing the subscription to stay open wrongfully.
 * @param {Store<any> | null | undefined} store
 * @param {string} store_name
 * @param {StoreReferencesContainer} stores
 */
function store_unsub(store, store_name, stores) {
	/** @type {StoreReferencesContainer[''] | undefined} */
	let entry = stores[store_name];

	if (entry && entry.store !== store) {
		// Don't reset store yet, so that store_get above can resubscribe to new store if necessary
		entry.unsubscribe();
		entry.unsubscribe = shared_utils.noop;
	}

	return store;
}

/**
 * Sets the new value of a store and returns that value.
 * @template V
 * @param {Store<V>} store
 * @param {V} value
 * @returns {V}
 */
function store_set(store, value) {
	store.set(value);
	return value;
}

/**
 * @param {StoreReferencesContainer} stores
 * @param {string} store_name
 */
function invalidate_store(stores, store_name) {
	var entry = stores[store_name];
	if (entry.store !== null) {
		store_set(entry.store, entry.source.v);
	}
}

/**
 * Unsubscribes from all auto-subscribed stores on destroy
 * @returns {[StoreReferencesContainer, ()=>void]}
 */
function setup_stores() {
	/** @type {StoreReferencesContainer} */
	const stores = {};

	function cleanup() {
		(0,reactivity_effects.teardown)(() => {
			for (var store_name in stores) {
				const ref = stores[store_name];
				ref.unsubscribe();
			}
			(0,shared_utils.define_property)(stores, IS_UNMOUNTED, {
				enumerable: false,
				value: true
			});
		});
	}

	return [stores, cleanup];
}

/**
 * Updates a store with a new value.
 * @param {Store<V>} store  the store to update
 * @param {any} expression  the expression that mutates the store
 * @param {V} new_value  the new store value
 * @template V
 */
function store_mutate(store, expression, new_value) {
	store.set(new_value);
	return expression;
}

/**
 * @param {Store<number>} store
 * @param {number} store_value
 * @param {1 | -1} [d]
 * @returns {number}
 */
function update_store(store, store_value, d = 1) {
	store.set(store_value + d);
	return store_value;
}

/**
 * @param {Store<number>} store
 * @param {number} store_value
 * @param {1 | -1} [d]
 * @returns {number}
 */
function update_pre_store(store, store_value, d = 1) {
	const value = store_value + d;
	store.set(value);
	return value;
}

/**
 * Called inside prop getters to communicate that the prop is a store binding
 */
function mark_store_binding() {
	is_store_binding = true;
}

/**
 * Returns a tuple that indicates whether `fn()` reads a prop that is a store binding.
 * Used to prevent `binding_property_non_reactive` validation false positives and
 * ensure that these props are treated as mutable even in runes mode
 * @template T
 * @param {() => T} fn
 * @returns {[T, boolean]}
 */
function capture_store_binding(fn) {
	var previous_is_store_binding = is_store_binding;

	try {
		is_store_binding = false;
		return [fn(), is_store_binding];
	} finally {
		is_store_binding = previous_is_store_binding;
	}
}

// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/flags/index.js
var internal_flags = __webpack_require__(9987);
;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/reactivity/props.js
/** @import { Effect, Source } from './types.js' */












/**
 * @param {((value?: number) => number)} fn
 * @param {1 | -1} [d]
 * @returns {number}
 */
function update_prop(fn, d = 1) {
	const value = fn();
	fn(value + d);
	return value;
}

/**
 * @param {((value?: number) => number)} fn
 * @param {1 | -1} [d]
 * @returns {number}
 */
function update_pre_prop(fn, d = 1) {
	const value = fn() + d;
	fn(value);
	return value;
}

/**
 * The proxy handler for rest props (i.e. `const { x, ...rest } = $props()`).
 * Is passed the full `$$props` object and excludes the named props.
 * @type {ProxyHandler<{ props: Record<string | symbol, unknown>, exclude: Array<string | symbol>, name?: string }>}}
 */
const rest_props_handler = {
	get(target, key) {
		if (target.exclude.includes(key)) return;
		return target.props[key];
	},
	set(target, key) {
		if (esm_env.DEV) {
			// TODO should this happen in prod too?
			client_errors.props_rest_readonly(`${target.name}.${String(key)}`);
		}

		return false;
	},
	getOwnPropertyDescriptor(target, key) {
		if (target.exclude.includes(key)) return;
		if (key in target.props) {
			return {
				enumerable: true,
				configurable: true,
				value: target.props[key]
			};
		}
	},
	has(target, key) {
		if (target.exclude.includes(key)) return false;
		return key in target.props;
	},
	ownKeys(target) {
		return Reflect.ownKeys(target.props).filter((key) => !target.exclude.includes(key));
	}
};

/**
 * @param {Record<string, unknown>} props
 * @param {string[]} exclude
 * @param {string} [name]
 * @returns {Record<string, unknown>}
 */
/*#__NO_SIDE_EFFECTS__*/
function rest_props(props, exclude, name) {
	return new Proxy(
		esm_env.DEV ? { props, exclude, name, other: {}, to_proxy: [] } : { props, exclude },
		rest_props_handler
	);
}

/**
 * The proxy handler for legacy $$restProps and $$props
 * @type {ProxyHandler<{ props: Record<string | symbol, unknown>, exclude: Array<string | symbol>, special: Record<string | symbol, (v?: unknown) => unknown>, version: Source<number>, parent_effect: Effect }>}}
 */
const legacy_rest_props_handler = {
	get(target, key) {
		if (target.exclude.includes(key)) return;
		(0,runtime.get)(target.version);
		return key in target.special ? target.special[key]() : target.props[key];
	},
	set(target, key, value) {
		if (!(key in target.special)) {
			var previous_effect = runtime.active_effect;

			try {
				(0,runtime.set_active_effect)(target.parent_effect);

				// Handle props that can temporarily get out of sync with the parent
				/** @type {Record<string, (v?: unknown) => unknown>} */
				target.special[key] = props_prop(
					{
						get [key]() {
							return target.props[key];
						}
					},
					/** @type {string} */ (key),
					constants.PROPS_IS_UPDATED
				);
			} finally {
				(0,runtime.set_active_effect)(previous_effect);
			}
		}

		target.special[key](value);
		(0,reactivity_sources.update)(target.version); // $$props is coarse-grained: when $$props.x is updated, usages of $$props.y etc are also rerun
		return true;
	},
	getOwnPropertyDescriptor(target, key) {
		if (target.exclude.includes(key)) return;
		if (key in target.props) {
			return {
				enumerable: true,
				configurable: true,
				value: target.props[key]
			};
		}
	},
	deleteProperty(target, key) {
		// Svelte 4 allowed for deletions on $$restProps
		if (target.exclude.includes(key)) return true;
		target.exclude.push(key);
		(0,reactivity_sources.update)(target.version);
		return true;
	},
	has(target, key) {
		if (target.exclude.includes(key)) return false;
		return key in target.props;
	},
	ownKeys(target) {
		return Reflect.ownKeys(target.props).filter((key) => !target.exclude.includes(key));
	}
};

/**
 * @param {Record<string, unknown>} props
 * @param {string[]} exclude
 * @returns {Record<string, unknown>}
 */
function legacy_rest_props(props, exclude) {
	return new Proxy(
		{
			props,
			exclude,
			special: {},
			version: (0,reactivity_sources.source)(0),
			// TODO this is only necessary because we need to track component
			// destruction inside `prop`, because of `bind:this`, but it
			// seems likely that we can simplify `bind:this` instead
			parent_effect: /** @type {Effect} */ (runtime.active_effect)
		},
		legacy_rest_props_handler
	);
}

/**
 * The proxy handler for spread props. Handles the incoming array of props
 * that looks like `() => { dynamic: props }, { static: prop }, ..` and wraps
 * them so that the whole thing is passed to the component as the `$$props` argument.
 * @type {ProxyHandler<{ props: Array<Record<string | symbol, unknown> | (() => Record<string | symbol, unknown>)> }>}}
 */
const spread_props_handler = {
	get(target, key) {
		let i = target.props.length;
		while (i--) {
			let p = target.props[i];
			if ((0,shared_utils.is_function)(p)) p = p();
			if (typeof p === 'object' && p !== null && key in p) return p[key];
		}
	},
	set(target, key, value) {
		let i = target.props.length;
		while (i--) {
			let p = target.props[i];
			if ((0,shared_utils.is_function)(p)) p = p();
			const desc = (0,shared_utils.get_descriptor)(p, key);
			if (desc && desc.set) {
				desc.set(value);
				return true;
			}
		}
		return false;
	},
	getOwnPropertyDescriptor(target, key) {
		let i = target.props.length;
		while (i--) {
			let p = target.props[i];
			if ((0,shared_utils.is_function)(p)) p = p();
			if (typeof p === 'object' && p !== null && key in p) {
				const descriptor = (0,shared_utils.get_descriptor)(p, key);
				if (descriptor && !descriptor.configurable) {
					// Prevent a "Non-configurability Report Error": The target is an array, it does
					// not actually contain this property. If it is now described as non-configurable,
					// the proxy throws a validation error. Setting it to true avoids that.
					descriptor.configurable = true;
				}
				return descriptor;
			}
		}
	},
	has(target, key) {
		// To prevent a false positive `is_entry_props` in the `prop` function
		if (key === client_constants.STATE_SYMBOL || key === client_constants.LEGACY_PROPS) return false;

		for (let p of target.props) {
			if ((0,shared_utils.is_function)(p)) p = p();
			if (p != null && key in p) return true;
		}

		return false;
	},
	ownKeys(target) {
		/** @type {Array<string | symbol>} */
		const keys = [];

		for (let p of target.props) {
			if ((0,shared_utils.is_function)(p)) p = p();
			if (!p) continue;

			for (const key in p) {
				if (!keys.includes(key)) keys.push(key);
			}

			for (const key of Object.getOwnPropertySymbols(p)) {
				if (!keys.includes(key)) keys.push(key);
			}
		}

		return keys;
	}
};

/**
 * @param {Array<Record<string, unknown> | (() => Record<string, unknown>)>} props
 * @returns {any}
 */
function spread_props(...props) {
	return new Proxy({ props }, spread_props_handler);
}

/**
 * This function is responsible for synchronizing a possibly bound prop with the inner component state.
 * It is used whenever the compiler sees that the component writes to the prop, or when it has a default prop_value.
 * @template V
 * @param {Record<string, unknown>} props
 * @param {string} key
 * @param {number} flags
 * @param {V | (() => V)} [fallback]
 * @returns {(() => V | ((arg: V) => V) | ((arg: V, mutation: boolean) => V))}
 */
function props_prop(props, key, flags, fallback) {
	var runes = !internal_flags.legacy_mode_flag || (flags & constants.PROPS_IS_RUNES) !== 0;
	var bindable = (flags & constants.PROPS_IS_BINDABLE) !== 0;
	var lazy = (flags & constants.PROPS_IS_LAZY_INITIAL) !== 0;

	var fallback_value = /** @type {V} */ (fallback);
	var fallback_dirty = true;

	var get_fallback = () => {
		if (fallback_dirty) {
			fallback_dirty = false;

			fallback_value = lazy
				? (0,runtime.untrack)(/** @type {() => V} */ (fallback))
				: /** @type {V} */ (fallback);
		}

		return fallback_value;
	};

	/** @type {((v: V) => void) | undefined} */
	var setter;

	if (bindable) {
		// Can be the case when someone does `mount(Component, props)` with `let props = $state({...})`
		// or `createClassComponent(Component, props)`
		var is_entry_props = client_constants.STATE_SYMBOL in props || client_constants.LEGACY_PROPS in props;

		setter =
			(0,shared_utils.get_descriptor)(props, key)?.set ??
			(is_entry_props && key in props ? (v) => (props[key] = v) : undefined);
	}

	var initial_value;
	var is_store_sub = false;

	if (bindable) {
		[initial_value, is_store_sub] = capture_store_binding(() => /** @type {V} */ (props[key]));
	} else {
		initial_value = /** @type {V} */ (props[key]);
	}

	if (initial_value === undefined && fallback !== undefined) {
		initial_value = get_fallback();

		if (setter) {
			if (runes) client_errors.props_invalid_value(key);
			setter(initial_value);
		}
	}

	/** @type {() => V} */
	var getter;

	if (runes) {
		getter = () => {
			var value = /** @type {V} */ (props[key]);
			if (value === undefined) return get_fallback();
			fallback_dirty = true;
			return value;
		};
	} else {
		getter = () => {
			var value = /** @type {V} */ (props[key]);

			if (value !== undefined) {
				// in legacy mode, we don't revert to the fallback value
				// if the prop goes from defined to undefined. The easiest
				// way to model this is to make the fallback undefined
				// as soon as the prop has a value
				fallback_value = /** @type {V} */ (undefined);
			}

			return value === undefined ? fallback_value : value;
		};
	}

	// prop is never written to — we only need a getter
	if (runes && (flags & constants.PROPS_IS_UPDATED) === 0) {
		return getter;
	}

	// prop is written to, but the parent component had `bind:foo` which
	// means we can just call `$$props.foo = value` directly
	if (setter) {
		var legacy_parent = props.$$legacy;
		return /** @type {() => V} */ (
			function (/** @type {V} */ value, /** @type {boolean} */ mutation) {
				if (arguments.length > 0) {
					// We don't want to notify if the value was mutated and the parent is in runes mode.
					// In that case the state proxy (if it exists) should take care of the notification.
					// If the parent is not in runes mode, we need to notify on mutation, too, that the prop
					// has changed because the parent will not be able to detect the change otherwise.
					if (!runes || !mutation || legacy_parent || is_store_sub) {
						/** @type {Function} */ (setter)(mutation ? getter() : value);
					}

					return value;
				}

				return getter();
			}
		);
	}

	// Either prop is written to, but there's no binding, which means we
	// create a derived that we can write to locally.
	// Or we are in legacy mode where we always create a derived to replicate that
	// Svelte 4 did not trigger updates when a primitive value was updated to the same value.
	var overridden = false;

	var d = ((flags & constants.PROPS_IS_IMMUTABLE) !== 0 ? deriveds.derived : deriveds.derived_safe_equal)(() => {
		overridden = false;
		return getter();
	});

	if (esm_env.DEV) {
		d.label = key;
	}

	// Capture the initial value if it's bindable
	if (bindable) (0,runtime.get)(d);

	var parent_effect = /** @type {Effect} */ (runtime.active_effect);

	return /** @type {() => V} */ (
		function (/** @type {any} */ value, /** @type {boolean} */ mutation) {
			if (arguments.length > 0) {
				const new_value = mutation ? (0,runtime.get)(d) : runes && bindable ? (0,proxy.proxy)(value) : value;

				(0,reactivity_sources.set)(d, new_value);
				overridden = true;

				if (fallback_value !== undefined) {
					fallback_value = new_value;
				}

				return value;
			}

			// special case — avoid recalculating the derived if we're in a
			// teardown function and the prop was overridden locally, or the
			// component was already destroyed (this latter part is necessary
			// because `bind:this` can read props after the component has
			// been destroyed. TODO simplify `bind:this`
			if ((runtime.is_destroying_effect && overridden) || (parent_effect.f & client_constants.DESTROYED) !== 0) {
				return d.v;
			}

			return (0,runtime.get)(d);
		}
	);
}

// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/legacy.js
var client_legacy = __webpack_require__(4240);
;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/validate.js









/**
 * @param {() => any} collection
 * @param {(item: any, index: number) => string} key_fn
 * @returns {void}
 */
function validate_each_keys(collection, key_fn) {
	(0,reactivity_effects.render_effect)(() => {
		const keys = new Map();
		const maybe_array = collection();
		const array = (0,shared_utils.is_array)(maybe_array)
			? maybe_array
			: maybe_array == null
				? []
				: Array.from(maybe_array);
		const length = array.length;
		for (let i = 0; i < length; i++) {
			const key = key_fn(array[i], i);
			if (keys.has(key)) {
				const a = String(keys.get(key));
				const b = String(i);

				/** @type {string | null} */
				let k = String(key);
				if (k.startsWith('[object ')) k = null;

				client_errors.each_key_duplicate(a, b, k);
			}
			keys.set(key, i);
		}
	});
}

/**
 * @param {string} binding
 * @param {Array<Promise<void>>} blockers
 * @param {() => Record<string, any>} get_object
 * @param {() => string} get_property
 * @param {number} line
 * @param {number} column
 */
function validate_binding(binding, blockers, get_object, get_property, line, column) {
	(0,reactivity_async.run_after_blockers)(blockers, () => {
		var warned = false;

		var filename = client_context.dev_current_component_function?.[constants.FILENAME];

		(0,reactivity_effects.render_effect)(() => {
			if (warned) return;

			var [object, is_store_sub] = capture_store_binding(get_object);

			if (is_store_sub) return;

			var property = get_property();

			var ran = false;

			// by making the (possibly false, but it would be an extreme edge case) assumption
			// that a getter has a corresponding setter, we can determine if a property is
			// reactive by seeing if this effect has dependencies
			var effect = (0,reactivity_effects.render_effect)(() => {
				if (ran) return;

				// eslint-disable-next-line @typescript-eslint/no-unused-expressions
				object[property];
			});

			ran = true;

			if (effect.deps === null) {
				var location = `${filename}:${line}:${column}`;
				warnings.binding_property_non_reactive(binding, location);

				warned = true;
			}
		});
	});
}

;// CONCATENATED MODULE: ../../node_modules/svelte/src/legacy/legacy-client.js
/** @import { ComponentConstructorOptions, ComponentType, SvelteComponent, Component } from 'svelte' */














/**
 * Takes the same options as a Svelte 4 component and the component function and returns a Svelte 4 compatible component.
 *
 * @deprecated Use this only as a temporary solution to migrate your imperative component code to Svelte 5.
 *
 * @template {Record<string, any>} Props
 * @template {Record<string, any>} Exports
 * @template {Record<string, any>} Events
 * @template {Record<string, any>} Slots
 *
 * @param {ComponentConstructorOptions<Props> & {
 * 	component: ComponentType<SvelteComponent<Props, Events, Slots>> | Component<Props>;
 * }} options
 * @returns {SvelteComponent<Props, Events, Slots> & Exports}
 */
function createClassComponent(options) {
	// @ts-expect-error $$prop_def etc are not actually defined
	return new Svelte4Component(options);
}

/**
 * Takes the component function and returns a Svelte 4 compatible component constructor.
 *
 * @deprecated Use this only as a temporary solution to migrate your imperative component code to Svelte 5.
 *
 * @template {Record<string, any>} Props
 * @template {Record<string, any>} Exports
 * @template {Record<string, any>} Events
 * @template {Record<string, any>} Slots
 *
 * @param {SvelteComponent<Props, Events, Slots> | Component<Props>} component
 * @returns {ComponentType<SvelteComponent<Props, Events, Slots> & Exports>}
 */
function asClassComponent(component) {
	// @ts-expect-error $$prop_def etc are not actually defined
	return class extends Svelte4Component {
		/** @param {any} options */
		constructor(options) {
			super({
				component,
				...options
			});
		}
	};
}

/**
 * Support using the component as both a class and function during the transition period
 * @typedef  {{new (o: ComponentConstructorOptions): SvelteComponent;(...args: Parameters<Component<Record<string, any>>>): ReturnType<Component<Record<string, any>, Record<string, any>>>;}} LegacyComponentType
 */

class Svelte4Component {
	/** @type {any} */
	#events;

	/** @type {Record<string, any>} */
	#instance;

	/**
	 * @param {ComponentConstructorOptions & {
	 *  component: any;
	 * }} options
	 */
	constructor(options) {
		var sources = new Map();

		/**
		 * @param {string | symbol} key
		 * @param {unknown} value
		 */
		var add_source = (key, value) => {
			var s = (0,reactivity_sources.mutable_source)(value, false, false);
			sources.set(key, s);
			return s;
		};

		// Replicate coarse-grained props through a proxy that has a version source for
		// each property, which is incremented on updates to the property itself. Do not
		// use our $state proxy because that one has fine-grained reactivity.
		const props = new Proxy(
			{ ...(options.props || {}), $$events: {} },
			{
				get(target, prop) {
					return (0,runtime.get)(sources.get(prop) ?? add_source(prop, Reflect.get(target, prop)));
				},
				has(target, prop) {
					// Necessary to not throw "invalid binding" validation errors on the component side
					if (prop === client_constants.LEGACY_PROPS) return true;

					(0,runtime.get)(sources.get(prop) ?? add_source(prop, Reflect.get(target, prop)));
					return Reflect.has(target, prop);
				},
				set(target, prop, value) {
					(0,reactivity_sources.set)(sources.get(prop) ?? add_source(prop, value), value);
					return Reflect.set(target, prop, value);
				}
			}
		);

		this.#instance = (options.hydrate ? render.hydrate : render.mount)(options.component, {
			target: options.target,
			anchor: options.anchor,
			props,
			context: options.context,
			intro: options.intro ?? false,
			recover: options.recover
		});

		// We don't flushSync for custom element wrappers or if the user doesn't want it,
		// or if we're in async mode since `flushSync()` will fail
		if (!internal_flags.async_mode_flag && (!options?.props?.$$host || options.sync === false)) {
			(0,reactivity_batch.flushSync)();
		}

		this.#events = props.$$events;

		for (const key of Object.keys(this.#instance)) {
			if (key === '$set' || key === '$destroy' || key === '$on') continue;
			(0,shared_utils.define_property)(this, key, {
				get() {
					return this.#instance[key];
				},
				/** @param {any} value */
				set(value) {
					this.#instance[key] = value;
				},
				enumerable: true
			});
		}

		this.#instance.$set = /** @param {Record<string, any>} next */ (next) => {
			Object.assign(props, next);
		};

		this.#instance.$destroy = () => {
			(0,render.unmount)(this.#instance);
		};
	}

	/** @param {Record<string, any>} props */
	$set(props) {
		this.#instance.$set(props);
	}

	/**
	 * @param {string} event
	 * @param {(...args: any[]) => any} callback
	 * @returns {any}
	 */
	$on(event, callback) {
		this.#events[event] = this.#events[event] || [];

		/** @param {any[]} args */
		const cb = (...args) => callback.call(this, ...args);
		this.#events[event].push(cb);
		return () => {
			this.#events[event] = this.#events[event].filter(/** @param {any} fn */ (fn) => fn !== cb);
		};
	}

	$destroy() {
		this.#instance.$destroy();
	}
}

/**
 * Runs the given function once immediately on the server, and works like `$effect.pre` on the client.
 *
 * @deprecated Use this only as a temporary solution to migrate your component code to Svelte 5.
 * @param {() => void | (() => void)} fn
 * @returns {void}
 */
function legacy_client_run(fn) {
	(0,reactivity_effects.user_pre_effect)(() => {
		fn();
		var effect = /** @type {import('#client').Effect} */ (runtime.active_effect);
		// If the effect is immediately made dirty again, mark it as maybe dirty to emulate legacy behaviour
		if ((effect.f & client_constants.DIRTY) !== 0) {
			let filename = "a file (we can't know which one)";
			if (esm_env.DEV) {
				// @ts-ignore
				filename = client_context.dev_current_component_function?.[constants.FILENAME] ?? filename;
			}
			warnings.legacy_recursive_reactive_block(filename);
			(0,runtime.set_signal_status)(effect, client_constants.MAYBE_DIRTY);
		}
	});
}

/**
 * Function to mimic the multiple listeners available in svelte 4
 * @deprecated
 * @param {EventListener[]} handlers
 * @returns {EventListener}
 */
function legacy_client_handlers(...handlers) {
	return function (event) {
		const { stopImmediatePropagation } = event;
		let stopped = false;

		event.stopImmediatePropagation = () => {
			stopped = true;
			stopImmediatePropagation.call(event);
		};

		const errors = [];

		for (const handler of handlers) {
			try {
				// @ts-expect-error `this` is not typed
				handler?.call(this, event);
			} catch (e) {
				errors.push(e);
			}

			if (stopped) {
				break;
			}
		}

		for (let error of errors) {
			queueMicrotask(() => {
				throw error;
			});
		}
	};
}

/**
 * Function to create a `bubble` function that mimic the behavior of `on:click` without handler available in svelte 4.
 * @deprecated Use this only as a temporary solution to migrate your automatically delegated events in Svelte 5.
 */
function createBubbler() {
	const active_component_context = client_context.component_context;
	if (active_component_context === null) {
		client_errors.lifecycle_outside_component('createBubbler');
	}

	return (/**@type {string}*/ type) => (/**@type {Event}*/ event) => {
		const events = /** @type {Record<string, Function | Function[]>} */ (
			active_component_context.s.$$events
		)?.[/** @type {any} */ (type)];

		if (events) {
			const callbacks = (0,shared_utils.is_array)(events) ? events.slice() : [events];
			for (const fn of callbacks) {
				fn.call(active_component_context.x, event);
			}
			return !event.defaultPrevented;
		}
		return true;
	};
}



;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dom/elements/custom-element.js





/**
 * @typedef {Object} CustomElementPropDefinition
 * @property {string} [attribute]
 * @property {boolean} [reflect]
 * @property {'String'|'Boolean'|'Number'|'Array'|'Object'} [type]
 */

/** @type {any} */
let SvelteElement;

if (typeof HTMLElement === 'function') {
	SvelteElement = class extends HTMLElement {
		/** The Svelte component constructor */
		$$ctor;
		/** Slots */
		$$s;
		/** @type {any} The Svelte component instance */
		$$c;
		/** Whether or not the custom element is connected */
		$$cn = false;
		/** @type {Record<string, any>} Component props data */
		$$d = {};
		/** `true` if currently in the process of reflecting component props back to attributes */
		$$r = false;
		/** @type {Record<string, CustomElementPropDefinition>} Props definition (name, reflected, type etc) */
		$$p_d = {};
		/** @type {Record<string, EventListenerOrEventListenerObject[]>} Event listeners */
		$$l = {};
		/** @type {Map<EventListenerOrEventListenerObject, Function>} Event listener unsubscribe functions */
		$$l_u = new Map();
		/** @type {any} The managed render effect for reflecting attributes */
		$$me;

		/**
		 * @param {*} $$componentCtor
		 * @param {*} $$slots
		 * @param {*} use_shadow_dom
		 */
		constructor($$componentCtor, $$slots, use_shadow_dom) {
			super();
			this.$$ctor = $$componentCtor;
			this.$$s = $$slots;
			if (use_shadow_dom) {
				this.attachShadow({ mode: 'open' });
			}
		}

		/**
		 * @param {string} type
		 * @param {EventListenerOrEventListenerObject} listener
		 * @param {boolean | AddEventListenerOptions} [options]
		 */
		addEventListener(type, listener, options) {
			// We can't determine upfront if the event is a custom event or not, so we have to
			// listen to both. If someone uses a custom event with the same name as a regular
			// browser event, this fires twice - we can't avoid that.
			this.$$l[type] = this.$$l[type] || [];
			this.$$l[type].push(listener);
			if (this.$$c) {
				const unsub = this.$$c.$on(type, listener);
				this.$$l_u.set(listener, unsub);
			}
			super.addEventListener(type, listener, options);
		}

		/**
		 * @param {string} type
		 * @param {EventListenerOrEventListenerObject} listener
		 * @param {boolean | AddEventListenerOptions} [options]
		 */
		removeEventListener(type, listener, options) {
			super.removeEventListener(type, listener, options);
			if (this.$$c) {
				const unsub = this.$$l_u.get(listener);
				if (unsub) {
					unsub();
					this.$$l_u.delete(listener);
				}
			}
		}

		async connectedCallback() {
			this.$$cn = true;
			if (!this.$$c) {
				// We wait one tick to let possible child slot elements be created/mounted
				await Promise.resolve();
				if (!this.$$cn || this.$$c) {
					return;
				}
				/** @param {string} name */
				function create_slot(name) {
					/**
					 * @param {Element} anchor
					 */
					return (anchor) => {
						const slot = document.createElement('slot');
						if (name !== 'default') slot.name = name;

						(0,template.append)(anchor, slot);
					};
				}
				/** @type {Record<string, any>} */
				const $$slots = {};
				const existing_slots = get_custom_elements_slots(this);
				for (const name of this.$$s) {
					if (name in existing_slots) {
						if (name === 'default' && !this.$$d.children) {
							this.$$d.children = create_slot(name);
							$$slots.default = true;
						} else {
							$$slots[name] = create_slot(name);
						}
					}
				}
				for (const attribute of this.attributes) {
					// this.$$data takes precedence over this.attributes
					const name = this.$$g_p(attribute.name);
					if (!(name in this.$$d)) {
						this.$$d[name] = get_custom_element_value(name, attribute.value, this.$$p_d, 'toProp');
					}
				}
				// Port over props that were set programmatically before ce was initialized
				for (const key in this.$$p_d) {
					// @ts-expect-error
					if (!(key in this.$$d) && this[key] !== undefined) {
						// @ts-expect-error
						this.$$d[key] = this[key]; // don't transform, these were set through JavaScript
						// @ts-expect-error
						delete this[key]; // remove the property that shadows the getter/setter
					}
				}
				this.$$c = createClassComponent({
					component: this.$$ctor,
					target: this.shadowRoot || this,
					props: {
						...this.$$d,
						$$slots,
						$$host: this
					}
				});

				// Reflect component props as attributes
				this.$$me = (0,reactivity_effects.effect_root)(() => {
					(0,reactivity_effects.render_effect)(() => {
						this.$$r = true;
						for (const key of (0,shared_utils.object_keys)(this.$$c)) {
							if (!this.$$p_d[key]?.reflect) continue;
							this.$$d[key] = this.$$c[key];
							const attribute_value = get_custom_element_value(
								key,
								this.$$d[key],
								this.$$p_d,
								'toAttribute'
							);
							if (attribute_value == null) {
								this.removeAttribute(this.$$p_d[key].attribute || key);
							} else {
								this.setAttribute(this.$$p_d[key].attribute || key, attribute_value);
							}
						}
						this.$$r = false;
					});
				});

				for (const type in this.$$l) {
					for (const listener of this.$$l[type]) {
						const unsub = this.$$c.$on(type, listener);
						this.$$l_u.set(listener, unsub);
					}
				}
				this.$$l = {};
			}
		}

		// We don't need this when working within Svelte code, but for compatibility of people using this outside of Svelte
		// and setting attributes through setAttribute etc, this is helpful

		/**
		 * @param {string} attr
		 * @param {string} _oldValue
		 * @param {string} newValue
		 */
		attributeChangedCallback(attr, _oldValue, newValue) {
			if (this.$$r) return;
			attr = this.$$g_p(attr);
			this.$$d[attr] = get_custom_element_value(attr, newValue, this.$$p_d, 'toProp');
			this.$$c?.$set({ [attr]: this.$$d[attr] });
		}

		disconnectedCallback() {
			this.$$cn = false;
			// In a microtask, because this could be a move within the DOM
			Promise.resolve().then(() => {
				if (!this.$$cn && this.$$c) {
					this.$$c.$destroy();
					this.$$me();
					this.$$c = undefined;
				}
			});
		}

		/**
		 * @param {string} attribute_name
		 */
		$$g_p(attribute_name) {
			return (
				(0,shared_utils.object_keys)(this.$$p_d).find(
					(key) =>
						this.$$p_d[key].attribute === attribute_name ||
						(!this.$$p_d[key].attribute && key.toLowerCase() === attribute_name)
				) || attribute_name
			);
		}
	};
}

/**
 * @param {string} prop
 * @param {any} value
 * @param {Record<string, CustomElementPropDefinition>} props_definition
 * @param {'toAttribute' | 'toProp'} [transform]
 */
function get_custom_element_value(prop, value, props_definition, transform) {
	const type = props_definition[prop]?.type;
	value = type === 'Boolean' && typeof value !== 'boolean' ? value != null : value;
	if (!transform || !props_definition[prop]) {
		return value;
	} else if (transform === 'toAttribute') {
		switch (type) {
			case 'Object':
			case 'Array':
				return value == null ? null : JSON.stringify(value);
			case 'Boolean':
				return value ? '' : null;
			case 'Number':
				return value == null ? null : value;
			default:
				return value;
		}
	} else {
		switch (type) {
			case 'Object':
			case 'Array':
				return value && JSON.parse(value);
			case 'Boolean':
				return value; // conversion already handled above
			case 'Number':
				return value != null ? +value : value;
			default:
				return value;
		}
	}
}

/**
 * @param {HTMLElement} element
 */
function get_custom_elements_slots(element) {
	/** @type {Record<string, true>} */
	const result = {};
	element.childNodes.forEach((node) => {
		result[/** @type {Element} node */ (node).slot || 'default'] = true;
	});
	return result;
}

/**
 * @internal
 *
 * Turn a Svelte component into a custom element.
 * @param {any} Component  A Svelte component function
 * @param {Record<string, CustomElementPropDefinition>} props_definition  The props to observe
 * @param {string[]} slots  The slots to create
 * @param {string[]} exports  Explicitly exported values, other than props
 * @param {boolean} use_shadow_dom  Whether to use shadow DOM
 * @param {(ce: new () => HTMLElement) => new () => HTMLElement} [extend]
 */
function create_custom_element(
	Component,
	props_definition,
	slots,
	exports,
	use_shadow_dom,
	extend
) {
	let Class = class extends SvelteElement {
		constructor() {
			super(Component, slots, use_shadow_dom);
			this.$$p_d = props_definition;
		}
		static get observedAttributes() {
			return (0,shared_utils.object_keys)(props_definition).map((key) =>
				(props_definition[key].attribute || key).toLowerCase()
			);
		}
	};
	(0,shared_utils.object_keys)(props_definition).forEach((prop) => {
		(0,shared_utils.define_property)(Class.prototype, prop, {
			get() {
				return this.$$c && prop in this.$$c ? this.$$c[prop] : this.$$d[prop];
			},
			set(value) {
				value = get_custom_element_value(prop, value, props_definition);
				this.$$d[prop] = value;
				var component = this.$$c;

				if (component) {
					// // If the instance has an accessor, use that instead
					var setter = (0,shared_utils.get_descriptor)(component, prop)?.get;

					if (setter) {
						component[prop] = value;
					} else {
						component.$set({ [prop]: value });
					}
				}
			}
		});
	});
	exports.forEach((property) => {
		(0,shared_utils.define_property)(Class.prototype, property, {
			get() {
				return this.$$c?.[property];
			}
		});
	});
	if (extend) {
		// @ts-expect-error - assigning here is fine
		Class = extend(Class);
	}
	Component.element = /** @type {any} */ Class;
	return Class;
}

// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/shared/validate.js
var validate = __webpack_require__(987);
// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/dev/equality.js
var dev_equality = __webpack_require__(9911);
;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/dev/console-log.js





/**
 * @param {string} method
 * @param  {...any} objects
 */
function log_if_contains_state(method, ...objects) {
	(0,runtime.untrack)(() => {
		try {
			let has_state = false;
			const transformed = [];

			for (const obj of objects) {
				if (obj && typeof obj === 'object' && client_constants.STATE_SYMBOL in obj) {
					transformed.push((0,clone.snapshot)(obj, true));
					has_state = true;
				} else {
					transformed.push(obj);
				}
			}

			if (has_state) {
				warnings.console_log_state(method);

				// eslint-disable-next-line no-console
				console.log('%c[snapshot]', 'color: grey', ...transformed);
			}
		} catch {}
	});

	return objects;
}

// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/error-handling.js
var error_handling = __webpack_require__(2219);
;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/client/index.js









































































}),
4240: 
/*!***************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/legacy.js ***!
  \***************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  captured_signals: () => (captured_signals)
});
/* import */var _reactivity_sources_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./reactivity/sources.js */ 6718);
/* import */var _runtime_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./runtime.js */ 5551);
/** @import { Value } from '#client' */



/**
 * @type {Set<Value> | null}
 * @deprecated
 */
let captured_signals = null;

/**
 * Capture an array of all the signals that are read when `fn` is called
 * @template T
 * @param {() => T} fn
 */
function capture_signals(fn) {
	var previous_captured_signals = captured_signals;

	try {
		captured_signals = new Set();

		(0,_runtime_js__WEBPACK_IMPORTED_MODULE_1__.untrack)(fn);

		if (previous_captured_signals !== null) {
			for (var signal of captured_signals) {
				previous_captured_signals.add(signal);
			}
		}

		return captured_signals;
	} finally {
		captured_signals = previous_captured_signals;
	}
}

/**
 * Invokes a function and captures all signals that are read during the invocation,
 * then invalidates them.
 * @param {() => any} fn
 * @deprecated
 */
function invalidate_inner_signals(fn) {
	for (var signal of capture_signals(fn)) {
		(0,_reactivity_sources_js__WEBPACK_IMPORTED_MODULE_0__.internal_set)(signal, signal.v);
	}
}


}),
4899: 
/*!**************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/proxy.js ***!
  \**************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  get_proxied_value: () => (get_proxied_value),
  is: () => (is),
  proxy: () => (proxy)
});
/* import */var esm_env__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! esm-env */ 3990);
/* import */var _runtime_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./runtime.js */ 5551);
/* import */var _shared_utils_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../shared/utils.js */ 2060);
/* import */var _reactivity_sources_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./reactivity/sources.js */ 6718);
/* import */var _client_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! #client/constants */ 5818);
/* import */var _constants_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../constants.js */ 7164);
/* import */var _errors_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./errors.js */ 1152);
/* import */var _dev_tracing_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./dev/tracing.js */ 6265);
/* import */var _flags_index_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../flags/index.js */ 9987);
/** @import { Source } from '#client' */










// TODO move all regexes into shared module?
const regex_is_valid_identifier = /^[a-zA-Z_$][a-zA-Z_$0-9]*$/;

/**
 * @template T
 * @param {T} value
 * @returns {T}
 */
function proxy(value) {
	// if non-proxyable, or is already a proxy, return `value`
	if (typeof value !== 'object' || value === null || _client_constants__WEBPACK_IMPORTED_MODULE_4__.STATE_SYMBOL in value) {
		return value;
	}

	const prototype = (0,_shared_utils_js__WEBPACK_IMPORTED_MODULE_2__.get_prototype_of)(value);

	if (prototype !== _shared_utils_js__WEBPACK_IMPORTED_MODULE_2__.object_prototype && prototype !== _shared_utils_js__WEBPACK_IMPORTED_MODULE_2__.array_prototype) {
		return value;
	}

	/** @type {Map<any, Source<any>>} */
	var sources = new Map();
	var is_proxied_array = (0,_shared_utils_js__WEBPACK_IMPORTED_MODULE_2__.is_array)(value);
	var version = (0,_reactivity_sources_js__WEBPACK_IMPORTED_MODULE_3__.state)(0);

	var stack = esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV && _flags_index_js__WEBPACK_IMPORTED_MODULE_8__.tracing_mode_flag ? (0,_dev_tracing_js__WEBPACK_IMPORTED_MODULE_7__.get_stack)('created at') : null;
	var parent_version = _runtime_js__WEBPACK_IMPORTED_MODULE_1__.update_version;

	/**
	 * Executes the proxy in the context of the reaction it was originally created in, if any
	 * @template T
	 * @param {() => T} fn
	 */
	var with_parent = (fn) => {
		if (_runtime_js__WEBPACK_IMPORTED_MODULE_1__.update_version === parent_version) {
			return fn();
		}

		// child source is being created after the initial proxy —
		// prevent it from being associated with the current reaction
		var reaction = _runtime_js__WEBPACK_IMPORTED_MODULE_1__.active_reaction;
		var version = _runtime_js__WEBPACK_IMPORTED_MODULE_1__.update_version;

		(0,_runtime_js__WEBPACK_IMPORTED_MODULE_1__.set_active_reaction)(null);
		(0,_runtime_js__WEBPACK_IMPORTED_MODULE_1__.set_update_version)(parent_version);

		var result = fn();

		(0,_runtime_js__WEBPACK_IMPORTED_MODULE_1__.set_active_reaction)(reaction);
		(0,_runtime_js__WEBPACK_IMPORTED_MODULE_1__.set_update_version)(version);

		return result;
	};

	if (is_proxied_array) {
		// We need to create the length source eagerly to ensure that
		// mutations to the array are properly synced with our proxy
		sources.set('length', (0,_reactivity_sources_js__WEBPACK_IMPORTED_MODULE_3__.state)(/** @type {any[]} */ (value).length, stack));
		if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
			value = /** @type {any} */ (inspectable_array(/** @type {any[]} */ (value)));
		}
	}

	/** Used in dev for $inspect.trace() */
	var path = '';
	let updating = false;
	/** @param {string} new_path */
	function update_path(new_path) {
		if (updating) return;
		updating = true;
		path = new_path;

		(0,_dev_tracing_js__WEBPACK_IMPORTED_MODULE_7__.tag)(version, `${path} version`);

		// rename all child sources and child proxies
		for (const [prop, source] of sources) {
			(0,_dev_tracing_js__WEBPACK_IMPORTED_MODULE_7__.tag)(source, get_label(path, prop));
		}
		updating = false;
	}

	return new Proxy(/** @type {any} */ (value), {
		defineProperty(_, prop, descriptor) {
			if (
				!('value' in descriptor) ||
				descriptor.configurable === false ||
				descriptor.enumerable === false ||
				descriptor.writable === false
			) {
				// we disallow non-basic descriptors, because unless they are applied to the
				// target object — which we avoid, so that state can be forked — we will run
				// afoul of the various invariants
				// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy/Proxy/getOwnPropertyDescriptor#invariants
				_errors_js__WEBPACK_IMPORTED_MODULE_6__.state_descriptors_fixed();
			}
			var s = sources.get(prop);
			if (s === undefined) {
				s = with_parent(() => {
					var s = (0,_reactivity_sources_js__WEBPACK_IMPORTED_MODULE_3__.state)(descriptor.value, stack);
					sources.set(prop, s);
					if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV && typeof prop === 'string') {
						(0,_dev_tracing_js__WEBPACK_IMPORTED_MODULE_7__.tag)(s, get_label(path, prop));
					}
					return s;
				});
			} else {
				(0,_reactivity_sources_js__WEBPACK_IMPORTED_MODULE_3__.set)(s, descriptor.value, true);
			}

			return true;
		},

		deleteProperty(target, prop) {
			var s = sources.get(prop);

			if (s === undefined) {
				if (prop in target) {
					const s = with_parent(() => (0,_reactivity_sources_js__WEBPACK_IMPORTED_MODULE_3__.state)(_constants_js__WEBPACK_IMPORTED_MODULE_5__.UNINITIALIZED, stack));
					sources.set(prop, s);
					(0,_reactivity_sources_js__WEBPACK_IMPORTED_MODULE_3__.increment)(version);

					if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
						(0,_dev_tracing_js__WEBPACK_IMPORTED_MODULE_7__.tag)(s, get_label(path, prop));
					}
				}
			} else {
				(0,_reactivity_sources_js__WEBPACK_IMPORTED_MODULE_3__.set)(s, _constants_js__WEBPACK_IMPORTED_MODULE_5__.UNINITIALIZED);
				(0,_reactivity_sources_js__WEBPACK_IMPORTED_MODULE_3__.increment)(version);
			}

			return true;
		},

		get(target, prop, receiver) {
			if (prop === _client_constants__WEBPACK_IMPORTED_MODULE_4__.STATE_SYMBOL) {
				return value;
			}

			if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV && prop === _client_constants__WEBPACK_IMPORTED_MODULE_4__.PROXY_PATH_SYMBOL) {
				return update_path;
			}

			var s = sources.get(prop);
			var exists = prop in target;

			// create a source, but only if it's an own property and not a prototype property
			if (s === undefined && (!exists || (0,_shared_utils_js__WEBPACK_IMPORTED_MODULE_2__.get_descriptor)(target, prop)?.writable)) {
				s = with_parent(() => {
					var p = proxy(exists ? target[prop] : _constants_js__WEBPACK_IMPORTED_MODULE_5__.UNINITIALIZED);
					var s = (0,_reactivity_sources_js__WEBPACK_IMPORTED_MODULE_3__.state)(p, stack);

					if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
						(0,_dev_tracing_js__WEBPACK_IMPORTED_MODULE_7__.tag)(s, get_label(path, prop));
					}

					return s;
				});

				sources.set(prop, s);
			}

			if (s !== undefined) {
				var v = (0,_runtime_js__WEBPACK_IMPORTED_MODULE_1__.get)(s);
				return v === _constants_js__WEBPACK_IMPORTED_MODULE_5__.UNINITIALIZED ? undefined : v;
			}

			return Reflect.get(target, prop, receiver);
		},

		getOwnPropertyDescriptor(target, prop) {
			var descriptor = Reflect.getOwnPropertyDescriptor(target, prop);

			if (descriptor && 'value' in descriptor) {
				var s = sources.get(prop);
				if (s) descriptor.value = (0,_runtime_js__WEBPACK_IMPORTED_MODULE_1__.get)(s);
			} else if (descriptor === undefined) {
				var source = sources.get(prop);
				var value = source?.v;

				if (source !== undefined && value !== _constants_js__WEBPACK_IMPORTED_MODULE_5__.UNINITIALIZED) {
					return {
						enumerable: true,
						configurable: true,
						value,
						writable: true
					};
				}
			}

			return descriptor;
		},

		has(target, prop) {
			if (prop === _client_constants__WEBPACK_IMPORTED_MODULE_4__.STATE_SYMBOL) {
				return true;
			}

			var s = sources.get(prop);
			var has = (s !== undefined && s.v !== _constants_js__WEBPACK_IMPORTED_MODULE_5__.UNINITIALIZED) || Reflect.has(target, prop);

			if (
				s !== undefined ||
				(_runtime_js__WEBPACK_IMPORTED_MODULE_1__.active_effect !== null && (!has || (0,_shared_utils_js__WEBPACK_IMPORTED_MODULE_2__.get_descriptor)(target, prop)?.writable))
			) {
				if (s === undefined) {
					s = with_parent(() => {
						var p = has ? proxy(target[prop]) : _constants_js__WEBPACK_IMPORTED_MODULE_5__.UNINITIALIZED;
						var s = (0,_reactivity_sources_js__WEBPACK_IMPORTED_MODULE_3__.state)(p, stack);

						if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
							(0,_dev_tracing_js__WEBPACK_IMPORTED_MODULE_7__.tag)(s, get_label(path, prop));
						}

						return s;
					});

					sources.set(prop, s);
				}

				var value = (0,_runtime_js__WEBPACK_IMPORTED_MODULE_1__.get)(s);
				if (value === _constants_js__WEBPACK_IMPORTED_MODULE_5__.UNINITIALIZED) {
					return false;
				}
			}

			return has;
		},

		set(target, prop, value, receiver) {
			var s = sources.get(prop);
			var has = prop in target;

			// variable.length = value -> clear all signals with index >= value
			if (is_proxied_array && prop === 'length') {
				for (var i = value; i < /** @type {Source<number>} */ (s).v; i += 1) {
					var other_s = sources.get(i + '');
					if (other_s !== undefined) {
						(0,_reactivity_sources_js__WEBPACK_IMPORTED_MODULE_3__.set)(other_s, _constants_js__WEBPACK_IMPORTED_MODULE_5__.UNINITIALIZED);
					} else if (i in target) {
						// If the item exists in the original, we need to create an uninitialized source,
						// else a later read of the property would result in a source being created with
						// the value of the original item at that index.
						other_s = with_parent(() => (0,_reactivity_sources_js__WEBPACK_IMPORTED_MODULE_3__.state)(_constants_js__WEBPACK_IMPORTED_MODULE_5__.UNINITIALIZED, stack));
						sources.set(i + '', other_s);

						if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
							(0,_dev_tracing_js__WEBPACK_IMPORTED_MODULE_7__.tag)(other_s, get_label(path, i));
						}
					}
				}
			}

			// If we haven't yet created a source for this property, we need to ensure
			// we do so otherwise if we read it later, then the write won't be tracked and
			// the heuristics of effects will be different vs if we had read the proxied
			// object property before writing to that property.
			if (s === undefined) {
				if (!has || (0,_shared_utils_js__WEBPACK_IMPORTED_MODULE_2__.get_descriptor)(target, prop)?.writable) {
					s = with_parent(() => (0,_reactivity_sources_js__WEBPACK_IMPORTED_MODULE_3__.state)(undefined, stack));

					if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
						(0,_dev_tracing_js__WEBPACK_IMPORTED_MODULE_7__.tag)(s, get_label(path, prop));
					}
					(0,_reactivity_sources_js__WEBPACK_IMPORTED_MODULE_3__.set)(s, proxy(value));

					sources.set(prop, s);
				}
			} else {
				has = s.v !== _constants_js__WEBPACK_IMPORTED_MODULE_5__.UNINITIALIZED;

				var p = with_parent(() => proxy(value));
				(0,_reactivity_sources_js__WEBPACK_IMPORTED_MODULE_3__.set)(s, p);
			}

			var descriptor = Reflect.getOwnPropertyDescriptor(target, prop);

			// Set the new value before updating any signals so that any listeners get the new value
			if (descriptor?.set) {
				descriptor.set.call(receiver, value);
			}

			if (!has) {
				// If we have mutated an array directly, we might need to
				// signal that length has also changed. Do it before updating metadata
				// to ensure that iterating over the array as a result of a metadata update
				// will not cause the length to be out of sync.
				if (is_proxied_array && typeof prop === 'string') {
					var ls = /** @type {Source<number>} */ (sources.get('length'));
					var n = Number(prop);

					if (Number.isInteger(n) && n >= ls.v) {
						(0,_reactivity_sources_js__WEBPACK_IMPORTED_MODULE_3__.set)(ls, n + 1);
					}
				}

				(0,_reactivity_sources_js__WEBPACK_IMPORTED_MODULE_3__.increment)(version);
			}

			return true;
		},

		ownKeys(target) {
			(0,_runtime_js__WEBPACK_IMPORTED_MODULE_1__.get)(version);

			var own_keys = Reflect.ownKeys(target).filter((key) => {
				var source = sources.get(key);
				return source === undefined || source.v !== _constants_js__WEBPACK_IMPORTED_MODULE_5__.UNINITIALIZED;
			});

			for (var [key, source] of sources) {
				if (source.v !== _constants_js__WEBPACK_IMPORTED_MODULE_5__.UNINITIALIZED && !(key in target)) {
					own_keys.push(key);
				}
			}

			return own_keys;
		},

		setPrototypeOf() {
			_errors_js__WEBPACK_IMPORTED_MODULE_6__.state_prototype_fixed();
		}
	});
}

/**
 * @param {string} path
 * @param {string | symbol} prop
 */
function get_label(path, prop) {
	if (typeof prop === 'symbol') return `${path}[Symbol(${prop.description ?? ''})]`;
	if (regex_is_valid_identifier.test(prop)) return `${path}.${prop}`;
	return /^\d+$/.test(prop) ? `${path}[${prop}]` : `${path}['${prop}']`;
}

/**
 * @param {any} value
 */
function get_proxied_value(value) {
	try {
		if (value !== null && typeof value === 'object' && _client_constants__WEBPACK_IMPORTED_MODULE_4__.STATE_SYMBOL in value) {
			return value[_client_constants__WEBPACK_IMPORTED_MODULE_4__.STATE_SYMBOL];
		}
	} catch {
		// the above if check can throw an error if the value in question
		// is the contentWindow of an iframe on another domain, in which
		// case we want to just return the value (because it's definitely
		// not a proxied value) so we don't break any JavaScript interacting
		// with that iframe (such as various payment companies client side
		// JavaScript libraries interacting with their iframes on the same
		// domain)
	}

	return value;
}

/**
 * @param {any} a
 * @param {any} b
 */
function is(a, b) {
	return Object.is(get_proxied_value(a), get_proxied_value(b));
}

const ARRAY_MUTATING_METHODS = new Set([
	'copyWithin',
	'fill',
	'pop',
	'push',
	'reverse',
	'shift',
	'sort',
	'splice',
	'unshift'
]);

/**
 * Wrap array mutating methods so $inspect is triggered only once and
 * to prevent logging an array in intermediate state (e.g. with an empty slot)
 * @param {any[]} array
 */
function inspectable_array(array) {
	return new Proxy(array, {
		get(target, prop, receiver) {
			var value = Reflect.get(target, prop, receiver);
			if (!ARRAY_MUTATING_METHODS.has(/** @type {string} */ (prop))) {
				return value;
			}

			/**
			 * @this {any[]}
			 * @param {any[]} args
			 */
			return function (...args) {
				(0,_reactivity_sources_js__WEBPACK_IMPORTED_MODULE_3__.set_eager_effects_deferred)();
				var result = value.apply(this, args);
				(0,_reactivity_sources_js__WEBPACK_IMPORTED_MODULE_3__.flush_eager_effects)();
				return result;
			};
		}
	});
}


}),
8771: 
/*!*************************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/reactivity/async.js ***!
  \*************************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  capture: () => (capture),
  flatten: () => (flatten),
  run_after_blockers: () => (run_after_blockers),
  unset_context: () => (unset_context)
});
/* import */var _client_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! #client/constants */ 5818);
/* import */var esm_env__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! esm-env */ 3990);
/* import */var _context_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../context.js */ 2204);
/* import */var _dom_blocks_boundary_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../dom/blocks/boundary.js */ 9478);
/* import */var _error_handling_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../error-handling.js */ 2219);
/* import */var _runtime_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../runtime.js */ 5551);
/* import */var _batch_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./batch.js */ 5812);
/* import */var _deriveds_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./deriveds.js */ 6064);
/* import */var _effects_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./effects.js */ 7770);
/* import */var _dom_hydration_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../dom/hydration.js */ 5742);
/** @import { Effect, TemplateNode, Value } from '#client' */











/**
 * @param {Array<Promise<void>>} blockers
 * @param {Array<() => any>} sync
 * @param {Array<() => Promise<any>>} async
 * @param {(values: Value[]) => any} fn
 */
function flatten(blockers, sync, async, fn) {
	const d = (0,_context_js__WEBPACK_IMPORTED_MODULE_2__.is_runes)() ? _deriveds_js__WEBPACK_IMPORTED_MODULE_7__.derived : _deriveds_js__WEBPACK_IMPORTED_MODULE_7__.derived_safe_equal;

	if (async.length === 0 && blockers.length === 0) {
		fn(sync.map(d));
		return;
	}

	var batch = _batch_js__WEBPACK_IMPORTED_MODULE_6__.current_batch;
	var parent = /** @type {Effect} */ (_runtime_js__WEBPACK_IMPORTED_MODULE_5__.active_effect);

	var restore = capture();

	function run() {
		Promise.all(async.map((expression) => (0,_deriveds_js__WEBPACK_IMPORTED_MODULE_7__.async_derived)(expression)))
			.then((result) => {
				restore();

				try {
					fn([...sync.map(d), ...result]);
				} catch (error) {
					// ignore errors in blocks that have already been destroyed
					if ((parent.f & _client_constants__WEBPACK_IMPORTED_MODULE_0__.DESTROYED) === 0) {
						(0,_error_handling_js__WEBPACK_IMPORTED_MODULE_4__.invoke_error_boundary)(error, parent);
					}
				}

				batch?.deactivate();
				unset_context();
			})
			.catch((error) => {
				(0,_error_handling_js__WEBPACK_IMPORTED_MODULE_4__.invoke_error_boundary)(error, parent);
			});
	}

	if (blockers.length > 0) {
		Promise.all(blockers).then(() => {
			restore();

			try {
				return run();
			} finally {
				batch?.deactivate();
				unset_context();
			}
		});
	} else {
		run();
	}
}

/**
 * @param {Array<Promise<void>>} blockers
 * @param {(values: Value[]) => any} fn
 */
function run_after_blockers(blockers, fn) {
	flatten(blockers, [], [], fn);
}

/**
 * Captures the current effect context so that we can restore it after
 * some asynchronous work has happened (so that e.g. `await a + b`
 * causes `b` to be registered as a dependency).
 */
function capture() {
	var previous_effect = _runtime_js__WEBPACK_IMPORTED_MODULE_5__.active_effect;
	var previous_reaction = _runtime_js__WEBPACK_IMPORTED_MODULE_5__.active_reaction;
	var previous_component_context = _context_js__WEBPACK_IMPORTED_MODULE_2__.component_context;
	var previous_batch = _batch_js__WEBPACK_IMPORTED_MODULE_6__.current_batch;

	if (esm_env__WEBPACK_IMPORTED_MODULE_1__.DEV) {
		var previous_dev_stack = _context_js__WEBPACK_IMPORTED_MODULE_2__.dev_stack;
	}

	return function restore(activate_batch = true) {
		(0,_runtime_js__WEBPACK_IMPORTED_MODULE_5__.set_active_effect)(previous_effect);
		(0,_runtime_js__WEBPACK_IMPORTED_MODULE_5__.set_active_reaction)(previous_reaction);
		(0,_context_js__WEBPACK_IMPORTED_MODULE_2__.set_component_context)(previous_component_context);
		if (activate_batch) previous_batch?.activate();

		if (esm_env__WEBPACK_IMPORTED_MODULE_1__.DEV) {
			(0,_deriveds_js__WEBPACK_IMPORTED_MODULE_7__.set_from_async_derived)(null);
			(0,_context_js__WEBPACK_IMPORTED_MODULE_2__.set_dev_stack)(previous_dev_stack);
		}
	};
}

/**
 * Wraps an `await` expression in such a way that the effect context that was
 * active before the expression evaluated can be reapplied afterwards —
 * `await a + b` becomes `(await $.save(a))() + b`
 * @template T
 * @param {Promise<T>} promise
 * @returns {Promise<() => T>}
 */
async function save(promise) {
	var restore = capture();
	var value = await promise;

	return () => {
		restore();
		return value;
	};
}

/**
 * Reset `current_async_effect` after the `promise` resolves, so
 * that we can emit `await_reactivity_loss` warnings
 * @template T
 * @param {Promise<T>} promise
 * @returns {Promise<() => T>}
 */
async function track_reactivity_loss(promise) {
	var previous_async_effect = _deriveds_js__WEBPACK_IMPORTED_MODULE_7__.current_async_effect;
	var value = await promise;

	return () => {
		(0,_deriveds_js__WEBPACK_IMPORTED_MODULE_7__.set_from_async_derived)(previous_async_effect);
		return value;
	};
}

/**
 * Used in `for await` loops in DEV, so
 * that we can emit `await_reactivity_loss` warnings
 * after each `async_iterator` result resolves and
 * after the `async_iterator` return resolves (if it runs)
 * @template T
 * @template TReturn
 * @param {Iterable<T> | AsyncIterable<T>} iterable
 * @returns {AsyncGenerator<T, TReturn | undefined>}
 */
async function* for_await_track_reactivity_loss(iterable) {
	// This is based on the algorithms described in ECMA-262:
	// ForIn/OfBodyEvaluation
	// https://tc39.es/ecma262/multipage/ecmascript-language-statements-and-declarations.html#sec-runtime-semantics-forin-div-ofbodyevaluation-lhs-stmt-iterator-lhskind-labelset
	// AsyncIteratorClose
	// https://tc39.es/ecma262/multipage/abstract-operations.html#sec-asynciteratorclose

	/** @type {AsyncIterator<T, TReturn>} */
	// @ts-ignore
	const iterator = iterable[Symbol.asyncIterator]?.() ?? iterable[Symbol.iterator]?.();

	if (iterator === undefined) {
		throw new TypeError('value is not async iterable');
	}

	/** Whether the completion of the iterator was "normal", meaning it wasn't ended via `break` or a similar method */
	let normal_completion = false;
	try {
		while (true) {
			const { done, value } = (await track_reactivity_loss(iterator.next()))();
			if (done) {
				normal_completion = true;
				break;
			}
			yield value;
		}
	} finally {
		// If the iterator had a normal completion and `return` is defined on the iterator, call it and return the value
		if (normal_completion && iterator.return !== undefined) {
			// eslint-disable-next-line no-unsafe-finally
			return /** @type {TReturn} */ ((await track_reactivity_loss(iterator.return()))().value);
		}
	}
}

function unset_context() {
	(0,_runtime_js__WEBPACK_IMPORTED_MODULE_5__.set_active_effect)(null);
	(0,_runtime_js__WEBPACK_IMPORTED_MODULE_5__.set_active_reaction)(null);
	(0,_context_js__WEBPACK_IMPORTED_MODULE_2__.set_component_context)(null);

	if (esm_env__WEBPACK_IMPORTED_MODULE_1__.DEV) {
		(0,_deriveds_js__WEBPACK_IMPORTED_MODULE_7__.set_from_async_derived)(null);
		(0,_context_js__WEBPACK_IMPORTED_MODULE_2__.set_dev_stack)(null);
	}
}

/**
 * @param {TemplateNode} anchor
 * @param {(target: TemplateNode) => Promise<void>} fn
 */
async function async_body(anchor, fn) {
	var boundary = (0,_dom_blocks_boundary_js__WEBPACK_IMPORTED_MODULE_3__.get_boundary)();
	var batch = /** @type {Batch} */ (_batch_js__WEBPACK_IMPORTED_MODULE_6__.current_batch);
	var blocking = !boundary.is_pending();

	boundary.update_pending_count(1);
	batch.increment(blocking);

	var active = /** @type {Effect} */ (_runtime_js__WEBPACK_IMPORTED_MODULE_5__.active_effect);

	var was_hydrating = _dom_hydration_js__WEBPACK_IMPORTED_MODULE_9__.hydrating;
	var next_hydrate_node = undefined;

	if (was_hydrating) {
		(0,_dom_hydration_js__WEBPACK_IMPORTED_MODULE_9__.hydrate_next)();
		next_hydrate_node = (0,_dom_hydration_js__WEBPACK_IMPORTED_MODULE_9__.skip_nodes)(false);
	}

	try {
		var promise = fn(anchor);
	} finally {
		if (next_hydrate_node) {
			(0,_dom_hydration_js__WEBPACK_IMPORTED_MODULE_9__.set_hydrate_node)(next_hydrate_node);
			(0,_dom_hydration_js__WEBPACK_IMPORTED_MODULE_9__.hydrate_next)();
		}
	}

	try {
		await promise;
	} catch (error) {
		if (!(0,_effects_js__WEBPACK_IMPORTED_MODULE_8__.aborted)(active)) {
			(0,_error_handling_js__WEBPACK_IMPORTED_MODULE_4__.invoke_error_boundary)(error, active);
		}
	} finally {
		boundary.update_pending_count(-1);
		batch.decrement(blocking);

		unset_context();
	}
}

/**
 * @param {Array<() => void | Promise<void>>} thunks
 */
function run(thunks) {
	const restore = capture();

	var boundary = (0,_dom_blocks_boundary_js__WEBPACK_IMPORTED_MODULE_3__.get_boundary)();
	var batch = /** @type {Batch} */ (_batch_js__WEBPACK_IMPORTED_MODULE_6__.current_batch);
	var blocking = !boundary.is_pending();

	boundary.update_pending_count(1);
	batch.increment(blocking);

	var active = /** @type {Effect} */ (_runtime_js__WEBPACK_IMPORTED_MODULE_5__.active_effect);

	/** @type {null | { error: any }} */
	var errored = null;

	/** @param {any} error */
	const handle_error = (error) => {
		errored = { error }; // wrap in object in case a promise rejects with a falsy value

		if (!(0,_effects_js__WEBPACK_IMPORTED_MODULE_8__.aborted)(active)) {
			(0,_error_handling_js__WEBPACK_IMPORTED_MODULE_4__.invoke_error_boundary)(error, active);
		}
	};

	var promise = Promise.resolve(thunks[0]()).catch(handle_error);

	var promises = [promise];

	for (const fn of thunks.slice(1)) {
		promise = promise
			.then(() => {
				if (errored) {
					throw errored.error;
				}

				if ((0,_effects_js__WEBPACK_IMPORTED_MODULE_8__.aborted)(active)) {
					throw _client_constants__WEBPACK_IMPORTED_MODULE_0__.STALE_REACTION;
				}

				try {
					restore();
					return fn();
				} finally {
					// TODO do we need it here as well as below?
					unset_context();
				}
			})
			.catch(handle_error)
			.finally(() => {
				unset_context();
			});

		promises.push(promise);
	}

	promise
		// wait one more tick, so that template effects are
		// guaranteed to run before `$effect(...)`
		.then(() => Promise.resolve())
		.finally(() => {
			boundary.update_pending_count(-1);
			batch.decrement(blocking);
		});

	return promises;
}


}),
5812: 
/*!*************************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/reactivity/batch.js ***!
  \*************************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  Batch: () => (Batch),
  batch_values: () => (batch_values),
  current_batch: () => (current_batch),
  eager_block_effects: () => (eager_block_effects),
  flushSync: () => (flushSync),
  is_flushing_sync: () => (is_flushing_sync),
  previous_batch: () => (previous_batch),
  schedule_effect: () => (schedule_effect)
});
/* import */var _client_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! #client/constants */ 5818);
/* import */var _flags_index_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../flags/index.js */ 9987);
/* import */var _shared_utils_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../shared/utils.js */ 2060);
/* import */var _runtime_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../runtime.js */ 5551);
/* import */var _errors_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../errors.js */ 1152);
/* import */var _dom_task_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../dom/task.js */ 7643);
/* import */var esm_env__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! esm-env */ 3990);
/* import */var _error_handling_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../error-handling.js */ 2219);
/* import */var _sources_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./sources.js */ 6718);
/* import */var _effects_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./effects.js */ 7770);
/** @import { Fork } from 'svelte' */
/** @import { Derived, Effect, Reaction, Source, Value } from '#client' */











/**
 * @typedef {{
 *   parent: EffectTarget | null;
 *   effect: Effect | null;
 *   effects: Effect[];
 *   render_effects: Effect[];
 *   block_effects: Effect[];
 * }} EffectTarget
 */

/** @type {Set<Batch>} */
const batches = new Set();

/** @type {Batch | null} */
let current_batch = null;

/**
 * This is needed to avoid overwriting inputs in non-async mode
 * TODO 6.0 remove this, as non-async mode will go away
 * @type {Batch | null}
 */
let previous_batch = null;

/**
 * When time travelling (i.e. working in one batch, while other batches
 * still have ongoing work), we ignore the real values of affected
 * signals in favour of their values within the batch
 * @type {Map<Value, any> | null}
 */
let batch_values = null;

/** @type {Effect[]} */
let queued_root_effects = [];

/** @type {Effect | null} */
let last_scheduled_effect = null;

let is_flushing = false;
let is_flushing_sync = false;

class Batch {
	committed = false;

	/**
	 * The current values of any sources that are updated in this batch
	 * They keys of this map are identical to `this.#previous`
	 * @type {Map<Source, any>}
	 */
	current = new Map();

	/**
	 * The values of any sources that are updated in this batch _before_ those updates took place.
	 * They keys of this map are identical to `this.#current`
	 * @type {Map<Source, any>}
	 */
	previous = new Map();

	/**
	 * When the batch is committed (and the DOM is updated), we need to remove old branches
	 * and append new ones by calling the functions added inside (if/each/key/etc) blocks
	 * @type {Set<() => void>}
	 */
	#commit_callbacks = new Set();

	/**
	 * If a fork is discarded, we need to destroy any effects that are no longer needed
	 * @type {Set<(batch: Batch) => void>}
	 */
	#discard_callbacks = new Set();

	/**
	 * The number of async effects that are currently in flight
	 */
	#pending = 0;

	/**
	 * The number of async effects that are currently in flight, _not_ inside a pending boundary
	 */
	#blocking_pending = 0;

	/**
	 * A deferred that resolves when the batch is committed, used with `settled()`
	 * TODO replace with Promise.withResolvers once supported widely enough
	 * @type {{ promise: Promise<void>, resolve: (value?: any) => void, reject: (reason: unknown) => void } | null}
	 */
	#deferred = null;

	/**
	 * Deferred effects (which run after async work has completed) that are DIRTY
	 * @type {Effect[]}
	 */
	#dirty_effects = [];

	/**
	 * Deferred effects that are MAYBE_DIRTY
	 * @type {Effect[]}
	 */
	#maybe_dirty_effects = [];

	/**
	 * A set of branches that still exist, but will be destroyed when this batch
	 * is committed — we skip over these during `process`
	 * @type {Set<Effect>}
	 */
	skipped_effects = new Set();

	is_fork = false;

	is_deferred() {
		return this.is_fork || this.#blocking_pending > 0;
	}

	/**
	 *
	 * @param {Effect[]} root_effects
	 */
	process(root_effects) {
		queued_root_effects = [];

		previous_batch = null;

		this.apply();

		/** @type {EffectTarget} */
		var target = {
			parent: null,
			effect: null,
			effects: [],
			render_effects: [],
			block_effects: []
		};

		for (const root of root_effects) {
			this.#traverse_effect_tree(root, target);
		}

		if (!this.is_fork) {
			this.#resolve();
		}

		if (this.is_deferred()) {
			this.#defer_effects(target.effects);
			this.#defer_effects(target.render_effects);
			this.#defer_effects(target.block_effects);
		} else {
			// If sources are written to, then work needs to happen in a separate batch, else prior sources would be mixed with
			// newly updated sources, which could lead to infinite loops when effects run over and over again.
			previous_batch = this;
			current_batch = null;

			flush_queued_effects(target.render_effects);
			flush_queued_effects(target.effects);

			previous_batch = null;

			this.#deferred?.resolve();
		}

		batch_values = null;
	}

	/**
	 * Traverse the effect tree, executing effects or stashing
	 * them for later execution as appropriate
	 * @param {Effect} root
	 * @param {EffectTarget} target
	 */
	#traverse_effect_tree(root, target) {
		root.f ^= _client_constants__WEBPACK_IMPORTED_MODULE_0__.CLEAN;

		var effect = root.first;

		while (effect !== null) {
			var flags = effect.f;
			var is_branch = (flags & (_client_constants__WEBPACK_IMPORTED_MODULE_0__.BRANCH_EFFECT | _client_constants__WEBPACK_IMPORTED_MODULE_0__.ROOT_EFFECT)) !== 0;
			var is_skippable_branch = is_branch && (flags & _client_constants__WEBPACK_IMPORTED_MODULE_0__.CLEAN) !== 0;

			var skip = is_skippable_branch || (flags & _client_constants__WEBPACK_IMPORTED_MODULE_0__.INERT) !== 0 || this.skipped_effects.has(effect);

			if ((effect.f & _client_constants__WEBPACK_IMPORTED_MODULE_0__.BOUNDARY_EFFECT) !== 0 && effect.b?.is_pending()) {
				target = {
					parent: target,
					effect,
					effects: [],
					render_effects: [],
					block_effects: []
				};
			}

			if (!skip && effect.fn !== null) {
				if (is_branch) {
					effect.f ^= _client_constants__WEBPACK_IMPORTED_MODULE_0__.CLEAN;
				} else if ((flags & _client_constants__WEBPACK_IMPORTED_MODULE_0__.EFFECT) !== 0) {
					target.effects.push(effect);
				} else if (_flags_index_js__WEBPACK_IMPORTED_MODULE_9__.async_mode_flag && (flags & _client_constants__WEBPACK_IMPORTED_MODULE_0__.RENDER_EFFECT) !== 0) {
					target.render_effects.push(effect);
				} else if ((0,_runtime_js__WEBPACK_IMPORTED_MODULE_2__.is_dirty)(effect)) {
					if ((effect.f & _client_constants__WEBPACK_IMPORTED_MODULE_0__.BLOCK_EFFECT) !== 0) target.block_effects.push(effect);
					(0,_runtime_js__WEBPACK_IMPORTED_MODULE_2__.update_effect)(effect);
				}

				var child = effect.first;

				if (child !== null) {
					effect = child;
					continue;
				}
			}

			var parent = effect.parent;
			effect = effect.next;

			while (effect === null && parent !== null) {
				if (parent === target.effect) {
					// TODO rather than traversing into pending boundaries and deferring the effects,
					// could we just attach the effects _to_ the pending boundary and schedule them
					// once the boundary is ready?
					this.#defer_effects(target.effects);
					this.#defer_effects(target.render_effects);
					this.#defer_effects(target.block_effects);

					target = /** @type {EffectTarget} */ (target.parent);
				}

				effect = parent.next;
				parent = parent.parent;
			}
		}
	}

	/**
	 * @param {Effect[]} effects
	 */
	#defer_effects(effects) {
		for (const e of effects) {
			const target = (e.f & _client_constants__WEBPACK_IMPORTED_MODULE_0__.DIRTY) !== 0 ? this.#dirty_effects : this.#maybe_dirty_effects;
			target.push(e);

			// Since we're not executing these effects now, we need to clear any WAS_MARKED flags
			// so that other batches can correctly reach these effects during their own traversal
			this.#clear_marked(e.deps);

			// mark as clean so they get scheduled if they depend on pending async state
			(0,_runtime_js__WEBPACK_IMPORTED_MODULE_2__.set_signal_status)(e, _client_constants__WEBPACK_IMPORTED_MODULE_0__.CLEAN);
		}
	}

	/**
	 * @param {Value[] | null} deps
	 */
	#clear_marked(deps) {
		if (deps === null) return;

		for (const dep of deps) {
			if ((dep.f & _client_constants__WEBPACK_IMPORTED_MODULE_0__.DERIVED) === 0 || (dep.f & _client_constants__WEBPACK_IMPORTED_MODULE_0__.WAS_MARKED) === 0) {
				continue;
			}

			dep.f ^= _client_constants__WEBPACK_IMPORTED_MODULE_0__.WAS_MARKED;

			this.#clear_marked(/** @type {Derived} */ (dep).deps);
		}
	}

	/**
	 * Associate a change to a given source with the current
	 * batch, noting its previous and current values
	 * @param {Source} source
	 * @param {any} value
	 */
	capture(source, value) {
		if (!this.previous.has(source)) {
			this.previous.set(source, value);
		}

		// Don't save errors in `batch_values`, or they won't be thrown in `runtime.js#get`
		if ((source.f & _client_constants__WEBPACK_IMPORTED_MODULE_0__.ERROR_VALUE) === 0) {
			this.current.set(source, source.v);
			batch_values?.set(source, source.v);
		}
	}

	activate() {
		current_batch = this;
		this.apply();
	}

	deactivate() {
		// If we're not the current batch, don't deactivate,
		// else we could create zombie batches that are never flushed
		if (current_batch !== this) return;

		current_batch = null;
		batch_values = null;
	}

	flush() {
		this.activate();

		if (queued_root_effects.length > 0) {
			flush_effects();

			if (current_batch !== null && current_batch !== this) {
				// this can happen if a new batch was created during `flush_effects()`
				return;
			}
		} else if (this.#pending === 0) {
			this.process([]); // TODO this feels awkward
		}

		this.deactivate();
	}

	discard() {
		for (const fn of this.#discard_callbacks) fn(this);
		this.#discard_callbacks.clear();
	}

	#resolve() {
		if (this.#blocking_pending === 0) {
			// append/remove branches
			for (const fn of this.#commit_callbacks) fn();
			this.#commit_callbacks.clear();
		}

		if (this.#pending === 0) {
			this.#commit();
		}
	}

	#commit() {
		// If there are other pending batches, they now need to be 'rebased' —
		// in other words, we re-run block/async effects with the newly
		// committed state, unless the batch in question has a more
		// recent value for a given source
		if (batches.size > 1) {
			this.previous.clear();

			var previous_batch_values = batch_values;
			var is_earlier = true;

			/** @type {EffectTarget} */
			var dummy_target = {
				parent: null,
				effect: null,
				effects: [],
				render_effects: [],
				block_effects: []
			};

			for (const batch of batches) {
				if (batch === this) {
					is_earlier = false;
					continue;
				}

				/** @type {Source[]} */
				const sources = [];

				for (const [source, value] of this.current) {
					if (batch.current.has(source)) {
						if (is_earlier && value !== batch.current.get(source)) {
							// bring the value up to date
							batch.current.set(source, value);
						} else {
							// same value or later batch has more recent value,
							// no need to re-run these effects
							continue;
						}
					}

					sources.push(source);
				}

				if (sources.length === 0) {
					continue;
				}

				// Re-run async/block effects that depend on distinct values changed in both batches
				const others = [...batch.current.keys()].filter((s) => !this.current.has(s));
				if (others.length > 0) {
					/** @type {Set<Value>} */
					const marked = new Set();
					/** @type {Map<Reaction, boolean>} */
					const checked = new Map();
					for (const source of sources) {
						mark_effects(source, others, marked, checked);
					}

					if (queued_root_effects.length > 0) {
						current_batch = batch;
						batch.apply();

						for (const root of queued_root_effects) {
							batch.#traverse_effect_tree(root, dummy_target);
						}

						// TODO do we need to do anything with `target`? defer block effects?

						queued_root_effects = [];
						batch.deactivate();
					}
				}
			}

			current_batch = null;
			batch_values = previous_batch_values;
		}

		this.committed = true;
		batches.delete(this);
	}

	/**
	 *
	 * @param {boolean} blocking
	 */
	increment(blocking) {
		this.#pending += 1;
		if (blocking) this.#blocking_pending += 1;
	}

	/**
	 *
	 * @param {boolean} blocking
	 */
	decrement(blocking) {
		this.#pending -= 1;
		if (blocking) this.#blocking_pending -= 1;

		this.revive();
	}

	revive() {
		for (const e of this.#dirty_effects) {
			(0,_runtime_js__WEBPACK_IMPORTED_MODULE_2__.set_signal_status)(e, _client_constants__WEBPACK_IMPORTED_MODULE_0__.DIRTY);
			schedule_effect(e);
		}

		for (const e of this.#maybe_dirty_effects) {
			(0,_runtime_js__WEBPACK_IMPORTED_MODULE_2__.set_signal_status)(e, _client_constants__WEBPACK_IMPORTED_MODULE_0__.MAYBE_DIRTY);
			schedule_effect(e);
		}

		this.#dirty_effects = [];
		this.#maybe_dirty_effects = [];

		this.flush();
	}

	/** @param {() => void} fn */
	oncommit(fn) {
		this.#commit_callbacks.add(fn);
	}

	/** @param {(batch: Batch) => void} fn */
	ondiscard(fn) {
		this.#discard_callbacks.add(fn);
	}

	settled() {
		return (this.#deferred ??= (0,_shared_utils_js__WEBPACK_IMPORTED_MODULE_1__.deferred)()).promise;
	}

	static ensure() {
		if (current_batch === null) {
			const batch = (current_batch = new Batch());
			batches.add(current_batch);

			if (!is_flushing_sync) {
				Batch.enqueue(() => {
					if (current_batch !== batch) {
						// a flushSync happened in the meantime
						return;
					}

					batch.flush();
				});
			}
		}

		return current_batch;
	}

	/** @param {() => void} task */
	static enqueue(task) {
		(0,_dom_task_js__WEBPACK_IMPORTED_MODULE_4__.queue_micro_task)(task);
	}

	apply() {
		if (!_flags_index_js__WEBPACK_IMPORTED_MODULE_9__.async_mode_flag || (!this.is_fork && batches.size === 1)) return;

		// if there are multiple batches, we are 'time travelling' —
		// we need to override values with the ones in this batch...
		batch_values = new Map(this.current);

		// ...and undo changes belonging to other batches
		for (const batch of batches) {
			if (batch === this) continue;

			for (const [source, previous] of batch.previous) {
				if (!batch_values.has(source)) {
					batch_values.set(source, previous);
				}
			}
		}
	}
}

/**
 * Synchronously flush any pending updates.
 * Returns void if no callback is provided, otherwise returns the result of calling the callback.
 * @template [T=void]
 * @param {(() => T) | undefined} [fn]
 * @returns {T}
 */
function flushSync(fn) {
	if (_flags_index_js__WEBPACK_IMPORTED_MODULE_9__.async_mode_flag && _runtime_js__WEBPACK_IMPORTED_MODULE_2__.active_effect !== null) {
		// We disallow this because it creates super-hard to reason about stack trace and because it's generally a bad idea
		_errors_js__WEBPACK_IMPORTED_MODULE_3__.flush_sync_in_effect();
	}

	var was_flushing_sync = is_flushing_sync;
	is_flushing_sync = true;

	try {
		var result;

		if (fn) {
			if (current_batch !== null) {
				flush_effects();
			}

			result = fn();
		}

		while (true) {
			(0,_dom_task_js__WEBPACK_IMPORTED_MODULE_4__.flush_tasks)();

			if (queued_root_effects.length === 0) {
				current_batch?.flush();

				// we need to check again, in case we just updated an `$effect.pending()`
				if (queued_root_effects.length === 0) {
					// this would be reset in `flush_effects()` but since we are early returning here,
					// we need to reset it here as well in case the first time there's 0 queued root effects
					last_scheduled_effect = null;

					return /** @type {T} */ (result);
				}
			}

			flush_effects();
		}
	} finally {
		is_flushing_sync = was_flushing_sync;
	}
}

function flush_effects() {
	var was_updating_effect = _runtime_js__WEBPACK_IMPORTED_MODULE_2__.is_updating_effect;
	is_flushing = true;

	try {
		var flush_count = 0;
		(0,_runtime_js__WEBPACK_IMPORTED_MODULE_2__.set_is_updating_effect)(true);

		while (queued_root_effects.length > 0) {
			var batch = Batch.ensure();

			if (flush_count++ > 1000) {
				if (esm_env__WEBPACK_IMPORTED_MODULE_5__.DEV) {
					var updates = new Map();

					for (const source of batch.current.keys()) {
						for (const [stack, update] of source.updated ?? []) {
							var entry = updates.get(stack);

							if (!entry) {
								entry = { error: update.error, count: 0 };
								updates.set(stack, entry);
							}

							entry.count += update.count;
						}
					}

					for (const update of updates.values()) {
						// eslint-disable-next-line no-console
						console.error(update.error);
					}
				}

				infinite_loop_guard();
			}

			batch.process(queued_root_effects);
			_sources_js__WEBPACK_IMPORTED_MODULE_7__.old_values.clear();
		}
	} finally {
		is_flushing = false;
		(0,_runtime_js__WEBPACK_IMPORTED_MODULE_2__.set_is_updating_effect)(was_updating_effect);

		last_scheduled_effect = null;
	}
}

function infinite_loop_guard() {
	try {
		_errors_js__WEBPACK_IMPORTED_MODULE_3__.effect_update_depth_exceeded();
	} catch (error) {
		if (esm_env__WEBPACK_IMPORTED_MODULE_5__.DEV) {
			// stack contains no useful information, replace it
			(0,_shared_utils_js__WEBPACK_IMPORTED_MODULE_1__.define_property)(error, 'stack', { value: '' });
		}

		// Best effort: invoke the boundary nearest the most recent
		// effect and hope that it's relevant to the infinite loop
		(0,_error_handling_js__WEBPACK_IMPORTED_MODULE_6__.invoke_error_boundary)(error, last_scheduled_effect);
	}
}

/** @type {Set<Effect> | null} */
let eager_block_effects = null;

/**
 * @param {Array<Effect>} effects
 * @returns {void}
 */
function flush_queued_effects(effects) {
	var length = effects.length;
	if (length === 0) return;

	var i = 0;

	while (i < length) {
		var effect = effects[i++];

		if ((effect.f & (_client_constants__WEBPACK_IMPORTED_MODULE_0__.DESTROYED | _client_constants__WEBPACK_IMPORTED_MODULE_0__.INERT)) === 0 && (0,_runtime_js__WEBPACK_IMPORTED_MODULE_2__.is_dirty)(effect)) {
			eager_block_effects = new Set();

			(0,_runtime_js__WEBPACK_IMPORTED_MODULE_2__.update_effect)(effect);

			// Effects with no dependencies or teardown do not get added to the effect tree.
			// Deferred effects (e.g. `$effect(...)`) _are_ added to the tree because we
			// don't know if we need to keep them until they are executed. Doing the check
			// here (rather than in `update_effect`) allows us to skip the work for
			// immediate effects.
			if (effect.deps === null && effect.first === null && effect.nodes_start === null) {
				// if there's no teardown or abort controller we completely unlink
				// the effect from the graph
				if (effect.teardown === null && effect.ac === null) {
					// remove this effect from the graph
					(0,_effects_js__WEBPACK_IMPORTED_MODULE_8__.unlink_effect)(effect);
				} else {
					// keep the effect in the graph, but free up some memory
					effect.fn = null;
				}
			}

			// If update_effect() has a flushSync() in it, we may have flushed another flush_queued_effects(),
			// which already handled this logic and did set eager_block_effects to null.
			if (eager_block_effects?.size > 0) {
				_sources_js__WEBPACK_IMPORTED_MODULE_7__.old_values.clear();

				for (const e of eager_block_effects) {
					// Skip eager effects that have already been unmounted
					if ((e.f & (_client_constants__WEBPACK_IMPORTED_MODULE_0__.DESTROYED | _client_constants__WEBPACK_IMPORTED_MODULE_0__.INERT)) !== 0) continue;

					// Run effects in order from ancestor to descendant, else we could run into nullpointers
					/** @type {Effect[]} */
					const ordered_effects = [e];
					let ancestor = e.parent;
					while (ancestor !== null) {
						if (eager_block_effects.has(ancestor)) {
							eager_block_effects.delete(ancestor);
							ordered_effects.push(ancestor);
						}
						ancestor = ancestor.parent;
					}

					for (let j = ordered_effects.length - 1; j >= 0; j--) {
						const e = ordered_effects[j];
						// Skip eager effects that have already been unmounted
						if ((e.f & (_client_constants__WEBPACK_IMPORTED_MODULE_0__.DESTROYED | _client_constants__WEBPACK_IMPORTED_MODULE_0__.INERT)) !== 0) continue;
						(0,_runtime_js__WEBPACK_IMPORTED_MODULE_2__.update_effect)(e);
					}
				}

				eager_block_effects.clear();
			}
		}
	}

	eager_block_effects = null;
}

/**
 * This is similar to `mark_reactions`, but it only marks async/block effects
 * depending on `value` and at least one of the other `sources`, so that
 * these effects can re-run after another batch has been committed
 * @param {Value} value
 * @param {Source[]} sources
 * @param {Set<Value>} marked
 * @param {Map<Reaction, boolean>} checked
 */
function mark_effects(value, sources, marked, checked) {
	if (marked.has(value)) return;
	marked.add(value);

	if (value.reactions !== null) {
		for (const reaction of value.reactions) {
			const flags = reaction.f;

			if ((flags & _client_constants__WEBPACK_IMPORTED_MODULE_0__.DERIVED) !== 0) {
				mark_effects(/** @type {Derived} */ (reaction), sources, marked, checked);
			} else if (
				(flags & (_client_constants__WEBPACK_IMPORTED_MODULE_0__.ASYNC | _client_constants__WEBPACK_IMPORTED_MODULE_0__.BLOCK_EFFECT)) !== 0 &&
				(flags & _client_constants__WEBPACK_IMPORTED_MODULE_0__.DIRTY) === 0 && // we may have scheduled this one already
				depends_on(reaction, sources, checked)
			) {
				(0,_runtime_js__WEBPACK_IMPORTED_MODULE_2__.set_signal_status)(reaction, _client_constants__WEBPACK_IMPORTED_MODULE_0__.DIRTY);
				schedule_effect(/** @type {Effect} */ (reaction));
			}
		}
	}
}

/**
 * When committing a fork, we need to trigger eager effects so that
 * any `$state.eager(...)` expressions update immediately. This
 * function allows us to discover them
 * @param {Value} value
 * @param {Set<Effect>} effects
 */
function mark_eager_effects(value, effects) {
	if (value.reactions === null) return;

	for (const reaction of value.reactions) {
		const flags = reaction.f;

		if ((flags & _client_constants__WEBPACK_IMPORTED_MODULE_0__.DERIVED) !== 0) {
			mark_eager_effects(/** @type {Derived} */ (reaction), effects);
		} else if ((flags & _client_constants__WEBPACK_IMPORTED_MODULE_0__.EAGER_EFFECT) !== 0) {
			(0,_runtime_js__WEBPACK_IMPORTED_MODULE_2__.set_signal_status)(reaction, _client_constants__WEBPACK_IMPORTED_MODULE_0__.DIRTY);
			effects.add(/** @type {Effect} */ (reaction));
		}
	}
}

/**
 * @param {Reaction} reaction
 * @param {Source[]} sources
 * @param {Map<Reaction, boolean>} checked
 */
function depends_on(reaction, sources, checked) {
	const depends = checked.get(reaction);
	if (depends !== undefined) return depends;

	if (reaction.deps !== null) {
		for (const dep of reaction.deps) {
			if (sources.includes(dep)) {
				return true;
			}

			if ((dep.f & _client_constants__WEBPACK_IMPORTED_MODULE_0__.DERIVED) !== 0 && depends_on(/** @type {Derived} */ (dep), sources, checked)) {
				checked.set(/** @type {Derived} */ (dep), true);
				return true;
			}
		}
	}

	checked.set(reaction, false);

	return false;
}

/**
 * @param {Effect} signal
 * @returns {void}
 */
function schedule_effect(signal) {
	var effect = (last_scheduled_effect = signal);

	while (effect.parent !== null) {
		effect = effect.parent;
		var flags = effect.f;

		// if the effect is being scheduled because a parent (each/await/etc) block
		// updated an internal source, bail out or we'll cause a second flush
		if (
			is_flushing &&
			effect === _runtime_js__WEBPACK_IMPORTED_MODULE_2__.active_effect &&
			(flags & _client_constants__WEBPACK_IMPORTED_MODULE_0__.BLOCK_EFFECT) !== 0 &&
			(flags & _client_constants__WEBPACK_IMPORTED_MODULE_0__.HEAD_EFFECT) === 0
		) {
			return;
		}

		if ((flags & (_client_constants__WEBPACK_IMPORTED_MODULE_0__.ROOT_EFFECT | _client_constants__WEBPACK_IMPORTED_MODULE_0__.BRANCH_EFFECT)) !== 0) {
			if ((flags & _client_constants__WEBPACK_IMPORTED_MODULE_0__.CLEAN) === 0) return;
			effect.f ^= _client_constants__WEBPACK_IMPORTED_MODULE_0__.CLEAN;
		}
	}

	queued_root_effects.push(effect);
}

/** @type {Source<number>[]} */
let eager_versions = [];

function eager_flush() {
	try {
		flushSync(() => {
			for (const version of eager_versions) {
				(0,_sources_js__WEBPACK_IMPORTED_MODULE_7__.update)(version);
			}
		});
	} finally {
		eager_versions = [];
	}
}

/**
 * Implementation of `$state.eager(fn())`
 * @template T
 * @param {() => T} fn
 * @returns {T}
 */
function eager(fn) {
	var version = (0,_sources_js__WEBPACK_IMPORTED_MODULE_7__.source)(0);
	var initial = true;
	var value = /** @type {T} */ (undefined);

	(0,_runtime_js__WEBPACK_IMPORTED_MODULE_2__.get)(version);

	(0,_effects_js__WEBPACK_IMPORTED_MODULE_8__.eager_effect)(() => {
		if (initial) {
			// the first time this runs, we create an eager effect
			// that will run eagerly whenever the expression changes
			var previous_batch_values = batch_values;

			try {
				batch_values = null;
				value = fn();
			} finally {
				batch_values = previous_batch_values;
			}

			return;
		}

		// the second time this effect runs, it's to schedule a
		// `version` update. since this will recreate the effect,
		// we don't need to evaluate the expression here
		if (eager_versions.length === 0) {
			(0,_dom_task_js__WEBPACK_IMPORTED_MODULE_4__.queue_micro_task)(eager_flush);
		}

		eager_versions.push(version);
	});

	initial = false;

	return value;
}

/**
 * Creates a 'fork', in which state changes are evaluated but not applied to the DOM.
 * This is useful for speculatively loading data (for example) when you suspect that
 * the user is about to take some action.
 *
 * Frameworks like SvelteKit can use this to preload data when the user touches or
 * hovers over a link, making any subsequent navigation feel instantaneous.
 *
 * The `fn` parameter is a synchronous function that modifies some state. The
 * state changes will be reverted after the fork is initialised, then reapplied
 * if and when the fork is eventually committed.
 *
 * When it becomes clear that a fork will _not_ be committed (e.g. because the
 * user navigated elsewhere), it must be discarded to avoid leaking memory.
 *
 * @param {() => void} fn
 * @returns {Fork}
 * @since 5.42
 */
function fork(fn) {
	if (!_flags_index_js__WEBPACK_IMPORTED_MODULE_9__.async_mode_flag) {
		_errors_js__WEBPACK_IMPORTED_MODULE_3__.experimental_async_fork();
	}

	if (current_batch !== null) {
		_errors_js__WEBPACK_IMPORTED_MODULE_3__.fork_timing();
	}

	var batch = Batch.ensure();
	batch.is_fork = true;

	var committed = false;
	var settled = batch.settled();

	flushSync(fn);

	// revert state changes
	for (var [source, value] of batch.previous) {
		source.v = value;
	}

	return {
		commit: async () => {
			if (committed) {
				await settled;
				return;
			}

			if (!batches.has(batch)) {
				_errors_js__WEBPACK_IMPORTED_MODULE_3__.fork_discarded();
			}

			committed = true;

			batch.is_fork = false;

			// apply changes
			for (var [source, value] of batch.current) {
				source.v = value;
			}

			// trigger any `$state.eager(...)` expressions with the new state.
			// eager effects don't get scheduled like other effects, so we
			// can't just encounter them during traversal, we need to
			// proactively flush them
			// TODO maybe there's a better implementation?
			flushSync(() => {
				/** @type {Set<Effect>} */
				var eager_effects = new Set();

				for (var source of batch.current.keys()) {
					mark_eager_effects(source, eager_effects);
				}

				(0,_sources_js__WEBPACK_IMPORTED_MODULE_7__.set_eager_effects)(eager_effects);
				(0,_sources_js__WEBPACK_IMPORTED_MODULE_7__.flush_eager_effects)();
			});

			batch.revive();
			await settled;
		},
		discard: () => {
			if (!committed && batches.has(batch)) {
				batches.delete(batch);
				batch.discard();
			}
		}
	};
}

/**
 * Forcibly remove all current batches, to prevent cross-talk between tests
 */
function clear() {
	batches.clear();
}


}),
6064: 
/*!****************************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/reactivity/deriveds.js ***!
  \****************************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  async_derived: () => (async_derived),
  current_async_effect: () => (current_async_effect),
  derived: () => (derived),
  derived_safe_equal: () => (derived_safe_equal),
  destroy_derived_effects: () => (destroy_derived_effects),
  execute_derived: () => (execute_derived),
  recent_async_deriveds: () => (recent_async_deriveds),
  set_from_async_derived: () => (set_from_async_derived),
  update_derived: () => (update_derived)
});
/* import */var esm_env__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! esm-env */ 3990);
/* import */var _client_constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! #client/constants */ 5818);
/* import */var _runtime_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../runtime.js */ 5551);
/* import */var _equality_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./equality.js */ 7566);
/* import */var _errors_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../errors.js */ 1152);
/* import */var _warnings_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../warnings.js */ 8658);
/* import */var _effects_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./effects.js */ 7770);
/* import */var _sources_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./sources.js */ 6718);
/* import */var _dev_tracing_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../dev/tracing.js */ 6265);
/* import */var _flags_index_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../flags/index.js */ 9987);
/* import */var _dom_blocks_boundary_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../dom/blocks/boundary.js */ 9478);
/* import */var _context_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../context.js */ 2204);
/* import */var _constants_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../constants.js */ 7164);
/* import */var _batch_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./batch.js */ 5812);
/* import */var _async_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./async.js */ 8771);
/* import */var _shared_utils_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../shared/utils.js */ 2060);
/** @import { Derived, Effect, Source } from '#client' */
/** @import { Batch } from './batch.js'; */

















/** @type {Effect | null} */
let current_async_effect = null;

/** @param {Effect | null} v */
function set_from_async_derived(v) {
	current_async_effect = v;
}

const recent_async_deriveds = new Set();

/**
 * @template V
 * @param {() => V} fn
 * @returns {Derived<V>}
 */
/*#__NO_SIDE_EFFECTS__*/
function derived(fn) {
	var flags = _client_constants__WEBPACK_IMPORTED_MODULE_1__.DERIVED | _client_constants__WEBPACK_IMPORTED_MODULE_1__.DIRTY;
	var parent_derived =
		_runtime_js__WEBPACK_IMPORTED_MODULE_2__.active_reaction !== null && (_runtime_js__WEBPACK_IMPORTED_MODULE_2__.active_reaction.f & _client_constants__WEBPACK_IMPORTED_MODULE_1__.DERIVED) !== 0
			? /** @type {Derived} */ (_runtime_js__WEBPACK_IMPORTED_MODULE_2__.active_reaction)
			: null;

	if (_runtime_js__WEBPACK_IMPORTED_MODULE_2__.active_effect !== null) {
		// Since deriveds are evaluated lazily, any effects created inside them are
		// created too late to ensure that the parent effect is added to the tree
		_runtime_js__WEBPACK_IMPORTED_MODULE_2__.active_effect.f |= _client_constants__WEBPACK_IMPORTED_MODULE_1__.EFFECT_PRESERVED;
	}

	/** @type {Derived<V>} */
	const signal = {
		ctx: _context_js__WEBPACK_IMPORTED_MODULE_9__.component_context,
		deps: null,
		effects: null,
		equals: _equality_js__WEBPACK_IMPORTED_MODULE_14__.equals,
		f: flags,
		fn,
		reactions: null,
		rv: 0,
		v: /** @type {V} */ (_constants_js__WEBPACK_IMPORTED_MODULE_10__.UNINITIALIZED),
		wv: 0,
		parent: parent_derived ?? _runtime_js__WEBPACK_IMPORTED_MODULE_2__.active_effect,
		ac: null
	};

	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV && _flags_index_js__WEBPACK_IMPORTED_MODULE_15__.tracing_mode_flag) {
		signal.created = (0,_dev_tracing_js__WEBPACK_IMPORTED_MODULE_7__.get_stack)('created at');
	}

	return signal;
}

/**
 * @template V
 * @param {() => V | Promise<V>} fn
 * @param {string} [location] If provided, print a warning if the value is not read immediately after update
 * @returns {Promise<Source<V>>}
 */
/*#__NO_SIDE_EFFECTS__*/
function async_derived(fn, location) {
	let parent = /** @type {Effect | null} */ (_runtime_js__WEBPACK_IMPORTED_MODULE_2__.active_effect);

	if (parent === null) {
		_errors_js__WEBPACK_IMPORTED_MODULE_3__.async_derived_orphan();
	}

	var boundary = /** @type {Boundary} */ (parent.b);

	var promise = /** @type {Promise<V>} */ (/** @type {unknown} */ (undefined));
	var signal = (0,_sources_js__WEBPACK_IMPORTED_MODULE_6__.source)(/** @type {V} */ (_constants_js__WEBPACK_IMPORTED_MODULE_10__.UNINITIALIZED));

	// only suspend in async deriveds created on initialisation
	var should_suspend = !_runtime_js__WEBPACK_IMPORTED_MODULE_2__.active_reaction;

	/** @type {Map<Batch, ReturnType<typeof deferred<V>>>} */
	var deferreds = new Map();

	(0,_effects_js__WEBPACK_IMPORTED_MODULE_5__.async_effect)(() => {
		if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) current_async_effect = _runtime_js__WEBPACK_IMPORTED_MODULE_2__.active_effect;

		/** @type {ReturnType<typeof deferred<V>>} */
		var d = (0,_shared_utils_js__WEBPACK_IMPORTED_MODULE_13__.deferred)();
		promise = d.promise;

		try {
			// If this code is changed at some point, make sure to still access the then property
			// of fn() to read any signals it might access, so that we track them as dependencies.
			// We call `unset_context` to undo any `save` calls that happen inside `fn()`
			Promise.resolve(fn())
				.then(d.resolve, d.reject)
				.then(() => {
					if (batch === _batch_js__WEBPACK_IMPORTED_MODULE_11__.current_batch && batch.committed) {
						// if the batch was rejected as stale, we need to cleanup
						// after any `$.save(...)` calls inside `fn()`
						batch.deactivate();
					}

					(0,_async_js__WEBPACK_IMPORTED_MODULE_12__.unset_context)();
				});
		} catch (error) {
			d.reject(error);
			(0,_async_js__WEBPACK_IMPORTED_MODULE_12__.unset_context)();
		}

		if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) current_async_effect = null;

		var batch = /** @type {Batch} */ (_batch_js__WEBPACK_IMPORTED_MODULE_11__.current_batch);

		if (should_suspend) {
			var blocking = !boundary.is_pending();

			boundary.update_pending_count(1);
			batch.increment(blocking);

			deferreds.get(batch)?.reject(_client_constants__WEBPACK_IMPORTED_MODULE_1__.STALE_REACTION);
			deferreds.delete(batch); // delete to ensure correct order in Map iteration below
			deferreds.set(batch, d);
		}

		/**
		 * @param {any} value
		 * @param {unknown} error
		 */
		const handler = (value, error = undefined) => {
			current_async_effect = null;

			batch.activate();

			if (error) {
				if (error !== _client_constants__WEBPACK_IMPORTED_MODULE_1__.STALE_REACTION) {
					signal.f |= _client_constants__WEBPACK_IMPORTED_MODULE_1__.ERROR_VALUE;

					// @ts-expect-error the error is the wrong type, but we don't care
					(0,_sources_js__WEBPACK_IMPORTED_MODULE_6__.internal_set)(signal, error);
				}
			} else {
				if ((signal.f & _client_constants__WEBPACK_IMPORTED_MODULE_1__.ERROR_VALUE) !== 0) {
					signal.f ^= _client_constants__WEBPACK_IMPORTED_MODULE_1__.ERROR_VALUE;
				}

				(0,_sources_js__WEBPACK_IMPORTED_MODULE_6__.internal_set)(signal, value);

				// All prior async derived runs are now stale
				for (const [b, d] of deferreds) {
					deferreds.delete(b);
					if (b === batch) break;
					d.reject(_client_constants__WEBPACK_IMPORTED_MODULE_1__.STALE_REACTION);
				}

				if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV && location !== undefined) {
					recent_async_deriveds.add(signal);

					setTimeout(() => {
						if (recent_async_deriveds.has(signal)) {
							_warnings_js__WEBPACK_IMPORTED_MODULE_4__.await_waterfall(/** @type {string} */ (signal.label), location);
							recent_async_deriveds.delete(signal);
						}
					});
				}
			}

			if (should_suspend) {
				boundary.update_pending_count(-1);
				batch.decrement(blocking);
			}
		};

		d.promise.then(handler, (e) => handler(null, e || 'unknown'));
	});

	(0,_effects_js__WEBPACK_IMPORTED_MODULE_5__.teardown)(() => {
		for (const d of deferreds.values()) {
			d.reject(_client_constants__WEBPACK_IMPORTED_MODULE_1__.STALE_REACTION);
		}
	});

	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		// add a flag that lets this be printed as a derived
		// when using `$inspect.trace()`
		signal.f |= _client_constants__WEBPACK_IMPORTED_MODULE_1__.ASYNC;
	}

	return new Promise((fulfil) => {
		/** @param {Promise<V>} p */
		function next(p) {
			function go() {
				if (p === promise) {
					fulfil(signal);
				} else {
					// if the effect re-runs before the initial promise
					// resolves, delay resolution until we have a value
					next(promise);
				}
			}

			p.then(go, go);
		}

		next(promise);
	});
}

/**
 * @template V
 * @param {() => V} fn
 * @returns {Derived<V>}
 */
/*#__NO_SIDE_EFFECTS__*/
function user_derived(fn) {
	const d = derived(fn);

	if (!_flags_index_js__WEBPACK_IMPORTED_MODULE_15__.async_mode_flag) (0,_runtime_js__WEBPACK_IMPORTED_MODULE_2__.push_reaction_value)(d);

	return d;
}

/**
 * @template V
 * @param {() => V} fn
 * @returns {Derived<V>}
 */
/*#__NO_SIDE_EFFECTS__*/
function derived_safe_equal(fn) {
	const signal = derived(fn);
	signal.equals = _equality_js__WEBPACK_IMPORTED_MODULE_14__.safe_equals;
	return signal;
}

/**
 * @param {Derived} derived
 * @returns {void}
 */
function destroy_derived_effects(derived) {
	var effects = derived.effects;

	if (effects !== null) {
		derived.effects = null;

		for (var i = 0; i < effects.length; i += 1) {
			(0,_effects_js__WEBPACK_IMPORTED_MODULE_5__.destroy_effect)(/** @type {Effect} */ (effects[i]));
		}
	}
}

/**
 * The currently updating deriveds, used to detect infinite recursion
 * in dev mode and provide a nicer error than 'too much recursion'
 * @type {Derived[]}
 */
let stack = [];

/**
 * @param {Derived} derived
 * @returns {Effect | null}
 */
function get_derived_parent_effect(derived) {
	var parent = derived.parent;
	while (parent !== null) {
		if ((parent.f & _client_constants__WEBPACK_IMPORTED_MODULE_1__.DERIVED) === 0) {
			return /** @type {Effect} */ (parent);
		}
		parent = parent.parent;
	}
	return null;
}

/**
 * @template T
 * @param {Derived} derived
 * @returns {T}
 */
function execute_derived(derived) {
	var value;
	var prev_active_effect = _runtime_js__WEBPACK_IMPORTED_MODULE_2__.active_effect;

	(0,_runtime_js__WEBPACK_IMPORTED_MODULE_2__.set_active_effect)(get_derived_parent_effect(derived));

	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		let prev_eager_effects = _sources_js__WEBPACK_IMPORTED_MODULE_6__.eager_effects;
		(0,_sources_js__WEBPACK_IMPORTED_MODULE_6__.set_eager_effects)(new Set());
		try {
			if (stack.includes(derived)) {
				_errors_js__WEBPACK_IMPORTED_MODULE_3__.derived_references_self();
			}

			stack.push(derived);

			derived.f &= ~_client_constants__WEBPACK_IMPORTED_MODULE_1__.WAS_MARKED;
			destroy_derived_effects(derived);
			value = (0,_runtime_js__WEBPACK_IMPORTED_MODULE_2__.update_reaction)(derived);
		} finally {
			(0,_runtime_js__WEBPACK_IMPORTED_MODULE_2__.set_active_effect)(prev_active_effect);
			(0,_sources_js__WEBPACK_IMPORTED_MODULE_6__.set_eager_effects)(prev_eager_effects);
			stack.pop();
		}
	} else {
		try {
			derived.f &= ~_client_constants__WEBPACK_IMPORTED_MODULE_1__.WAS_MARKED;
			destroy_derived_effects(derived);
			value = (0,_runtime_js__WEBPACK_IMPORTED_MODULE_2__.update_reaction)(derived);
		} finally {
			(0,_runtime_js__WEBPACK_IMPORTED_MODULE_2__.set_active_effect)(prev_active_effect);
		}
	}

	return value;
}

/**
 * @param {Derived} derived
 * @returns {void}
 */
function update_derived(derived) {
	var value = execute_derived(derived);

	if (!derived.equals(value)) {
		// TODO can we avoid setting `derived.v` when `batch_values !== null`,
		// without causing the value to be stale later?
		derived.v = value;
		derived.wv = (0,_runtime_js__WEBPACK_IMPORTED_MODULE_2__.increment_write_version)();
	}

	// don't mark derived clean if we're reading it inside a
	// cleanup function, or it will cache a stale value
	if (_runtime_js__WEBPACK_IMPORTED_MODULE_2__.is_destroying_effect) {
		return;
	}

	// During time traveling we don't want to reset the status so that
	// traversal of the graph in the other batches still happens
	if (_batch_js__WEBPACK_IMPORTED_MODULE_11__.batch_values !== null) {
		// only cache the value if we're in a tracking context, otherwise we won't
		// clear the cache in `mark_reactions` when dependencies are updated
		if ((0,_effects_js__WEBPACK_IMPORTED_MODULE_5__.effect_tracking)()) {
			_batch_js__WEBPACK_IMPORTED_MODULE_11__.batch_values.set(derived, derived.v);
		}
	} else {
		var status = (derived.f & _client_constants__WEBPACK_IMPORTED_MODULE_1__.CONNECTED) === 0 ? _client_constants__WEBPACK_IMPORTED_MODULE_1__.MAYBE_DIRTY : _client_constants__WEBPACK_IMPORTED_MODULE_1__.CLEAN;
		(0,_runtime_js__WEBPACK_IMPORTED_MODULE_2__.set_signal_status)(derived, status);
	}
}


}),
7770: 
/*!***************************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/reactivity/effects.js ***!
  \***************************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  aborted: () => (aborted),
  async_effect: () => (async_effect),
  block: () => (block),
  branch: () => (branch),
  component_root: () => (component_root),
  create_user_effect: () => (create_user_effect),
  destroy_block_effect_children: () => (destroy_block_effect_children),
  destroy_effect: () => (destroy_effect),
  destroy_effect_children: () => (destroy_effect_children),
  eager_effect: () => (eager_effect),
  effect: () => (effect),
  effect_root: () => (effect_root),
  effect_tracking: () => (effect_tracking),
  execute_effect_teardown: () => (execute_effect_teardown),
  move_effect: () => (move_effect),
  pause_children: () => (pause_children),
  pause_effect: () => (pause_effect),
  remove_effect_dom: () => (remove_effect_dom),
  render_effect: () => (render_effect),
  resume_effect: () => (resume_effect),
  run_out_transitions: () => (run_out_transitions),
  teardown: () => (teardown),
  template_effect: () => (template_effect),
  unlink_effect: () => (unlink_effect),
  user_effect: () => (user_effect),
  user_pre_effect: () => (user_pre_effect),
  validate_effect: () => (validate_effect)
});
/* import */var _runtime_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../runtime.js */ 5551);
/* import */var _client_constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! #client/constants */ 5818);
/* import */var _errors_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../errors.js */ 1152);
/* import */var esm_env__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! esm-env */ 3990);
/* import */var _shared_utils_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/utils.js */ 2060);
/* import */var _dom_operations_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../dom/operations.js */ 6756);
/* import */var _context_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../context.js */ 2204);
/* import */var _batch_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./batch.js */ 5812);
/* import */var _async_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./async.js */ 8771);
/* import */var _dom_elements_bindings_shared_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../dom/elements/bindings/shared.js */ 6766);
/** @import { ComponentContext, ComponentContextLegacy, Derived, Effect, TemplateNode, TransitionManager } from '#client' */











/**
 * @param {'$effect' | '$effect.pre' | '$inspect'} rune
 */
function validate_effect(rune) {
	if (_runtime_js__WEBPACK_IMPORTED_MODULE_0__.active_effect === null) {
		if (_runtime_js__WEBPACK_IMPORTED_MODULE_0__.active_reaction === null) {
			_errors_js__WEBPACK_IMPORTED_MODULE_2__.effect_orphan(rune);
		}

		_errors_js__WEBPACK_IMPORTED_MODULE_2__.effect_in_unowned_derived();
	}

	if (_runtime_js__WEBPACK_IMPORTED_MODULE_0__.is_destroying_effect) {
		_errors_js__WEBPACK_IMPORTED_MODULE_2__.effect_in_teardown(rune);
	}
}

/**
 * @param {Effect} effect
 * @param {Effect} parent_effect
 */
function push_effect(effect, parent_effect) {
	var parent_last = parent_effect.last;
	if (parent_last === null) {
		parent_effect.last = parent_effect.first = effect;
	} else {
		parent_last.next = effect;
		effect.prev = parent_last;
		parent_effect.last = effect;
	}
}

/**
 * @param {number} type
 * @param {null | (() => void | (() => void))} fn
 * @param {boolean} sync
 * @returns {Effect}
 */
function create_effect(type, fn, sync) {
	var parent = _runtime_js__WEBPACK_IMPORTED_MODULE_0__.active_effect;

	if (esm_env__WEBPACK_IMPORTED_MODULE_3__.DEV) {
		// Ensure the parent is never an inspect effect
		while (parent !== null && (parent.f & _client_constants__WEBPACK_IMPORTED_MODULE_1__.EAGER_EFFECT) !== 0) {
			parent = parent.parent;
		}
	}

	if (parent !== null && (parent.f & _client_constants__WEBPACK_IMPORTED_MODULE_1__.INERT) !== 0) {
		type |= _client_constants__WEBPACK_IMPORTED_MODULE_1__.INERT;
	}

	/** @type {Effect} */
	var effect = {
		ctx: _context_js__WEBPACK_IMPORTED_MODULE_6__.component_context,
		deps: null,
		nodes_start: null,
		nodes_end: null,
		f: type | _client_constants__WEBPACK_IMPORTED_MODULE_1__.DIRTY | _client_constants__WEBPACK_IMPORTED_MODULE_1__.CONNECTED,
		first: null,
		fn,
		last: null,
		next: null,
		parent,
		b: parent && parent.b,
		prev: null,
		teardown: null,
		transitions: null,
		wv: 0,
		ac: null
	};

	if (esm_env__WEBPACK_IMPORTED_MODULE_3__.DEV) {
		effect.component_function = _context_js__WEBPACK_IMPORTED_MODULE_6__.dev_current_component_function;
	}

	if (sync) {
		try {
			(0,_runtime_js__WEBPACK_IMPORTED_MODULE_0__.update_effect)(effect);
			effect.f |= _client_constants__WEBPACK_IMPORTED_MODULE_1__.EFFECT_RAN;
		} catch (e) {
			destroy_effect(effect);
			throw e;
		}
	} else if (fn !== null) {
		(0,_batch_js__WEBPACK_IMPORTED_MODULE_7__.schedule_effect)(effect);
	}

	/** @type {Effect | null} */
	var e = effect;

	// if an effect has already ran and doesn't need to be kept in the tree
	// (because it won't re-run, has no DOM, and has no teardown etc)
	// then we skip it and go to its child (if any)
	if (
		sync &&
		e.deps === null &&
		e.teardown === null &&
		e.nodes_start === null &&
		e.first === e.last && // either `null`, or a singular child
		(e.f & _client_constants__WEBPACK_IMPORTED_MODULE_1__.EFFECT_PRESERVED) === 0
	) {
		e = e.first;
		if ((type & _client_constants__WEBPACK_IMPORTED_MODULE_1__.BLOCK_EFFECT) !== 0 && (type & _client_constants__WEBPACK_IMPORTED_MODULE_1__.EFFECT_TRANSPARENT) !== 0 && e !== null) {
			e.f |= _client_constants__WEBPACK_IMPORTED_MODULE_1__.EFFECT_TRANSPARENT;
		}
	}

	if (e !== null) {
		e.parent = parent;

		if (parent !== null) {
			push_effect(e, parent);
		}

		// if we're in a derived, add the effect there too
		if (
			_runtime_js__WEBPACK_IMPORTED_MODULE_0__.active_reaction !== null &&
			(_runtime_js__WEBPACK_IMPORTED_MODULE_0__.active_reaction.f & _client_constants__WEBPACK_IMPORTED_MODULE_1__.DERIVED) !== 0 &&
			(type & _client_constants__WEBPACK_IMPORTED_MODULE_1__.ROOT_EFFECT) === 0
		) {
			var derived = /** @type {Derived} */ (_runtime_js__WEBPACK_IMPORTED_MODULE_0__.active_reaction);
			(derived.effects ??= []).push(e);
		}
	}

	return effect;
}

/**
 * Internal representation of `$effect.tracking()`
 * @returns {boolean}
 */
function effect_tracking() {
	return _runtime_js__WEBPACK_IMPORTED_MODULE_0__.active_reaction !== null && !_runtime_js__WEBPACK_IMPORTED_MODULE_0__.untracking;
}

/**
 * @param {() => void} fn
 */
function teardown(fn) {
	const effect = create_effect(_client_constants__WEBPACK_IMPORTED_MODULE_1__.RENDER_EFFECT, null, false);
	(0,_runtime_js__WEBPACK_IMPORTED_MODULE_0__.set_signal_status)(effect, _client_constants__WEBPACK_IMPORTED_MODULE_1__.CLEAN);
	effect.teardown = fn;
	return effect;
}

/**
 * Internal representation of `$effect(...)`
 * @param {() => void | (() => void)} fn
 */
function user_effect(fn) {
	validate_effect('$effect');

	if (esm_env__WEBPACK_IMPORTED_MODULE_3__.DEV) {
		(0,_shared_utils_js__WEBPACK_IMPORTED_MODULE_4__.define_property)(fn, 'name', {
			value: '$effect'
		});
	}

	// Non-nested `$effect(...)` in a component should be deferred
	// until the component is mounted
	var flags = /** @type {Effect} */ _runtime_js__WEBPACK_IMPORTED_MODULE_0__.active_effect.f;
	var defer = !_runtime_js__WEBPACK_IMPORTED_MODULE_0__.active_reaction && (flags & _client_constants__WEBPACK_IMPORTED_MODULE_1__.BRANCH_EFFECT) !== 0 && (flags & _client_constants__WEBPACK_IMPORTED_MODULE_1__.EFFECT_RAN) === 0;

	if (defer) {
		// Top-level `$effect(...)` in an unmounted component — defer until mount
		var context = /** @type {ComponentContext} */ (_context_js__WEBPACK_IMPORTED_MODULE_6__.component_context);
		(context.e ??= []).push(fn);
	} else {
		// Everything else — create immediately
		return create_user_effect(fn);
	}
}

/**
 * @param {() => void | (() => void)} fn
 */
function create_user_effect(fn) {
	return create_effect(_client_constants__WEBPACK_IMPORTED_MODULE_1__.EFFECT | _client_constants__WEBPACK_IMPORTED_MODULE_1__.USER_EFFECT, fn, false);
}

/**
 * Internal representation of `$effect.pre(...)`
 * @param {() => void | (() => void)} fn
 * @returns {Effect}
 */
function user_pre_effect(fn) {
	validate_effect('$effect.pre');
	if (esm_env__WEBPACK_IMPORTED_MODULE_3__.DEV) {
		(0,_shared_utils_js__WEBPACK_IMPORTED_MODULE_4__.define_property)(fn, 'name', {
			value: '$effect.pre'
		});
	}
	return create_effect(_client_constants__WEBPACK_IMPORTED_MODULE_1__.RENDER_EFFECT | _client_constants__WEBPACK_IMPORTED_MODULE_1__.USER_EFFECT, fn, true);
}

/** @param {() => void | (() => void)} fn */
function eager_effect(fn) {
	return create_effect(_client_constants__WEBPACK_IMPORTED_MODULE_1__.EAGER_EFFECT, fn, true);
}

/**
 * Internal representation of `$effect.root(...)`
 * @param {() => void | (() => void)} fn
 * @returns {() => void}
 */
function effect_root(fn) {
	_batch_js__WEBPACK_IMPORTED_MODULE_7__.Batch.ensure();
	const effect = create_effect(_client_constants__WEBPACK_IMPORTED_MODULE_1__.ROOT_EFFECT | _client_constants__WEBPACK_IMPORTED_MODULE_1__.EFFECT_PRESERVED, fn, true);

	return () => {
		destroy_effect(effect);
	};
}

/**
 * An effect root whose children can transition out
 * @param {() => void} fn
 * @returns {(options?: { outro?: boolean }) => Promise<void>}
 */
function component_root(fn) {
	_batch_js__WEBPACK_IMPORTED_MODULE_7__.Batch.ensure();
	const effect = create_effect(_client_constants__WEBPACK_IMPORTED_MODULE_1__.ROOT_EFFECT | _client_constants__WEBPACK_IMPORTED_MODULE_1__.EFFECT_PRESERVED, fn, true);

	return (options = {}) => {
		return new Promise((fulfil) => {
			if (options.outro) {
				pause_effect(effect, () => {
					destroy_effect(effect);
					fulfil(undefined);
				});
			} else {
				destroy_effect(effect);
				fulfil(undefined);
			}
		});
	};
}

/**
 * @param {() => void | (() => void)} fn
 * @returns {Effect}
 */
function effect(fn) {
	return create_effect(_client_constants__WEBPACK_IMPORTED_MODULE_1__.EFFECT, fn, false);
}

/**
 * Internal representation of `$: ..`
 * @param {() => any} deps
 * @param {() => void | (() => void)} fn
 */
function legacy_pre_effect(deps, fn) {
	var context = /** @type {ComponentContextLegacy} */ (_context_js__WEBPACK_IMPORTED_MODULE_6__.component_context);

	/** @type {{ effect: null | Effect, ran: boolean, deps: () => any }} */
	var token = { effect: null, ran: false, deps };

	context.l.$.push(token);

	token.effect = render_effect(() => {
		deps();

		// If this legacy pre effect has already run before the end of the reset, then
		// bail out to emulate the same behavior.
		if (token.ran) return;

		token.ran = true;
		(0,_runtime_js__WEBPACK_IMPORTED_MODULE_0__.untrack)(fn);
	});
}

function legacy_pre_effect_reset() {
	var context = /** @type {ComponentContextLegacy} */ (_context_js__WEBPACK_IMPORTED_MODULE_6__.component_context);

	render_effect(() => {
		// Run dirty `$:` statements
		for (var token of context.l.$) {
			token.deps();

			var effect = token.effect;

			// If the effect is CLEAN, then make it MAYBE_DIRTY. This ensures we traverse through
			// the effects dependencies and correctly ensure each dependency is up-to-date.
			if ((effect.f & _client_constants__WEBPACK_IMPORTED_MODULE_1__.CLEAN) !== 0) {
				(0,_runtime_js__WEBPACK_IMPORTED_MODULE_0__.set_signal_status)(effect, _client_constants__WEBPACK_IMPORTED_MODULE_1__.MAYBE_DIRTY);
			}

			if ((0,_runtime_js__WEBPACK_IMPORTED_MODULE_0__.is_dirty)(effect)) {
				(0,_runtime_js__WEBPACK_IMPORTED_MODULE_0__.update_effect)(effect);
			}

			token.ran = false;
		}
	});
}

/**
 * @param {() => void | (() => void)} fn
 * @returns {Effect}
 */
function async_effect(fn) {
	return create_effect(_client_constants__WEBPACK_IMPORTED_MODULE_1__.ASYNC | _client_constants__WEBPACK_IMPORTED_MODULE_1__.EFFECT_PRESERVED, fn, true);
}

/**
 * @param {() => void | (() => void)} fn
 * @returns {Effect}
 */
function render_effect(fn, flags = 0) {
	return create_effect(_client_constants__WEBPACK_IMPORTED_MODULE_1__.RENDER_EFFECT | flags, fn, true);
}

/**
 * @param {(...expressions: any) => void | (() => void)} fn
 * @param {Array<() => any>} sync
 * @param {Array<() => Promise<any>>} async
 * @param {Array<Promise<void>>} blockers
 */
function template_effect(fn, sync = [], async = [], blockers = []) {
	(0,_async_js__WEBPACK_IMPORTED_MODULE_8__.flatten)(blockers, sync, async, (values) => {
		create_effect(_client_constants__WEBPACK_IMPORTED_MODULE_1__.RENDER_EFFECT, () => fn(...values.map(_runtime_js__WEBPACK_IMPORTED_MODULE_0__.get)), true);
	});
}

/**
 * Like `template_effect`, but with an effect which is deferred until the batch commits
 * @param {(...expressions: any) => void | (() => void)} fn
 * @param {Array<() => any>} sync
 * @param {Array<() => Promise<any>>} async
 * @param {Array<Promise<void>>} blockers
 */
function deferred_template_effect(fn, sync = [], async = [], blockers = []) {
	var batch = /** @type {Batch} */ (_batch_js__WEBPACK_IMPORTED_MODULE_7__.current_batch);
	var is_async = async.length > 0 || blockers.length > 0;

	if (is_async) batch.increment(true);

	(0,_async_js__WEBPACK_IMPORTED_MODULE_8__.flatten)(blockers, sync, async, (values) => {
		create_effect(_client_constants__WEBPACK_IMPORTED_MODULE_1__.EFFECT, () => fn(...values.map(_runtime_js__WEBPACK_IMPORTED_MODULE_0__.get)), false);
		if (is_async) batch.decrement(true);
	});
}

/**
 * @param {(() => void)} fn
 * @param {number} flags
 */
function block(fn, flags = 0) {
	var effect = create_effect(_client_constants__WEBPACK_IMPORTED_MODULE_1__.BLOCK_EFFECT | flags, fn, true);
	if (esm_env__WEBPACK_IMPORTED_MODULE_3__.DEV) {
		effect.dev_stack = _context_js__WEBPACK_IMPORTED_MODULE_6__.dev_stack;
	}
	return effect;
}

/**
 * @param {(() => void)} fn
 */
function branch(fn) {
	return create_effect(_client_constants__WEBPACK_IMPORTED_MODULE_1__.BRANCH_EFFECT | _client_constants__WEBPACK_IMPORTED_MODULE_1__.EFFECT_PRESERVED, fn, true);
}

/**
 * @param {Effect} effect
 */
function execute_effect_teardown(effect) {
	var teardown = effect.teardown;
	if (teardown !== null) {
		const previously_destroying_effect = _runtime_js__WEBPACK_IMPORTED_MODULE_0__.is_destroying_effect;
		const previous_reaction = _runtime_js__WEBPACK_IMPORTED_MODULE_0__.active_reaction;
		(0,_runtime_js__WEBPACK_IMPORTED_MODULE_0__.set_is_destroying_effect)(true);
		(0,_runtime_js__WEBPACK_IMPORTED_MODULE_0__.set_active_reaction)(null);
		try {
			teardown.call(null);
		} finally {
			(0,_runtime_js__WEBPACK_IMPORTED_MODULE_0__.set_is_destroying_effect)(previously_destroying_effect);
			(0,_runtime_js__WEBPACK_IMPORTED_MODULE_0__.set_active_reaction)(previous_reaction);
		}
	}
}

/**
 * @param {Effect} signal
 * @param {boolean} remove_dom
 * @returns {void}
 */
function destroy_effect_children(signal, remove_dom = false) {
	var effect = signal.first;
	signal.first = signal.last = null;

	while (effect !== null) {
		const controller = effect.ac;

		if (controller !== null) {
			(0,_dom_elements_bindings_shared_js__WEBPACK_IMPORTED_MODULE_9__.without_reactive_context)(() => {
				controller.abort(_client_constants__WEBPACK_IMPORTED_MODULE_1__.STALE_REACTION);
			});
		}

		var next = effect.next;

		if ((effect.f & _client_constants__WEBPACK_IMPORTED_MODULE_1__.ROOT_EFFECT) !== 0) {
			// this is now an independent root
			effect.parent = null;
		} else {
			destroy_effect(effect, remove_dom);
		}

		effect = next;
	}
}

/**
 * @param {Effect} signal
 * @returns {void}
 */
function destroy_block_effect_children(signal) {
	var effect = signal.first;

	while (effect !== null) {
		var next = effect.next;
		if ((effect.f & _client_constants__WEBPACK_IMPORTED_MODULE_1__.BRANCH_EFFECT) === 0) {
			destroy_effect(effect);
		}
		effect = next;
	}
}

/**
 * @param {Effect} effect
 * @param {boolean} [remove_dom]
 * @returns {void}
 */
function destroy_effect(effect, remove_dom = true) {
	var removed = false;

	if (
		(remove_dom || (effect.f & _client_constants__WEBPACK_IMPORTED_MODULE_1__.HEAD_EFFECT) !== 0) &&
		effect.nodes_start !== null &&
		effect.nodes_end !== null
	) {
		remove_effect_dom(effect.nodes_start, /** @type {TemplateNode} */ (effect.nodes_end));
		removed = true;
	}

	destroy_effect_children(effect, remove_dom && !removed);
	(0,_runtime_js__WEBPACK_IMPORTED_MODULE_0__.remove_reactions)(effect, 0);
	(0,_runtime_js__WEBPACK_IMPORTED_MODULE_0__.set_signal_status)(effect, _client_constants__WEBPACK_IMPORTED_MODULE_1__.DESTROYED);

	var transitions = effect.transitions;

	if (transitions !== null) {
		for (const transition of transitions) {
			transition.stop();
		}
	}

	execute_effect_teardown(effect);

	var parent = effect.parent;

	// If the parent doesn't have any children, then skip this work altogether
	if (parent !== null && parent.first !== null) {
		unlink_effect(effect);
	}

	if (esm_env__WEBPACK_IMPORTED_MODULE_3__.DEV) {
		effect.component_function = null;
	}

	// `first` and `child` are nulled out in destroy_effect_children
	// we don't null out `parent` so that error propagation can work correctly
	effect.next =
		effect.prev =
		effect.teardown =
		effect.ctx =
		effect.deps =
		effect.fn =
		effect.nodes_start =
		effect.nodes_end =
		effect.ac =
			null;
}

/**
 *
 * @param {TemplateNode | null} node
 * @param {TemplateNode} end
 */
function remove_effect_dom(node, end) {
	while (node !== null) {
		/** @type {TemplateNode | null} */
		var next = node === end ? null : /** @type {TemplateNode} */ ((0,_dom_operations_js__WEBPACK_IMPORTED_MODULE_5__.get_next_sibling)(node));

		node.remove();
		node = next;
	}
}

/**
 * Detach an effect from the effect tree, freeing up memory and
 * reducing the amount of work that happens on subsequent traversals
 * @param {Effect} effect
 */
function unlink_effect(effect) {
	var parent = effect.parent;
	var prev = effect.prev;
	var next = effect.next;

	if (prev !== null) prev.next = next;
	if (next !== null) next.prev = prev;

	if (parent !== null) {
		if (parent.first === effect) parent.first = next;
		if (parent.last === effect) parent.last = prev;
	}
}

/**
 * When a block effect is removed, we don't immediately destroy it or yank it
 * out of the DOM, because it might have transitions. Instead, we 'pause' it.
 * It stays around (in memory, and in the DOM) until outro transitions have
 * completed, and if the state change is reversed then we _resume_ it.
 * A paused effect does not update, and the DOM subtree becomes inert.
 * @param {Effect} effect
 * @param {() => void} [callback]
 * @param {boolean} [destroy]
 */
function pause_effect(effect, callback, destroy = true) {
	/** @type {TransitionManager[]} */
	var transitions = [];

	pause_children(effect, transitions, true);

	run_out_transitions(transitions, () => {
		if (destroy) destroy_effect(effect);
		if (callback) callback();
	});
}

/**
 * @param {TransitionManager[]} transitions
 * @param {() => void} fn
 */
function run_out_transitions(transitions, fn) {
	var remaining = transitions.length;
	if (remaining > 0) {
		var check = () => --remaining || fn();
		for (var transition of transitions) {
			transition.out(check);
		}
	} else {
		fn();
	}
}

/**
 * @param {Effect} effect
 * @param {TransitionManager[]} transitions
 * @param {boolean} local
 */
function pause_children(effect, transitions, local) {
	if ((effect.f & _client_constants__WEBPACK_IMPORTED_MODULE_1__.INERT) !== 0) return;
	effect.f ^= _client_constants__WEBPACK_IMPORTED_MODULE_1__.INERT;

	if (effect.transitions !== null) {
		for (const transition of effect.transitions) {
			if (transition.is_global || local) {
				transitions.push(transition);
			}
		}
	}

	var child = effect.first;

	while (child !== null) {
		var sibling = child.next;
		var transparent =
			(child.f & _client_constants__WEBPACK_IMPORTED_MODULE_1__.EFFECT_TRANSPARENT) !== 0 ||
			// If this is a branch effect without a block effect parent,
			// it means the parent block effect was pruned. In that case,
			// transparency information was transferred to the branch effect.
			((child.f & _client_constants__WEBPACK_IMPORTED_MODULE_1__.BRANCH_EFFECT) !== 0 && (effect.f & _client_constants__WEBPACK_IMPORTED_MODULE_1__.BLOCK_EFFECT) !== 0);
		// TODO we don't need to call pause_children recursively with a linked list in place
		// it's slightly more involved though as we have to account for `transparent` changing
		// through the tree.
		pause_children(child, transitions, transparent ? local : false);
		child = sibling;
	}
}

/**
 * The opposite of `pause_effect`. We call this if (for example)
 * `x` becomes falsy then truthy: `{#if x}...{/if}`
 * @param {Effect} effect
 */
function resume_effect(effect) {
	resume_children(effect, true);
}

/**
 * @param {Effect} effect
 * @param {boolean} local
 */
function resume_children(effect, local) {
	if ((effect.f & _client_constants__WEBPACK_IMPORTED_MODULE_1__.INERT) === 0) return;
	effect.f ^= _client_constants__WEBPACK_IMPORTED_MODULE_1__.INERT;

	// If a dependency of this effect changed while it was paused,
	// schedule the effect to update. we don't use `is_dirty`
	// here because we don't want to eagerly recompute a derived like
	// `{#if foo}{foo.bar()}{/if}` if `foo` is now `undefined
	if ((effect.f & _client_constants__WEBPACK_IMPORTED_MODULE_1__.CLEAN) === 0) {
		(0,_runtime_js__WEBPACK_IMPORTED_MODULE_0__.set_signal_status)(effect, _client_constants__WEBPACK_IMPORTED_MODULE_1__.DIRTY);
		(0,_batch_js__WEBPACK_IMPORTED_MODULE_7__.schedule_effect)(effect);
	}

	var child = effect.first;

	while (child !== null) {
		var sibling = child.next;
		var transparent = (child.f & _client_constants__WEBPACK_IMPORTED_MODULE_1__.EFFECT_TRANSPARENT) !== 0 || (child.f & _client_constants__WEBPACK_IMPORTED_MODULE_1__.BRANCH_EFFECT) !== 0;
		// TODO we don't need to call resume_children recursively with a linked list in place
		// it's slightly more involved though as we have to account for `transparent` changing
		// through the tree.
		resume_children(child, transparent ? local : false);
		child = sibling;
	}

	if (effect.transitions !== null) {
		for (const transition of effect.transitions) {
			if (transition.is_global || local) {
				transition.in();
			}
		}
	}
}

function aborted(effect = /** @type {Effect} */ (_runtime_js__WEBPACK_IMPORTED_MODULE_0__.active_effect)) {
	return (effect.f & _client_constants__WEBPACK_IMPORTED_MODULE_1__.DESTROYED) !== 0;
}

/**
 * @param {Effect} effect
 * @param {DocumentFragment} fragment
 */
function move_effect(effect, fragment) {
	var node = effect.nodes_start;
	var end = effect.nodes_end;

	while (node !== null) {
		/** @type {TemplateNode | null} */
		var next = node === end ? null : /** @type {TemplateNode} */ ((0,_dom_operations_js__WEBPACK_IMPORTED_MODULE_5__.get_next_sibling)(node));

		fragment.append(node);
		node = next;
	}
}


}),
7566: 
/*!****************************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/reactivity/equality.js ***!
  \****************************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  equals: () => (equals),
  safe_equals: () => (safe_equals),
  safe_not_equal: () => (safe_not_equal)
});
/** @import { Equals } from '#client' */

/** @type {Equals} */
function equals(value) {
	return value === this.v;
}

/**
 * @param {unknown} a
 * @param {unknown} b
 * @returns {boolean}
 */
function safe_not_equal(a, b) {
	return a != a
		? b == b
		: a !== b || (a !== null && typeof a === 'object') || typeof a === 'function';
}

/**
 * @param {unknown} a
 * @param {unknown} b
 * @returns {boolean}
 */
function not_equal(a, b) {
	return a !== b;
}

/** @type {Equals} */
function safe_equals(value) {
	return !safe_not_equal(value, this.v);
}


}),
6718: 
/*!***************************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/reactivity/sources.js ***!
  \***************************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  eager_effects: () => (eager_effects),
  flush_eager_effects: () => (flush_eager_effects),
  increment: () => (increment),
  internal_set: () => (internal_set),
  mutable_source: () => (mutable_source),
  old_values: () => (old_values),
  set: () => (set),
  set_eager_effects: () => (set_eager_effects),
  set_eager_effects_deferred: () => (set_eager_effects_deferred),
  source: () => (source),
  state: () => (state),
  update: () => (update)
});
/* import */var esm_env__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! esm-env */ 3990);
/* import */var _runtime_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../runtime.js */ 5551);
/* import */var _equality_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./equality.js */ 7566);
/* import */var _client_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! #client/constants */ 5818);
/* import */var _errors_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../errors.js */ 1152);
/* import */var _flags_index_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../flags/index.js */ 9987);
/* import */var _dev_tracing_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../dev/tracing.js */ 6265);
/* import */var _context_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../context.js */ 2204);
/* import */var _batch_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./batch.js */ 5812);
/* import */var _proxy_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../proxy.js */ 4899);
/* import */var _deriveds_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./deriveds.js */ 6064);
/** @import { Derived, Effect, Source, Value } from '#client' */












/** @type {Set<any>} */
let eager_effects = new Set();

/** @type {Map<Source, any>} */
const old_values = new Map();

/**
 * @param {Set<any>} v
 */
function set_eager_effects(v) {
	eager_effects = v;
}

let eager_effects_deferred = false;

function set_eager_effects_deferred() {
	eager_effects_deferred = true;
}

/**
 * @template V
 * @param {V} v
 * @param {Error | null} [stack]
 * @returns {Source<V>}
 */
// TODO rename this to `state` throughout the codebase
function source(v, stack) {
	/** @type {Value} */
	var signal = {
		f: 0, // TODO ideally we could skip this altogether, but it causes type errors
		v,
		reactions: null,
		equals: _equality_js__WEBPACK_IMPORTED_MODULE_9__.equals,
		rv: 0,
		wv: 0
	};

	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV && _flags_index_js__WEBPACK_IMPORTED_MODULE_10__.tracing_mode_flag) {
		signal.created = stack ?? (0,_dev_tracing_js__WEBPACK_IMPORTED_MODULE_4__.get_stack)('created at');
		signal.updated = null;
		signal.set_during_effect = false;
		signal.trace = null;
	}

	return signal;
}

/**
 * @template V
 * @param {V} v
 * @param {Error | null} [stack]
 */
/*#__NO_SIDE_EFFECTS__*/
function state(v, stack) {
	const s = source(v, stack);

	(0,_runtime_js__WEBPACK_IMPORTED_MODULE_1__.push_reaction_value)(s);

	return s;
}

/**
 * @template V
 * @param {V} initial_value
 * @param {boolean} [immutable]
 * @returns {Source<V>}
 */
/*#__NO_SIDE_EFFECTS__*/
function mutable_source(initial_value, immutable = false, trackable = true) {
	const s = source(initial_value);
	if (!immutable) {
		s.equals = _equality_js__WEBPACK_IMPORTED_MODULE_9__.safe_equals;
	}

	// bind the signal to the component context, in case we need to
	// track updates to trigger beforeUpdate/afterUpdate callbacks
	if (_flags_index_js__WEBPACK_IMPORTED_MODULE_10__.legacy_mode_flag && trackable && _context_js__WEBPACK_IMPORTED_MODULE_5__.component_context !== null && _context_js__WEBPACK_IMPORTED_MODULE_5__.component_context.l !== null) {
		(_context_js__WEBPACK_IMPORTED_MODULE_5__.component_context.l.s ??= []).push(s);
	}

	return s;
}

/**
 * @template V
 * @param {Value<V>} source
 * @param {V} value
 */
function mutate(source, value) {
	set(
		source,
		(0,_runtime_js__WEBPACK_IMPORTED_MODULE_1__.untrack)(() => (0,_runtime_js__WEBPACK_IMPORTED_MODULE_1__.get)(source))
	);
	return value;
}

/**
 * @template V
 * @param {Source<V>} source
 * @param {V} value
 * @param {boolean} [should_proxy]
 * @returns {V}
 */
function set(source, value, should_proxy = false) {
	if (
		_runtime_js__WEBPACK_IMPORTED_MODULE_1__.active_reaction !== null &&
		// since we are untracking the function inside `$inspect.with` we need to add this check
		// to ensure we error if state is set inside an inspect effect
		(!_runtime_js__WEBPACK_IMPORTED_MODULE_1__.untracking || (_runtime_js__WEBPACK_IMPORTED_MODULE_1__.active_reaction.f & _client_constants__WEBPACK_IMPORTED_MODULE_2__.EAGER_EFFECT) !== 0) &&
		(0,_context_js__WEBPACK_IMPORTED_MODULE_5__.is_runes)() &&
		(_runtime_js__WEBPACK_IMPORTED_MODULE_1__.active_reaction.f & (_client_constants__WEBPACK_IMPORTED_MODULE_2__.DERIVED | _client_constants__WEBPACK_IMPORTED_MODULE_2__.BLOCK_EFFECT | _client_constants__WEBPACK_IMPORTED_MODULE_2__.ASYNC | _client_constants__WEBPACK_IMPORTED_MODULE_2__.EAGER_EFFECT)) !== 0 &&
		!_runtime_js__WEBPACK_IMPORTED_MODULE_1__.current_sources?.includes(source)
	) {
		_errors_js__WEBPACK_IMPORTED_MODULE_3__.state_unsafe_mutation();
	}

	let new_value = should_proxy ? (0,_proxy_js__WEBPACK_IMPORTED_MODULE_7__.proxy)(value) : value;

	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		(0,_dev_tracing_js__WEBPACK_IMPORTED_MODULE_4__.tag_proxy)(new_value, /** @type {string} */ (source.label));
	}

	return internal_set(source, new_value);
}

/**
 * @template V
 * @param {Source<V>} source
 * @param {V} value
 * @returns {V}
 */
function internal_set(source, value) {
	if (!source.equals(value)) {
		var old_value = source.v;

		if (_runtime_js__WEBPACK_IMPORTED_MODULE_1__.is_destroying_effect) {
			old_values.set(source, value);
		} else {
			old_values.set(source, old_value);
		}

		source.v = value;

		var batch = _batch_js__WEBPACK_IMPORTED_MODULE_6__.Batch.ensure();
		batch.capture(source, old_value);

		if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
			if (_flags_index_js__WEBPACK_IMPORTED_MODULE_10__.tracing_mode_flag || _runtime_js__WEBPACK_IMPORTED_MODULE_1__.active_effect !== null) {
				const error = (0,_dev_tracing_js__WEBPACK_IMPORTED_MODULE_4__.get_stack)('updated at');

				if (error !== null) {
					source.updated ??= new Map();
					let entry = source.updated.get(error.stack);

					if (!entry) {
						entry = { error, count: 0 };
						source.updated.set(error.stack, entry);
					}

					entry.count++;
				}
			}

			if (_runtime_js__WEBPACK_IMPORTED_MODULE_1__.active_effect !== null) {
				source.set_during_effect = true;
			}
		}

		if ((source.f & _client_constants__WEBPACK_IMPORTED_MODULE_2__.DERIVED) !== 0) {
			// if we are assigning to a dirty derived we set it to clean/maybe dirty but we also eagerly execute it to track the dependencies
			if ((source.f & _client_constants__WEBPACK_IMPORTED_MODULE_2__.DIRTY) !== 0) {
				(0,_deriveds_js__WEBPACK_IMPORTED_MODULE_8__.execute_derived)(/** @type {Derived} */ (source));
			}

			(0,_runtime_js__WEBPACK_IMPORTED_MODULE_1__.set_signal_status)(source, (source.f & _client_constants__WEBPACK_IMPORTED_MODULE_2__.CONNECTED) !== 0 ? _client_constants__WEBPACK_IMPORTED_MODULE_2__.CLEAN : _client_constants__WEBPACK_IMPORTED_MODULE_2__.MAYBE_DIRTY);
		}

		source.wv = (0,_runtime_js__WEBPACK_IMPORTED_MODULE_1__.increment_write_version)();

		mark_reactions(source, _client_constants__WEBPACK_IMPORTED_MODULE_2__.DIRTY);

		// It's possible that the current reaction might not have up-to-date dependencies
		// whilst it's actively running. So in the case of ensuring it registers the reaction
		// properly for itself, we need to ensure the current effect actually gets
		// scheduled. i.e: `$effect(() => x++)`
		if (
			(0,_context_js__WEBPACK_IMPORTED_MODULE_5__.is_runes)() &&
			_runtime_js__WEBPACK_IMPORTED_MODULE_1__.active_effect !== null &&
			(_runtime_js__WEBPACK_IMPORTED_MODULE_1__.active_effect.f & _client_constants__WEBPACK_IMPORTED_MODULE_2__.CLEAN) !== 0 &&
			(_runtime_js__WEBPACK_IMPORTED_MODULE_1__.active_effect.f & (_client_constants__WEBPACK_IMPORTED_MODULE_2__.BRANCH_EFFECT | _client_constants__WEBPACK_IMPORTED_MODULE_2__.ROOT_EFFECT)) === 0
		) {
			if (_runtime_js__WEBPACK_IMPORTED_MODULE_1__.untracked_writes === null) {
				(0,_runtime_js__WEBPACK_IMPORTED_MODULE_1__.set_untracked_writes)([source]);
			} else {
				_runtime_js__WEBPACK_IMPORTED_MODULE_1__.untracked_writes.push(source);
			}
		}

		if (!batch.is_fork && eager_effects.size > 0 && !eager_effects_deferred) {
			flush_eager_effects();
		}
	}

	return value;
}

function flush_eager_effects() {
	eager_effects_deferred = false;

	const inspects = Array.from(eager_effects);

	for (const effect of inspects) {
		// Mark clean inspect-effects as maybe dirty and then check their dirtiness
		// instead of just updating the effects - this way we avoid overfiring.
		if ((effect.f & _client_constants__WEBPACK_IMPORTED_MODULE_2__.CLEAN) !== 0) {
			(0,_runtime_js__WEBPACK_IMPORTED_MODULE_1__.set_signal_status)(effect, _client_constants__WEBPACK_IMPORTED_MODULE_2__.MAYBE_DIRTY);
		}

		if ((0,_runtime_js__WEBPACK_IMPORTED_MODULE_1__.is_dirty)(effect)) {
			(0,_runtime_js__WEBPACK_IMPORTED_MODULE_1__.update_effect)(effect);
		}
	}

	eager_effects.clear();
}

/**
 * @template {number | bigint} T
 * @param {Source<T>} source
 * @param {1 | -1} [d]
 * @returns {T}
 */
function update(source, d = 1) {
	var value = (0,_runtime_js__WEBPACK_IMPORTED_MODULE_1__.get)(source);
	var result = d === 1 ? value++ : value--;

	set(source, value);

	// @ts-expect-error
	return result;
}

/**
 * @template {number | bigint} T
 * @param {Source<T>} source
 * @param {1 | -1} [d]
 * @returns {T}
 */
function update_pre(source, d = 1) {
	var value = (0,_runtime_js__WEBPACK_IMPORTED_MODULE_1__.get)(source);

	// @ts-expect-error
	return set(source, d === 1 ? ++value : --value);
}

/**
 * Silently (without using `get`) increment a source
 * @param {Source<number>} source
 */
function increment(source) {
	set(source, source.v + 1);
}

/**
 * @param {Value} signal
 * @param {number} status should be DIRTY or MAYBE_DIRTY
 * @returns {void}
 */
function mark_reactions(signal, status) {
	var reactions = signal.reactions;
	if (reactions === null) return;

	var runes = (0,_context_js__WEBPACK_IMPORTED_MODULE_5__.is_runes)();
	var length = reactions.length;

	for (var i = 0; i < length; i++) {
		var reaction = reactions[i];
		var flags = reaction.f;

		// In legacy mode, skip the current effect to prevent infinite loops
		if (!runes && reaction === _runtime_js__WEBPACK_IMPORTED_MODULE_1__.active_effect) continue;

		// Inspect effects need to run immediately, so that the stack trace makes sense
		if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV && (flags & _client_constants__WEBPACK_IMPORTED_MODULE_2__.EAGER_EFFECT) !== 0) {
			eager_effects.add(reaction);
			continue;
		}

		var not_dirty = (flags & _client_constants__WEBPACK_IMPORTED_MODULE_2__.DIRTY) === 0;

		// don't set a DIRTY reaction to MAYBE_DIRTY
		if (not_dirty) {
			(0,_runtime_js__WEBPACK_IMPORTED_MODULE_1__.set_signal_status)(reaction, status);
		}

		if ((flags & _client_constants__WEBPACK_IMPORTED_MODULE_2__.DERIVED) !== 0) {
			var derived = /** @type {Derived} */ (reaction);

			_batch_js__WEBPACK_IMPORTED_MODULE_6__.batch_values?.delete(derived);

			if ((flags & _client_constants__WEBPACK_IMPORTED_MODULE_2__.WAS_MARKED) === 0) {
				// Only connected deriveds can be reliably unmarked right away
				if (flags & _client_constants__WEBPACK_IMPORTED_MODULE_2__.CONNECTED) {
					reaction.f |= _client_constants__WEBPACK_IMPORTED_MODULE_2__.WAS_MARKED;
				}

				mark_reactions(derived, _client_constants__WEBPACK_IMPORTED_MODULE_2__.MAYBE_DIRTY);
			}
		} else if (not_dirty) {
			if ((flags & _client_constants__WEBPACK_IMPORTED_MODULE_2__.BLOCK_EFFECT) !== 0) {
				if (_batch_js__WEBPACK_IMPORTED_MODULE_6__.eager_block_effects !== null) {
					_batch_js__WEBPACK_IMPORTED_MODULE_6__.eager_block_effects.add(/** @type {Effect} */ (reaction));
				}
			}

			(0,_batch_js__WEBPACK_IMPORTED_MODULE_6__.schedule_effect)(/** @type {Effect} */ (reaction));
		}
	}
}


}),
5891: 
/*!***************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/render.js ***!
  \***************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  hydrate: () => (hydrate),
  mount: () => (mount),
  set_should_intro: () => (set_should_intro),
  should_intro: () => (should_intro),
  unmount: () => (unmount)
});
/* import */var esm_env__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! esm-env */ 3990);
/* import */var _dom_operations_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dom/operations.js */ 6756);
/* import */var _constants_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../constants.js */ 7164);
/* import */var _runtime_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./runtime.js */ 5551);
/* import */var _context_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./context.js */ 2204);
/* import */var _reactivity_effects_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./reactivity/effects.js */ 7770);
/* import */var _dom_hydration_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./dom/hydration.js */ 5742);
/* import */var _shared_utils_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../shared/utils.js */ 2060);
/* import */var _dom_elements_events_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./dom/elements/events.js */ 5311);
/* import */var _warnings_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./warnings.js */ 8658);
/* import */var _errors_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./errors.js */ 1152);
/* import */var _dom_template_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./dom/template.js */ 2752);
/* import */var _utils_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../utils.js */ 9264);
/* import */var _constants_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./constants.js */ 5818);
/* import */var _dom_blocks_boundary_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./dom/blocks/boundary.js */ 9478);
/** @import { ComponentContext, Effect, TemplateNode } from '#client' */
/** @import { Component, ComponentType, SvelteComponent, MountOptions } from '../../index.js' */
















/**
 * This is normally true — block effects should run their intro transitions —
 * but is false during hydration (unless `options.intro` is `true`) and
 * when creating the children of a `<svelte:element>` that just changed tag
 */
let should_intro = true;

/** @param {boolean} value */
function set_should_intro(value) {
	should_intro = value;
}

/**
 * @param {Element} text
 * @param {string} value
 * @returns {void}
 */
function set_text(text, value) {
	// For objects, we apply string coercion (which might make things like $state array references in the template reactive) before diffing
	var str = value == null ? '' : typeof value === 'object' ? value + '' : value;
	// @ts-expect-error
	if (str !== (text.__t ??= text.nodeValue)) {
		// @ts-expect-error
		text.__t = str;
		text.nodeValue = str + '';
	}
}

/**
 * Mounts a component to the given target and returns the exports and potentially the props (if compiled with `accessors: true`) of the component.
 * Transitions will play during the initial render unless the `intro` option is set to `false`.
 *
 * @template {Record<string, any>} Props
 * @template {Record<string, any>} Exports
 * @param {ComponentType<SvelteComponent<Props>> | Component<Props, Exports, any>} component
 * @param {MountOptions<Props>} options
 * @returns {Exports}
 */
function mount(component, options) {
	return _mount(component, options);
}

/**
 * Hydrates a component on the given target and returns the exports and potentially the props (if compiled with `accessors: true`) of the component
 *
 * @template {Record<string, any>} Props
 * @template {Record<string, any>} Exports
 * @param {ComponentType<SvelteComponent<Props>> | Component<Props, Exports, any>} component
 * @param {{} extends Props ? {
 * 		target: Document | Element | ShadowRoot;
 * 		props?: Props;
 * 		events?: Record<string, (e: any) => any>;
 *  	context?: Map<any, any>;
 * 		intro?: boolean;
 * 		recover?: boolean;
 * 	} : {
 * 		target: Document | Element | ShadowRoot;
 * 		props: Props;
 * 		events?: Record<string, (e: any) => any>;
 *  	context?: Map<any, any>;
 * 		intro?: boolean;
 * 		recover?: boolean;
 * 	}} options
 * @returns {Exports}
 */
function hydrate(component, options) {
	(0,_dom_operations_js__WEBPACK_IMPORTED_MODULE_1__.init_operations)();
	options.intro = options.intro ?? false;
	const target = options.target;
	const was_hydrating = _dom_hydration_js__WEBPACK_IMPORTED_MODULE_6__.hydrating;
	const previous_hydrate_node = _dom_hydration_js__WEBPACK_IMPORTED_MODULE_6__.hydrate_node;

	try {
		var anchor = /** @type {TemplateNode} */ ((0,_dom_operations_js__WEBPACK_IMPORTED_MODULE_1__.get_first_child)(target));
		while (
			anchor &&
			(anchor.nodeType !== _constants_js__WEBPACK_IMPORTED_MODULE_13__.COMMENT_NODE || /** @type {Comment} */ (anchor).data !== _constants_js__WEBPACK_IMPORTED_MODULE_2__.HYDRATION_START)
		) {
			anchor = /** @type {TemplateNode} */ ((0,_dom_operations_js__WEBPACK_IMPORTED_MODULE_1__.get_next_sibling)(anchor));
		}

		if (!anchor) {
			throw _constants_js__WEBPACK_IMPORTED_MODULE_2__.HYDRATION_ERROR;
		}

		(0,_dom_hydration_js__WEBPACK_IMPORTED_MODULE_6__.set_hydrating)(true);
		(0,_dom_hydration_js__WEBPACK_IMPORTED_MODULE_6__.set_hydrate_node)(/** @type {Comment} */ (anchor));

		const instance = _mount(component, { ...options, anchor });

		(0,_dom_hydration_js__WEBPACK_IMPORTED_MODULE_6__.set_hydrating)(false);

		return /**  @type {Exports} */ (instance);
	} catch (error) {
		// re-throw Svelte errors - they are certainly not related to hydration
		if (
			error instanceof Error &&
			error.message.split('\n').some((line) => line.startsWith('https://svelte.dev/e/'))
		) {
			throw error;
		}
		if (error !== _constants_js__WEBPACK_IMPORTED_MODULE_2__.HYDRATION_ERROR) {
			// eslint-disable-next-line no-console
			console.warn('Failed to hydrate: ', error);
		}

		if (options.recover === false) {
			_errors_js__WEBPACK_IMPORTED_MODULE_10__.hydration_failed();
		}

		// If an error occurred above, the operations might not yet have been initialised.
		(0,_dom_operations_js__WEBPACK_IMPORTED_MODULE_1__.init_operations)();
		(0,_dom_operations_js__WEBPACK_IMPORTED_MODULE_1__.clear_text_content)(target);

		(0,_dom_hydration_js__WEBPACK_IMPORTED_MODULE_6__.set_hydrating)(false);
		return mount(component, options);
	} finally {
		(0,_dom_hydration_js__WEBPACK_IMPORTED_MODULE_6__.set_hydrating)(was_hydrating);
		(0,_dom_hydration_js__WEBPACK_IMPORTED_MODULE_6__.set_hydrate_node)(previous_hydrate_node);
	}
}

/** @type {Map<string, number>} */
const document_listeners = new Map();

/**
 * @template {Record<string, any>} Exports
 * @param {ComponentType<SvelteComponent<any>> | Component<any>} Component
 * @param {MountOptions} options
 * @returns {Exports}
 */
function _mount(Component, { target, anchor, props = {}, events, context, intro = true }) {
	(0,_dom_operations_js__WEBPACK_IMPORTED_MODULE_1__.init_operations)();

	/** @type {Set<string>} */
	var registered_events = new Set();

	/** @param {Array<string>} events */
	var event_handle = (events) => {
		for (var i = 0; i < events.length; i++) {
			var event_name = events[i];

			if (registered_events.has(event_name)) continue;
			registered_events.add(event_name);

			var passive = (0,_utils_js__WEBPACK_IMPORTED_MODULE_12__.is_passive_event)(event_name);

			// Add the event listener to both the container and the document.
			// The container listener ensures we catch events from within in case
			// the outer content stops propagation of the event.
			target.addEventListener(event_name, _dom_elements_events_js__WEBPACK_IMPORTED_MODULE_8__.handle_event_propagation, { passive });

			var n = document_listeners.get(event_name);

			if (n === undefined) {
				// The document listener ensures we catch events that originate from elements that were
				// manually moved outside of the container (e.g. via manual portals).
				document.addEventListener(event_name, _dom_elements_events_js__WEBPACK_IMPORTED_MODULE_8__.handle_event_propagation, { passive });
				document_listeners.set(event_name, 1);
			} else {
				document_listeners.set(event_name, n + 1);
			}
		}
	};

	event_handle((0,_shared_utils_js__WEBPACK_IMPORTED_MODULE_7__.array_from)(_dom_elements_events_js__WEBPACK_IMPORTED_MODULE_8__.all_registered_events));
	_dom_elements_events_js__WEBPACK_IMPORTED_MODULE_8__.root_event_handles.add(event_handle);

	/** @type {Exports} */
	// @ts-expect-error will be defined because the render effect runs synchronously
	var component = undefined;

	var unmount = (0,_reactivity_effects_js__WEBPACK_IMPORTED_MODULE_5__.component_root)(() => {
		var anchor_node = anchor ?? target.appendChild((0,_dom_operations_js__WEBPACK_IMPORTED_MODULE_1__.create_text)());

		(0,_dom_blocks_boundary_js__WEBPACK_IMPORTED_MODULE_14__.boundary)(
			/** @type {TemplateNode} */ (anchor_node),
			{
				pending: () => {}
			},
			(anchor_node) => {
				if (context) {
					(0,_context_js__WEBPACK_IMPORTED_MODULE_4__.push)({});
					var ctx = /** @type {ComponentContext} */ (_context_js__WEBPACK_IMPORTED_MODULE_4__.component_context);
					ctx.c = context;
				}

				if (events) {
					// We can't spread the object or else we'd lose the state proxy stuff, if it is one
					/** @type {any} */ (props).$$events = events;
				}

				if (_dom_hydration_js__WEBPACK_IMPORTED_MODULE_6__.hydrating) {
					(0,_dom_template_js__WEBPACK_IMPORTED_MODULE_11__.assign_nodes)(/** @type {TemplateNode} */ (anchor_node), null);
				}

				should_intro = intro;
				// @ts-expect-error the public typings are not what the actual function looks like
				component = Component(anchor_node, props) || {};
				should_intro = true;

				if (_dom_hydration_js__WEBPACK_IMPORTED_MODULE_6__.hydrating) {
					/** @type {Effect} */ _runtime_js__WEBPACK_IMPORTED_MODULE_3__.active_effect.nodes_end = _dom_hydration_js__WEBPACK_IMPORTED_MODULE_6__.hydrate_node;

					if (
						_dom_hydration_js__WEBPACK_IMPORTED_MODULE_6__.hydrate_node === null ||
						_dom_hydration_js__WEBPACK_IMPORTED_MODULE_6__.hydrate_node.nodeType !== _constants_js__WEBPACK_IMPORTED_MODULE_13__.COMMENT_NODE ||
						/** @type {Comment} */ _dom_hydration_js__WEBPACK_IMPORTED_MODULE_6__.hydrate_node.data !== _constants_js__WEBPACK_IMPORTED_MODULE_2__.HYDRATION_END
					) {
						_warnings_js__WEBPACK_IMPORTED_MODULE_9__.hydration_mismatch();
						throw _constants_js__WEBPACK_IMPORTED_MODULE_2__.HYDRATION_ERROR;
					}
				}

				if (context) {
					(0,_context_js__WEBPACK_IMPORTED_MODULE_4__.pop)();
				}
			}
		);

		return () => {
			for (var event_name of registered_events) {
				target.removeEventListener(event_name, _dom_elements_events_js__WEBPACK_IMPORTED_MODULE_8__.handle_event_propagation);

				var n = /** @type {number} */ (document_listeners.get(event_name));

				if (--n === 0) {
					document.removeEventListener(event_name, _dom_elements_events_js__WEBPACK_IMPORTED_MODULE_8__.handle_event_propagation);
					document_listeners.delete(event_name);
				} else {
					document_listeners.set(event_name, n);
				}
			}

			_dom_elements_events_js__WEBPACK_IMPORTED_MODULE_8__.root_event_handles["delete"](event_handle);

			if (anchor_node !== anchor) {
				anchor_node.parentNode?.removeChild(anchor_node);
			}
		};
	});

	mounted_components.set(component, unmount);
	return component;
}

/**
 * References of the components that were mounted or hydrated.
 * Uses a `WeakMap` to avoid memory leaks.
 */
let mounted_components = new WeakMap();

/**
 * Unmounts a component that was previously mounted using `mount` or `hydrate`.
 *
 * Since 5.13.0, if `options.outro` is `true`, [transitions](https://svelte.dev/docs/svelte/transition) will play before the component is removed from the DOM.
 *
 * Returns a `Promise` that resolves after transitions have completed if `options.outro` is true, or immediately otherwise (prior to 5.13.0, returns `void`).
 *
 * ```js
 * import { mount, unmount } from 'svelte';
 * import App from './App.svelte';
 *
 * const app = mount(App, { target: document.body });
 *
 * // later...
 * unmount(app, { outro: true });
 * ```
 * @param {Record<string, any>} component
 * @param {{ outro?: boolean }} [options]
 * @returns {Promise<void>}
 */
function unmount(component, options) {
	const fn = mounted_components.get(component);

	if (fn) {
		mounted_components.delete(component);
		return fn(options);
	}

	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		if (_constants_js__WEBPACK_IMPORTED_MODULE_13__.STATE_SYMBOL in component) {
			_warnings_js__WEBPACK_IMPORTED_MODULE_9__.state_proxy_unmount();
		} else {
			_warnings_js__WEBPACK_IMPORTED_MODULE_9__.lifecycle_double_unmount();
		}
	}

	return Promise.resolve();
}


}),
5551: 
/*!****************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/runtime.js ***!
  \****************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  active_effect: () => (active_effect),
  active_reaction: () => (active_reaction),
  current_sources: () => (current_sources),
  deep_read_state: () => (deep_read_state),
  get: () => (get),
  increment_write_version: () => (increment_write_version),
  is_destroying_effect: () => (is_destroying_effect),
  is_dirty: () => (is_dirty),
  is_updating_effect: () => (is_updating_effect),
  push_reaction_value: () => (push_reaction_value),
  remove_reactions: () => (remove_reactions),
  set_active_effect: () => (set_active_effect),
  set_active_reaction: () => (set_active_reaction),
  set_is_destroying_effect: () => (set_is_destroying_effect),
  set_is_updating_effect: () => (set_is_updating_effect),
  set_signal_status: () => (set_signal_status),
  set_untracked_writes: () => (set_untracked_writes),
  set_update_version: () => (set_update_version),
  tick: () => (tick),
  untrack: () => (untrack),
  untracked_writes: () => (untracked_writes),
  untracking: () => (untracking),
  update_effect: () => (update_effect),
  update_reaction: () => (update_reaction),
  update_version: () => (update_version)
});
/* import */var esm_env__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! esm-env */ 3990);
/* import */var _shared_utils_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../shared/utils.js */ 2060);
/* import */var _reactivity_effects_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./reactivity/effects.js */ 7770);
/* import */var _constants_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./constants.js */ 5818);
/* import */var _reactivity_sources_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./reactivity/sources.js */ 6718);
/* import */var _reactivity_deriveds_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./reactivity/deriveds.js */ 6064);
/* import */var _flags_index_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../flags/index.js */ 9987);
/* import */var _dev_tracing_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./dev/tracing.js */ 6265);
/* import */var _context_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./context.js */ 2204);
/* import */var _warnings_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./warnings.js */ 8658);
/* import */var _reactivity_batch_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./reactivity/batch.js */ 5812);
/* import */var _error_handling_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./error-handling.js */ 2219);
/* import */var _constants_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../constants.js */ 7164);
/* import */var _legacy_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./legacy.js */ 4240);
/* import */var _dom_elements_bindings_shared_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./dom/elements/bindings/shared.js */ 6766);
/** @import { Derived, Effect, Reaction, Signal, Source, Value } from '#client' */
















let is_updating_effect = false;

/** @param {boolean} value */
function set_is_updating_effect(value) {
	is_updating_effect = value;
}

let is_destroying_effect = false;

/** @param {boolean} value */
function set_is_destroying_effect(value) {
	is_destroying_effect = value;
}

/** @type {null | Reaction} */
let active_reaction = null;

let untracking = false;

/** @param {null | Reaction} reaction */
function set_active_reaction(reaction) {
	active_reaction = reaction;
}

/** @type {null | Effect} */
let active_effect = null;

/** @param {null | Effect} effect */
function set_active_effect(effect) {
	active_effect = effect;
}

/**
 * When sources are created within a reaction, reading and writing
 * them within that reaction should not cause a re-run
 * @type {null | Source[]}
 */
let current_sources = null;

/** @param {Value} value */
function push_reaction_value(value) {
	if (active_reaction !== null && (!_flags_index_js__WEBPACK_IMPORTED_MODULE_14__.async_mode_flag || (active_reaction.f & _constants_js__WEBPACK_IMPORTED_MODULE_3__.DERIVED) !== 0)) {
		if (current_sources === null) {
			current_sources = [value];
		} else {
			current_sources.push(value);
		}
	}
}

/**
 * The dependencies of the reaction that is currently being executed. In many cases,
 * the dependencies are unchanged between runs, and so this will be `null` unless
 * and until a new dependency is accessed — we track this via `skipped_deps`
 * @type {null | Value[]}
 */
let new_deps = null;

let skipped_deps = 0;

/**
 * Tracks writes that the effect it's executed in doesn't listen to yet,
 * so that the dependency can be added to the effect later on if it then reads it
 * @type {null | Source[]}
 */
let untracked_writes = null;

/** @param {null | Source[]} value */
function set_untracked_writes(value) {
	untracked_writes = value;
}

/**
 * @type {number} Used by sources and deriveds for handling updates.
 * Version starts from 1 so that unowned deriveds differentiate between a created effect and a run one for tracing
 **/
let write_version = 1;

/** @type {number} Used to version each read of a source of derived to avoid duplicating depedencies inside a reaction */
let read_version = 0;

let update_version = read_version;

/** @param {number} value */
function set_update_version(value) {
	update_version = value;
}

function increment_write_version() {
	return ++write_version;
}

/**
 * Determines whether a derived or effect is dirty.
 * If it is MAYBE_DIRTY, will set the status to CLEAN
 * @param {Reaction} reaction
 * @returns {boolean}
 */
function is_dirty(reaction) {
	var flags = reaction.f;

	if ((flags & _constants_js__WEBPACK_IMPORTED_MODULE_3__.DIRTY) !== 0) {
		return true;
	}

	if (flags & _constants_js__WEBPACK_IMPORTED_MODULE_3__.DERIVED) {
		reaction.f &= ~_constants_js__WEBPACK_IMPORTED_MODULE_3__.WAS_MARKED;
	}

	if ((flags & _constants_js__WEBPACK_IMPORTED_MODULE_3__.MAYBE_DIRTY) !== 0) {
		var dependencies = reaction.deps;

		if (dependencies !== null) {
			var length = dependencies.length;

			for (var i = 0; i < length; i++) {
				var dependency = dependencies[i];

				if (is_dirty(/** @type {Derived} */ (dependency))) {
					(0,_reactivity_deriveds_js__WEBPACK_IMPORTED_MODULE_5__.update_derived)(/** @type {Derived} */ (dependency));
				}

				if (dependency.wv > reaction.wv) {
					return true;
				}
			}
		}

		if (
			(flags & _constants_js__WEBPACK_IMPORTED_MODULE_3__.CONNECTED) !== 0 &&
			// During time traveling we don't want to reset the status so that
			// traversal of the graph in the other batches still happens
			_reactivity_batch_js__WEBPACK_IMPORTED_MODULE_9__.batch_values === null
		) {
			set_signal_status(reaction, _constants_js__WEBPACK_IMPORTED_MODULE_3__.CLEAN);
		}
	}

	return false;
}

/**
 * @param {Value} signal
 * @param {Effect} effect
 * @param {boolean} [root]
 */
function schedule_possible_effect_self_invalidation(signal, effect, root = true) {
	var reactions = signal.reactions;
	if (reactions === null) return;

	if (!_flags_index_js__WEBPACK_IMPORTED_MODULE_14__.async_mode_flag && current_sources?.includes(signal)) {
		return;
	}

	for (var i = 0; i < reactions.length; i++) {
		var reaction = reactions[i];

		if ((reaction.f & _constants_js__WEBPACK_IMPORTED_MODULE_3__.DERIVED) !== 0) {
			schedule_possible_effect_self_invalidation(/** @type {Derived} */ (reaction), effect, false);
		} else if (effect === reaction) {
			if (root) {
				set_signal_status(reaction, _constants_js__WEBPACK_IMPORTED_MODULE_3__.DIRTY);
			} else if ((reaction.f & _constants_js__WEBPACK_IMPORTED_MODULE_3__.CLEAN) !== 0) {
				set_signal_status(reaction, _constants_js__WEBPACK_IMPORTED_MODULE_3__.MAYBE_DIRTY);
			}
			(0,_reactivity_batch_js__WEBPACK_IMPORTED_MODULE_9__.schedule_effect)(/** @type {Effect} */ (reaction));
		}
	}
}

/** @param {Reaction} reaction */
function update_reaction(reaction) {
	var previous_deps = new_deps;
	var previous_skipped_deps = skipped_deps;
	var previous_untracked_writes = untracked_writes;
	var previous_reaction = active_reaction;
	var previous_sources = current_sources;
	var previous_component_context = _context_js__WEBPACK_IMPORTED_MODULE_7__.component_context;
	var previous_untracking = untracking;
	var previous_update_version = update_version;

	var flags = reaction.f;

	new_deps = /** @type {null | Value[]} */ (null);
	skipped_deps = 0;
	untracked_writes = null;
	active_reaction = (flags & (_constants_js__WEBPACK_IMPORTED_MODULE_3__.BRANCH_EFFECT | _constants_js__WEBPACK_IMPORTED_MODULE_3__.ROOT_EFFECT)) === 0 ? reaction : null;

	current_sources = null;
	(0,_context_js__WEBPACK_IMPORTED_MODULE_7__.set_component_context)(reaction.ctx);
	untracking = false;
	update_version = ++read_version;

	if (reaction.ac !== null) {
		(0,_dom_elements_bindings_shared_js__WEBPACK_IMPORTED_MODULE_13__.without_reactive_context)(() => {
			/** @type {AbortController} */ (reaction.ac).abort(_constants_js__WEBPACK_IMPORTED_MODULE_3__.STALE_REACTION);
		});

		reaction.ac = null;
	}

	try {
		reaction.f |= _constants_js__WEBPACK_IMPORTED_MODULE_3__.REACTION_IS_UPDATING;
		var fn = /** @type {Function} */ (reaction.fn);
		var result = fn();
		var deps = reaction.deps;

		if (new_deps !== null) {
			var i;

			remove_reactions(reaction, skipped_deps);

			if (deps !== null && skipped_deps > 0) {
				deps.length = skipped_deps + new_deps.length;
				for (i = 0; i < new_deps.length; i++) {
					deps[skipped_deps + i] = new_deps[i];
				}
			} else {
				reaction.deps = deps = new_deps;
			}

			if (is_updating_effect && (0,_reactivity_effects_js__WEBPACK_IMPORTED_MODULE_2__.effect_tracking)() && (reaction.f & _constants_js__WEBPACK_IMPORTED_MODULE_3__.CONNECTED) !== 0) {
				for (i = skipped_deps; i < deps.length; i++) {
					(deps[i].reactions ??= []).push(reaction);
				}
			}
		} else if (deps !== null && skipped_deps < deps.length) {
			remove_reactions(reaction, skipped_deps);
			deps.length = skipped_deps;
		}

		// If we're inside an effect and we have untracked writes, then we need to
		// ensure that if any of those untracked writes result in re-invalidation
		// of the current effect, then that happens accordingly
		if (
			(0,_context_js__WEBPACK_IMPORTED_MODULE_7__.is_runes)() &&
			untracked_writes !== null &&
			!untracking &&
			deps !== null &&
			(reaction.f & (_constants_js__WEBPACK_IMPORTED_MODULE_3__.DERIVED | _constants_js__WEBPACK_IMPORTED_MODULE_3__.MAYBE_DIRTY | _constants_js__WEBPACK_IMPORTED_MODULE_3__.DIRTY)) === 0
		) {
			for (i = 0; i < /** @type {Source[]} */ (untracked_writes).length; i++) {
				schedule_possible_effect_self_invalidation(
					untracked_writes[i],
					/** @type {Effect} */ (reaction)
				);
			}
		}

		// If we are returning to an previous reaction then
		// we need to increment the read version to ensure that
		// any dependencies in this reaction aren't marked with
		// the same version
		if (previous_reaction !== null && previous_reaction !== reaction) {
			read_version++;

			if (untracked_writes !== null) {
				if (previous_untracked_writes === null) {
					previous_untracked_writes = untracked_writes;
				} else {
					previous_untracked_writes.push(.../** @type {Source[]} */ (untracked_writes));
				}
			}
		}

		if ((reaction.f & _constants_js__WEBPACK_IMPORTED_MODULE_3__.ERROR_VALUE) !== 0) {
			reaction.f ^= _constants_js__WEBPACK_IMPORTED_MODULE_3__.ERROR_VALUE;
		}

		return result;
	} catch (error) {
		return (0,_error_handling_js__WEBPACK_IMPORTED_MODULE_10__.handle_error)(error);
	} finally {
		reaction.f ^= _constants_js__WEBPACK_IMPORTED_MODULE_3__.REACTION_IS_UPDATING;
		new_deps = previous_deps;
		skipped_deps = previous_skipped_deps;
		untracked_writes = previous_untracked_writes;
		active_reaction = previous_reaction;
		current_sources = previous_sources;
		(0,_context_js__WEBPACK_IMPORTED_MODULE_7__.set_component_context)(previous_component_context);
		untracking = previous_untracking;
		update_version = previous_update_version;
	}
}

/**
 * @template V
 * @param {Reaction} signal
 * @param {Value<V>} dependency
 * @returns {void}
 */
function remove_reaction(signal, dependency) {
	let reactions = dependency.reactions;
	if (reactions !== null) {
		var index = _shared_utils_js__WEBPACK_IMPORTED_MODULE_1__.index_of.call(reactions, signal);
		if (index !== -1) {
			var new_length = reactions.length - 1;
			if (new_length === 0) {
				reactions = dependency.reactions = null;
			} else {
				// Swap with last element and then remove.
				reactions[index] = reactions[new_length];
				reactions.pop();
			}
		}
	}

	// If the derived has no reactions, then we can disconnect it from the graph,
	// allowing it to either reconnect in the future, or be GC'd by the VM.
	if (
		reactions === null &&
		(dependency.f & _constants_js__WEBPACK_IMPORTED_MODULE_3__.DERIVED) !== 0 &&
		// Destroying a child effect while updating a parent effect can cause a dependency to appear
		// to be unused, when in fact it is used by the currently-updating parent. Checking `new_deps`
		// allows us to skip the expensive work of disconnecting and immediately reconnecting it
		(new_deps === null || !new_deps.includes(dependency))
	) {
		set_signal_status(dependency, _constants_js__WEBPACK_IMPORTED_MODULE_3__.MAYBE_DIRTY);
		// If we are working with a derived that is owned by an effect, then mark it as being
		// disconnected and remove the mark flag, as it cannot be reliably removed otherwise
		if ((dependency.f & _constants_js__WEBPACK_IMPORTED_MODULE_3__.CONNECTED) !== 0) {
			dependency.f ^= _constants_js__WEBPACK_IMPORTED_MODULE_3__.CONNECTED;
			dependency.f &= ~_constants_js__WEBPACK_IMPORTED_MODULE_3__.WAS_MARKED;
		}
		// Disconnect any reactions owned by this reaction
		(0,_reactivity_deriveds_js__WEBPACK_IMPORTED_MODULE_5__.destroy_derived_effects)(/** @type {Derived} **/ (dependency));
		remove_reactions(/** @type {Derived} **/ (dependency), 0);
	}
}

/**
 * @param {Reaction} signal
 * @param {number} start_index
 * @returns {void}
 */
function remove_reactions(signal, start_index) {
	var dependencies = signal.deps;
	if (dependencies === null) return;

	for (var i = start_index; i < dependencies.length; i++) {
		remove_reaction(signal, dependencies[i]);
	}
}

/**
 * @param {Effect} effect
 * @returns {void}
 */
function update_effect(effect) {
	var flags = effect.f;

	if ((flags & _constants_js__WEBPACK_IMPORTED_MODULE_3__.DESTROYED) !== 0) {
		return;
	}

	set_signal_status(effect, _constants_js__WEBPACK_IMPORTED_MODULE_3__.CLEAN);

	var previous_effect = active_effect;
	var was_updating_effect = is_updating_effect;

	active_effect = effect;
	is_updating_effect = true;

	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		var previous_component_fn = _context_js__WEBPACK_IMPORTED_MODULE_7__.dev_current_component_function;
		(0,_context_js__WEBPACK_IMPORTED_MODULE_7__.set_dev_current_component_function)(effect.component_function);
		var previous_stack = /** @type {any} */ (_context_js__WEBPACK_IMPORTED_MODULE_7__.dev_stack);
		// only block effects have a dev stack, keep the current one otherwise
		(0,_context_js__WEBPACK_IMPORTED_MODULE_7__.set_dev_stack)(effect.dev_stack ?? _context_js__WEBPACK_IMPORTED_MODULE_7__.dev_stack);
	}

	try {
		if ((flags & _constants_js__WEBPACK_IMPORTED_MODULE_3__.BLOCK_EFFECT) !== 0) {
			(0,_reactivity_effects_js__WEBPACK_IMPORTED_MODULE_2__.destroy_block_effect_children)(effect);
		} else {
			(0,_reactivity_effects_js__WEBPACK_IMPORTED_MODULE_2__.destroy_effect_children)(effect);
		}

		(0,_reactivity_effects_js__WEBPACK_IMPORTED_MODULE_2__.execute_effect_teardown)(effect);
		var teardown = update_reaction(effect);
		effect.teardown = typeof teardown === 'function' ? teardown : null;
		effect.wv = write_version;

		// In DEV, increment versions of any sources that were written to during the effect,
		// so that they are correctly marked as dirty when the effect re-runs
		if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV && _flags_index_js__WEBPACK_IMPORTED_MODULE_14__.tracing_mode_flag && (effect.f & _constants_js__WEBPACK_IMPORTED_MODULE_3__.DIRTY) !== 0 && effect.deps !== null) {
			for (var dep of effect.deps) {
				if (dep.set_during_effect) {
					dep.wv = increment_write_version();
					dep.set_during_effect = false;
				}
			}
		}
	} finally {
		is_updating_effect = was_updating_effect;
		active_effect = previous_effect;

		if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
			(0,_context_js__WEBPACK_IMPORTED_MODULE_7__.set_dev_current_component_function)(previous_component_fn);
			(0,_context_js__WEBPACK_IMPORTED_MODULE_7__.set_dev_stack)(previous_stack);
		}
	}
}

/**
 * Returns a promise that resolves once any pending state changes have been applied.
 * @returns {Promise<void>}
 */
async function tick() {
	if (_flags_index_js__WEBPACK_IMPORTED_MODULE_14__.async_mode_flag) {
		return new Promise((f) => {
			// Race them against each other - in almost all cases requestAnimationFrame will fire first,
			// but e.g. in case the window is not focused or a view transition happens, requestAnimationFrame
			// will be delayed and setTimeout helps us resolve fast enough in that case
			requestAnimationFrame(() => f());
			setTimeout(() => f());
		});
	}

	await Promise.resolve();

	// By calling flushSync we guarantee that any pending state changes are applied after one tick.
	// TODO look into whether we can make flushing subsequent updates synchronously in the future.
	(0,_reactivity_batch_js__WEBPACK_IMPORTED_MODULE_9__.flushSync)();
}

/**
 * Returns a promise that resolves once any state changes, and asynchronous work resulting from them,
 * have resolved and the DOM has been updated
 * @returns {Promise<void>}
 * @since 5.36
 */
function settled() {
	return _reactivity_batch_js__WEBPACK_IMPORTED_MODULE_9__.Batch.ensure().settled();
}

/**
 * @template V
 * @param {Value<V>} signal
 * @returns {V}
 */
function get(signal) {
	var flags = signal.f;
	var is_derived = (flags & _constants_js__WEBPACK_IMPORTED_MODULE_3__.DERIVED) !== 0;

	_legacy_js__WEBPACK_IMPORTED_MODULE_12__.captured_signals?.add(signal);

	// Register the dependency on the current reaction signal.
	if (active_reaction !== null && !untracking) {
		// if we're in a derived that is being read inside an _async_ derived,
		// it's possible that the effect was already destroyed. In this case,
		// we don't add the dependency, because that would create a memory leak
		var destroyed = active_effect !== null && (active_effect.f & _constants_js__WEBPACK_IMPORTED_MODULE_3__.DESTROYED) !== 0;

		if (!destroyed && !current_sources?.includes(signal)) {
			var deps = active_reaction.deps;

			if ((active_reaction.f & _constants_js__WEBPACK_IMPORTED_MODULE_3__.REACTION_IS_UPDATING) !== 0) {
				// we're in the effect init/update cycle
				if (signal.rv < read_version) {
					signal.rv = read_version;

					// If the signal is accessing the same dependencies in the same
					// order as it did last time, increment `skipped_deps`
					// rather than updating `new_deps`, which creates GC cost
					if (new_deps === null && deps !== null && deps[skipped_deps] === signal) {
						skipped_deps++;
					} else if (new_deps === null) {
						new_deps = [signal];
					} else if (!new_deps.includes(signal)) {
						new_deps.push(signal);
					}
				}
			} else {
				// we're adding a dependency outside the init/update cycle
				// (i.e. after an `await`)
				(active_reaction.deps ??= []).push(signal);

				var reactions = signal.reactions;

				if (reactions === null) {
					signal.reactions = [active_reaction];
				} else if (!reactions.includes(active_reaction)) {
					reactions.push(active_reaction);
				}
			}
		}
	}

	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		// TODO reinstate this, but make it actually work
		// if (current_async_effect) {
		// 	var tracking = (current_async_effect.f & REACTION_IS_UPDATING) !== 0;
		// 	var was_read = current_async_effect.deps?.includes(signal);

		// 	if (!tracking && !untracking && !was_read) {
		// 		w.await_reactivity_loss(/** @type {string} */ (signal.label));

		// 		var trace = get_stack('traced at');
		// 		// eslint-disable-next-line no-console
		// 		if (trace) console.warn(trace);
		// 	}
		// }

		_reactivity_deriveds_js__WEBPACK_IMPORTED_MODULE_5__.recent_async_deriveds["delete"](signal);

		if (
			_flags_index_js__WEBPACK_IMPORTED_MODULE_14__.tracing_mode_flag &&
			!untracking &&
			_dev_tracing_js__WEBPACK_IMPORTED_MODULE_6__.tracing_expressions !== null &&
			active_reaction !== null &&
			_dev_tracing_js__WEBPACK_IMPORTED_MODULE_6__.tracing_expressions.reaction === active_reaction
		) {
			// Used when mapping state between special blocks like `each`
			if (signal.trace) {
				signal.trace();
			} else {
				var trace = (0,_dev_tracing_js__WEBPACK_IMPORTED_MODULE_6__.get_stack)('traced at');

				if (trace) {
					var entry = _dev_tracing_js__WEBPACK_IMPORTED_MODULE_6__.tracing_expressions.entries.get(signal);

					if (entry === undefined) {
						entry = { traces: [] };
						_dev_tracing_js__WEBPACK_IMPORTED_MODULE_6__.tracing_expressions.entries.set(signal, entry);
					}

					var last = entry.traces[entry.traces.length - 1];

					// traces can be duplicated, e.g. by `snapshot` invoking both
					// both `getOwnPropertyDescriptor` and `get` traps at once
					if (trace.stack !== last?.stack) {
						entry.traces.push(trace);
					}
				}
			}
		}
	}

	if (is_destroying_effect) {
		if (_reactivity_sources_js__WEBPACK_IMPORTED_MODULE_4__.old_values.has(signal)) {
			return _reactivity_sources_js__WEBPACK_IMPORTED_MODULE_4__.old_values.get(signal);
		}

		if (is_derived) {
			var derived = /** @type {Derived} */ (signal);

			var value = derived.v;

			// if the derived is dirty and has reactions, or depends on the values that just changed, re-execute
			// (a derived can be maybe_dirty due to the effect destroy removing its last reaction)
			if (
				((derived.f & _constants_js__WEBPACK_IMPORTED_MODULE_3__.CLEAN) === 0 && derived.reactions !== null) ||
				depends_on_old_values(derived)
			) {
				value = (0,_reactivity_deriveds_js__WEBPACK_IMPORTED_MODULE_5__.execute_derived)(derived);
			}

			_reactivity_sources_js__WEBPACK_IMPORTED_MODULE_4__.old_values.set(derived, value);

			return value;
		}
	} else if (is_derived) {
		derived = /** @type {Derived} */ (signal);

		if (_reactivity_batch_js__WEBPACK_IMPORTED_MODULE_9__.batch_values?.has(derived)) {
			return _reactivity_batch_js__WEBPACK_IMPORTED_MODULE_9__.batch_values.get(derived);
		}

		if (is_dirty(derived)) {
			(0,_reactivity_deriveds_js__WEBPACK_IMPORTED_MODULE_5__.update_derived)(derived);
		}

		if (is_updating_effect && (0,_reactivity_effects_js__WEBPACK_IMPORTED_MODULE_2__.effect_tracking)() && (derived.f & _constants_js__WEBPACK_IMPORTED_MODULE_3__.CONNECTED) === 0) {
			reconnect(derived);
		}
	} else if (_reactivity_batch_js__WEBPACK_IMPORTED_MODULE_9__.batch_values?.has(signal)) {
		return _reactivity_batch_js__WEBPACK_IMPORTED_MODULE_9__.batch_values.get(signal);
	}

	if ((signal.f & _constants_js__WEBPACK_IMPORTED_MODULE_3__.ERROR_VALUE) !== 0) {
		throw signal.v;
	}

	return signal.v;
}

/**
 * (Re)connect a disconnected derived, so that it is notified
 * of changes in `mark_reactions`
 * @param {Derived} derived
 */
function reconnect(derived) {
	if (derived.deps === null) return;

	derived.f ^= _constants_js__WEBPACK_IMPORTED_MODULE_3__.CONNECTED;

	for (const dep of derived.deps) {
		(dep.reactions ??= []).push(derived);

		if ((dep.f & _constants_js__WEBPACK_IMPORTED_MODULE_3__.DERIVED) !== 0 && (dep.f & _constants_js__WEBPACK_IMPORTED_MODULE_3__.CONNECTED) === 0) {
			reconnect(/** @type {Derived} */ (dep));
		}
	}
}

/** @param {Derived} derived */
function depends_on_old_values(derived) {
	if (derived.v === _constants_js__WEBPACK_IMPORTED_MODULE_11__.UNINITIALIZED) return true; // we don't know, so assume the worst
	if (derived.deps === null) return false;

	for (const dep of derived.deps) {
		if (_reactivity_sources_js__WEBPACK_IMPORTED_MODULE_4__.old_values.has(dep)) {
			return true;
		}

		if ((dep.f & _constants_js__WEBPACK_IMPORTED_MODULE_3__.DERIVED) !== 0 && depends_on_old_values(/** @type {Derived} */ (dep))) {
			return true;
		}
	}

	return false;
}

/**
 * Like `get`, but checks for `undefined`. Used for `var` declarations because they can be accessed before being declared
 * @template V
 * @param {Value<V> | undefined} signal
 * @returns {V | undefined}
 */
function safe_get(signal) {
	return signal && get(signal);
}

/**
 * When used inside a [`$derived`](https://svelte.dev/docs/svelte/$derived) or [`$effect`](https://svelte.dev/docs/svelte/$effect),
 * any state read inside `fn` will not be treated as a dependency.
 *
 * ```ts
 * $effect(() => {
 *   // this will run when `data` changes, but not when `time` changes
 *   save(data, {
 *     timestamp: untrack(() => time)
 *   });
 * });
 * ```
 * @template T
 * @param {() => T} fn
 * @returns {T}
 */
function untrack(fn) {
	var previous_untracking = untracking;
	try {
		untracking = true;
		return fn();
	} finally {
		untracking = previous_untracking;
	}
}

const STATUS_MASK = ~(_constants_js__WEBPACK_IMPORTED_MODULE_3__.DIRTY | _constants_js__WEBPACK_IMPORTED_MODULE_3__.MAYBE_DIRTY | _constants_js__WEBPACK_IMPORTED_MODULE_3__.CLEAN);

/**
 * @param {Signal} signal
 * @param {number} status
 * @returns {void}
 */
function set_signal_status(signal, status) {
	signal.f = (signal.f & STATUS_MASK) | status;
}

/**
 * @param {Record<string | symbol, unknown>} obj
 * @param {Array<string | symbol>} keys
 * @returns {Record<string | symbol, unknown>}
 */
function exclude_from_object(obj, keys) {
	/** @type {Record<string | symbol, unknown>} */
	var result = {};

	for (var key in obj) {
		if (!keys.includes(key)) {
			result[key] = obj[key];
		}
	}

	for (var symbol of Object.getOwnPropertySymbols(obj)) {
		if (Object.propertyIsEnumerable.call(obj, symbol) && !keys.includes(symbol)) {
			result[symbol] = obj[symbol];
		}
	}

	return result;
}

/**
 * Possibly traverse an object and read all its properties so that they're all reactive in case this is `$state`.
 * Does only check first level of an object for performance reasons (heuristic should be good for 99% of all cases).
 * @param {any} value
 * @returns {void}
 */
function deep_read_state(value) {
	if (typeof value !== 'object' || !value || value instanceof EventTarget) {
		return;
	}

	if (_constants_js__WEBPACK_IMPORTED_MODULE_3__.STATE_SYMBOL in value) {
		deep_read(value);
	} else if (!Array.isArray(value)) {
		for (let key in value) {
			const prop = value[key];
			if (typeof prop === 'object' && prop && _constants_js__WEBPACK_IMPORTED_MODULE_3__.STATE_SYMBOL in prop) {
				deep_read(prop);
			}
		}
	}
}

/**
 * Deeply traverse an object and read all its properties
 * so that they're all reactive in case this is `$state`
 * @param {any} value
 * @param {Set<any>} visited
 * @returns {void}
 */
function deep_read(value, visited = new Set()) {
	if (
		typeof value === 'object' &&
		value !== null &&
		// We don't want to traverse DOM elements
		!(value instanceof EventTarget) &&
		!visited.has(value)
	) {
		visited.add(value);
		// When working with a possible SvelteDate, this
		// will ensure we capture changes to it.
		if (value instanceof Date) {
			value.getTime();
		}
		for (let key in value) {
			try {
				deep_read(value[key], visited);
			} catch (e) {
				// continue
			}
		}
		const proto = (0,_shared_utils_js__WEBPACK_IMPORTED_MODULE_1__.get_prototype_of)(value);
		if (
			proto !== Object.prototype &&
			proto !== Array.prototype &&
			proto !== Map.prototype &&
			proto !== Set.prototype &&
			proto !== Date.prototype
		) {
			const descriptors = (0,_shared_utils_js__WEBPACK_IMPORTED_MODULE_1__.get_descriptors)(proto);
			for (let key in descriptors) {
				const get = descriptors[key].get;
				if (get) {
					try {
						get.call(value);
					} catch (e) {
						// continue
					}
				}
			}
		}
	}
}


}),
8658: 
/*!*****************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/client/warnings.js ***!
  \*****************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  assignment_value_stale: () => (assignment_value_stale),
  await_waterfall: () => (await_waterfall),
  binding_property_non_reactive: () => (binding_property_non_reactive),
  console_log_state: () => (console_log_state),
  event_handler_invalid: () => (event_handler_invalid),
  hydration_attribute_changed: () => (hydration_attribute_changed),
  hydration_html_changed: () => (hydration_html_changed),
  hydration_mismatch: () => (hydration_mismatch),
  invalid_raw_snippet_render: () => (invalid_raw_snippet_render),
  legacy_recursive_reactive_block: () => (legacy_recursive_reactive_block),
  lifecycle_double_unmount: () => (lifecycle_double_unmount),
  ownership_invalid_binding: () => (ownership_invalid_binding),
  ownership_invalid_mutation: () => (ownership_invalid_mutation),
  select_multiple_invalid_value: () => (select_multiple_invalid_value),
  state_proxy_equality_mismatch: () => (state_proxy_equality_mismatch),
  state_proxy_unmount: () => (state_proxy_unmount),
  svelte_boundary_reset_noop: () => (svelte_boundary_reset_noop)
});
/* import */var esm_env__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! esm-env */ 3990);
/* This file is generated by scripts/process-messages/index.js. Do not edit! */



var bold = 'font-weight: bold';
var normal = 'font-weight: normal';

/**
 * Assignment to `%property%` property (%location%) will evaluate to the right-hand side, not the value of `%property%` following the assignment. This may result in unexpected behaviour.
 * @param {string} property
 * @param {string} location
 */
function assignment_value_stale(property, location) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		console.warn(`%c[svelte] assignment_value_stale\n%cAssignment to \`${property}\` property (${location}) will evaluate to the right-hand side, not the value of \`${property}\` following the assignment. This may result in unexpected behaviour.\nhttps://svelte.dev/e/assignment_value_stale`, bold, normal);
	} else {
		console.warn(`https://svelte.dev/e/assignment_value_stale`);
	}
}

/**
 * Detected reactivity loss when reading `%name%`. This happens when state is read in an async function after an earlier `await`
 * @param {string} name
 */
function await_reactivity_loss(name) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		console.warn(`%c[svelte] await_reactivity_loss\n%cDetected reactivity loss when reading \`${name}\`. This happens when state is read in an async function after an earlier \`await\`\nhttps://svelte.dev/e/await_reactivity_loss`, bold, normal);
	} else {
		console.warn(`https://svelte.dev/e/await_reactivity_loss`);
	}
}

/**
 * An async derived, `%name%` (%location%) was not read immediately after it resolved. This often indicates an unnecessary waterfall, which can slow down your app
 * @param {string} name
 * @param {string} location
 */
function await_waterfall(name, location) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		console.warn(`%c[svelte] await_waterfall\n%cAn async derived, \`${name}\` (${location}) was not read immediately after it resolved. This often indicates an unnecessary waterfall, which can slow down your app\nhttps://svelte.dev/e/await_waterfall`, bold, normal);
	} else {
		console.warn(`https://svelte.dev/e/await_waterfall`);
	}
}

/**
 * `%binding%` (%location%) is binding to a non-reactive property
 * @param {string} binding
 * @param {string | undefined | null} [location]
 */
function binding_property_non_reactive(binding, location) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		console.warn(
			`%c[svelte] binding_property_non_reactive\n%c${location
				? `\`${binding}\` (${location}) is binding to a non-reactive property`
				: `\`${binding}\` is binding to a non-reactive property`}\nhttps://svelte.dev/e/binding_property_non_reactive`,
			bold,
			normal
		);
	} else {
		console.warn(`https://svelte.dev/e/binding_property_non_reactive`);
	}
}

/**
 * Your `console.%method%` contained `$state` proxies. Consider using `$inspect(...)` or `$state.snapshot(...)` instead
 * @param {string} method
 */
function console_log_state(method) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		console.warn(`%c[svelte] console_log_state\n%cYour \`console.${method}\` contained \`$state\` proxies. Consider using \`$inspect(...)\` or \`$state.snapshot(...)\` instead\nhttps://svelte.dev/e/console_log_state`, bold, normal);
	} else {
		console.warn(`https://svelte.dev/e/console_log_state`);
	}
}

/**
 * %handler% should be a function. Did you mean to %suggestion%?
 * @param {string} handler
 * @param {string} suggestion
 */
function event_handler_invalid(handler, suggestion) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		console.warn(`%c[svelte] event_handler_invalid\n%c${handler} should be a function. Did you mean to ${suggestion}?\nhttps://svelte.dev/e/event_handler_invalid`, bold, normal);
	} else {
		console.warn(`https://svelte.dev/e/event_handler_invalid`);
	}
}

/**
 * The `%attribute%` attribute on `%html%` changed its value between server and client renders. The client value, `%value%`, will be ignored in favour of the server value
 * @param {string} attribute
 * @param {string} html
 * @param {string} value
 */
function hydration_attribute_changed(attribute, html, value) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		console.warn(`%c[svelte] hydration_attribute_changed\n%cThe \`${attribute}\` attribute on \`${html}\` changed its value between server and client renders. The client value, \`${value}\`, will be ignored in favour of the server value\nhttps://svelte.dev/e/hydration_attribute_changed`, bold, normal);
	} else {
		console.warn(`https://svelte.dev/e/hydration_attribute_changed`);
	}
}

/**
 * The value of an `{@html ...}` block %location% changed between server and client renders. The client value will be ignored in favour of the server value
 * @param {string | undefined | null} [location]
 */
function hydration_html_changed(location) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		console.warn(
			`%c[svelte] hydration_html_changed\n%c${location
				? `The value of an \`{@html ...}\` block ${location} changed between server and client renders. The client value will be ignored in favour of the server value`
				: 'The value of an `{@html ...}` block changed between server and client renders. The client value will be ignored in favour of the server value'}\nhttps://svelte.dev/e/hydration_html_changed`,
			bold,
			normal
		);
	} else {
		console.warn(`https://svelte.dev/e/hydration_html_changed`);
	}
}

/**
 * Hydration failed because the initial UI does not match what was rendered on the server. The error occurred near %location%
 * @param {string | undefined | null} [location]
 */
function hydration_mismatch(location) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		console.warn(
			`%c[svelte] hydration_mismatch\n%c${location
				? `Hydration failed because the initial UI does not match what was rendered on the server. The error occurred near ${location}`
				: 'Hydration failed because the initial UI does not match what was rendered on the server'}\nhttps://svelte.dev/e/hydration_mismatch`,
			bold,
			normal
		);
	} else {
		console.warn(`https://svelte.dev/e/hydration_mismatch`);
	}
}

/**
 * The `render` function passed to `createRawSnippet` should return HTML for a single element
 */
function invalid_raw_snippet_render() {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		console.warn(`%c[svelte] invalid_raw_snippet_render\n%cThe \`render\` function passed to \`createRawSnippet\` should return HTML for a single element\nhttps://svelte.dev/e/invalid_raw_snippet_render`, bold, normal);
	} else {
		console.warn(`https://svelte.dev/e/invalid_raw_snippet_render`);
	}
}

/**
 * Detected a migrated `$:` reactive block in `%filename%` that both accesses and updates the same reactive value. This may cause recursive updates when converted to an `$effect`.
 * @param {string} filename
 */
function legacy_recursive_reactive_block(filename) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		console.warn(`%c[svelte] legacy_recursive_reactive_block\n%cDetected a migrated \`$:\` reactive block in \`${filename}\` that both accesses and updates the same reactive value. This may cause recursive updates when converted to an \`$effect\`.\nhttps://svelte.dev/e/legacy_recursive_reactive_block`, bold, normal);
	} else {
		console.warn(`https://svelte.dev/e/legacy_recursive_reactive_block`);
	}
}

/**
 * Tried to unmount a component that was not mounted
 */
function lifecycle_double_unmount() {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		console.warn(`%c[svelte] lifecycle_double_unmount\n%cTried to unmount a component that was not mounted\nhttps://svelte.dev/e/lifecycle_double_unmount`, bold, normal);
	} else {
		console.warn(`https://svelte.dev/e/lifecycle_double_unmount`);
	}
}

/**
 * %parent% passed property `%prop%` to %child% with `bind:`, but its parent component %owner% did not declare `%prop%` as a binding. Consider creating a binding between %owner% and %parent% (e.g. `bind:%prop%={...}` instead of `%prop%={...}`)
 * @param {string} parent
 * @param {string} prop
 * @param {string} child
 * @param {string} owner
 */
function ownership_invalid_binding(parent, prop, child, owner) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		console.warn(`%c[svelte] ownership_invalid_binding\n%c${parent} passed property \`${prop}\` to ${child} with \`bind:\`, but its parent component ${owner} did not declare \`${prop}\` as a binding. Consider creating a binding between ${owner} and ${parent} (e.g. \`bind:${prop}={...}\` instead of \`${prop}={...}\`)\nhttps://svelte.dev/e/ownership_invalid_binding`, bold, normal);
	} else {
		console.warn(`https://svelte.dev/e/ownership_invalid_binding`);
	}
}

/**
 * Mutating unbound props (`%name%`, at %location%) is strongly discouraged. Consider using `bind:%prop%={...}` in %parent% (or using a callback) instead
 * @param {string} name
 * @param {string} location
 * @param {string} prop
 * @param {string} parent
 */
function ownership_invalid_mutation(name, location, prop, parent) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		console.warn(`%c[svelte] ownership_invalid_mutation\n%cMutating unbound props (\`${name}\`, at ${location}) is strongly discouraged. Consider using \`bind:${prop}={...}\` in ${parent} (or using a callback) instead\nhttps://svelte.dev/e/ownership_invalid_mutation`, bold, normal);
	} else {
		console.warn(`https://svelte.dev/e/ownership_invalid_mutation`);
	}
}

/**
 * The `value` property of a `<select multiple>` element should be an array, but it received a non-array value. The selection will be kept as is.
 */
function select_multiple_invalid_value() {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		console.warn(`%c[svelte] select_multiple_invalid_value\n%cThe \`value\` property of a \`<select multiple>\` element should be an array, but it received a non-array value. The selection will be kept as is.\nhttps://svelte.dev/e/select_multiple_invalid_value`, bold, normal);
	} else {
		console.warn(`https://svelte.dev/e/select_multiple_invalid_value`);
	}
}

/**
 * Reactive `$state(...)` proxies and the values they proxy have different identities. Because of this, comparisons with `%operator%` will produce unexpected results
 * @param {string} operator
 */
function state_proxy_equality_mismatch(operator) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		console.warn(`%c[svelte] state_proxy_equality_mismatch\n%cReactive \`$state(...)\` proxies and the values they proxy have different identities. Because of this, comparisons with \`${operator}\` will produce unexpected results\nhttps://svelte.dev/e/state_proxy_equality_mismatch`, bold, normal);
	} else {
		console.warn(`https://svelte.dev/e/state_proxy_equality_mismatch`);
	}
}

/**
 * Tried to unmount a state proxy, rather than a component
 */
function state_proxy_unmount() {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		console.warn(`%c[svelte] state_proxy_unmount\n%cTried to unmount a state proxy, rather than a component\nhttps://svelte.dev/e/state_proxy_unmount`, bold, normal);
	} else {
		console.warn(`https://svelte.dev/e/state_proxy_unmount`);
	}
}

/**
 * A `<svelte:boundary>` `reset` function only resets the boundary the first time it is called
 */
function svelte_boundary_reset_noop() {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		console.warn(`%c[svelte] svelte_boundary_reset_noop\n%cA \`<svelte:boundary>\` \`reset\` function only resets the boundary the first time it is called\nhttps://svelte.dev/e/svelte_boundary_reset_noop`, bold, normal);
	} else {
		console.warn(`https://svelte.dev/e/svelte_boundary_reset_noop`);
	}
}

/**
 * The `slide` transition does not work correctly for elements with `display: %value%`
 * @param {string} value
 */
function transition_slide_display(value) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		console.warn(`%c[svelte] transition_slide_display\n%cThe \`slide\` transition does not work correctly for elements with \`display: ${value}\`\nhttps://svelte.dev/e/transition_slide_display`, bold, normal);
	} else {
		console.warn(`https://svelte.dev/e/transition_slide_display`);
	}
}

}),
9987: 
/*!*************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/flags/index.js ***!
  \*************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  async_mode_flag: () => (async_mode_flag),
  enable_legacy_mode_flag: () => (enable_legacy_mode_flag),
  legacy_mode_flag: () => (legacy_mode_flag),
  tracing_mode_flag: () => (tracing_mode_flag)
});
let async_mode_flag = false;
let legacy_mode_flag = false;
let tracing_mode_flag = false;

function enable_async_mode_flag() {
	async_mode_flag = true;
}

/** ONLY USE THIS DURING TESTING */
function disable_async_mode_flag() {
	async_mode_flag = false;
}

function enable_legacy_mode_flag() {
	legacy_mode_flag = true;
}

function enable_tracing_mode_flag() {
	tracing_mode_flag = true;
}


}),
444: 
/*!**************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/shared/clone.js ***!
  \**************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  snapshot: () => (snapshot)
});
/* import */var esm_env__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! esm-env */ 3990);
/* import */var _warnings_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./warnings.js */ 3076);
/* import */var _utils_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./utils.js */ 2060);
/** @import { Snapshot } from './types' */




/**
 * In dev, we keep track of which properties could not be cloned. In prod
 * we don't bother, but we keep a dummy array around so that the
 * signature stays the same
 * @type {string[]}
 */
const empty = [];

/**
 * @template T
 * @param {T} value
 * @param {boolean} [skip_warning]
 * @param {boolean} [no_tojson]
 * @returns {Snapshot<T>}
 */
function snapshot(value, skip_warning = false, no_tojson = false) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV && !skip_warning) {
		/** @type {string[]} */
		const paths = [];

		const copy = clone(value, new Map(), '', paths, null, no_tojson);
		if (paths.length === 1 && paths[0] === '') {
			// value could not be cloned
			_warnings_js__WEBPACK_IMPORTED_MODULE_1__.state_snapshot_uncloneable();
		} else if (paths.length > 0) {
			// some properties could not be cloned
			const slice = paths.length > 10 ? paths.slice(0, 7) : paths.slice(0, 10);
			const excess = paths.length - slice.length;

			let uncloned = slice.map((path) => `- <value>${path}`).join('\n');
			if (excess > 0) uncloned += `\n- ...and ${excess} more`;

			_warnings_js__WEBPACK_IMPORTED_MODULE_1__.state_snapshot_uncloneable(uncloned);
		}

		return copy;
	}

	return clone(value, new Map(), '', empty, null, no_tojson);
}

/**
 * @template T
 * @param {T} value
 * @param {Map<T, Snapshot<T>>} cloned
 * @param {string} path
 * @param {string[]} paths
 * @param {null | T} [original] The original value, if `value` was produced from a `toJSON` call
 * @param {boolean} [no_tojson]
 * @returns {Snapshot<T>}
 */
function clone(value, cloned, path, paths, original = null, no_tojson = false) {
	if (typeof value === 'object' && value !== null) {
		var unwrapped = cloned.get(value);
		if (unwrapped !== undefined) return unwrapped;

		if (value instanceof Map) return /** @type {Snapshot<T>} */ (new Map(value));
		if (value instanceof Set) return /** @type {Snapshot<T>} */ (new Set(value));

		if ((0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.is_array)(value)) {
			var copy = /** @type {Snapshot<any>} */ (Array(value.length));
			cloned.set(value, copy);

			if (original !== null) {
				cloned.set(original, copy);
			}

			for (var i = 0; i < value.length; i += 1) {
				var element = value[i];
				if (i in value) {
					copy[i] = clone(element, cloned, esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV ? `${path}[${i}]` : path, paths, null, no_tojson);
				}
			}

			return copy;
		}

		if ((0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.get_prototype_of)(value) === _utils_js__WEBPACK_IMPORTED_MODULE_2__.object_prototype) {
			/** @type {Snapshot<any>} */
			copy = {};
			cloned.set(value, copy);

			if (original !== null) {
				cloned.set(original, copy);
			}

			for (var key in value) {
				copy[key] = clone(
					// @ts-expect-error
					value[key],
					cloned,
					esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV ? `${path}.${key}` : path,
					paths,
					null,
					no_tojson
				);
			}

			return copy;
		}

		if (value instanceof Date) {
			return /** @type {Snapshot<T>} */ (structuredClone(value));
		}

		if (typeof (/** @type {T & { toJSON?: any } } */ (value).toJSON) === 'function' && !no_tojson) {
			return clone(
				/** @type {T & { toJSON(): any } } */ (value).toJSON(),
				cloned,
				esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV ? `${path}.toJSON()` : path,
				paths,
				// Associate the instance with the toJSON clone
				value
			);
		}
	}

	if (value instanceof EventTarget) {
		// can't be cloned
		return /** @type {Snapshot<T>} */ (value);
	}

	try {
		return /** @type {Snapshot<T>} */ (structuredClone(value));
	} catch (e) {
		if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
			paths.push(path);
		}

		return /** @type {Snapshot<T>} */ (value);
	}
}


}),
4934: 
/*!***************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/shared/errors.js ***!
  \***************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  invalid_snippet_arguments: () => (invalid_snippet_arguments),
  lifecycle_outside_component: () => (lifecycle_outside_component),
  missing_context: () => (missing_context),
  snippet_without_render_tag: () => (snippet_without_render_tag),
  store_invalid_shape: () => (store_invalid_shape),
  svelte_element_invalid_this_value: () => (svelte_element_invalid_this_value)
});
/* import */var esm_env__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! esm-env */ 3990);
/* This file is generated by scripts/process-messages/index.js. Do not edit! */



/**
 * Cannot use `{@render children(...)}` if the parent component uses `let:` directives. Consider using a named snippet instead
 * @returns {never}
 */
function invalid_default_snippet() {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`invalid_default_snippet\nCannot use \`{@render children(...)}\` if the parent component uses \`let:\` directives. Consider using a named snippet instead\nhttps://svelte.dev/e/invalid_default_snippet`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/invalid_default_snippet`);
	}
}

/**
 * A snippet function was passed invalid arguments. Snippets should only be instantiated via `{@render ...}`
 * @returns {never}
 */
function invalid_snippet_arguments() {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`invalid_snippet_arguments\nA snippet function was passed invalid arguments. Snippets should only be instantiated via \`{@render ...}\`\nhttps://svelte.dev/e/invalid_snippet_arguments`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/invalid_snippet_arguments`);
	}
}

/**
 * `%name%(...)` can only be used during component initialisation
 * @param {string} name
 * @returns {never}
 */
function lifecycle_outside_component(name) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`lifecycle_outside_component\n\`${name}(...)\` can only be used during component initialisation\nhttps://svelte.dev/e/lifecycle_outside_component`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/lifecycle_outside_component`);
	}
}

/**
 * Context was not set in a parent component
 * @returns {never}
 */
function missing_context() {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`missing_context\nContext was not set in a parent component\nhttps://svelte.dev/e/missing_context`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/missing_context`);
	}
}

/**
 * Attempted to render a snippet without a `{@render}` block. This would cause the snippet code to be stringified instead of its content being rendered to the DOM. To fix this, change `{snippet}` to `{@render snippet()}`.
 * @returns {never}
 */
function snippet_without_render_tag() {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`snippet_without_render_tag\nAttempted to render a snippet without a \`{@render}\` block. This would cause the snippet code to be stringified instead of its content being rendered to the DOM. To fix this, change \`{snippet}\` to \`{@render snippet()}\`.\nhttps://svelte.dev/e/snippet_without_render_tag`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/snippet_without_render_tag`);
	}
}

/**
 * `%name%` is not a store with a `subscribe` method
 * @param {string} name
 * @returns {never}
 */
function store_invalid_shape(name) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`store_invalid_shape\n\`${name}\` is not a store with a \`subscribe\` method\nhttps://svelte.dev/e/store_invalid_shape`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/store_invalid_shape`);
	}
}

/**
 * The `this` prop on `<svelte:element>` must be a string, if defined
 * @returns {never}
 */
function svelte_element_invalid_this_value() {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		const error = new Error(`svelte_element_invalid_this_value\nThe \`this\` prop on \`<svelte:element>\` must be a string, if defined\nhttps://svelte.dev/e/svelte_element_invalid_this_value`);

		error.name = 'Svelte error';

		throw error;
	} else {
		throw new Error(`https://svelte.dev/e/svelte_element_invalid_this_value`);
	}
}

}),
2060: 
/*!**************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/shared/utils.js ***!
  \**************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  array_from: () => (array_from),
  array_prototype: () => (array_prototype),
  deferred: () => (deferred),
  define_property: () => (define_property),
  get_descriptor: () => (get_descriptor),
  get_descriptors: () => (get_descriptors),
  get_prototype_of: () => (get_prototype_of),
  index_of: () => (index_of),
  is_array: () => (is_array),
  is_extensible: () => (is_extensible),
  is_function: () => (is_function),
  is_promise: () => (is_promise),
  noop: () => (noop),
  object_keys: () => (object_keys),
  object_prototype: () => (object_prototype),
  run: () => (run),
  run_all: () => (run_all)
});
// Store the references to globals in case someone tries to monkey patch these, causing the below
// to de-opt (this occurs often when using popular extensions).
var is_array = Array.isArray;
var index_of = Array.prototype.indexOf;
var array_from = Array.from;
var object_keys = Object.keys;
var define_property = Object.defineProperty;
var get_descriptor = Object.getOwnPropertyDescriptor;
var get_descriptors = Object.getOwnPropertyDescriptors;
var object_prototype = Object.prototype;
var array_prototype = Array.prototype;
var get_prototype_of = Object.getPrototypeOf;
var is_extensible = Object.isExtensible;

/**
 * @param {any} thing
 * @returns {thing is Function}
 */
function is_function(thing) {
	return typeof thing === 'function';
}

const noop = () => {};

// Adapted from https://github.com/then/is-promise/blob/master/index.js
// Distributed under MIT License https://github.com/then/is-promise/blob/master/LICENSE

/**
 * @template [T=any]
 * @param {any} value
 * @returns {value is PromiseLike<T>}
 */
function is_promise(value) {
	return typeof value?.then === 'function';
}

/** @param {Function} fn */
function run(fn) {
	return fn();
}

/** @param {Array<() => void>} arr */
function run_all(arr) {
	for (var i = 0; i < arr.length; i++) {
		arr[i]();
	}
}

/**
 * TODO replace with Promise.withResolvers once supported widely enough
 * @template T
 */
function deferred() {
	/** @type {(value: T) => void} */
	var resolve;

	/** @type {(reason: any) => void} */
	var reject;

	/** @type {Promise<T>} */
	var promise = new Promise((res, rej) => {
		resolve = res;
		reject = rej;
	});

	// @ts-expect-error
	return { promise, resolve, reject };
}

/**
 * @template V
 * @param {V} value
 * @param {V | (() => V)} fallback
 * @param {boolean} [lazy]
 * @returns {V}
 */
function fallback(value, fallback, lazy = false) {
	return value === undefined
		? lazy
			? /** @type {() => V} */ (fallback)()
			: /** @type {V} */ (fallback)
		: value;
}

/**
 * When encountering a situation like `let [a, b, c] = $derived(blah())`,
 * we need to stash an intermediate value that `a`, `b`, and `c` derive
 * from, in case it's an iterable
 * @template T
 * @param {ArrayLike<T> | Iterable<T>} value
 * @param {number} [n]
 * @returns {Array<T>}
 */
function to_array(value, n) {
	// return arrays unchanged
	if (Array.isArray(value)) {
		return value;
	}

	// if value is not iterable, or `n` is unspecified (indicates a rest
	// element, which means we're not concerned about unbounded iterables)
	// convert to an array with `Array.from`
	if (n === undefined || !(Symbol.iterator in value)) {
		return Array.from(value);
	}

	// otherwise, populate an array with `n` values

	/** @type {T[]} */
	const array = [];

	for (const element of value) {
		array.push(element);
		if (array.length === n) break;
	}

	return array;
}


}),
987: 
/*!*****************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/shared/validate.js ***!
  \*****************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  prevent_snippet_stringification: () => (prevent_snippet_stringification)
});
/* import */var _utils_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../utils.js */ 9264);
/* import */var _warnings_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./warnings.js */ 3076);
/* import */var _errors_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./errors.js */ 4934);






/**
 * @param {() => string} tag_fn
 * @returns {void}
 */
function validate_void_dynamic_element(tag_fn) {
	const tag = tag_fn();
	if (tag && (0,_utils_js__WEBPACK_IMPORTED_MODULE_0__.is_void)(tag)) {
		_warnings_js__WEBPACK_IMPORTED_MODULE_1__.dynamic_void_element_content(tag);
	}
}

/** @param {() => unknown} tag_fn */
function validate_dynamic_element_tag(tag_fn) {
	const tag = tag_fn();
	const is_string = typeof tag === 'string';
	if (tag && !is_string) {
		_errors_js__WEBPACK_IMPORTED_MODULE_2__.svelte_element_invalid_this_value();
	}
}

/**
 * @param {any} store
 * @param {string} name
 */
function validate_store(store, name) {
	if (store != null && typeof store.subscribe !== 'function') {
		_errors_js__WEBPACK_IMPORTED_MODULE_2__.store_invalid_shape(name);
	}
}

/**
 * @template {(...args: any[]) => unknown} T
 * @param {T} fn
 */
function prevent_snippet_stringification(fn) {
	fn.toString = () => {
		_errors_js__WEBPACK_IMPORTED_MODULE_2__.snippet_without_render_tag();
		return '';
	};
	return fn;
}


}),
3076: 
/*!*****************************************************************!*\
  !*** ../../node_modules/svelte/src/internal/shared/warnings.js ***!
  \*****************************************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  dynamic_void_element_content: () => (dynamic_void_element_content),
  state_snapshot_uncloneable: () => (state_snapshot_uncloneable)
});
/* import */var esm_env__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! esm-env */ 3990);
/* This file is generated by scripts/process-messages/index.js. Do not edit! */



var bold = 'font-weight: bold';
var normal = 'font-weight: normal';

/**
 * `<svelte:element this="%tag%">` is a void element — it cannot have content
 * @param {string} tag
 */
function dynamic_void_element_content(tag) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		console.warn(`%c[svelte] dynamic_void_element_content\n%c\`<svelte:element this="${tag}">\` is a void element — it cannot have content\nhttps://svelte.dev/e/dynamic_void_element_content`, bold, normal);
	} else {
		console.warn(`https://svelte.dev/e/dynamic_void_element_content`);
	}
}

/**
 * The following properties cannot be cloned with `$state.snapshot` — the return value contains the originals:
 * 
 * %properties%
 * @param {string | undefined | null} [properties]
 */
function state_snapshot_uncloneable(properties) {
	if (esm_env__WEBPACK_IMPORTED_MODULE_0__.DEV) {
		console.warn(
			`%c[svelte] state_snapshot_uncloneable\n%c${properties
				? `The following properties cannot be cloned with \`$state.snapshot\` — the return value contains the originals:

${properties}`
				: 'Value cannot be cloned with `$state.snapshot` — the original value was returned'}\nhttps://svelte.dev/e/state_snapshot_uncloneable`,
			bold,
			normal
		);
	} else {
		console.warn(`https://svelte.dev/e/state_snapshot_uncloneable`);
	}
}

}),
9264: 
/*!**********************************************!*\
  !*** ../../node_modules/svelte/src/utils.js ***!
  \**********************************************/
(function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
"use strict";
__webpack_require__.d(__webpack_exports__, {
  can_delegate_event: () => (can_delegate_event),
  hash: () => (hash),
  is_capture_event: () => (is_capture_event),
  is_passive_event: () => (is_passive_event),
  is_raw_text_element: () => (is_raw_text_element),
  is_void: () => (is_void),
  normalize_attribute: () => (normalize_attribute),
  sanitize_location: () => (sanitize_location)
});
const regex_return_characters = /\r/g;

/**
 * @param {string} str
 * @returns {string}
 */
function hash(str) {
	str = str.replace(regex_return_characters, '');
	let hash = 5381;
	let i = str.length;

	while (i--) hash = ((hash << 5) - hash) ^ str.charCodeAt(i);
	return (hash >>> 0).toString(36);
}

const VOID_ELEMENT_NAMES = [
	'area',
	'base',
	'br',
	'col',
	'command',
	'embed',
	'hr',
	'img',
	'input',
	'keygen',
	'link',
	'meta',
	'param',
	'source',
	'track',
	'wbr'
];

/**
 * Returns `true` if `name` is of a void element
 * @param {string} name
 */
function is_void(name) {
	return VOID_ELEMENT_NAMES.includes(name) || name.toLowerCase() === '!doctype';
}

const RESERVED_WORDS = [
	'arguments',
	'await',
	'break',
	'case',
	'catch',
	'class',
	'const',
	'continue',
	'debugger',
	'default',
	'delete',
	'do',
	'else',
	'enum',
	'eval',
	'export',
	'extends',
	'false',
	'finally',
	'for',
	'function',
	'if',
	'implements',
	'import',
	'in',
	'instanceof',
	'interface',
	'let',
	'new',
	'null',
	'package',
	'private',
	'protected',
	'public',
	'return',
	'static',
	'super',
	'switch',
	'this',
	'throw',
	'true',
	'try',
	'typeof',
	'var',
	'void',
	'while',
	'with',
	'yield'
];

/**
 * Returns `true` if `word` is a reserved JavaScript keyword
 * @param {string} word
 */
function is_reserved(word) {
	return RESERVED_WORDS.includes(word);
}

/**
 * @param {string} name
 */
function is_capture_event(name) {
	return name.endsWith('capture') && name !== 'gotpointercapture' && name !== 'lostpointercapture';
}

/** List of Element events that will be delegated */
const DELEGATED_EVENTS = [
	'beforeinput',
	'click',
	'change',
	'dblclick',
	'contextmenu',
	'focusin',
	'focusout',
	'input',
	'keydown',
	'keyup',
	'mousedown',
	'mousemove',
	'mouseout',
	'mouseover',
	'mouseup',
	'pointerdown',
	'pointermove',
	'pointerout',
	'pointerover',
	'pointerup',
	'touchend',
	'touchmove',
	'touchstart'
];

/**
 * Returns `true` if `event_name` is a delegated event
 * @param {string} event_name
 */
function can_delegate_event(event_name) {
	return DELEGATED_EVENTS.includes(event_name);
}

/**
 * Attributes that are boolean, i.e. they are present or not present.
 */
const DOM_BOOLEAN_ATTRIBUTES = [
	'allowfullscreen',
	'async',
	'autofocus',
	'autoplay',
	'checked',
	'controls',
	'default',
	'disabled',
	'formnovalidate',
	'indeterminate',
	'inert',
	'ismap',
	'loop',
	'multiple',
	'muted',
	'nomodule',
	'novalidate',
	'open',
	'playsinline',
	'readonly',
	'required',
	'reversed',
	'seamless',
	'selected',
	'webkitdirectory',
	'defer',
	'disablepictureinpicture',
	'disableremoteplayback'
];

/**
 * Returns `true` if `name` is a boolean attribute
 * @param {string} name
 */
function is_boolean_attribute(name) {
	return DOM_BOOLEAN_ATTRIBUTES.includes(name);
}

/**
 * @type {Record<string, string>}
 * List of attribute names that should be aliased to their property names
 * because they behave differently between setting them as an attribute and
 * setting them as a property.
 */
const ATTRIBUTE_ALIASES = {
	// no `class: 'className'` because we handle that separately
	formnovalidate: 'formNoValidate',
	ismap: 'isMap',
	nomodule: 'noModule',
	playsinline: 'playsInline',
	readonly: 'readOnly',
	defaultvalue: 'defaultValue',
	defaultchecked: 'defaultChecked',
	srcobject: 'srcObject',
	novalidate: 'noValidate',
	allowfullscreen: 'allowFullscreen',
	disablepictureinpicture: 'disablePictureInPicture',
	disableremoteplayback: 'disableRemotePlayback'
};

/**
 * @param {string} name
 */
function normalize_attribute(name) {
	name = name.toLowerCase();
	return ATTRIBUTE_ALIASES[name] ?? name;
}

const DOM_PROPERTIES = [
	...DOM_BOOLEAN_ATTRIBUTES,
	'formNoValidate',
	'isMap',
	'noModule',
	'playsInline',
	'readOnly',
	'value',
	'volume',
	'defaultValue',
	'defaultChecked',
	'srcObject',
	'noValidate',
	'allowFullscreen',
	'disablePictureInPicture',
	'disableRemotePlayback'
];

/**
 * @param {string} name
 */
function is_dom_property(name) {
	return DOM_PROPERTIES.includes(name);
}

const NON_STATIC_PROPERTIES = ['autofocus', 'muted', 'defaultValue', 'defaultChecked'];

/**
 * Returns `true` if the given attribute cannot be set through the template
 * string, i.e. needs some kind of JavaScript handling to work.
 * @param {string} name
 */
function cannot_be_set_statically(name) {
	return NON_STATIC_PROPERTIES.includes(name);
}

/**
 * Subset of delegated events which should be passive by default.
 * These two are already passive via browser defaults on window, document and body.
 * But since
 * - we're delegating them
 * - they happen often
 * - they apply to mobile which is generally less performant
 * we're marking them as passive by default for other elements, too.
 */
const PASSIVE_EVENTS = ['touchstart', 'touchmove'];

/**
 * Returns `true` if `name` is a passive event
 * @param {string} name
 */
function is_passive_event(name) {
	return PASSIVE_EVENTS.includes(name);
}

const CONTENT_EDITABLE_BINDINGS = ['textContent', 'innerHTML', 'innerText'];

/** @param {string} name */
function is_content_editable_binding(name) {
	return CONTENT_EDITABLE_BINDINGS.includes(name);
}

const LOAD_ERROR_ELEMENTS = [
	'body',
	'embed',
	'iframe',
	'img',
	'link',
	'object',
	'script',
	'style',
	'track'
];

/**
 * Returns `true` if the element emits `load` and `error` events
 * @param {string} name
 */
function is_load_error_element(name) {
	return LOAD_ERROR_ELEMENTS.includes(name);
}

const SVG_ELEMENTS = [
	'altGlyph',
	'altGlyphDef',
	'altGlyphItem',
	'animate',
	'animateColor',
	'animateMotion',
	'animateTransform',
	'circle',
	'clipPath',
	'color-profile',
	'cursor',
	'defs',
	'desc',
	'discard',
	'ellipse',
	'feBlend',
	'feColorMatrix',
	'feComponentTransfer',
	'feComposite',
	'feConvolveMatrix',
	'feDiffuseLighting',
	'feDisplacementMap',
	'feDistantLight',
	'feDropShadow',
	'feFlood',
	'feFuncA',
	'feFuncB',
	'feFuncG',
	'feFuncR',
	'feGaussianBlur',
	'feImage',
	'feMerge',
	'feMergeNode',
	'feMorphology',
	'feOffset',
	'fePointLight',
	'feSpecularLighting',
	'feSpotLight',
	'feTile',
	'feTurbulence',
	'filter',
	'font',
	'font-face',
	'font-face-format',
	'font-face-name',
	'font-face-src',
	'font-face-uri',
	'foreignObject',
	'g',
	'glyph',
	'glyphRef',
	'hatch',
	'hatchpath',
	'hkern',
	'image',
	'line',
	'linearGradient',
	'marker',
	'mask',
	'mesh',
	'meshgradient',
	'meshpatch',
	'meshrow',
	'metadata',
	'missing-glyph',
	'mpath',
	'path',
	'pattern',
	'polygon',
	'polyline',
	'radialGradient',
	'rect',
	'set',
	'solidcolor',
	'stop',
	'svg',
	'switch',
	'symbol',
	'text',
	'textPath',
	'tref',
	'tspan',
	'unknown',
	'use',
	'view',
	'vkern'
];

/** @param {string} name */
function is_svg(name) {
	return SVG_ELEMENTS.includes(name);
}

const MATHML_ELEMENTS = [
	'annotation',
	'annotation-xml',
	'maction',
	'math',
	'merror',
	'mfrac',
	'mi',
	'mmultiscripts',
	'mn',
	'mo',
	'mover',
	'mpadded',
	'mphantom',
	'mprescripts',
	'mroot',
	'mrow',
	'ms',
	'mspace',
	'msqrt',
	'mstyle',
	'msub',
	'msubsup',
	'msup',
	'mtable',
	'mtd',
	'mtext',
	'mtr',
	'munder',
	'munderover',
	'semantics'
];

/** @param {string} name */
function is_mathml(name) {
	return MATHML_ELEMENTS.includes(name);
}

const STATE_CREATION_RUNES = /** @type {const} */ ([
	'$state',
	'$state.raw',
	'$derived',
	'$derived.by'
]);

const RUNES = /** @type {const} */ ([
	...STATE_CREATION_RUNES,
	'$state.eager',
	'$state.snapshot',
	'$props',
	'$props.id',
	'$bindable',
	'$effect',
	'$effect.pre',
	'$effect.tracking',
	'$effect.root',
	'$effect.pending',
	'$inspect',
	'$inspect().with',
	'$inspect.trace',
	'$host'
]);

/** @typedef {typeof RUNES[number]} RuneName */

/**
 * @param {string} name
 * @returns {name is RuneName}
 */
function is_rune(name) {
	return RUNES.includes(/** @type {RuneName} */ (name));
}

/** @typedef {typeof STATE_CREATION_RUNES[number]} StateCreationRuneName */

/**
 * @param {string} name
 * @returns {name is StateCreationRuneName}
 */
function is_state_creation_rune(name) {
	return STATE_CREATION_RUNES.includes(/** @type {StateCreationRuneName} */ (name));
}

/** List of elements that require raw contents and should not have SSR comments put in them */
const RAW_TEXT_ELEMENTS = /** @type {const} */ (['textarea', 'script', 'style', 'title']);

/** @param {string} name */
function is_raw_text_element(name) {
	return RAW_TEXT_ELEMENTS.includes(/** @type {typeof RAW_TEXT_ELEMENTS[number]} */ (name));
}

/**
 * Prevent devtools trying to make `location` a clickable link by inserting a zero-width space
 * @template {string | undefined} T
 * @param {T} location
 * @returns {T};
 */
function sanitize_location(location) {
	return /** @type {T} */ (location?.replace(/\//g, '/\u200b'));
}


}),

});
// The module cache
var __webpack_module_cache__ = {};

// The require function
function __webpack_require__(moduleId) {

// Check if module is in cache
var cachedModule = __webpack_module_cache__[moduleId];
if (cachedModule !== undefined) {
return cachedModule.exports;
}
// Create a new module (and put it into the cache)
var module = (__webpack_module_cache__[moduleId] = {
id: moduleId,
loaded: false,
exports: {}
});
// Execute the module function
var execOptions = { id: moduleId, module: module, factory: __webpack_modules__[moduleId], require: __webpack_require__ };
__webpack_require__.i.forEach(function(handler) { handler(execOptions); });
module = execOptions.module;
if (!execOptions.factory) {
  console.error("undefined factory", moduleId);
  throw Error("RuntimeError: factory is undefined (" + moduleId + ")");
}
execOptions.factory.call(module.exports, module, module.exports, execOptions.require);

// Flag the module as loaded
module.loaded = true;
// Return the exports of the module
return module.exports;

}

// expose the modules object (__webpack_modules__)
__webpack_require__.m = __webpack_modules__;

// expose the module cache
__webpack_require__.c = __webpack_module_cache__;

// expose the module execution interceptor
__webpack_require__.i = [];

// webpack/runtime/WebExtensionBrowserRuntime
(() => {
let isChrome, runtime;
try {
	if (typeof browser !== "undefined" && typeof browser.runtime?.getURL === "function") {
		runtime = browser;
	}
} catch (_) {}
if (!runtime) {
	try {
		if (typeof chrome !== "undefined" && typeof chrome.runtime?.getURL === "function") {
			isChrome = true;
			runtime = chrome;
		}
	} catch (_) {}
}
__webpack_require__.webExtRtModern = !isChrome;
__webpack_require__.webExtRt = runtime || {
	get runtime() {
		throw new Error("No chrome or browser runtime found");
	}
}
if (!runtime && (typeof self !== "object" || !self.addEventListener)) {
	__webpack_require__.webExtRt = { runtime: { getURL: String } };
}
})();
// webpack/runtime/compat_get_default_export
(() => {
// getDefaultExport function for compatibility with non-ESM modules
__webpack_require__.n = (module) => {
	var getter = module && module.__esModule ?
		() => (module['default']) :
		() => (module);
	__webpack_require__.d(getter, { a: getter });
	return getter;
};

})();
// webpack/runtime/define_property_getters
(() => {
__webpack_require__.d = (exports, definition) => {
	for(var key in definition) {
        if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
            Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
        }
    }
};
})();
// webpack/runtime/get css chunk filename
(() => {
// This function allow to reference chunks
__webpack_require__.k = (chunkId) => {
  // return url for filenames not based on template
  
  // return url for filenames based on template
  return "" + chunkId + ".css"
}
})();
// webpack/runtime/get_chunk_update_filename
(() => {
__webpack_require__.hu = (chunkId) => ('hot/' + chunkId + '.' + __webpack_require__.h() + '.js')
})();
// webpack/runtime/get_full_hash
(() => {
__webpack_require__.h = () => ("c93d2012805a52db")
})();
// webpack/runtime/get_main_filename/update manifest
(() => {
__webpack_require__.hmrF = function () {
            return "hot/content_scripts/content-0." + __webpack_require__.h() + ".json";
         };
        
})();
// webpack/runtime/has_own_property
(() => {
__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
})();
// webpack/runtime/hot_module_replacement
(() => {
var currentModuleData = {};
var installedModules = __webpack_require__.c;

// module and require creation
var currentChildModule;
var currentParents = [];

// status
var registeredStatusHandlers = [];
var currentStatus = "idle";

// while downloading
var blockingPromises = 0;
var blockingPromisesWaiting = [];

// The update info
var currentUpdateApplyHandlers;
var queuedInvalidatedModules;

__webpack_require__.hmrD = currentModuleData;
__webpack_require__.i.push(function (options) {
	var module = options.module;
	var require = createRequire(options.require, options.id);
	module.hot = createModuleHotObject(options.id, module);
	module.parents = currentParents;
	module.children = [];
	currentParents = [];
	options.require = require;
});

__webpack_require__.hmrC = {};
__webpack_require__.hmrI = {};

function createRequire(require, moduleId) {
	var me = installedModules[moduleId];
	if (!me) return require;
	var fn = function (request) {
		if (me.hot.active) {
			if (installedModules[request]) {
				var parents = installedModules[request].parents;
				if (parents.indexOf(moduleId) === -1) {
					parents.push(moduleId);
				}
			} else {
				currentParents = [moduleId];
				currentChildModule = request;
			}
			if (me.children.indexOf(request) === -1) {
				me.children.push(request);
			}
		} else {
			console.warn(
				"[HMR] unexpected require(" +
				request +
				") from disposed module " +
				moduleId
			);
			currentParents = [];
		}
		return require(request);
	};
	var createPropertyDescriptor = function (name) {
		return {
			configurable: true,
			enumerable: true,
			get: function () {
				return require[name];
			},
			set: function (value) {
				require[name] = value;
			}
		};
	};
	for (var name in require) {
		if (Object.prototype.hasOwnProperty.call(require, name) && name !== "e") {
			Object.defineProperty(fn, name, createPropertyDescriptor(name));
		}
	}

	fn.e = function (chunkId, fetchPriority) {
		return trackBlockingPromise(require.e(chunkId, fetchPriority));
	};

	return fn;
}

function createModuleHotObject(moduleId, me) {
	var _main = currentChildModule !== moduleId;
	var hot = {
		_acceptedDependencies: {},
		_acceptedErrorHandlers: {},
		_declinedDependencies: {},
		_selfAccepted: false,
		_selfDeclined: false,
		_selfInvalidated: false,
		_disposeHandlers: [],
		_main: _main,
		_requireSelf: function () {
			currentParents = me.parents.slice();
			currentChildModule = _main ? undefined : moduleId;
			__webpack_require__(moduleId);
		},
		active: true,
		accept: function (dep, callback, errorHandler) {
			if (dep === undefined) hot._selfAccepted = true;
			else if (typeof dep === "function") hot._selfAccepted = dep;
			else if (typeof dep === "object" && dep !== null) {
				for (var i = 0; i < dep.length; i++) {
					hot._acceptedDependencies[dep[i]] = callback || function () { };
					hot._acceptedErrorHandlers[dep[i]] = errorHandler;
				}
			} else {
				hot._acceptedDependencies[dep] = callback || function () { };
				hot._acceptedErrorHandlers[dep] = errorHandler;
			}
		},
		decline: function (dep) {
			if (dep === undefined) hot._selfDeclined = true;
			else if (typeof dep === "object" && dep !== null)
				for (var i = 0; i < dep.length; i++)
					hot._declinedDependencies[dep[i]] = true;
			else hot._declinedDependencies[dep] = true;
		},
		dispose: function (callback) {
			hot._disposeHandlers.push(callback);
		},
		addDisposeHandler: function (callback) {
			hot._disposeHandlers.push(callback);
		},
		removeDisposeHandler: function (callback) {
			var idx = hot._disposeHandlers.indexOf(callback);
			if (idx >= 0) hot._disposeHandlers.splice(idx, 1);
		},
		invalidate: function () {
			this._selfInvalidated = true;
			switch (currentStatus) {
				case "idle":
					currentUpdateApplyHandlers = [];
					Object.keys(__webpack_require__.hmrI).forEach(function (key) {
						__webpack_require__.hmrI[key](moduleId, currentUpdateApplyHandlers);
					});
					setStatus("ready");
					break;
				case "ready":
					Object.keys(__webpack_require__.hmrI).forEach(function (key) {
						__webpack_require__.hmrI[key](moduleId, currentUpdateApplyHandlers);
					});
					break;
				case "prepare":
				case "check":
				case "dispose":
				case "apply":
					(queuedInvalidatedModules = queuedInvalidatedModules || []).push(
						moduleId
					);
					break;
				default:
					break;
			}
		},
		check: hotCheck,
		apply: hotApply,
		status: function (l) {
			if (!l) return currentStatus;
			registeredStatusHandlers.push(l);
		},
		addStatusHandler: function (l) {
			registeredStatusHandlers.push(l);
		},
		removeStatusHandler: function (l) {
			var idx = registeredStatusHandlers.indexOf(l);
			if (idx >= 0) registeredStatusHandlers.splice(idx, 1);
		},
		data: currentModuleData[moduleId]
	};
	currentChildModule = undefined;
	return hot;
}

function setStatus(newStatus) {
	currentStatus = newStatus; 
	var results = [];
	for (var i = 0; i < registeredStatusHandlers.length; i++)
		results[i] = registeredStatusHandlers[i].call(null, newStatus);

	return Promise.all(results).then(function () { });
}

function unblock() {
	if (--blockingPromises === 0) {
		setStatus("ready").then(function () {
			if (blockingPromises === 0) {
				var list = blockingPromisesWaiting;
				blockingPromisesWaiting = [];
				for (var i = 0; i < list.length; i++) {
					list[i]();
				}
			}
		});
	}
}

function trackBlockingPromise(promise) {
	switch (currentStatus) {
		case "ready":
			setStatus("prepare");
		case "prepare":
			blockingPromises++;
			promise.then(unblock, unblock);
			return promise;
		default:
			return promise;
	}
}

function waitForBlockingPromises(fn) {
	if (blockingPromises === 0) return fn();
	return new Promise(function (resolve) {
		blockingPromisesWaiting.push(function () {
			resolve(fn());
		});
	});
}

function hotCheck(applyOnUpdate) {
	if (currentStatus !== "idle") {
		throw new Error("check() is only allowed in idle status");
	} 
	return setStatus("check")
		.then(__webpack_require__.hmrM)
		.then(function (update) {
			if (!update) {
				return setStatus(applyInvalidatedModules() ? "ready" : "idle").then(
					function () {
						return null;
					}
				);
			}

			return setStatus("prepare").then(function () {
				var updatedModules = [];
				currentUpdateApplyHandlers = [];

				return Promise.all(
					Object.keys(__webpack_require__.hmrC).reduce(function (
						promises,
						key
					) {
						__webpack_require__.hmrC[key](
							update.c,
							update.r,
							update.m,
							promises,
							currentUpdateApplyHandlers,
							updatedModules
						);
						return promises;
					},
						[])
				).then(function () {
					return waitForBlockingPromises(function () {
						if (applyOnUpdate) {
							return internalApply(applyOnUpdate);
						}
						return setStatus("ready").then(function () {
							return updatedModules;
						});
					});
				});
			});
		});
}

function hotApply(options) {
	if (currentStatus !== "ready") {
		return Promise.resolve().then(function () {
			throw new Error(
				"apply() is only allowed in ready status (state: " + currentStatus + ")"
			);
		});
	}
	return internalApply(options);
}

function internalApply(options) {
	options = options || {};
	applyInvalidatedModules();
	var results = currentUpdateApplyHandlers.map(function (handler) {
		return handler(options);
	});
	currentUpdateApplyHandlers = undefined;
	var errors = results
		.map(function (r) {
			return r.error;
		})
		.filter(Boolean);

	if (errors.length > 0) {
		return setStatus("abort").then(function () {
			throw errors[0];
		});
	}

	var disposePromise = setStatus("dispose");

	results.forEach(function (result) {
		if (result.dispose) result.dispose();
	});

	var applyPromise = setStatus("apply");

	var error;
	var reportError = function (err) {
		if (!error) error = err;
	};

	var outdatedModules = [];
	results.forEach(function (result) {
		if (result.apply) {
			var modules = result.apply(reportError);
			if (modules) {
				for (var i = 0; i < modules.length; i++) {
					outdatedModules.push(modules[i]);
				}
			}
		}
	});

	return Promise.all([disposePromise, applyPromise]).then(function () {
		if (error) {
			return setStatus("fail").then(function () {
				throw error;
			});
		}

		if (queuedInvalidatedModules) {
			return internalApply(options).then(function (list) {
				outdatedModules.forEach(function (moduleId) {
					if (list.indexOf(moduleId) < 0) list.push(moduleId);
				});
				return list;
			});
		}

		return setStatus("idle").then(function () {
			return outdatedModules;
		});
	});
}

function applyInvalidatedModules() {
	if (queuedInvalidatedModules) {
		if (!currentUpdateApplyHandlers) currentUpdateApplyHandlers = [];
		Object.keys(__webpack_require__.hmrI).forEach(function (key) {
			queuedInvalidatedModules.forEach(function (moduleId) {
				__webpack_require__.hmrI[key](moduleId, currentUpdateApplyHandlers);
			});
		});
		queuedInvalidatedModules = undefined;
		return true;
	}
}

})();
// webpack/runtime/load_script
(() => {
var inProgress = {};

var dataWebpackPrefix = "@extension-js/svelte:";
// loadScript function to load a script via script tag
__webpack_require__.l = function (url, done, key, chunkId) {
	if (inProgress[url]) {
		inProgress[url].push(done);
		return;
	}
	var script, needAttach;
	if (key !== undefined) {
		var scripts = document.getElementsByTagName("script");
		for (var i = 0; i < scripts.length; i++) {
			var s = scripts[i];
			if (s.getAttribute("src") == url || s.getAttribute("data-webpack") == dataWebpackPrefix + key) {
				script = s;
				break;
			}
		}
	}
	if (!script) {
		needAttach = true;
		
    script = document.createElement('script');
    
		
		script.timeout = 120;
		if (__webpack_require__.nc) {
			script.setAttribute("nonce", __webpack_require__.nc);
		}
		script.setAttribute("data-webpack", dataWebpackPrefix + key);
		
		script.src = url;
		
    
	}
	inProgress[url] = [done];
	var onScriptComplete = function (prev, event) {
		script.onerror = script.onload = null;
		clearTimeout(timeout);
		var doneFns = inProgress[url];
		delete inProgress[url];
		script.parentNode && script.parentNode.removeChild(script);
		doneFns &&
			doneFns.forEach(function (fn) {
				return fn(event);
			});
		if (prev) return prev(event);
	};
	var timeout = setTimeout(
		onScriptComplete.bind(null, undefined, {
			type: 'timeout',
			target: script
		}),
		120000
	);
	script.onerror = onScriptComplete.bind(null, script.onerror);
	script.onload = onScriptComplete.bind(null, script.onload);
	needAttach && document.head.appendChild(script);
};

})();
// webpack/runtime/make_namespace_object
(() => {
// define __esModule on exports
__webpack_require__.r = (exports) => {
	if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
		Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
	}
	Object.defineProperty(exports, '__esModule', { value: true });
};
})();
// webpack/runtime/node_module_decorator
(() => {
__webpack_require__.nmd = (module) => {
  module.paths = [];
  if (!module.children) module.children = [];
  return module;
};
})();
// webpack/runtime/public_path
(() => {
__webpack_require__.p = "/";
})();
// webpack/runtime/rspack_version
(() => {
__webpack_require__.rv = () => ("1.6.3")
})();
// webpack/runtime/load script
(() => {
let bug816121warned, isNotIframe;
try {
	isNotIframe = typeof window === "object" ? window.top === window : true;
} catch(e) {
	isNotIframe = false /* CORS error */;
}
const classicLoader = (url, done) => {
	const msg = { type: "WTW_INJECT", file: url };
	const onError = (e) => {
		done(Object.assign(e, { type: "missing" }))
	};
	if (__webpack_require__.webExtRtModern) {
		__webpack_require__.webExtRt.runtime.sendMessage(msg).then(done, onError);
	} else {
		__webpack_require__.webExtRt.runtime.sendMessage(msg, () => {
			const error = __webpack_require__.webExtRt.runtime.lastError;
			if (error) onError(error);
			else done();
		});
	}
};
const dynamicImportLoader = (url, done, key, chunkId) => {
	import(url).then(() => {
		if (isNotIframe) return done();
		try {
			// It's a Chrome bug, if the import() is called in a sandboxed iframe, it _fails_ the script loading but _resolve_ the Promise.
			// we call __webpack_require__.f.j(chunkId) to check if it is loaded.
			// if it is, this is a no-op. if it is not, it will throw a TypeError because this function requires 2 parameters.
			// This call will not trigger the chunk loading because it is already loading.
			// see https://github.com/awesome-webextension/webpack-target-webextension/issues/41
			chunkId !== undefined && __webpack_require__.f.j(chunkId);
			done();
		}
		catch (_) {
			if (!bug816121warned) {
				console.warn("Chrome bug https://crbug.com/816121 hit.");
				bug816121warned = true;
			}
			return fallbackLoader(url, done, key, chunkId);
		}
	}, (e) => {
		console.warn("Dynamic import loader failed. Using fallback loader (see https://github.com/awesome-webextension/webpack-target-webextension#content-script).", e);
		fallbackLoader(url, done, key, chunkId);
	});
}
const scriptLoader = (url, done) => {
	const script = document.createElement('script');
	script.src = url;
	script.onload = done;
	script.onerror = done;
	document.body.appendChild(script);
}
const workerLoader = (url, done) => {
	try {
		importScripts(url);
		done();
	} catch (e) {
		done(e);
	}
}
const isWorker = typeof importScripts === 'function'
if (typeof location === 'object' && location.protocol.includes('-extension:')) {
	__webpack_require__.l = isWorker ? workerLoader : scriptLoader;
}
else if (!isWorker) __webpack_require__.l = classicLoader;
else { throw new TypeError('Unable to determinate the chunk loader: content script + Worker'); }
const fallbackLoader = __webpack_require__.l;
__webpack_require__.l = dynamicImportLoader;
})();
// webpack/runtime/publicPath
(() => {
if (__webpack_require__.webExtRt) {
	__webpack_require__.p = __webpack_require__.webExtRt.runtime.getURL("/");
}
})();
// webpack/runtime/css_loading
(() => {
var installedChunks = {};
var uniqueName = "@extension-js/svelte";
function handleCssComposes(exports, composes) {
	for (var i = 0; i < composes.length; i += 3) {
		var moduleId = composes[i];
		var composeFrom = composes[i + 1];
		var composeVar = composes[i + 2];
		var composedId = __webpack_require__(composeFrom)[composeVar];
		exports[moduleId] = exports[moduleId] + " " + composedId
	}
}
var loadCssChunkData = (target, chunkId) => {
var moduleIds = [];
if(target == __webpack_require__.m)
installedChunks[chunkId] = 0;
return moduleIds
} 
var loadingAttribute = "data-webpack-loading";
var loadStylesheet = (chunkId, url, done, hmr, fetchPriority) => {
	var link,
		needAttach,
		key = "chunk-" + chunkId;
	if (!hmr) {
		var links = document.getElementsByTagName("link");
		for (var i = 0; i < links.length; i++) {
			var l = links[i];
			var href = l.getAttribute("href") || l.href;
			if (href && !href.startsWith(__webpack_require__.p)) {
				href =
					__webpack_require__.p + (href.startsWith("/") ? href.slice(1) : href);
			}
			if (
				l.rel == "stylesheet" &&
				((href && href.startsWith(url)) ||
					l.getAttribute("data-webpack") == uniqueName + ":" + key)
			) {
				link = l;
				break;
			}
		}
		if (!done) return link;
	}
	if (!link) {
		needAttach = true;
		link = document.createElement("link");
		if (__webpack_require__.nc) {
			link.setAttribute("nonce", __webpack_require__.nc);
		}
		link.setAttribute("data-webpack", uniqueName + ":" + key);
		if (fetchPriority) {
			link.setAttribute("fetchpriority", fetchPriority);
		}
		link.setAttribute(loadingAttribute, 1);
		link.rel = "stylesheet";
		link.href = url;

		
	}
	var onLinkComplete = (prev, event) => {
		link.onerror = link.onload = null;
		link.removeAttribute(loadingAttribute);
		clearTimeout(timeout);
		if (event && event.type != "load") link.parentNode.removeChild(link);
		done(event);
		if (prev) return prev(event);
	};
	if (link.getAttribute(loadingAttribute)) {
		var timeout = setTimeout(
			onLinkComplete.bind(null, undefined, { type: "timeout", target: link }),
			120000 
		);
		link.onerror = onLinkComplete.bind(null, link.onerror);
		link.onload = onLinkComplete.bind(null, link.onload);
	} else onLinkComplete(undefined, { type: "load", target: link });
	if (hmr && hmr.getAttribute("fetchpriority")) link.setAttribute("fetchpriority", hmr.getAttribute("fetchpriority"));
	hmr ? document.head.insertBefore(link, hmr) : needAttach && document.head.appendChild(link);
	return link;
};
// no initial css
var oldTags = [];
var newTags = [];
var applyHandler = (options) => {
	return {
		dispose: () => { },
		apply: () => {
			var moduleIds = [];
			newTags.forEach((info) => {
				info[1].sheet.disabled = false;
			});
			while (oldTags.length) {
				var oldTag = oldTags.pop();
				if (oldTag.parentNode) oldTag.parentNode.removeChild(oldTag);
			}
			while (newTags.length) {
				var info = newTags.pop();
				var chunkModuleIds = loadCssChunkData(__webpack_require__.m, info[0]);
				chunkModuleIds.forEach(function(id) {
				    moduleIds.push(id)
				});
			}
			return moduleIds;
		}
	};
};
var cssTextKey = (link) => {
	return Array.from(link.sheet.cssRules, (r) => (r.cssText)).join();
};
__webpack_require__.hmrC.css = (chunkIds, removedChunks, removedModules, promises, applyHandlers, updatedModulesList) => {
	if (typeof document === 'undefined') return;
	applyHandlers.push(applyHandler);
	chunkIds.forEach((chunkId) => {
		var filename = __webpack_require__.k(chunkId);
		var url = __webpack_require__.p + filename;
		var oldTag = loadStylesheet(chunkId, url);
		if (!oldTag) return;
		promises.push(
			new Promise((resolve, reject) => {
				var link = loadStylesheet(
					chunkId,
					url + (url.indexOf("?") < 0 ? "?" : "&") + "hmr=" + Date.now(),
					(event) => {
						if (event.type !== "load") {
							var error = new Error();
							var errorType = event && event.type;
							var realSrc = event && event.target && event.target.src;
							error.message =
								"Loading css hot update chunk " +
								chunkId +
								" failed.\n(" +
								errorType +
								": " +
								realSrc +
								")";
							error.name = "ChunkLoadError";
							error.type = errorType;
							error.request = realSrc;
							reject(error);
						} else {
							try {
								if (cssTextKey(oldTag) == cssTextKey(link)) {
									if (link.parentNode) link.parentNode.removeChild(link);
									return resolve();
								}
							} catch (e) {}
							var factories = {};
							loadCssChunkData(factories, link, chunkId);
							Object.keys(factories).forEach(function(id) {
							    (updatedModulesList.push(id));
							});
							link.sheet.disabled = true;
							oldTags.push(oldTag);
							newTags.push([chunkId, link]);
							resolve();
						}
					},
					oldTag
				);
			})
		);
	});
};

})();
// webpack/runtime/jsonp_chunk_loading
(() => {
__webpack_require__.b = document.baseURI || self.location.href;

      // object to store loaded and loading chunks
      // undefined = chunk not loaded, null = chunk preloaded/prefetched
      // [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
      var installedChunks = __webpack_require__.hmrS_jsonp = __webpack_require__.hmrS_jsonp || {"343": 0,};
      var currentUpdatedModulesList;
var waitingUpdateResolves = {};
function loadUpdateChunk(chunkId, updatedModulesList) {
	currentUpdatedModulesList = updatedModulesList;
	return new Promise((resolve, reject) => {
		waitingUpdateResolves[chunkId] = resolve;
		// start update chunk loading
		var url = __webpack_require__.p + __webpack_require__.hu(chunkId);
		// create error before stack unwound to get useful stacktrace later
		var error = new Error();
		var loadingEnded = (event) => {
			if (waitingUpdateResolves[chunkId]) {
				waitingUpdateResolves[chunkId] = undefined;
				var errorType =
					event && (event.type === 'load' ? 'missing' : event.type);
				var realSrc = event && event.target && event.target.src;
				error.message =
					'Loading hot update chunk ' +
					chunkId +
					' failed.\n(' +
					errorType +
					': ' +
					realSrc +
					')';
				error.name = 'ChunkLoadError';
				error.type = errorType;
				error.request = realSrc;
				reject(error);
			}
		};
		__webpack_require__.l(url, loadingEnded);
	});
}

self["webpackHotUpdate_extension_js_svelte"] = (chunkId, moreModules, runtime) => {
	for (var moduleId in moreModules) {
		if (__webpack_require__.o(moreModules, moduleId)) {
			currentUpdate[moduleId] = moreModules[moduleId];
			if (currentUpdatedModulesList) currentUpdatedModulesList.push(moduleId);
		}
	}
	if (runtime) currentUpdateRuntime.push(runtime);
	if (waitingUpdateResolves[chunkId]) {
		waitingUpdateResolves[chunkId]();
		waitingUpdateResolves[chunkId] = undefined;
	}
};
var currentUpdateChunks;
var currentUpdate;
var currentUpdateRemovedChunks;
var currentUpdateRuntime;
function applyHandler(options) {
	if (__webpack_require__.f) delete __webpack_require__.f.jsonpHmr;
	currentUpdateChunks = undefined;
	function getAffectedModuleEffects(updateModuleId) {
		var outdatedModules = [updateModuleId];
		var outdatedDependencies = {};
		var queue = outdatedModules.map(function (id) {
			return {
				chain: [id],
				id: id
			};
		});
		while (queue.length > 0) {
			var queueItem = queue.pop();
			var moduleId = queueItem.id;
			var chain = queueItem.chain;
			var module = __webpack_require__.c[moduleId];
			if (
				!module ||
				(module.hot._selfAccepted && !module.hot._selfInvalidated)
			) {
				continue;
			}

			if (module.hot._selfDeclined) {
				return {
					type: "self-declined",
					chain: chain,
					moduleId: moduleId
				};
			}

			if (module.hot._main) {
				return {
					type: "unaccepted",
					chain: chain,
					moduleId: moduleId
				};
			}

			for (var i = 0; i < module.parents.length; i++) {
				var parentId = module.parents[i];
				var parent = __webpack_require__.c[parentId];
				if (!parent) {
					continue;
				}
				if (parent.hot._declinedDependencies[moduleId]) {
					return {
						type: "declined",
						chain: chain.concat([parentId]),
						moduleId: moduleId,
						parentId: parentId
					};
				}
				if (outdatedModules.indexOf(parentId) !== -1) {
					continue;
				}
				if (parent.hot._acceptedDependencies[moduleId]) {
					if (!outdatedDependencies[parentId]) {
						outdatedDependencies[parentId] = [];
					}
					addAllToSet(outdatedDependencies[parentId], [moduleId]);
					continue;
				}
				delete outdatedDependencies[parentId];
				outdatedModules.push(parentId);
				queue.push({
					chain: chain.concat([parentId]),
					id: parentId
				});
			}
		}

		return {
			type: "accepted",
			moduleId: updateModuleId,
			outdatedModules: outdatedModules,
			outdatedDependencies: outdatedDependencies
		};
	}

	function addAllToSet(a, b) {
		for (var i = 0; i < b.length; i++) {
			var item = b[i];
			if (a.indexOf(item) === -1) a.push(item);
		}
	}

	var outdatedDependencies = {};
	var outdatedModules = [];
	var appliedUpdate = {};

	var warnUnexpectedRequire = function warnUnexpectedRequire(module) {
		console.warn(
			"[HMR] unexpected require(" + module.id + ") to disposed module"
		);
		throw Error("RuntimeError: factory is undefined(" + module.id + ")");
	};

	for (var moduleId in currentUpdate) {
		if (__webpack_require__.o(currentUpdate, moduleId)) {
			var newModuleFactory = currentUpdate[moduleId];
			var result = newModuleFactory ? getAffectedModuleEffects(moduleId) : {
				type: "disposed",
				moduleId: moduleId
			};
			var abortError = false;
			var doApply = false;
			var doDispose = false;
			var chainInfo = "";
			if (result.chain) {
				chainInfo = "\nUpdate propagation: " + result.chain.join(" -> ");
			}
			switch (result.type) {
				case "self-declined":
					if (options.onDeclined) options.onDeclined(result);
					if (!options.ignoreDeclined)
						abortError = new Error(
							"Aborted because of self decline: " + result.moduleId + chainInfo
						);
					break;
				case "declined":
					if (options.onDeclined) options.onDeclined(result);
					if (!options.ignoreDeclined)
						abortError = new Error(
							"Aborted because of declined dependency: " +
							result.moduleId +
							" in " +
							result.parentId +
							chainInfo
						);
					break;
				case "unaccepted":
					if (options.onUnaccepted) options.onUnaccepted(result);
					if (!options.ignoreUnaccepted)
						abortError = new Error(
							"Aborted because " + moduleId + " is not accepted" + chainInfo
						);
					break;
				case "accepted":
					if (options.onAccepted) options.onAccepted(result);
					doApply = true;
					break;
				case "disposed":
					if (options.onDisposed) options.onDisposed(result);
					doDispose = true;
					break;
				default:
					throw new Error("Unexception type " + result.type);
			}
			if (abortError) {
				return {
					error: abortError
				};
			}
			if (doApply) {
				appliedUpdate[moduleId] = newModuleFactory;
				addAllToSet(outdatedModules, result.outdatedModules);
				for (moduleId in result.outdatedDependencies) {
					if (__webpack_require__.o(result.outdatedDependencies, moduleId)) {
						if (!outdatedDependencies[moduleId])
							outdatedDependencies[moduleId] = [];
						addAllToSet(
							outdatedDependencies[moduleId],
							result.outdatedDependencies[moduleId]
						);
					}
				}
			}
			if (doDispose) {
				addAllToSet(outdatedModules, [result.moduleId]);
				appliedUpdate[moduleId] = warnUnexpectedRequire;
			}
		}
	}
	currentUpdate = undefined;

	var outdatedSelfAcceptedModules = [];
	for (var j = 0; j < outdatedModules.length; j++) {
		var outdatedModuleId = outdatedModules[j];
		var module = __webpack_require__.c[outdatedModuleId];
		if (
			module &&
			(module.hot._selfAccepted || module.hot._main) &&
			// removed self-accepted modules should not be required
			appliedUpdate[outdatedModuleId] !== warnUnexpectedRequire &&
			// when called invalidate self-accepting is not possible
			!module.hot._selfInvalidated
		) {
			outdatedSelfAcceptedModules.push({
				module: outdatedModuleId,
				require: module.hot._requireSelf,
				errorHandler: module.hot._selfAccepted
			});
		}
	} 

	var moduleOutdatedDependencies;
	return {
		dispose: function () {
			currentUpdateRemovedChunks.forEach(function (chunkId) {
				delete installedChunks[chunkId];
			});
			currentUpdateRemovedChunks = undefined;

			var idx;
			var queue = outdatedModules.slice();
			while (queue.length > 0) {
				var moduleId = queue.pop();
				var module = __webpack_require__.c[moduleId];
				if (!module) continue;

				var data = {};

				// Call dispose handlers
				var disposeHandlers = module.hot._disposeHandlers; 
				for (j = 0; j < disposeHandlers.length; j++) {
					disposeHandlers[j].call(null, data);
				}
				__webpack_require__.hmrD[moduleId] = data;

				module.hot.active = false;

				delete __webpack_require__.c[moduleId];

				delete outdatedDependencies[moduleId];

				for (j = 0; j < module.children.length; j++) {
					var child = __webpack_require__.c[module.children[j]];
					if (!child) continue;
					idx = child.parents.indexOf(moduleId);
					if (idx >= 0) {
						child.parents.splice(idx, 1);
					}
				}
			}

			var dependency;
			for (var outdatedModuleId in outdatedDependencies) {
				if (__webpack_require__.o(outdatedDependencies, outdatedModuleId)) {
					module = __webpack_require__.c[outdatedModuleId];
					if (module) {
						moduleOutdatedDependencies = outdatedDependencies[outdatedModuleId];
						for (j = 0; j < moduleOutdatedDependencies.length; j++) {
							dependency = moduleOutdatedDependencies[j];
							idx = module.children.indexOf(dependency);
							if (idx >= 0) module.children.splice(idx, 1);
						}
					}
				}
			}
		},
		apply: function (reportError) {
			// insert new code
			for (var updateModuleId in appliedUpdate) {
				if (__webpack_require__.o(appliedUpdate, updateModuleId)) {
					__webpack_require__.m[updateModuleId] = appliedUpdate[updateModuleId]; 
				}
			}

			// run new runtime modules
			for (var i = 0; i < currentUpdateRuntime.length; i++) {
				currentUpdateRuntime[i](__webpack_require__);
			}

			// call accept handlers
			for (var outdatedModuleId in outdatedDependencies) {
				if (__webpack_require__.o(outdatedDependencies, outdatedModuleId)) {
					var module = __webpack_require__.c[outdatedModuleId];
					if (module) {
						moduleOutdatedDependencies = outdatedDependencies[outdatedModuleId];
						var callbacks = [];
						var errorHandlers = [];
						var dependenciesForCallbacks = [];
						for (var j = 0; j < moduleOutdatedDependencies.length; j++) {
							var dependency = moduleOutdatedDependencies[j];
							var acceptCallback = module.hot._acceptedDependencies[dependency];
							var errorHandler = module.hot._acceptedErrorHandlers[dependency];
							if (acceptCallback) {
								if (callbacks.indexOf(acceptCallback) !== -1) continue;
								callbacks.push(acceptCallback);
								errorHandlers.push(errorHandler); 
								dependenciesForCallbacks.push(dependency);
							}
						}
						for (var k = 0; k < callbacks.length; k++) {
							try {
								callbacks[k].call(null, moduleOutdatedDependencies);
							} catch (err) {
								if (typeof errorHandlers[k] === "function") {
									try {
										errorHandlers[k](err, {
											moduleId: outdatedModuleId,
											dependencyId: dependenciesForCallbacks[k]
										});
									} catch (err2) {
										if (options.onErrored) {
											options.onErrored({
												type: "accept-error-handler-errored",
												moduleId: outdatedModuleId,
												dependencyId: dependenciesForCallbacks[k],
												error: err2,
												originalError: err
											});
										}
										if (!options.ignoreErrored) {
											reportError(err2);
											reportError(err);
										}
									}
								} else {
									if (options.onErrored) {
										options.onErrored({
											type: "accept-errored",
											moduleId: outdatedModuleId,
											dependencyId: dependenciesForCallbacks[k],
											error: err
										});
									}
									if (!options.ignoreErrored) {
										reportError(err);
									}
								}
							}
						}
					}
				}
			}

			// Load self accepted modules
			for (var o = 0; o < outdatedSelfAcceptedModules.length; o++) {
				var item = outdatedSelfAcceptedModules[o];
				var moduleId = item.module;
				try {
					item.require(moduleId);
				} catch (err) {
					if (typeof item.errorHandler === "function") {
						try {
							item.errorHandler(err, {
								moduleId: moduleId,
								module: __webpack_require__.c[moduleId]
							});
						} catch (err1) {
							if (options.onErrored) {
								options.onErrored({
									type: "self-accept-error-handler-errored",
									moduleId: moduleId,
									error: err1,
									originalError: err
								});
							}
							if (!options.ignoreErrored) {
								reportError(err1);
								reportError(err);
							}
						}
					} else {
						if (options.onErrored) {
							options.onErrored({
								type: "self-accept-errored",
								moduleId: moduleId,
								error: err
							});
						}
						if (!options.ignoreErrored) {
							reportError(err);
						}
					}
				}
			}

			return outdatedModules;
		}
	};
}

__webpack_require__.hmrI.jsonp = function (moduleId, applyHandlers) {
	if (!currentUpdate) {
		currentUpdate = {};
		currentUpdateRuntime = [];
		currentUpdateRemovedChunks = [];
		applyHandlers.push(applyHandler);
	}
	if (!__webpack_require__.o(currentUpdate, moduleId)) {
		currentUpdate[moduleId] = __webpack_require__.m[moduleId];
	}
};

__webpack_require__.hmrC.jsonp = function (
	chunkIds,
	removedChunks,
	removedModules,
	promises,
	applyHandlers,
	updatedModulesList
) {
	applyHandlers.push(applyHandler);
	currentUpdateChunks = {};
	currentUpdateRemovedChunks = removedChunks;
	currentUpdate = removedModules.reduce(function (obj, key) {
		obj[key] = false;
		return obj;
	}, {});
	currentUpdateRuntime = [];
	chunkIds.forEach(function (chunkId) {
		if (
			__webpack_require__.o(installedChunks, chunkId) &&
			installedChunks[chunkId] !== undefined
		) {
			promises.push(loadUpdateChunk(chunkId, updatedModulesList));
			currentUpdateChunks[chunkId] = true;
		} else {
			currentUpdateChunks[chunkId] = false;
		}
	});
	if (__webpack_require__.f) {
		__webpack_require__.f.jsonpHmr = function (chunkId, promises) {
			if (
				currentUpdateChunks &&
				__webpack_require__.o(currentUpdateChunks, chunkId) &&
				!currentUpdateChunks[chunkId]
			) {
				promises.push(loadUpdateChunk(chunkId));
				currentUpdateChunks[chunkId] = true;
			}
		};
	}
};
__webpack_require__.hmrM = () => {
	if (typeof fetch === "undefined")
		throw new Error("No browser support: need fetch API");
	return fetch(__webpack_require__.p + __webpack_require__.hmrF()).then(
		(response) => {
			if (response.status === 404) return; // no update available
			if (!response.ok)
				throw new Error(
					"Failed to fetch update manifest " + response.statusText
				);
			return response.json();
		}
	);
};

})();
// webpack/runtime/rspack_unique_id
(() => {
__webpack_require__.ruid = "bundler=rspack@1.6.3";

})();
// module cache are used so entry inlining is disabled
// startup
// Load entry module and return exports
__webpack_require__(2516);
__webpack_require__(5925);
var __webpack_exports__ = __webpack_require__(1987);
})()
;
//# sourceMappingURL=content-0.js.map