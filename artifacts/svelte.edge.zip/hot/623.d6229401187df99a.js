"use strict";
self["webpackHotUpdate_extension_js_svelte"]("623", {
5868: 
/*!***************************************************!*\
  !*** ./src/sidebar/SidebarApp.svelte + 4 modules ***!
  \***************************************************/
(function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ SidebarApp)
});

;// CONCATENATED MODULE: ../../node_modules/svelte/src/version.js
// generated during release, do not modify

/**
 * The current version, as set in package.json.
 * @type {string}
 */
const VERSION = '5.38.7';
const PUBLIC_VERSION = '5';

;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/disclose-version.js


if (typeof window !== 'undefined') {
	// @ts-expect-error
	((window.__svelte ??= {}).v ??= new Set()).add(PUBLIC_VERSION);
}

// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/flags/index.js
var flags = __webpack_require__(5039);
;// CONCATENATED MODULE: ../../node_modules/svelte/src/internal/flags/legacy.js


(0,flags.enable_legacy_mode_flag)();

// EXTERNAL MODULE: ../../node_modules/svelte/src/internal/client/index.js + 52 modules
var client = __webpack_require__(1670);
;// CONCATENATED MODULE: ./src/images/logo.png
const logo_namespaceObject = __webpack_require__.p + "assets/logo.png";
;// CONCATENATED MODULE: ./src/sidebar/SidebarApp.svelte



SidebarApp[client.FILENAME] = 'templates/svelte/src/sidebar/SidebarApp.svelte';




var root = client.add_locations(client.from_html(`<div class="sidebar_app"><img class="sidebar_logo" alt="The Svelte logo"/> <h1 class="sidebar_title">Sidebar Panel</h1> <p class="sidebar_description"> <a href="https://extension.js.org" target="_blank" rel="noopener noreferrer">https://extension.js.org</a> .</p></div>`), SidebarApp[client.FILENAME], [[5, 0, [[6, 2], [7, 2], [8, 2, [[10, 4]]]]]]);

function SidebarApp($$anchor, $$props) {
	client.check_target(new.target);
	client.push($$props, false, SidebarApp);

	var $$exports = { ...client.legacy_api() };
	var div = root();
	var img = client.child(div);
	var p = client.sibling(img, 4);
	var text = client.child(p);

	text.nodeValue = 'Learn more about creating cross-browser extensions at  ';
	client.next(2);
	client.reset(p);
	client.reset(div);
	client.template_effect(() => client.set_attribute(img, 'src', logo_namespaceObject));
	client.append($$anchor, div);

	return client.pop($$exports);
}

}),

},function(__webpack_require__) {
// webpack/runtime/get_full_hash
(() => {
__webpack_require__.h = () => ("3b4f702fec8484cf")
})();

}
);
//# sourceMappingURL=623.d6229401187df99a.js.map