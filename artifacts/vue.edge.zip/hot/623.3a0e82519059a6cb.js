"use strict";
self["webpackHotUpdate_extension_js_vue"]("623", {
369: 
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./src/sidebar/SidebarApp.vue.ts?vue&type=template&id=b1c9ed1e&ts=true!=!builtin:swc-loader??clonedRuleSet-1.use!../../programs/develop/dist/ensure-hmr-for-scripts.js??clonedRuleSet-6.use[0]!../../programs/develop/dist/content-script-wrapper.js??clonedRuleSet-7.use[0]!../../programs/develop/dist/add-hmr-accept-code.js??clonedRuleSet-9.use[0]!../../programs/develop/dist/resolve-paths-loader.js??clonedRuleSet-10.use[0]!../../node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[11].use[0]!../../node_modules/vue-loader/dist/index.js??ruleSet[0]!../../programs/develop/dist/warn-no-default-export.js??ruleSet[1].rules[8].use[0]!./src/sidebar/SidebarApp.vue?vue&type=template&id=b1c9ed1e&ts=true ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
(function (module, __webpack_exports__, __webpack_require__) {
__webpack_require__.d(__webpack_exports__, {
  render: () => (render)
});
/* ESM import */var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ 127);
if (true) {
    try {
        // Accept updates for HTML-attached scripts and clear common containers
        module.hot.accept();
        module.hot.dispose(function() {
            try {
                var clear = function(el) {
                    if (!el) return;
                    while(el.firstChild)el.removeChild(el.firstChild);
                };
                // Clear default template container
                clear(document.getElementById('app'));
                // Also clear any extension-root wrappers if present
                var roots = document.querySelectorAll('[data-extension-root]');
                roots.forEach(function(node) {
                    clear(node);
                });
            } catch (err) {
                // 'err' is local in this catch, keep for error clarity
                console.error('Error clearing HTML containers', err);
            }
        });
    } catch (error) {
        console.error('Error accepting HMR', error);
    }
}

const _hoisted_1 = {
    class: "sidebar_app"
};
const _hoisted_2 = [
    "src"
];
function render(_ctx, _cache, $props, $setup, $data, $options) {
    return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_1, [
        (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("img", {
            class: "sidebar_logo",
            src: $setup.vueLogo,
            alt: "The Vue logo"
        }, null, 8 /* PROPS */ , _hoisted_2),
        _cache[0] || (_cache[0] = (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("h1", {
            class: "sidebar_title"
        }, "Sidebar Panel", -1 /* CACHED */ )),
        _cache[1] || (_cache[1] = (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("p", {
            class: "sidebar_description"
        }, [
            (0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)(" Learn more about creating cross-browser extensions at "),
            (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("a", {
                href: "https://extension.js.org",
                target: "_blank",
                rel: "noopener noreferrer"
            }, " https://extension.js.org "),
            (0,vue__WEBPACK_IMPORTED_MODULE_0__.createTextVNode)(" . ")
        ], -1 /* CACHED */ ))
    ]);
}


}),

},function(__webpack_require__) {
// webpack/runtime/get_full_hash
(() => {
__webpack_require__.h = () => ("fdfd8bb7867aab70")
})();

}
);
//# sourceMappingURL=623.3a0e82519059a6cb.js.map