"use strict";
(self["webpackChunk_extension_js_javascript"] = self["webpackChunk_extension_js_javascript"] || []).push([["630"], {
268: 
/*!********************************!*\
  !*** ./src/content/styles.css ***!
  \********************************/
(function (module) {
module.exports = "data:text/css;base64,LmNvbnRlbnRfc2NyaXB0IHsKICBwb3NpdGlvbjogYWJzb2x1dGU7CiAgcmlnaHQ6IDAuNzVyZW07CiAgYm90dG9tOiAwLjc1cmVtOwogIHotaW5kZXg6IDk5OTk7Cn0KCi5jb250ZW50X3BpbGwgewogIC13ZWJraXQtZm9udC1zbW9vdGhpbmc6IGFudGlhbGlhc2VkOwogIC1tb3otb3N4LWZvbnQtc21vb3RoaW5nOiBncmF5c2NhbGU7CiAgYXBwZWFyYW5jZTogbm9uZTsKICBib3JkZXI6IG5vbmU7CiAgb3V0bGluZTogbm9uZTsKICBjdXJzb3I6IHBvaW50ZXI7CiAgZGlzcGxheTogaW5saW5lLWZsZXg7CiAgYWxpZ24taXRlbXM6IGNlbnRlcjsKICBnYXA6IDAuNXJlbTsKICBiYWNrZ3JvdW5kOiB2YXIoLS1zaWRlYmFyLWJnLCAjMGEwYzEwKTsKICBjb2xvcjogdmFyKC0tc2lkZWJhci10ZXh0LCAjYzljOWM5KTsKICBwYWRkaW5nOiAwLjVyZW0gMXJlbSAwLjVyZW0gMC41cmVtOwogIGJvcmRlci1yYWRpdXM6IDk5OTlweDsKICBib3gtc2hhZG93OiAwIDJweCAxMHB4IHJnYmEoMCwgMCwgMCwgMC4yNSk7Cn0KCi5jb250ZW50X3BpbGw6aG92ZXIgewogIGJhY2tncm91bmQ6ICMxMTE1MWM7Cn0KCi5jb250ZW50X3BpbGxfbG9nbyB7CiAgaGVpZ2h0OiAxLjVyZW07CiAgYm9yZGVyLXJhZGl1czogOTk5OXB4OwogIGJhY2tncm91bmQ6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC4wOCk7CiAgb2JqZWN0LWZpdDogY29udGFpbjsKICBhc3BlY3QtcmF0aW86IDEvMTsKICBwYWRkaW5nOiAwLjEyNXJlbTsKfQoKLmNvbnRlbnRfcGlsbF90ZXh0IHsKICBmb250LXNpemU6IDAuODVyZW07CiAgZm9udC13ZWlnaHQ6IDYwMDsKICBsaW5lLWhlaWdodDogMTsKICBmb250LWZhbWlseTogLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCAnU2Vnb2UgVUknLCBSb2JvdG8sCiAgICAnSGVsdmV0aWNhIE5ldWUnLCBBcmlhbCwgJ05vdG8gU2FucycsIHNhbnMtc2VyaWY7Cn0K";

}),
765: 
/*!*****************************!*\
  !*** ./src/images/logo.png ***!
  \*****************************/
(function (module, __unused_webpack_exports, __webpack_require__) {
module.exports = __webpack_require__.p + "assets/logo.png";

}),
519: 
/*!***********************************!*\
  !*** ./src/content/ContentApp.js ***!
  \***********************************/
(function (__webpack_module__, __webpack_exports__, __webpack_require__) {
__webpack_require__.d(__webpack_exports__, {
  "default": () => (createContentApp)
});
/* ESM import */var _images_logo_png__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../images/logo.png */ 765);
if (true) {
    __webpack_module__.hot.accept();
}

function createContentApp() {
    const container = document.createElement('div');
    container.className = 'content_script';
    const pill = document.createElement('button');
    pill.type = 'button';
    pill.className = 'content_pill';
    pill.setAttribute('aria-label', 'Open sidebar');
    pill.addEventListener('click', ()=>{
        try {
            if (false) {} else {
                chrome.runtime.sendMessage({
                    type: 'openSidebar'
                });
            }
        } catch (error) {
            console.error(error);
        }
    });
    const img = document.createElement('img');
    img.className = 'content_pill_logo';
    img.src = _images_logo_png__WEBPACK_IMPORTED_MODULE_0__;
    img.alt = '';
    img.setAttribute('aria-hidden', 'true');
    const text = document.createElement('span');
    text.className = 'content_pill_text';
    text.textContent = 'Open sidebar';
    pill.appendChild(img);
    pill.appendChild(text);
    container.appendChild(pill);
    return container;
}


}),
209: 
/*!************************************************!*\
  !*** ./src/content/scripts.js?__extjs_inner=1 ***!
  \************************************************/
(function (__webpack_module__, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var _ContentApp_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ContentApp.js */ 519);
/* ESM import */var _styles_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./styles.css */ 268);
if (true) {
    __webpack_module__.hot.accept();
}
function __EXTENSIONJS_mountWithHMR(mount) {
    var cleanup;
    function apply() {
        cleanup = mount();
    }
    function unmount() {
        if (typeof cleanup === 'function') cleanup();
    }
    function remount() {
        unmount();
        apply();
    }
    if (typeof document !== 'undefined') {
        if (document.readyState === 'complete') {
            apply();
        } else {
            var onReady = function() {
                if (document.readyState === 'complete') {
                    document.removeEventListener('readystatechange', onReady);
                    apply();
                }
            };
            document.addEventListener('readystatechange', onReady);
        }
    } else {
        apply();
    }
    if (true) {
        if (typeof __webpack_module__.hot.accept === "function") __webpack_module__.hot.accept();
        if (typeof __webpack_module__.hot.dispose === "function") __webpack_module__.hot.dispose(unmount);
        if (typeof __webpack_module__.hot.addStatusHandler === "function") {
            __webpack_module__.hot.addStatusHandler(function(s) {
                if (s === 'abort' || s === 'fail') {
                    console.warn('[extension.js] HMR status:', s);
                }
            });
        }
    }
    var cssEvt = '__EXTENSIONJS_CSS_UPDATE__';
    var onCss = function() {
        remount();
    };
    window.addEventListener(cssEvt, onCss);
    return function() {
        window.removeEventListener(cssEvt, onCss);
        unmount();
    };
}


const __EXTENSIONJS_default__ = function initial() {
    const rootDiv = document.createElement('div');
    rootDiv.setAttribute('data-extension-root', 'hmr-ok');
    document.body.appendChild(rootDiv);
    // Injecting content_scripts inside a shadow dom
    // prevents conflicts with the host page's styles.
    // This way, styles from the extension won't leak into the host page.
    const shadowRoot = rootDiv.attachShadow({
        mode: 'open'
    });
    const styleElement = document.createElement('style');
    shadowRoot.appendChild(styleElement);
    fetchCSS().then((response)=>styleElement.textContent = response);
    // Render ContentApp inside shadow root
    const container = (0,_ContentApp_js__WEBPACK_IMPORTED_MODULE_0__["default"])();
    shadowRoot.appendChild(container);
    return ()=>{
        rootDiv.remove();
    };
};
async function fetchCSS() {
    const cssUrl = new URL(/* asset import */__webpack_require__(/*! ./styles.css */ 268), __webpack_require__.b);
    const response = await fetch(cssUrl);
    const text = await response.text();
    return response.ok ? text : Promise.reject(text);
}
; /* __EXTENSIONJS_MOUNT_WRAPPED__ */ 
try {
    __EXTENSIONJS_mountWithHMR(__EXTENSIONJS_default__);
} catch  {}
try {
    if (true) {
        __webpack_module__.hot.accept(/*! ./styles.css */ 268, function(__WEBPACK_OUTDATED_DEPENDENCIES__) {
/* ESM import */_styles_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./styles.css */ 268);
(()=>{
            try {
                window.dispatchEvent(new CustomEvent('__EXTENSIONJS_CSS_UPDATE__'));
            } catch  {}
        })(__WEBPACK_OUTDATED_DEPENDENCIES__); }.bind(this));
    }
} catch  {}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__EXTENSIONJS_default__);


}),

}]);
//# sourceMappingURL=630.js.map