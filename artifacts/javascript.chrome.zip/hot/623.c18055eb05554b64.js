"use strict";
self["webpackHotUpdate_extension_js_javascript"]("623", {
183: 
/*!***********************************!*\
  !*** ./src/sidebar/SidebarApp.js ***!
  \***********************************/
(function (__webpack_module__, __unused_webpack___webpack_exports__, __webpack_require__) {
/* ESM import */var _images_logo_png__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../images/logo.png */ 765);
/* ESM import */var _styles_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./styles.css */ 575);
if (true) {
    try {
        // Accept updates for HTML-attached scripts and clear common containers
        __webpack_module__.hot.accept();
        __webpack_module__.hot.dispose(function() {
            try {
                var clear = function(el) {
                    if (!el) return;
                    while(el.firstChild)el.removeChild(el.firstChild);
                };
                // Clear default template container
                clear(document.getElementById('app'));
                // Also clear any extension-root wrappers if present
                var roots = document.querySelectorAll('[data-extension-root]');
                roots.forEach(function(node) {
                    clear(node);
                });
            } catch (err) {
                // 'err' is local in this catch, keep for error clarity
                console.error('Error clearing HTML containers', err);
            }
        });
    } catch (error) {
        console.error('Error accepting HMR', error);
    }
}


function SidebarApp() {
    const root = document.getElementById('root');
    if (!root) return;
    root.innerHTML = `
    <div class="sidebar_app">
      <img
        class="sidebar_logo"
        src="${_images_logo_png__WEBPACK_IMPORTED_MODULE_0__}"
        alt="The JavaScript logo"
      />
      <h1 class="sidebar_title">Sidebar Panel</h1>
      <p class="sidebar_description">
        Learn more about creating cross-browser extensions at
        <a
          href="https://extension.js.org"
          target="_blank"
        >
          https://extension.js.org
        </a>
        .
      </p>
    </div>
  `;
}
SidebarApp();


}),

},function(__webpack_require__) {
// webpack/runtime/get_full_hash
(() => {
__webpack_require__.h = () => ("758b6b6b243d4ea0")
})();

}
);
//# sourceMappingURL=623.c18055eb05554b64.js.map