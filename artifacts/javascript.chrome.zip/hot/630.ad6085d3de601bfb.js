"use strict";
self["webpackHotUpdate_extension_js_javascript"]("630", {
209: 
/*!************************************************!*\
  !*** ./src/content/scripts.js?__extjs_inner=1 ***!
  \************************************************/
(function (__webpack_module__, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__WEBPACK_DEFAULT_EXPORT__)
});
/* ESM import */var _ContentApp_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ContentApp.js */ 519);
/* ESM import */var _styles_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./styles.css */ 268);
if (true) {
    try {
        // Accept updates for HTML-attached scripts and clear common containers
        __webpack_module__.hot.accept();
        __webpack_module__.hot.dispose(function() {
            try {
                var clear = function(el) {
                    if (!el) return;
                    while(el.firstChild)el.removeChild(el.firstChild);
                };
                // Clear default template container
                clear(document.getElementById('app'));
                // Also clear any extension-root wrappers if present
                var roots = document.querySelectorAll('[data-extension-root]');
                roots.forEach(function(node) {
                    clear(node);
                });
            } catch (err) {
                // 'err' is local in this catch, keep for error clarity
                console.error('Error clearing HTML containers', err);
            }
        });
    } catch (error) {
        console.error('Error accepting HMR', error);
    }
}
function __EXTENSIONJS_mountWithHMR(mount) {
    var cleanup;
    function apply() {
        cleanup = mount();
    }
    function unmount() {
        if (typeof cleanup === 'function') cleanup();
    }
    function remount() {
        unmount();
        apply();
    }
    if (typeof document !== 'undefined') {
        if (document.readyState === 'complete') {
            apply();
        } else {
            var onReady = function() {
                if (document.readyState === 'complete') {
                    document.removeEventListener('readystatechange', onReady);
                    apply();
                }
            };
            document.addEventListener('readystatechange', onReady);
        }
    } else {
        apply();
    }
    if (true) {
        if (typeof __webpack_module__.hot.accept === "function") __webpack_module__.hot.accept();
        if (typeof __webpack_module__.hot.dispose === "function") __webpack_module__.hot.dispose(unmount);
        if (typeof __webpack_module__.hot.addStatusHandler === "function") {
            __webpack_module__.hot.addStatusHandler(function(s) {
                if (s === 'abort' || s === 'fail') {
                    console.warn('[extension.js] HMR status:', s);
                }
            });
        }
    }
    var cssEvt = '__EXTENSIONJS_CSS_UPDATE__';
    var onCss = function() {
        remount();
    };
    window.addEventListener(cssEvt, onCss);
    return function() {
        window.removeEventListener(cssEvt, onCss);
        unmount();
    };
}


const __EXTENSIONJS_default__ = function initial() {
    const rootDiv = document.createElement('div');
    rootDiv.setAttribute('data-extension-root', 'hmr-ok');
    document.body.appendChild(rootDiv);
    // Injecting content_scripts inside a shadow dom
    // prevents conflicts with the host page's styles.
    // This way, styles from the extension won't leak into the host page.
    const shadowRoot = rootDiv.attachShadow({
        mode: 'open'
    });
    const styleElement = document.createElement('style');
    shadowRoot.appendChild(styleElement);
    fetchCSS().then((response)=>styleElement.textContent = response);
    // Render ContentApp inside shadow root
    const container = (0,_ContentApp_js__WEBPACK_IMPORTED_MODULE_0__["default"])();
    shadowRoot.appendChild(container);
    return ()=>{
        rootDiv.remove();
    };
};
async function fetchCSS() {
    const cssUrl = new URL(/* asset import */__webpack_require__(/*! ./styles.css */ 268), __webpack_require__.b);
    const response = await fetch(cssUrl);
    const text = await response.text();
    return response.ok ? text : Promise.reject(text);
}
; /* __EXTENSIONJS_MOUNT_WRAPPED__ */ 
try {
    __EXTENSIONJS_mountWithHMR(__EXTENSIONJS_default__);
} catch  {}
try {
    if (true) {
        __webpack_module__.hot.accept(/*! ./styles.css */ 268, function(__WEBPACK_OUTDATED_DEPENDENCIES__) {
/* ESM import */_styles_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./styles.css */ 268);
(()=>{
            try {
                window.dispatchEvent(new CustomEvent('__EXTENSIONJS_CSS_UPDATE__'));
            } catch  {}
        })(__WEBPACK_OUTDATED_DEPENDENCIES__); }.bind(this));
    }
} catch  {}
/* ESM default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__EXTENSIONJS_default__);


}),

});
//# sourceMappingURL=630.ad6085d3de601bfb.js.map