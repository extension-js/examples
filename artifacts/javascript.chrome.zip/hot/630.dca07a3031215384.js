"use strict";
self["webpackHotUpdate_extension_js_javascript"]("630", {
519: 
/*!***********************************!*\
  !*** ./src/content/ContentApp.js ***!
  \***********************************/
(function (__webpack_module__, __webpack_exports__, __webpack_require__) {
__webpack_require__.d(__webpack_exports__, {
  "default": () => (createContentApp)
});
/* ESM import */var _images_logo_png__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../images/logo.png */ 765);
if (true) {
    __webpack_module__.hot.accept();
}

function createContentApp() {
    const container = document.createElement('div');
    container.className = 'content_script';
    const pill = document.createElement('button');
    pill.type = 'button';
    pill.className = 'content_pill';
    pill.setAttribute('aria-label', 'Open sidebar');
    pill.addEventListener('click', ()=>{
        try {
            if (false) {} else {
                chrome.runtime.sendMessage({
                    type: 'openSidebar'
                });
            }
        } catch (error) {
            console.error(error);
        }
    });
    const img = document.createElement('img');
    img.className = 'content_pill_logo';
    img.src = _images_logo_png__WEBPACK_IMPORTED_MODULE_0__;
    img.alt = '';
    img.setAttribute('aria-hidden', 'true');
    const text = document.createElement('span');
    text.className = 'content_pill_text';
    text.textContent = 'Open sidebar (HMR OK)';
    pill.appendChild(img);
    pill.appendChild(text);
    container.appendChild(pill);
    return container;
}


}),

});
//# sourceMappingURL=630.dca07a3031215384.js.map