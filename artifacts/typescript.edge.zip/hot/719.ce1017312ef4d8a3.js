"use strict";
self["webpackHotUpdate_extension_js_typescript"]("719", {
504: 
/*!***********************************!*\
  !*** ./src/content/ContentApp.ts ***!
  \***********************************/
(function (module, __webpack_exports__, __webpack_require__) {
__webpack_require__.d(__webpack_exports__, {
  "default": () => (createContentApp)
});
/* ESM import */var _images_logo_svg__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../images/logo.svg */ 525);
if (true) {
    module.hot.accept();
}

function createContentApp() {
    const container = document.createElement('div');
    container.className = 'content_script';
    const pill = document.createElement('button');
    pill.type = 'button';
    pill.className = 'content_pill';
    pill.setAttribute('aria-label', 'Open sidebar');
    pill.addEventListener('click', ()=>{
        if (false) {} else {
            chrome.runtime.sendMessage({
                type: 'openSidebar'
            });
        }
    });
    const img = document.createElement('img');
    img.className = 'content_pill_logo';
    img.src = _images_logo_svg__WEBPACK_IMPORTED_MODULE_0__;
    img.alt = '';
    img.setAttribute('aria-hidden', 'true');
    const text = document.createElement('span');
    text.className = 'content_pill_text';
    text.textContent = 'Open sidebar???';
    pill.appendChild(img);
    pill.appendChild(text);
    container.appendChild(pill);
    return container;
}


}),

});
//# sourceMappingURL=719.ce1017312ef4d8a3.js.map