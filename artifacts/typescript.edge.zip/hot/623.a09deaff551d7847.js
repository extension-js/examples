"use strict";
self["webpackHotUpdate_extension_js_typescript"]("623", {
640: 
/*!***********************************!*\
  !*** ./src/sidebar/SidebarApp.ts ***!
  \***********************************/
(function (module, __unused_webpack___webpack_exports__, __webpack_require__) {
/* ESM import */var _images_logo_svg__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../images/logo.svg */ 525);
if (true) {
    try {
        // Accept updates for HTML-attached scripts and clear common containers
        module.hot.accept();
        module.hot.dispose(()=>{
            try {
                const clear = (el)=>{
                    if (!el) return;
                    while(el.firstChild)el.removeChild(el.firstChild);
                };
                // Clear default template container
                clear(document.getElementById('app'));
                // Also clear any extension-root wrappers if present
                const roots = document.querySelectorAll('[data-extension-root]');
                roots.forEach((node)=>clear(node));
            } catch  {}
        });
    } catch (_) {}
}

function SidebarApp() {
    const root = document.getElementById('root');
    if (!root) return;
    root.innerHTML = `
    <div class="sidebar_app">
      <img
        class="sidebar_logo"
        src="${_images_logo_svg__WEBPACK_IMPORTED_MODULE_0__}"
        alt="The TypeScript logo"
      />
      <h1 class="sidebar_title">Sidebar Panel</h1>
      <p class="sidebar_description">
        Learn more about creating cross-browser extensions at??
        <a
          href="https://extension.js.org"
          target="_blank"
        >
          https://extension.js.org
        </a>
        .
      </p>
    </div>
  `;
}
SidebarApp();


}),

},function(__webpack_require__) {
// webpack/runtime/get_full_hash
(() => {
__webpack_require__.h = () => ("2c97ecb3e2a1b770")
})();

}
);
//# sourceMappingURL=623.a09deaff551d7847.js.map