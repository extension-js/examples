"use strict";
(self["webpackChunk_extension_js_typescript"] = self["webpackChunk_extension_js_typescript"] || []).push([["719"], {
268: 
/*!********************************!*\
  !*** ./src/content/styles.css ***!
  \********************************/
(function (module) {
module.exports = "data:text/css;base64,LmNvbnRlbnRfc2NyaXB0IHsKICBwb3NpdGlvbjogYWJzb2x1dGU7CiAgcmlnaHQ6IDAuNzVyZW07CiAgYm90dG9tOiAwLjc1cmVtOwogIHotaW5kZXg6IDk5OTk7Cn0KCi5jb250ZW50X3BpbGwgewogIC13ZWJraXQtZm9udC1zbW9vdGhpbmc6IGFudGlhbGlhc2VkOwogIC1tb3otb3N4LWZvbnQtc21vb3RoaW5nOiBncmF5c2NhbGU7CiAgYXBwZWFyYW5jZTogbm9uZTsKICBib3JkZXI6IG5vbmU7CiAgb3V0bGluZTogbm9uZTsKICBjdXJzb3I6IHBvaW50ZXI7CiAgZGlzcGxheTogaW5saW5lLWZsZXg7CiAgYWxpZ24taXRlbXM6IGNlbnRlcjsKICBnYXA6IDAuNXJlbTsKICBiYWNrZ3JvdW5kOiB2YXIoLS1zaWRlYmFyLWJnLCAjMGEwYzEwKTsKICBjb2xvcjogdmFyKC0tc2lkZWJhci10ZXh0LCAjYzljOWM5KTsKICBwYWRkaW5nOiAwLjVyZW0gMXJlbSAwLjVyZW0gMC41cmVtOwogIGJvcmRlci1yYWRpdXM6IDk5OTlweDsKICBib3gtc2hhZG93OiAwIDJweCAxMHB4IHJnYmEoMCwgMCwgMCwgMC4yNSk7Cn0KCi5jb250ZW50X3BpbGw6aG92ZXIgewogIGJhY2tncm91bmQ6ICMxMTE1MWM7Cn0KCi5jb250ZW50X3BpbGxfbG9nbyB7CiAgaGVpZ2h0OiAxLjVyZW07CiAgYm9yZGVyLXJhZGl1czogOTk5OXB4OwogIGJhY2tncm91bmQ6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC4wOCk7CiAgb2JqZWN0LWZpdDogY29udGFpbjsKICBhc3BlY3QtcmF0aW86IDEvMTsKICBwYWRkaW5nOiAwLjEyNXJlbTsKfQoKLmNvbnRlbnRfcGlsbF90ZXh0IHsKICBmb250LXNpemU6IDAuODVyZW07CiAgZm9udC13ZWlnaHQ6IDYwMDsKICBsaW5lLWhlaWdodDogMTsKICBmb250LWZhbWlseTogLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCAnU2Vnb2UgVUknLCBSb2JvdG8sCiAgICAnSGVsdmV0aWNhIE5ldWUnLCBBcmlhbCwgJ05vdG8gU2FucycsIHNhbnMtc2VyaWY7Cn0K";

}),
525: 
/*!*****************************!*\
  !*** ./src/images/logo.svg ***!
  \*****************************/
(function (module) {
module.exports = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMDAwIDEwMDAiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDEwMDAgMTAwMCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+PHBhdGggZD0iTTk3LjcgMGg4MDQuN2M1My45IDAgOTcuNyA0My43IDk3LjcgOTcuN3Y4MDQuN2MwIDUzLjktNDMuNyA5Ny43LTk3LjcgOTcuN0g5Ny43QzQzLjcgMTAwMCAwIDk1Ni4zIDAgOTAyLjNWOTcuN0MwIDQzLjcgNDMuNyAwIDk3LjcgMHoiIHN0eWxlPSJmaWxsOiMzMTc4YzYiLz48cGF0aCBkPSJNNjE5LjEgNzk0Ljl2OTcuN2MxNS44IDguMiAzNS4yIDE0LjMgNTYuNiAxOC40czQ0LjkgNi4xIDY4LjQgNi4xIDQ0LjktMi4xIDY2LjQtNi42YzIxLjUtNC41IDM5LjEtMTEuOSA1NC43LTIxLjUgMTUuOC0xMC40IDI5LjMtMjMuNCAzNy4xLTQxczEzLjktMzcuMSAxMy45LTYyLjVjMC0xNy44LTIuNy0zMy4yLTgtNDYuOXMtMTIuOS0yNS40LTIzLjQtMzUuMmMtMTAtMTAuNC0yMS41LTE5LjUtMzUuMi0yNy4zcy0yOS4zLTE2LTQ2LjktMjMuNGMtMTIuOS01LjMtMjMuNC0xMC40LTM1LjItMTUuNC0xMC4yLTUuMS0xOC45LTEwLjItMjUuNC0xNS4yLTcuMi01LjMtMTIuNy0xMC43LTE2LjYtMTYuNC0zLjktNS45LTUuOS0xMi4zLTUuOS0xOS41IDAtNi42IDEuNy0xMi43IDUuMy0xOC4yIDMuNS01LjUgOC40LTEwIDE0LjYtMTMuOSA2LjMtMy45IDE0LjEtNi44IDIzLjQtOSA5LjItMi4xIDE5LjMtMy4xIDMxLjMtMy4xIDguMiAwIDE2LjguNiAyNS40IDEuOCA5IDEuMiAxOC4yIDMuMSAyNy4zIDUuNyA5LjIgMi41IDE4LjIgNS43IDI3LjMgOS42IDguNiAzLjkgMTYuNiA4LjQgMjMuNCAxMy41di05MS44Yy0xNC44LTUuNy0zMS4zLTEwLTQ4LjgtMTIuNy0xNy42LTIuNy0zNy4xLTQuMS02MC41LTQuMXMtNDQuOSAyLjUtNjYuNCA3LjQtMzkuMSAxMi43LTU0LjcgMjMuNGMtMTUuOCAxMC41LTI3LjMgMjMuNC0zNy4xIDQxLTkuMiAxNi40LTEzLjcgMzUuMi0xMy43IDU4LjYgMCAyOS4zIDguNCA1NC43IDI1LjQgNzQuMiAxNi44IDIxLjUgNDMgMzcuMSA3Ni4yIDUyLjcgMTMuNSA1LjUgMjUuNCAxMC45IDM3LjEgMTYuMiAxMS43IDUuMyAyMS41IDEwLjcgMjkuMyAxNi40IDguNCA1LjcgMTUgMTEuOSAxOS41IDE4LjYgNC45IDYuNiA3LjQgMTQuNSA3LjQgMjMuNCAwIDYuMy0xLjUgMTIuMS00LjUgMTcuNi0zIDUuNS03LjYgMTAuMi0xMy45IDE0LjEtNi4zIDMuOS0xMy45IDctMjMuNCA5LjQtOS4yIDIuMS0xOS41IDMuMy0zMy4yIDMuMy0yMS41IDAtNDMtMy43LTYyLjUtMTEuMS0yMS41LTcuNC00MS0xOC42LTU4LjYtMzMuMmwzLjktMS4xem0tMTY0LTI0MC4yaDEyNXYtODAuMUgyMzAuNXY4MC4xaDEyNXYzNTcuNGg5OS42VjU1NC43eiIgc3R5bGU9ImZpbGwtcnVsZTpldmVub2RkO2NsaXAtcnVsZTpldmVub2RkO2ZpbGw6I2ZmZiIvPjwvc3ZnPg==";

}),
504: 
/*!***********************************!*\
  !*** ./src/content/ContentApp.ts ***!
  \***********************************/
(function (module, __webpack_exports__, __webpack_require__) {
__webpack_require__.d(__webpack_exports__, {
  "default": () => (createContentApp)
});
/* ESM import */var _images_logo_svg__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../images/logo.svg */ 525);
if (true) {
    module.hot.accept();
}

function createContentApp() {
    const container = document.createElement('div');
    container.className = 'content_script';
    const pill = document.createElement('button');
    pill.type = 'button';
    pill.className = 'content_pill';
    pill.setAttribute('aria-label', 'Open sidebar');
    pill.addEventListener('click', ()=>{
        if (false) {} else {
            chrome.runtime.sendMessage({
                type: 'openSidebar'
            });
        }
    });
    const img = document.createElement('img');
    img.className = 'content_pill_logo';
    img.src = _images_logo_svg__WEBPACK_IMPORTED_MODULE_0__;
    img.alt = '';
    img.setAttribute('aria-hidden', 'true');
    const text = document.createElement('span');
    text.className = 'content_pill_text';
    text.textContent = 'Open sidebar';
    pill.appendChild(img);
    pill.appendChild(text);
    container.appendChild(pill);
    return container;
}


}),
780: 
/*!************************************************!*\
  !*** ./src/content/scripts.ts?__extjs_inner=1 ***!
  \************************************************/
(function (module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* ESM import */var _ContentApp__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ContentApp */ 504);
/* ESM import */var _styles_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./styles.css */ 268);
if (true) {
    module.hot.accept();
}


console.log('hello from content_scripts');
function initial() {
    const rootDiv = document.createElement('div');
    rootDiv.setAttribute('data-extension-root', 'true');
    document.body.appendChild(rootDiv);
    // Injecting content_scripts inside a shadow dom
    // prevents conflicts with the host page's styles.
    // This way, styles from the extension won't leak into the host page.
    const shadowRoot = rootDiv.attachShadow({
        mode: 'open'
    });
    const styleElement = document.createElement('style');
    shadowRoot.appendChild(styleElement);
    fetchCSS().then((response)=>styleElement.textContent = response);
    // Render ContentApp inside shadow root
    const container = (0,_ContentApp__WEBPACK_IMPORTED_MODULE_0__["default"])();
    shadowRoot.appendChild(container);
    return ()=>{
        rootDiv.remove();
    };
}
initial();
async function fetchCSS() {
    const cssUrl = new URL(/* asset import */__webpack_require__(/*! ./styles.css */ 268), __webpack_require__.b);
    const response = await fetch(cssUrl);
    const text = await response.text();
    return response.ok ? text : Promise.reject(text);
}


}),

}]);
//# sourceMappingURL=719.js.map