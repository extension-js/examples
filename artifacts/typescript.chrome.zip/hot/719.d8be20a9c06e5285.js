"use strict";
self["webpackHotUpdate_extension_js_typescript"]("719", {
780: 
/*!************************************************!*\
  !*** ./src/content/scripts.ts?__extjs_inner=1 ***!
  \************************************************/
(function (module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* ESM import */var _ContentApp__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ContentApp */ 504);
/* ESM import */var _styles_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./styles.css */ 268);
if (true) {
    module.hot.accept();
}


console.log('hello from content_scripts');
function initial() {
    const rootDiv = document.createElement('div');
    rootDiv.setAttribute('data-extension-root', 'true');
    document.body.appendChild(rootDiv);
    // Injecting content_scripts inside a shadow dom
    // prevents conflicts with the host page's styles.
    // This way, styles from the extension won't leak into the host page.
    const shadowRoot = rootDiv.attachShadow({
        mode: 'open'
    });
    const styleElement = document.createElement('style');
    shadowRoot.appendChild(styleElement);
    fetchCSS().then((response)=>styleElement.textContent = response);
    // Render ContentApp inside shadow root
    const container = (0,_ContentApp__WEBPACK_IMPORTED_MODULE_0__["default"])();
    shadowRoot.appendChild(container);
    return ()=>{
        rootDiv.remove();
    };
}
initial();
async function fetchCSS() {
    const cssUrl = new URL(/* asset import */__webpack_require__(/*! ./styles.css */ 268), __webpack_require__.b);
    const response = await fetch(cssUrl);
    const text = await response.text();
    return response.ok ? text : Promise.reject(text);
}


}),

});
//# sourceMappingURL=719.d8be20a9c06e5285.js.map